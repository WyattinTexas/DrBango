// =================================================================
// BATTLE ENGINE — Extracted from testroom for multiplayer use
// Depends on: cards.js (GHOSTS, getGhost, getActiveGhosts, SHELVED_IDS)
// =================================================================

// Alias: testroom uses ghostData, cards.js uses getGhost
function ghostData(id) { return getGhost(id); }

// Safety: testroom code does getElementById().style/.classList without null checks.
// In multiplayer, some elements may not exist. We use a safe getter helper instead
// of overriding the global getElementById (which breaks other libraries).
function safeEl(id) {
  const el = document.getElementById(id);
  if (el) return el;
  // Audio elements must return null so playSfx() can handle gracefully
  if (id && (id.startsWith('sfx') || id.startsWith('bg') || id === 'triplesSfx')) return null;
  // Return a dummy div for DOM access safety (style, classList, etc.)
  if (!safeEl._dummy) {
    safeEl._dummy = document.createElement('div');
    safeEl._dummy.id = '_battle_dummy';
    safeEl._dummy.style.display = 'none';
  }
  return safeEl._dummy;
}

// ── Hook system ──────────────────────────────────────────────────
// Registered hooks fire before default behavior. resetRollButtons hooks
// can return true to consume (skip default). Replaces monkey-patching.
const _gameOverHooks = [];
const _resetRollHooks = [];
const _postResolveHooks = [];
function onGameOver(fn) { _gameOverHooks.push(fn); }
function onResetRollButtons(fn) { _resetRollHooks.push(fn); }
function onPostResolve(fn) { _postResolveHooks.push(fn); }

// Missing globals from testroom
var DEBUG = false;

// Stubs for testroom-specific functions not needed in multiplayer
function recordWin(id) {}
function recordLoss(id) {}
function recordKO(id) {}
function recordKill(id) {}
function recordMvp(id) {}
function renderPicks() {}
function renderGallery() {}
let autoPlayRunning = false;
let autoPlayQueue = 0;
let autoPlayTotal = 0;

// Battle state (from testroom)
let S = { tab:'battle', redPicks:[], bluePicks:[], battle:null };

// =================================================================
// BOSS MODE — Raid system hooks
// When window.BOSS_MODE is true, the blue team is a raid boss.
// - Blue roll button is hidden; boss auto-rolls via bossAutoRoll()
// - All damage dealt to blue team also drains the shared boss HP pool
// - Instant-kill abilities deal flat damage instead vs bosses
// - After each roll resolution, a spectator snapshot is written
// =================================================================

/**
 * Track damage dealt to the boss team for HP pool drain.
 * Called after any HP reduction on a blue-team ghost in boss mode.
 * @param {number} damage — amount of HP lost
 * @param {object} ghost — the ghost that took damage
 */
function bossDamageTracker(damage, ghost) {
  if (!window.BOSS_MODE || !window.BOSS_RAID_DATA) return;
  if (damage <= 0) return;

  // Glacier Ice Wall check: boss cannot take damage while Ice Wall lives
  const raidState = window.BOSS_RAID_DATA;
  if (raidState.bossConfig?.personality === 'glacier' && !ghost?.isMinion) {
    if (typeof isIceWallActive === 'function' && isIceWallActive(raidState.bossTeam)) {
      return; // Damage blocked by Ice Wall
    }
  }

  // Drain the shared HP pool
  raidState.totalDamageDealt += damage;
  if (typeof drainBossHpPool === 'function') {
    drainBossHpPool(damage);
  }
  // Keep local pool HP in sync (RaidState is the single source of truth)
  if (typeof RaidState !== 'undefined') {
    RaidState.bossCurrentHp = Math.max(0, (RaidState.bossCurrentHp || 0) - damage);
  }
}

/**
 * Check if an instant-kill ability should be converted to flat damage vs a boss.
 * Returns the flat damage amount if in boss mode, or 0 if not (let normal logic proceed).
 */
function bossInstantKillCheck(targetGhost) {
  if (!window.BOSS_MODE) return 0;
  if (targetGhost?.isBoss) return 5; // RAID_CONFIG.INSTANT_KILL_FLAT_DAMAGE
  return 0; // Minions can be instant-killed normally
}

/**
 * Write spectator snapshot after each roll resolution in boss mode.
 */
function bossWriteSnapshot(redDice, blueDice, winner, damage) {
  if (!window.BOSS_MODE || !window.BOSS_RAID_DATA || !B) return;
  if (typeof writeBattleSnapshot !== 'function') return;

  const raidState = window.BOSS_RAID_DATA;
  const user = firebase.auth().currentUser;

  writeBattleSnapshot({
    playerName: user?.displayName || 'Raider',
    playerGhost: active(B.red),
    bossGhost: active(B.blue),
    playerSideline: B.red.ghosts.filter((g, i) => i !== B.red.activeIdx),
    bossSideline: B.blue.ghosts.filter((g, i) => i !== B.blue.activeIdx),
    lastRoll: {
      player: redDice,
      boss: blueDice,
      winner: winner,
      damage: damage
    },
    round: B.round,
    isWave: window.IS_WAVE_FIGHT || false
  });
}


// =================================================================
// MP / PVP MODE FLAGS
// =================================================================
let MP_MODE = false; // set true when loaded via multiplayer page URL params
let RAID_MODE = false; // set true when loaded via raid mode
let RAID_PARAMS = null; // { raidId, instanceId, slot, bossHp, bossMaxHp, bossName, personality }
let LIVE_PVP = false; // true when in real-time PvP mode
let PVP_SIDE = null;  // 'red' or 'blue' — which side this client controls
let PVP_GAME_ID = null;
let PVP_GAME_REF = null;
let PVP_OPPONENT_READY = false; // tracks if opponent has clicked roll
let MP_DAILY = false; // true when loaded via daily rival mode
let MP_PLAYER_NAMES = { red: 'Red', blue: 'Blue' }; // display names for game over screen
let pvpAbilityEvents = []; // v721: capture ability callouts for Blue sync
let pvpRedClickedRoll = false; // v733: async MP — AI waits for Red to click READY before rolling
let pvpBlueResolvedLocally = false; // v725: flag to prevent double-resolution on Blue
let pvpRedReady = false; // v726: Red has committed resources and is waiting for Blue

// ============================================================
// BATTLE SPEED — multiplier for all animation/delay timings
// 0=1x (normal), 1=10x, 2=25x, 3=100x
// ============================================================
const SPEED_DIVISORS = [1, 10, 25, 100];
const SPEED_LABELS = ['1x', '10x', '25x', '100x'];
function getSpeedDivisor() { return SPEED_DIVISORS[parseInt(document.getElementById('speedSlider')?.value) || 0]; }
function spd(ms) { return Math.max(1, Math.round(ms / getSpeedDivisor())); }
function updateSpeedLabel() { document.getElementById('speedLabel').textContent = 'Speed: ' + SPEED_LABELS[parseInt(document.getElementById('speedSlider')?.value) || 0]; }
function getSpecialsTimerSecs() { return parseInt(document.getElementById('specialsTimerSlider')?.value) || 5; }

// Lite Mode — reduce animations for better performance on slower devices
function toggleLiteMode(on) {
  document.body.classList.toggle('lite-mode', on);
  localStorage.setItem('tr_liteMode', on ? '1' : '0');
}

// Charlie (18) — Flick face detection: determine die value from current 3D rotation
function getFlickFaceValue(rx, ry) {
  let best = 1, bestD = Infinity;
  for (const [v, t] of Object.entries(FACE_TARGET)) {
    const drx = ((rx % 360) + 360) % 360, try_ = ((t.rx % 360) + 360) % 360;
    const dry = ((ry % 360) + 360) % 360, tyy = ((t.ry % 360) + 360) % 360;
    const dx = Math.min(Math.abs(drx - try_), 360 - Math.abs(drx - try_));
    const dy = Math.min(Math.abs(dry - tyy), 360 - Math.abs(dry - tyy));
    const d = dx + dy;
    if (d < bestD) { bestD = d; best = parseInt(v); }
  }
  return best;
}

function initMatchStats() {
  B.matchStats = {
    red: {}, blue: {},
    finishingBlowGhostId: null,
    finishingBlowTeam: null,
    snapshot: null,
    // Per-round side-band: resource amounts that have been explicitly credited
    // to a specific ghost (via creditGhost). Subtracted from the delta in
    // creditRoundDelta so we don't double-count them to the active fighter.
    explicit: { red: { ls:0, ms:0, ice:0, fire:0, seed:0 }, blue: { ls:0, ms:0, ice:0, fire:0, seed:0 } }
  };
}

function ensureMatchStat(team, ghostId) {
  if (!B.matchStats[team][ghostId]) {
    B.matchStats[team][ghostId] = {
      rollsWon: 0,
      kosScored: 0,
      damageDealt: 0,
      ls: 0, ms: 0, ice: 0, fire: 0, seed: 0
    };
  }
  return B.matchStats[team][ghostId];
}

// Explicit per-ghost credit. Call this inside any sideline onShow callback
// that grants a resource, so the sideline ghost (not the active fighter)
// gets the MVP points. The amount is added to B.matchStats.explicit so
// creditRoundDelta's snapshot-diff doesn't also credit the active fighter
// for the same grant.
function creditGhost(team, ghostId, resource, amount) {
  if (!B || !B.matchStats || !ghostId || amount <= 0) return;
  if (team !== 'red' && team !== 'blue') return;
  if (!['ls','ms','ice','fire','seed'].includes(resource)) return;
  const stat = ensureMatchStat(team, ghostId);
  stat[resource] = (stat[resource] || 0) + amount;
  B.matchStats.explicit[team][resource] = (B.matchStats.explicit[team][resource] || 0) + amount;
}

function snapshotRound() {
  if (!B || !B.matchStats) return;
  // Reset the explicit side-band — credits accumulate per-round only
  B.matchStats.explicit = { red: { ls:0, ms:0, ice:0, fire:0, seed:0 }, blue: { ls:0, ms:0, ice:0, fire:0, seed:0 } };
  B.matchStats.snapshot = {
    red: {
      res: { ...B.red.resources },
      ghosts: B.red.ghosts.map(g => ({ id: g.id, hp: g.hp, ko: g.ko }))
    },
    blue: {
      res: { ...B.blue.resources },
      ghosts: B.blue.ghosts.map(g => ({ id: g.id, hp: g.hp, ko: g.ko }))
    }
  };
}

function creditRoundDelta(roundWinner) {
  if (!B || !B.matchStats || !B.matchStats.snapshot) return;
  const snap = B.matchStats.snapshot;
  ['red', 'blue'].forEach(team => {
    const t = B[team];
    const activeF = active(t);
    if (!activeF) return;
    const stat = ensureMatchStat(team, activeF.id);
    // Resource deltas — credit the currently-active ghost for the non-explicit leftover.
    // Sideline generators (Gary, Farmer Jeff, Granny, etc.) call creditGhost() directly
    // inside their onShow callbacks, populating B.matchStats.explicit[team]. We subtract
    // those amounts here so the active fighter only gets credit for resources they earned.
    const rNow = t.resources;
    const rBefore = snap[team].res;
    const explicit = B.matchStats.explicit[team] || { ls:0, ms:0, ice:0, fire:0, seed:0 };
    const clampPos = (a, b, sub) => Math.max(0, (a || 0) - (b || 0) - (sub || 0));
    stat.ls   += clampPos(rNow.luckyStone, rBefore.luckyStone, explicit.ls);
    stat.ms   += clampPos(rNow.moonstone, rBefore.moonstone, explicit.ms);
    stat.ice  += clampPos(rNow.ice, rBefore.ice, explicit.ice);
    stat.fire += clampPos(rNow.fire, rBefore.fire, explicit.fire);
    stat.seed += clampPos(rNow.healingSeed, rBefore.healingSeed, explicit.seed);
    // Damage dealt / KOs scored: enemy ghosts took damage credited to this active
    const enemyTeam = team === 'red' ? 'blue' : 'red';
    const enemyBefore = snap[enemyTeam].ghosts;
    const enemyNow = B[enemyTeam].ghosts;
    enemyNow.forEach((g, i) => {
      const before = enemyBefore[i];
      if (!before) return;
      const dmg = Math.max(0, (before.hp || 0) - (g.hp || 0));
      if (dmg > 0) stat.damageDealt += dmg;
      if (!before.ko && g.ko) {
        stat.kosScored++;
        // Track the LAST KO seen so the final-round KO gets the finishing-blow bonus
        B.matchStats.finishingBlowGhostId = activeF.id;
        B.matchStats.finishingBlowTeam = team;
      }
    });
  });
  // Roll won: credit the winning team's active
  if (roundWinner === 'red' || roundWinner === 'blue') {
    const wActive = active(B[roundWinner]);
    if (wActive) {
      const wStat = ensureMatchStat(roundWinner, wActive.id);
      wStat.rollsWon++;
    }
  }
}

function computeMvpScore(stat, isSurvivor, isFinishingBlow) {
  const ko = (stat.kosScored || 0) * 5;
  const rw = (stat.rollsWon || 0) * 1;
  const dmg = (stat.damageDealt || 0) * 0.5;
  const res = (stat.ls || 0) * 1 + (stat.ms || 0) * 3 + (stat.fire || 0) * 3 + (stat.ice || 0) * 1 + (stat.seed || 0) * 1;
  const surv = isSurvivor ? 3 : 0;
  const fb = isFinishingBlow ? 5 : 0;
  return ko + rw + dmg + res + surv + fb;
}

function pickMatchMvp(winnerTeamName) {
  if (!B || !B.matchStats || (winnerTeamName !== 'red' && winnerTeamName !== 'blue')) return null;
  const team = B[winnerTeamName];
  const stats = B.matchStats[winnerTeamName] || {};
  const fbId = B.matchStats.finishingBlowGhostId;
  const fbTeam = B.matchStats.finishingBlowTeam;
  let best = null;
  team.ghosts.forEach(g => {
    const s = stats[g.id] || { rollsWon:0, kosScored:0, damageDealt:0, ls:0, ms:0, ice:0, fire:0, seed:0 };
    const survived = !g.ko;
    const finishing = (g.id === fbId && fbTeam === winnerTeamName);
    const score = computeMvpScore(s, survived, finishing);
    const candidate = { id: g.id, name: g.name, score, kos: s.kosScored || 0, dmg: s.damageDealt || 0 };
    if (!best) { best = candidate; return; }
    if (candidate.score > best.score) { best = candidate; return; }
    if (candidate.score === best.score) {
      if (candidate.kos > best.kos) { best = candidate; return; }
      if (candidate.kos === best.kos) {
        if (candidate.dmg > best.dmg) { best = candidate; return; }
        if (candidate.dmg === best.dmg && candidate.name.localeCompare(best.name) < 0) { best = candidate; return; }
      }
    }
  });
  return best;
}

const RARITY_ORDER = {common:0, uncommon:1, rare:2, 'ghost-rare':3, legendary:4};
const SET_ORDER = ['Set 1','Dark Castle','Frost Valley','Volcanic Isles','Rolling Hills'];
function getSetClass(s) {
  if (s === 'Rolling Hills') return 'set-rolling';
  if (s === 'Volcanic Isles') return 'set-volcanic';
  if (s === 'Set 1') return 'set-set1';
  if (s === 'Dark Castle') return 'set-darkcastle';
  if (s === 'Frost Valley') return 'set-frostvalley';
  return '';
}
function getSetColor(s) {
  if (s === 'Rolling Hills') return 'var(--uncommon)';
  if (s === 'Volcanic Isles') return 'var(--magma)';
  if (s === 'Set 1') return '#c084fc';
  if (s === 'Dark Castle') return '#f87171';
  if (s === 'Frost Valley') return '#67e8f9';
  return 'var(--text2)';
}
function sortBySetThenRarity(a, b) {
  const sa = SET_ORDER.indexOf(a.set);
  const sb = SET_ORDER.indexOf(b.set);
  if (sa !== sb) return sa - sb;
  return (RARITY_ORDER[a.rarity]||0) - (RARITY_ORDER[b.rarity]||0);
}
function sortByRarity(a, b) { return (RARITY_ORDER[a.rarity]||0) - (RARITY_ORDER[b.rarity]||0); }

// --- Curated Team Compositions (Wyatt Directive 2026-04-11) ---
// Each team is [starter, sideline1, sideline2]. Order matters:
//   starter  = the fighter who battles first
//   sideline1 = primary support / second fighter
//   sideline2 = backup / synergy piece
const CURATED_TEAMS = [
  // ===================== HIGH TIER (15 teams) =====================

  // #1  Valkin's Grand Conquest — Valkin KOs for full resource suite, Bigsby evolves into Doom on Moonstone, Willow +1 die after losses
  [432, 424, 435],
  // #2  Blue Fire Burn Chain — Lucy wins for Sacred Fires, Rascals entry 3 Burn, Mable spends Burn to remove dice + gain Sacred Fire
  [108, 437, 446],
  // #3  Ice Blade Forge — Zain forges Ice Blade from wins, Sylvia free Ice Shards, Finn forges Flame Blade from seeds+fire
  [206, 313, 431],
  // #4  Resurrection Engine — Miyoshi Bonzai sacrifices HP for +5 dice, Bo revives on KO + 3 Fireflies, Lucas buffs revived ghost +3HP/+1die
  [454, 109, 433],
  // #5  Dice Destroyer — Pip triples remove opponent dice permanently, Haywire triples gain permanent die, Willow +1 die after losses
  [418, 78, 435],
  // #6  Resource Avalanche — Chester wins for seeds/fireflies, Twyla spends Lucky Stones for +dice/+seeds, Zippa converts seeds to stones
  [426, 417, 423],
  // #7  Mountain King Doubles — TMK 2X doubles damage, Tabitha +2 doubles damage from sideline, Admiral +2 even doubles from sideline
  [110, 95, 71],
  // #8  Shade Pressure — Shade deals 1 before every roll, Shade's Shadow deals 1 to <4HP from sideline, Princess Shade +1 to pre-roll damage
  [111, 205, 436],
  // #9  Nerina Blitz — Nerina entry 3 damage, Nicholas 2 damage on enemy entry from sideline, Grawr entry 1 damage
  [306, 51, 34],
  // #10 Timber Lockdown — Timber forces discard or -1 die, Dylan blocks enemy before-roll effects + gains Burn, Piper negates effects/-1 die
  [210, 301, 107],
  // #11 Humar Burn Assault — Humar wins for 2 pre-roll damage + Burn, Mable spends Burn to remove dice, Princess Shade +1 pre-roll damage
  [336, 446, 436],
  // #12 Red Hunter Aggro — Red Hunter +3 damage if enemy holds specials, Gordok steals 2 specials on win, Dark Jeff +1 all damage from sideline
  [345, 430, 74],
  // #13 Sacred Fire Engine — Lucy wins for Sacred Fire, Fed & Hayden Sacred Fires don't discard, Lucy's Shadow doubles Lucy's fire damage
  [108, 406, 439],
  // #14 Toby All-In — Toby declares final roll for KO, Guardian Fairy takes hits from sideline, Hector singles beat doubles
  [97, 99, 96],
  // #15 Frost Blade Master — Skylar Ice Shards deal +2, Pal Al wins for 4 Ice Shards, Spockles wins for 2 Ice Shards
  [104, 431, 81],

  // ===================== MID TIER (25 teams) =====================

  // #16 Dark Castle Control — Captain James triples for 2 Sacred Fires, Garrick -1 damage on loss + Sacred Fire on KO, Champ immune to specials
  [443, 427, 438],
  // #17 Rolling Hills Harvest — Farmer Jeff 6s gain Healing Seeds, Aunt Susan spends seeds for +2 damage/heal, Boopies seeds → stones
  [314, 309, 419],
  // #18 Frost Valley Blizzard — Romy predicts die for +3, Marcus 3+ damage taken → 4 extra dice, Pale Nimbus +2 if roll <7 from sideline
  [114, 57, 88],
  // #19 Tank & Spank — Bubble Boys 9HP wall, Bilbo +2 singles damage from sideline, Dark Jeff +1 all damage from sideline
  [44, 80, 74],
  // #20 Volcanic Disruption — Knight Terror enemy loses 2HP on ability trigger, Knight Light gains +1 die on enemy ability, Smudge names number to negate
  [401, 402, 403],
  // #21 Doubles Delight — Doc +5 doubles damage, Tabitha +2 doubles from sideline, Flora +2HP on doubles
  [42, 95, 75],
  // #22 Defensive Wall — Stone Cold 7HP + 3X double-1s, Puff -1 from enemy doubles/triples, Guard Thomas immune to singles below 6HP
  [73, 5, 41],
  // #23 Healing Seed Engine — Young Cap seeds give +1die/+1shard/+1surge, Chow spends seed for +2 dice, Kaplan gains seeds on enemy doubles
  [429, 414, 308],
  // #24 Frost Valley Thieves — Dallas steals 1 die for 2 rolls on entry, Suspicious Jeff steals 1 die on ally win, Outlaw doubles remove 1 die
  [60, 61, 43],
  // #25 Moonstone Madness — Benjamin free Moonstone use, Natalia even doubles → 2 Moonstones, Harvey wins → Moonstones per 5 rolled
  [203, 327, 448],
  // #26 Lucky Stone Payoff — Hank 4s gain Lucky Stones, Twyla spends stones for +dice/+seeds, Selene doubles → 2 seeds or 3 stones
  [305, 417, 207],
  // #27 Burn & Punish — Sable odd rolls gain Sacred Fire, The Ember Force 1 damage before rolling, Rook immune to fire + Surge damage bonus
  [304, 413, 416],
  // #28 Entry Damage Blitz — Grawr 1 damage on entry, Jenkins rolls 4 dice damage on entry, Nicholas 2 damage to enemy on entry
  [34, 94, 51],
  // #29 Simon's Fire Factory — Simon gains Sacred Fire when taking damage, Marcus 3+ damage → 4 extra dice, Mallow removes fire for 3HP from sideline
  [24, 57, 89],
  // #30 Surge Builder — Dart wins for 2 Surge, Boris spends Surge for +2HP, Chagrin loses for 1 Surge
  [209, 343, 404],
  // #31 Chow Kitchen — Chow spends seeds for +2 dice, Farmer Jeff 6s → seeds, Maximo gains seed + stone each round
  [414, 314, 302],
  // #32 Gordok Pirate — Gordok steals 2 specials on win + Moonstone, Nick & Knack steals 1 special + 3HP, Sandwiches mirrors enemy specials
  [430, 409, 33],
  // #33 Frost Valley Snipers — Night Master doubles+win → destroy <4HP sideline ghost, Pelter +2 doubles damage, Bogey reflects damage once
  [103, 86, 53],
  // #34 Redd Entrance — Redd entry +2 dice, Hugo enemy loses die on hit, Floop enemy loses die on doubles
  [98, 52, 20],
  // #35 Volcanic Isles Core — Rook immune to fire + Surge bonus, Sable odd rolls Sacred Fire, The Ember Force 1 pre-roll damage
  [416, 413, 304],
  // #36 HP Swap Gambit — Eloise spends Ice Shard to swap HP, Chad entry 2 Ice Shards, Sad Sal loses → Ice Shard
  [85, 56, 29],
  // #37 Wandering Sue Sniper — Sue destroys 12+ HP enemies, Villager +1HP on wins from sideline, Shoo +2HP when <4HP from sideline
  [84, 11, 13],
  // #38 Midrange Doubles — Prince Balatron counter die on survive loss, Kairan doubles → +1 die, Laura numeric order → +3 damage
  [113, 68, 79],
  // #39 Castle Guards Threes — Castle Guards 3s multiply damage by 2, Zach +3 doubles damage for Guard Thomas (but Guards benefit from 3s), Lou +1dmg/+1HP for Grawr from sideline
  [39, 87, 88],
  // #40 Jasper Glass Cannon — Jasper wins → bonus die damage + self-damage, Bilbo +2 singles from sideline, Dark Jeff +1 all damage
  [428, 80, 74],

  // ===================== FUN / MEME TIER (10 teams) =====================

  // #41 Glass Cannon Squad — all tiny HP, maximum chaos
  [8, 205, 410],   // Buttons 1HP triple-6 dream + Shade's Shadow <4HP poke + Mirror Matt reflects doubles
  // #42 Mirror Theft — Mirror Matt reflects doubles, Nick & Knack steals specials, Outlaw removes dice on doubles
  [410, 409, 43],
  // #43 Tie Party — Jimmy ties for 5 stones + firefly, Goobs ties for 2 fireflies each, Ancient One +3HP on ties from sideline
  [352, 444, 22],
  // #44 Tommy Salami Chain-6s — Tommy 6s chain extra dice, Rascals entry 3 Burn for fuel, Lars entry resources
  [30, 437, 420],
  // #45 All Legendary Showdown — Bo revives, Shade pre-roll damage, Selene doubles for resources
  [109, 111, 305],
  // #46 Buttons & Needle Dream — Buttons triple-6 for +15, Needle gives Buttons +1 die from sideline, Tabitha +2 doubles from sideline
  [8, 21, 95],
  // #47 Dupy Coin Flip — Dupy ties instant KO, Hermit entry HP per defeated ghosts, Little Boo turns enemy triples into 1-2-3
  [12, 47, 9],
  // #48 Fang Tag Team — Fang Outside swaps on win, Fang Undercover swaps on damage, Doug swaps once + gains die
  [6, 7, 63],
  // #49 Chaos Reroll — Jackson removes HP to reroll dice, Sonya changes die to 2, Dealer numeric order negates damage
  [50, 69, 37],
  // #50 Wanderer's Gambit — Wanderer 8HP reveals hidden cards, Cameron gains dice from enemy specials + damage can't be negated, Masked Hero punishes before-roll effects
  [4, 25, 55],

  // ===================== NEW WAVE (25 teams) =====================

  // #51 Gary's Ice Factory — Skylar boosts Ice Shards to +2, Gary generates 2 shards per 1 rolled from sideline, Artemis wins for 3 shards
  [104, 92, 307],
  // #52 Hermit Late Game — Powder dies first (gives 3 Ice Shards on death), Granny harvests KO resources from sideline, Hermit enters last with +2HP per KO'd ghost
  [23, 310, 47],
  // #53 Splinter Poison — Splinter wins once to start permanent pre-roll chip, Princess Shade amplifies every pre-roll hit +1, Shoo heals active from sideline
  [101, 436, 13],
  // #54 Fredrick Lockdown — Fredrick caps enemy to 3 dice, Antoinette mirrors enemy dice count for parity, Floop punishes enemy doubles with -1 die
  [27, 82, 20],
  // #55 Munch Cleanup Crew — Greg bullies with 2x damage when higher HP, Munch gains 4HP on KO to sustain, Calvin & Anna swap on KO for flexibility
  [49, 66, 91],
  // #56 Chip Even Doubles — Chip deals +3 on even doubles, Admiral boosts even doubles +2 from sideline, Natalia generates 2 Moonstones on even doubles
  [16, 71, 327],
  // #57 Ancient Librarian Math — Librarian stacks +1 damage per 2 rolled by anyone, Sonya forces a die to 2 every roll, Dark Jeff +1 all damage from sideline
  [3, 69, 74],
  // #58 Katrina Sustain — Katrina gains 1HP when lower HP, Villager heals +1HP on wins from sideline, Opa gains +1HP on every win or tie
  [70, 11, 48],
  // #59 Triple Threat — Larry deals 3x on triples, Haywire gains permanent die + damage on triples, Pip removes enemy die on triples permanently
  [35, 78, 418],
  // #60 Cave Ambush — Cave Dweller deals 3x on first-roll win, Dallas steals a die for 2 rolls on entry, Bandit Pete +3 damage when anyone rolls only 2 dice
  [46, 60, 93],
  // #61 Bill & Bob Berserker — Bill & Bob deal 2x below 4HP, Cyboo gives +1 die when active below 3HP from sideline, Shade's Shadow chips <4HP enemies from sideline
  [36, 100, 205],
  // #62 Wim All-Odds — Wim deals +5 when all dice are odd, Laura adds +3 on numeric order wins, Pale Nimbus adds +2 when roll sum <7 from sideline
  [65, 79, 88],
  // #63 Snorton Six Stacker — Tommy chains 6s for extra dice, Snorton deals +5 when 2+ sixes hit, Harvey generates Moonstones per 5 rolled
  [30, 67, 448],
  // #64 Kodako Counter — Kodako negates damage and deals 4 on 1-2-3, Little Boo turns enemy triples into 1-2-3, Dealer negates damage on numeric order
  [1, 9, 37],
  // #65 Professor Moonstone — Natalia generates Moonstones on even doubles, Professor Hawking rolls +2 dice while holding Moonstone, Benjamin uses Moonstones for free
  [327, 447, 203],
  // #66 Dark Fang Disruption — Dark Fang forces enemy swap pre-roll, Raditz forces enemy swap on entry, Winston forces enemy swap on doubles
  [202, 62, 15],
  // #67 Bo's Proper Setup — Munch fights first (gains 4HP on KO), Granny harvests resources on ally KO from sideline, Bo enters last to resurrect fallen ally
  [66, 310, 109],
  // #68 Gus Swap Punish — Gus forces enemy swap instead of damage, Nicholas deals 2 damage to every entering ghost from sideline, Lars enters with Surge + Stone + Burn
  [31, 51, 420],
  // #69 Charlie Double-2s — Charlie deals 7 on double 2s, Ancient Librarian stacks +1 per 2 rolled, Sonya forces a die to 2 every roll
  [18, 3, 69],
  // #70 Sparky One-Bomb — Sparky deals +3 per 1 rolled, Gary generates 2 Ice Shards per 1 from sideline, Sad Sal gains Ice Shard on every loss
  [64, 92, 29],
  // #71 King Jay Reflect — King Jay reflects all damage on lose+sum=7, Marcus gains 4 extra dice on 3+ damage taken, Puff reduces enemy doubles/triples -1
  [106, 57, 5],
  // #72 Patrick Stone Wall — Patrick deals 3 and negates on enemy singles (no dice rolled), Cornelius shuts down all enemy sideline effects, Villager heals +1HP on wins from sideline
  [10, 45, 11],
  // #73 Dream Cat Die Ladder — Dream Cat gains +2 dice on mutual doubles, Kairan gains +1 die on any doubles, TMK deals 2x damage on doubles
  [28, 68, 110],
  // #74 Nyx Seed Harvest — Zippa deals +1 per Healing Seed held, Harrison spends seeds for extra dice, Nyx & Bessie generate 4 seeds on KO from sideline
  [423, 315, 415],
  // #75 Carpenter's Workshop — Dart fights first generating Surge, Carpenter enters and uses Surge to evolve up the chain, Bilbo adds +2 singles from sideline
  [209, 449, 80],
  // #76 Dark Pressure — Ryder Toll forces opponent choice (1 dmg or Sacred Fire), Tyler doubles Sacred Fire damage, Princess Shade +1 on all pre-roll chip damage
  [456, 105, 436],

  // ===================== NEW WAVE 2 (20 teams) =====================

  // #77 Ridley Sniper Squad — Ridley +1 singles/+2 doubles, Dark Jeff +1 all from bench, Bilbo +2 singles from bench. Singles deal +4.
  [462, 74, 80],
  // #78 Zork Burn Engine — Ronan generates Ice+Burn on doubles, Zork Smolders Burn into dice, Lars enters with Surge+Stone+Burn fuel
  [461, 463, 420],
  // #79 Maisie's Lucky Fives — Maisie 1s→5s, Eli generates Lucky Stones every round, Twyla spends stones for +dice/+seeds
  [458, 459, 417],
  // #80 Sophia's Dark Court — Gom wins doubles for Sacred Fire, Sophia comes in for Mask, Willow +1 die on loss from bench
  [440, 457, 435],
  // #81 Explorer Jeff's Hoard — Lars enters with 3 specials instantly, Explorer Jeff gets +1 die/+1 dmg at 3+ specials, Chester maintains diversity
  [420, 455, 426],
  // #82 Kaylee Dice Thief — Kaylee swaps 2s for opponent's best, Suspicious Jeff steals die on wins from bench, Dallas steals die on entry
  [453, 61, 60],
  // #83 Castle Gardener Forge — Gardener converts seeds→fire, Farmer Jeff generates seeds on 6s from bench, Finn forges Flame Blade
  [442, 314, 204],
  // #84 Troubling Haters Brawl — Haters grow +2 HP on 4+ damage, Shoo +2 HP when <4 from bench, Jeffery +3 HP on wins from bench
  [83, 13, 14],
  // #85 Tyson Tag Team — Tyson hops to dodge matchups, Redd enters with +2 dice power spike, Grawr deals 1 on entry
  [365, 98, 34],
  // #86 Michael's Shield Wall — Michael makes bench immune to Burn, Boopies generates stones on seed spends, Kaplan generates seeds on enemy doubles
  [445, 419, 308],
  // #87 City Cyboo Anti-Doubles — Cyboo no doubles damage, Puff -1 from doubles/triples, Little Boo turns enemy triples into 1-2-3
  [77, 5, 9],
  // #88 Wendy Firefly Factory — Wendy doubles for Fireflies, Goobs bench +5 HP + ties give Fireflies, Jimmy ties for 3 stones + Firefly
  [441, 444, 352],
  // #89 Jeanie's Insurance — Stone Cold 7HP tank + 3X double-1s, Jeanie forces enemy reroll once, Guardian Fairy takes hits from bench
  [73, 90, 99],
  // #90 Ronan's Dual Engine — Ronan generates Ice+Burn on doubles, Spockles wins for 2 Ice Shards, Ashley wins for Sacred Fire
  [461, 81, 58],
  // #91 Ripagoo Transform Chain — Carpenter evolves on Surge, Ripagoo gains 2 Burn per transform from bench, Dart generates Surge on wins
  [449, 452, 209],
  // #92 Slicer's Patience — Miyoshi Bonzais for 9 dice (quads possible), Slicer bench destroys sideline ghost on quads, Haywire gains permanent dice on triples
  [454, 460, 78],
  // #93 Eli's Slow Build — Eli generates Lucky Stones every round, Dark Jeff +1 all damage from bench, Twyla spends stone mountain for +dice/+seeds
  [459, 74, 417],
  // #94 Maisie Power — Maisie 1s→5s boosted rolls, Tabitha +2 doubles from bench, Dark Jeff +1 all from bench
  [458, 95, 74],
  // #95 Gom Gom to Lucy — Gom generates Sacred Fire on doubles, Lucy's Shadow waits on bench, Lucy enters and Shadow doubles her fire gains + damage
  [440, 439, 108],
  // #96 Ridley Snowball — Ridley +1 singles/+2 doubles, Villager heals +1 on wins from bench, Suspicious Jeff steals die on wins from bench
  [462, 11, 61],
];

// --- Quick-fill helpers (Wyatt Directive 2026-04-11) ---
// Picks a curated 3-ghost composition. excludeIds prevents overlap with the other team.
function getCuratedTeam(excludeIds = []) {
  const validIds = new Set(GHOSTS.filter(g => !SHELVED_IDS.has(g.id)).map(g => g.id));
  const available = CURATED_TEAMS.filter(team =>
    team.every(id => validIds.has(id)) &&
    !team.some(id => excludeIds.includes(id))
  );
  if (available.length === 0) return getRandomTeamFallback(excludeIds);
  return [...available[Math.floor(Math.random() * available.length)]];
}

// Fallback: purely random team when no curated team fits (e.g. extreme overlap)
function getRandomTeamFallback(excludeIds = []) {
  const pool = GHOSTS.filter(g => !SHELVED_IDS.has(g.id) && !excludeIds.includes(g.id));
  const picks = [];
  let hasLegendary = false;
  const shuffled = [...pool].sort(() => Math.random() - 0.5);
  for (const g of shuffled) {
    if (picks.length >= 3) break;
    if (g.rarity === 'legendary') {
      if (hasLegendary) continue;
      hasLegendary = true;
    }
    picks.push(g.id);
  }
  return picks;
}

function pickRandomTeam(team) {
  const other = S[team === 'red' ? 'bluePicks' : 'redPicks'];
  S[`${team}Picks`] = getCuratedTeam(other);
  renderPicks();
}

// Fills both teams at once with two non-overlapping curated teams.
function pickRandomBoth() {
  S.redPicks = getCuratedTeam([]);
  S.bluePicks = getCuratedTeam(S.redPicks);
  renderPicks();
}

// ============================================================
// BATTLE ENGINE
// ============================================================
// ghostData(id) defined in header — uses getGhost() from cards.js


function makeTeam(ids) {
  return {
    ghosts: ids.map(id => {
      const g = ghostData(id);
      return { id, name:g.name, hp:g.maxHp, maxHp:g.maxHp, ko:false, ability:g.ability, abilityDesc:g.abilityDesc, rarity:g.rarity,
        hankFirstRoll:false, maximoFirstRoll:false, usedMagicTouch:false };
    }),
    activeIdx: 0,
    resources: { moonstone:0, ice:0, fire:0, surge:0, healingSeed:0, luckyStone:0, firefly:0 },
    moonstoneSickness: 0,       // Mode A: permanent stacking counter
    moonstoneSicknessCount: 0,  // Mode B: escalating counter
    moonstoneSicknessPending: 0 // Mode B & C: damage to apply next roll
  };
}

function active(t) { return t.ghosts[t.activeIdx]; }
function opp(team) { return team===B.red ? B.blue : B.red; }
function teamName(team) { return team===B.red ? 'Red' : 'Blue'; }

let B = null; // battle state
let prevResources = { red: {}, blue: {} }; // for resource-gained flash

const LOG_MAX = 50; // [shadow] perf: cap battle log to prevent unbounded array growth
function log(html) { B.log.unshift(html); if (B.log.length > LOG_MAX) B.log.length = LOG_MAX; }

function startBattle() {
  prevResources = { red: {}, blue: {} };
  narrateQueue = []; narrateActive = false;
  B = {
    red: makeTeam(S.redPicks), blue: makeTeam(S.bluePicks),
    round:1, log:[], phase:'ready',
    pendingMoonstone:null, pendingSteal:null,
    // === HAND LIMIT ===
    handLimitMode: !!(document.getElementById('handLimitCheckbox')?.checked),
    HAND_LIMIT: parseInt(document.getElementById('handLimitSlider')?.value) || 3,
    handLimitPending: null,
    // === DUEL PHASE ===
    // Lower-HP loser goes first in the pre-roll commit phase. Toggle off to revert to simultaneous.
    duelPhaseMode: true,
    duelPriority: null,     // 'red' | 'blue' | null — who goes first THIS round's Duel Phase (null = simultaneous)
    duelActiveTeam: null,   // who is currently acting during Duel Phase (gates clicks)
    duelLastLoser: null,    // team that lost the previous roll (null on tie or round 1)
    committed: { red: { ice:0, fire:0, surge:0, auntSusan:0, auntSusanHeal:0, harrison:0, zainBlade:0 }, blue: { ice:0, fire:0, surge:0, auntSusan:0, auntSusanHeal:0, harrison:0, zainBlade:0 } },
    retributionDice: { red: 0, blue: 0 },
    cameronBonusDice: { red: 0, blue: 0 },
    pressureUsed: { red: false, blue: false },
    romyPrediction: { red: null, blue: null },
    pureHeartDeclared: { red: null, blue: null },
    pureHeartScheduledKO: { red: false, blue: false },
    splinterActivated: { red: false, blue: false },
    guardianFairyStandby: { red: false, blue: false },
    letsDanceBonus: { red: 0, blue: 0 },
    tommyRegulatorBonus: { red: 0, blue: 0 },
    eloiseUsedThisRound: { red: false, blue: false },
    outlawStolenDie: { red: 0, blue: 0 },
    bogeyUsed: { red: false, blue: false },
    marcusGlacialBonus: { red: 0, blue: 0 },
    hugoWreckage: { red: 0, blue: 0 },
    logeyLockout: { red: 0, blue: 0 },
    dreamCatBonus: { red: 0, blue: 0 },
    // galeForcePending/galeForceDecided removed — Gus is now reactive post-win
    alucardUsed: { red: false, blue: false },
    jacksonUsedThisRound: { red: false, blue: false },
    sonyaUsedThisRound: { red: false, blue: false },
    darkWingUsedThisGame: { red: false, blue: false },
    haywireBonus: { red: 0, blue: 0 },
    haywireDamageBonus: { red: 0, blue: 0 },
    chowDecided: { red: false, blue: false },
    zorkDecided: { red: false, blue: false },
    zorkExtraDie: { red: 0, blue: 0 },
    bonzaiDecided: { red: false, blue: false },
    battleStarted: false,
    cultivateDecided: { red: false, blue: false },
    willowLostLast: { red: false, blue: false },
    haywireUsed: { red: false, blue: false },
    mallowDecided: { red: false, blue: false },
    jeanieUsed: { red: false, blue: false },
    raditzHuntReady: { red: false, blue: false },
    dougCautionUsed: { red: false, blue: false },
    dougCautionDieBonus: { red: false, blue: false },
    jeffSnicker: { red: 0, blue: 0 },
    pendingLucyDmg: { red: 0, blue: 0 },
    fangUndercoverArmed: { red: false, blue: false },
    fangUndercoverSwapPending: null,
    winstonSchemePending: null,
    winstonDiceBonus: { red: 0, blue: 0 },
    catchyTuneUnlocked: { red: false, blue: false },
    catchyTuneLockedDie: { red: null, blue: null },
    catchyTunePending: null,
    lastRollDiceCount: { red: 3, blue: 3 },
    tysonDisabled: { red: [], blue: [] },
    tysonPickerPending: null,
    galeForcePicker: null,
    scallywagsFrenzyBonus: { red: 0, blue: 0 },
    floopMuck: { red: 0, blue: 0 },
    tylerDecidedThisRound: { red: false, blue: false },
    booTeamworkDecidedThisRound: { red: false, blue: false },
    tylerHeatUpDieBonus: { red: 0, blue: 0 },
    booTeamworkDieDebt: { red: 0, blue: 0 },
    pipToastedUsed: { red: false, blue: false },
    pipDieRemoval: { red: 0, blue: 0 },
    luckyStoneSpentThisTurn: { red: 0, blue: 0 },
    preRollAbilitiesFiredThisTurn: { red: false, blue: false }, moonstoneSicknessFiredThisTurn: false,
    burn: { red: {}, blue: {} },
    burnSource: { red: {}, blue: {} },
    lucasKindlingBonus: { red: 0, blue: 0 },
    iceBladeForgedPermanent: { red: false, blue: false },
    flameBlade: { red: false, blue: false },
    flameBladeSwing: { red: false, blue: false },
    iceBladeSwing: { red: false, blue: false },
    gordokDieBonus: { red: 0, blue: 0 },
    hexDieRemoval: { red: 0, blue: 0 },
    carpenterHammer: { red: false, blue: false },
    welderTorch: { red: false, blue: false },
    foremanDieBonus: { red: 0, blue: 0 },
    carpenterDiceTrade: { red: 0, blue: 0 },
    sophiaMask: { red: null, blue: null },
    sophiaMaskActive: { red: false, blue: false },
  };
  S.battle = B;
  if (typeof initMatchStats === 'function') initMatchStats();
  const _teamSel = document.getElementById('team-select');
  if (_teamSel) _teamSel.style.display = 'none';
  const _battleView = document.getElementById('battle-view');
  if (_battleView) _battleView.style.display = 'block';
  const _appEl = document.querySelector('.app');
  if (_appEl) _appEl.classList.add('battle-active');
  if (typeof startMusic === 'function') startMusic();
  log('<span class="log-round">Battle begins!</span>');
  renderBattle();

  // Disable roll buttons until everything is done
  const rBtn = document.getElementById('rollRedBtn');
  const bBtn = document.getElementById('rollBlueBtn');
  if (rBtn) { rBtn.disabled = true; }
  if (bBtn) { bBtn.disabled = true; }

  // Show VS splash FIRST, then entry abilities cinematic sequence
  const splash = document.getElementById('vsSplash');
  if (splash) {
    document.getElementById('vsRedName').textContent = active(B.red).name;
    document.getElementById('vsBlueName').textContent = active(B.blue).name;
    if (RAID_MODE && RAID_PARAMS) {
      document.getElementById('vsBlueName').textContent = '\u2694 ' + RAID_PARAMS.bossName + ' \u2694';
    }
    const redBench = B.red.ghosts.filter((g,i) => i !== B.red.activeIdx).map(g => g.name);
    const blueBench = B.blue.ghosts.filter((g,i) => i !== B.blue.activeIdx).map(g => g.name);
    document.getElementById('vsRedRoster').textContent = redBench.join(' / ');
    document.getElementById('vsBlueRoster').textContent = blueBench.join(' / ');
    splash.classList.add('active');
    setTimeout(() => {
      splash.classList.remove('active');
      // VS splash done — now fire entry abilities cinematically.
      // Duel Phase v1: ENTRY EFFECT ORDER matches the Duel Phase priority.
      // Lower-HP ghost's entry fires first (the underdog strikes). If HP tied,
      // compute priority via the helper (which uses rarity and finally coin flip).
      // If fully symmetric (mirror match), fall back to Red-first as before.
      const _priority = computeDuelPriority();
      const firstTeam  = (_priority === 'blue') ? B.blue : B.red;
      const secondTeam = (_priority === 'blue') ? B.red  : B.blue;
      const firstEntryCount = triggerEntry(firstTeam);
      renderBattle();
      afterEntryWithJenkins(firstEntryCount, () => {
        const secondEntryCount = triggerEntry(secondTeam);
        renderBattle();
        afterEntryWithJenkins(secondEntryCount, () => {
          // All entry effects done — check for KOs, then enable rolling
          B.battleStarted = true; // Nicholas Sneak Attack can now fire on swaps
          if (handleKOs()) return;
          // Duel Phase v1: check for priority before unlocking rolls
          startNextRound();
          narrate(`<b class="gold">Round 1</b> — <b class="red-text">${active(B.red).name}</b>&nbsp;vs&nbsp;<b class="blue-text">${active(B.blue).name}</b> — <b class="gold">Fight!</b>`);
        });
      });
    }, spd(2200));
  } else {
    // No splash — fire entries in Duel Phase priority order, then enable
    const _priority2 = computeDuelPriority();
    const firstTeam2  = (_priority2 === 'blue') ? B.blue : B.red;
    const secondTeam2 = (_priority2 === 'blue') ? B.red  : B.blue;
    const ec1 = triggerEntry(firstTeam2);
    afterEntryWithJenkins(ec1, () => {
      const ec2 = triggerEntry(secondTeam2);
      afterEntryWithJenkins(ec2, () => {
        renderBattle();
        B.battleStarted = true; // Nicholas Sneak Attack can now fire on swaps
        if (handleKOs()) return;
        startNextRound();
        narrate(`<b class="gold">Round 1</b> — <b class="red-text">${active(B.red).name}</b>&nbsp;vs&nbsp;<b class="blue-text">${active(B.blue).name}</b> — <b class="gold">Fight!</b>`);
      });
    });
  }
}

function triggerEntry(team, skipEntryEffects) {
  const f = active(team);
  const enemy = opp(team);
  if (skipEntryEffects || window._raidSkipEntry) return 0;

  const entryTeamName = team === B.red ? 'red' : 'blue';

  // Tyson (365) — Hop: when a disabled ghost enters play, re-enable its sideline ability
  if (B.tysonDisabled && B.tysonDisabled[entryTeamName].includes(team.activeIdx)) {
    B.tysonDisabled[entryTeamName] = B.tysonDisabled[entryTeamName].filter(i => i !== team.activeIdx);
    log(`<span class="log-ability">${f.name}</span> — enters play! Sideline ability re-enabled.`);
  }
  narrate(`<b class="${entryTeamName}-text">${f.name}</b> enters the arena!`);

  // Castle Guide (420) — Burn: check if the entering ghost has burn on it
  // Mike (445) — Torrent: while Mike is on the team (sideline), entering ghosts are immune to Burn
  let burnEntryFired = false;
  // Debug: log burn state on every entry for tracking burn-not-firing issues
  if (DEBUG) console.log(`[BURN DEBUG] ${f.name} (id:${f.id}) entering for ${entryTeamName}, activeIdx=${team.activeIdx}, B.burn[${entryTeamName}]=`, JSON.stringify(B.burn?.[entryTeamName] || {}));
  if (B.burn && B.burn[entryTeamName]) {
    const activeIdx = team.activeIdx;
    const burnCount = B.burn[entryTeamName][activeIdx] || 0;
    // Mike (445) — Torrent: if Mike is on the sideline of this team, burn is consumed but deals 0
    const mikeProtects = hasSideline(team, 445);
    if (burnCount > 0 && !f.ko && mikeProtects) {
      // Mike's Torrent: sideline immune to Burn — consume burn, deal 0
      delete B.burn[entryTeamName][activeIdx];
      if (B.burnSource && B.burnSource[entryTeamName]) delete B.burnSource[entryTeamName][activeIdx];
      burnEntryFired = true;
      showAbilityCallout('TORRENT!', 'var(--rare)', `Mike — Torrent! Sideline immune to Burn! ${f.name} takes no damage.`, entryTeamName);
      log(`<span class="log-ability">Mike</span> — Torrent! <span class="log-heal">Sideline immune to Burn!</span> ${f.name} takes no damage.`);
    } else if (burnCount > 0 && !f.ko && f.id !== 416) {
      // Welder (450) active OR Welder's Torch permanent: burns deal +1 extra damage
      const oppTeamName = entryTeamName === 'red' ? 'blue' : 'red';
      const welderBurnBonus = (active(B[oppTeamName]).id === 450 && !active(B[oppTeamName]).ko) || (B.welderTorch && B.welderTorch[oppTeamName]) ? burnCount : 0;
      const totalBurnDmg = burnCount + welderBurnBonus;
      const burnPre = f.hp;
      f.hp = Math.max(0, f.hp - totalBurnDmg);
      // Credit the Spiritkin who placed the most burn on this ghost
      if (f.hp <= 0) {
        f.ko = true;
        let topBurner = -2;
        const sources = B.burnSource && B.burnSource[entryTeamName] && B.burnSource[entryTeamName][activeIdx];
        if (sources) {
          let maxCount = 0;
          for (const [sid, cnt] of Object.entries(sources)) {
            if (cnt > maxCount) { maxCount = cnt; topBurner = parseInt(sid); }
          }
        }
        f.killedBy = topBurner;
      }
      delete B.burn[entryTeamName][activeIdx];
      if (B.burnSource && B.burnSource[entryTeamName]) delete B.burnSource[entryTeamName][activeIdx];
      burnEntryFired = true;
      const welderBurnLabel = welderBurnBonus > 0 ? ` (Welder's Torch: +${welderBurnBonus}!)` : '';
      showAbilityCallout('BURN!', 'var(--accent)', `${f.name} takes ${totalBurnDmg} Burn damage on entry!${welderBurnLabel} (${burnPre} → ${f.hp} HP)${f.ko ? ' KO!' : ''}`, entryTeamName);
      log(`<span class="log-dmg">${f.name}</span> — Burn! <span class="log-dmg">${totalBurnDmg} damage on entry!</span>${welderBurnLabel} (${burnPre} → ${f.hp} HP)${f.ko ? ' <span class="log-ko">KO!</span>' : ''}`);
    } else if (burnCount > 0 && f.id === 416) {
      // Rook (416) — Immune to Burn: consume burn but take no damage
      delete B.burn[entryTeamName][activeIdx];
      if (B.burnSource && B.burnSource[entryTeamName]) delete B.burnSource[entryTeamName][activeIdx];
      burnEntryFired = true;
      showAbilityCallout('BURN IMMUNE!', 'var(--rare)', `${f.name} — Immune to Burn! No damage taken.`, entryTeamName);
      log(`<span class="log-ability">${f.name}</span> — <span class="log-heal">Immune to Burn!</span> No damage taken.`);
    }
  }

  // Collect all entry callouts (entry ability + any Knight reactions) into a sequential array,
  // then fire them with 1500ms spacing. This prevents HEAVY AIR! / RETRIBUTION! from
  // instantly stomping the entry callout (same sequential-stomp pattern fixed in v90–v95
  // for Selene, Timber modal, Timber forced-auto, and Harrison Ascend).
  const entryCallouts = [];

  // Helper: collect Knight reactions into entryCallouts via temporary queue mode
  const collectKnightReactions = () => {
    const savedQ = abilityQueue;
    abilityQueue = [];
    abilityQueueMode = true;
    checkKnightEffects(entryTeamName, f.name);
    abilityQueue.forEach(item => entryCallouts.push([item.name, item.color, item.desc, item.team]));
    abilityQueue = savedQ;
    abilityQueueMode = false;
  };

  // Bouril (201) — Slumber: first roll is auto 1-2-3
  if (f.id === 201) {
    f.hankFirstRoll = true;
    entryCallouts.push(['SLUMBER!', 'var(--uncommon)', `${f.name} — first roll locked to 1-2-3!`, entryTeamName]);
    log(`<span class="log-ability">${f.name}</span> enters lazily — first roll will be 1-2-3.`);
    collectKnightReactions();
  }

  // Zain (206) — Ice Blade: opt-in pre-roll forge button (see useZainForge), no entry effect

  // Nerina (306) — Leviathan: deal 3 damage to enemy active
  if (f.id === 306) {
    const ef = active(enemy);
    if (!ef.ko) {
      ef.hp = Math.max(0, ef.hp - 3);
      if (ef.hp <= 0) { ef.ko = true; ef.killedBy = (f.originalId || f.id); }
      const enemyName = enemy === B.red ? 'red' : 'blue';
      entryCallouts.push(['LEVIATHAN!', 'var(--legendary)', `${f.name} — 3 entry damage to ${ef.name}!`, entryTeamName]);
      log(`<span class="log-ability">${f.name}</span> — Leviathan! <span class="log-dmg">3 entry damage to ${ef.name}!</span> ${ef.ko?'<span class="log-ko">KO!</span>':ef.hp+' HP left'}`);
      playDamageSfx(3);
      hitDamage(enemyName);
      collectKnightReactions();
    }
  }

  // Maximo (302) — Nap: first roll is 1 die
  if (f.id === 302) {
    f.maximoFirstRoll = true;
    entryCallouts.push(['NAP!', 'var(--common)', `${f.name} — first roll is 1 die only!`, entryTeamName]);
    log(`<span class="log-ability">${f.name}</span> is napping... first roll will be only 1 die.`);
    collectKnightReactions();
  }

  // Redd (98) — Notorious: first roll after entry gets +2 extra dice
  if (f.id === 98) {
    f.reddFirstRoll = true;
    entryCallouts.push(['NOTORIOUS!', 'var(--ghost-rare)', `${f.name} — +2 dice for this roll!`, entryTeamName]);
    log(`<span class="log-ability">${f.name}</span> — Notorious! Enters with +2 bonus dice for the first roll!`);
    collectKnightReactions();
  }

  // Jenkins (94) — Greeting: on entry, roll 4 dice and deal damage by roll TYPE (not sum).
  // Deferred to interactive modal — dice are pre-computed here, damage applied after player rolls.
  if (f.id === 94) {
    const ef = active(enemy);
    if (!ef.ko) {
      const jenkinsDice = rollDice(4);
      const jenkinsRoll = classify(jenkinsDice);
      const jenkinsDmg = jenkinsRoll.damage;
      const enemyTeamName = enemy === B.red ? 'red' : 'blue';
      B.jenkinsPending = {
        team: entryTeamName,
        enemyTeam: enemyTeamName,
        dice: jenkinsDice,
        roll: jenkinsRoll,
        damage: jenkinsDmg,
        enemyName: ef.name,
        jenkinsName: f.name
      };
      // No callout here — the modal handles the reveal
      collectKnightReactions();
    }
  }

  // Timber (210) — Howl: no entry callout; the pre-roll Howl modal/callout handles it every round

  // Timpleton (312) — Big Target: v640 rework — moved from Entry strike to Win-roll damage multiplier.
  // New logic lives in _resolveRoundImpl near Red Hunter (345) (search: "Timpleton (312) — Big Target").

  // Grawr (34) — Menace: on entry, deal 1 damage to the enemy active ghost
  if (f.id === 34) {
    const ef = active(enemy);
    if (!ef.ko) {
      ef.hp = Math.max(0, ef.hp - 1);
      if (ef.hp <= 0) { ef.ko = true; ef.killedBy = (f.originalId || f.id); }
      const enemyName = enemy === B.red ? 'red' : 'blue';
      entryCallouts.push(['MENACE!', 'var(--uncommon)', `${f.name} — 1 entry damage to ${ef.name}!`, entryTeamName]);
      log(`<span class="log-ability">${f.name}</span> — Menace! <span class="log-dmg">1 entry damage to ${ef.name}!</span> ${ef.ko ? '<span class="log-ko">KO!</span>' : ef.hp + ' HP left'}`);
      playDamageSfx(1);
      hitDamage(enemyName);
      collectKnightReactions();
    }
  }

  // Hermit (47) — Solitude: on entry, gain +2 HP per ghost defeated on both teams
  if (f.id === 47) {
    const koCount = [...B.red.ghosts, ...B.blue.ghosts].filter(g => g.ko && !g.isPadded).length;
    if (koCount > 0) {
      const gain = koCount * 2;
      const before = f.hp;
      f.hp += gain; // allow overclock — late-game scaling tank
      entryCallouts.push(['SOLITUDE!', 'var(--uncommon)', `${f.name} — +${gain} HP from ${koCount} fallen ghost${koCount > 1 ? 's' : ''}! (${before}→${f.hp} HP)`, entryTeamName]);
      log(`<span class="log-ability">${f.name}</span> — Solitude! +${gain} HP from ${koCount} fallen ghosts. (${before}→${f.hp} HP)`);
    } else {
      entryCallouts.push(['SOLITUDE!', 'var(--uncommon)', `${f.name} — No fallen ghosts yet. Waiting...`, entryTeamName]);
      log(`<span class="log-ability">${f.name}</span> — Solitude! No fallen ghosts yet.`);
    }
  }

  // Chad (56) — Sploop!: on entry, gain 2 Ice Shards
  // Sandwiches (33) Dependable: opponent mirrors the Ice Shard gain.
  if (f.id === 56) {
    team.resources.ice += 2;
    entryCallouts.push(['SPLOOP!', 'var(--uncommon)', `${f.name} — +2 Ice Shards! (${team.resources.ice} total)`, entryTeamName]);
    log(`<span class="log-ability">${f.name}</span> — Sploop! Gained <span class="log-ice">2 Ice Shards</span>! (${team.resources.ice} total)`);
    collectKnightReactions();
    if (hasOnTeam(enemy, 33)) {
      enemy.resources.ice += 2;
      entryCallouts.push(['DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Sploop! +2 Ice Shards! (${enemy.resources.ice} total)`, entryTeamName === 'red' ? 'blue' : 'red']);
      log(`<span class="log-ability">Sandwiches</span> — Dependable! Mirrors Sploop: +<span class="log-ice">2 Ice Shards</span>! (${enemy.resources.ice} total)`);
    }
  }

  // Raditz (62) — Hunt: on entry, may force opponent to swap their active ghost (one-time)
  // Prime the Hunt flag so it fires before Raditz's first roll (handled in rollReady).
  if (f.id === 62 && !skipEntryEffects) {
    const teamName = team === B.red ? 'red' : 'blue';
    const enemySideline = enemy.ghosts.filter((g, i) => i !== enemy.activeIdx && !g.ko);
    if (enemySideline.length > 0) {
      if (!B.raditzHuntReady) B.raditzHuntReady = { red: false, blue: false };
      B.raditzHuntReady[teamName] = true;
      entryCallouts.push(['HUNT!', 'var(--rare)', `${f.name} — may force an opponent swap before rolling!`, entryTeamName]);
      log(`<span class="log-ability">${f.name}</span> — Hunt! Primed — choose to force an opponent swap before rolling.`);
    }
  }

  // Dallas (60) — Quick Draw: on entry from sideline, prime die theft for first 2 rolls
  // Only fires when coming OFF the sideline — not when Dallas starts as the active ghost
  if (f.id === 60 && B.battleStarted) {
    f.dallasQuickDraw = 2;
    entryCallouts.push(['QUICK DRAW!', 'var(--uncommon)', `${f.name} — stealing 1 opponent die for the next 2 rolls!`, entryTeamName]);
    log(`<span class="log-ability">${f.name}</span> — Quick Draw! Steals 1 opponent die for the first 2 rolls.`);
    collectKnightReactions();
  }

  // Lars (420) — Light the Way: entry → +1 Surge, +1 Lucky Stone, +1 Burn (as resource — player clicks to place)
  if (f.id === 420) {
    team.resources.surge++;
    team.resources.luckyStone++;
    if (!team.resources.burn) team.resources.burn = 0;
    team.resources.burn++;
    entryCallouts.push(['LIGHT THE WAY!', 'var(--uncommon)', `${f.name} — Entry! +1 Surge, +1 Lucky Stone, +1 Burn!`, entryTeamName]);
    log(`<span class="log-ability">${f.name}</span> — Light the Way! <span class="log-ms">+1 Surge, +1 Lucky Stone, +1 Burn!</span>`);
    collectKnightReactions();
  }

  // Rascals (437) — Stampede: Entry → gain 3 Burn
  if (f.id === 437 && !f.ko) {
    if (!team.resources.burn) team.resources.burn = 0;
    team.resources.burn += 3;
    entryCallouts.push(['STAMPEDE!', 'var(--common)', `${f.name} — Entry! +3 Burn!`, entryTeamName]);
    log(`<span class="log-ability">${f.name}</span> — Stampede! Entry → <span class="log-dmg">+3 Burn!</span>`);
    collectKnightReactions();
  }

  // Nicholas (51) — Sneak Attack: while on the sideline, deal 2 damage to the entering ghost
  // Does NOT fire at initial battle setup — only fires on mid-battle swaps (KO, Pressure, Gus, etc.)
  // B.battleStarted is set to true after the initial entry sequence completes.
  if (hasSideline(enemy, 51) && !f.ko && B.battleStarted) {
    const nicholasGhost = getSidelineGhost(enemy, 51);
    f.hp = Math.max(0, f.hp - 2);
    if (f.hp <= 0) { f.ko = true; f.killedBy = 51; }
    const enteringTeamName = team === B.red ? 'red' : 'blue';
    const nicholasTeamName = enteringTeamName === 'red' ? 'blue' : 'red';
    entryCallouts.push(['SNEAK ATTACK!', 'var(--uncommon)',
      `${nicholasGhost.name} — 2 damage to ${f.name} on entry!`, nicholasTeamName]);
    log(`<span class="log-ability">${nicholasGhost.name}</span> — Sneak Attack! <span class="log-dmg">2 damage to ${f.name} on entry!</span> ${f.ko ? '<span class="log-ko">KO!</span>' : f.hp + ' HP left'}`);
    playDamageSfx(2);
    hitDamage(enteringTeamName);
    // Knight reactions: Nicholas's ability belongs to the enemy team — the entering team may counter.
    // Use nicholasTeamName (not entryTeamName) so Knight Terror/Light on the ENTERING side
    // correctly punish/reward in response to the enemy ability (not double-punish the entering ghost).
    const savedQN = abilityQueue;
    abilityQueue = [];
    abilityQueueMode = true;
    checkKnightEffects(nicholasTeamName, nicholasGhost.name);
    abilityQueue.forEach(item => entryCallouts.push([item.name, item.color, item.desc, item.team]));
    abilityQueue = savedQN;
    abilityQueueMode = false;
  }

  // Fire all entry callouts sequentially — each 1500ms after the previous
  // c[3] = team string for card-glow spotlight; undefined = narrator-only fallback
  entryCallouts.forEach((c, i) => {
    setTimeout(() => showAbilityCallout(c[0], c[1], c[2], c[3]), i * spd(1500));
  });
  return entryCallouts.length;
}

function rollDice(n) {
  const d = [];
  for (let i=0;i<n;i++) d.push(Math.floor(Math.random()*6)+1);
  return d.sort((a,b)=>a-b);
}

// Weighted roll — cinematic luck system
// Subtle nudges that make tight moments more exciting:
// - 1 HP: 25% chance of forced doubles (3-6 value) — clutch comeback energy
// - 2 HP: 15% chance of forced doubles — still dangerous but not as desperate
// - 5+ dice: 10% penta nudge — reward the player for earning extra dice
// - General: low HP rolls get a slight quality boost (reroll lowest die if below average)
function weightedRoll(team, count) {
  const dice = [];
  for (let i = 0; i < count; i++) dice.push(Math.floor(Math.random()*6)+1);
  if (!B || !B[team]) return dice.sort((a,b)=>a-b);
  const f = active(B[team]);

  // Penta nudge: 5+ dice → 10% chance all dice match (huge cinematic moment)
  if (count >= 5 && Math.random() < 0.10) {
    const v = Math.ceil(Math.random()*4)+2; // 3–6 for exciting penta
    for (let i = 0; i < dice.length; i++) dice[i] = v;
    return dice.sort((a,b)=>a-b);
  }

  // Clutch doubles: low HP → chance of forced doubles
  if (f && f.hp === 1 && Math.random() < 0.25) {
    const v = Math.ceil(Math.random()*4)+2; // 3–6
    dice[0] = v;
    if (dice.length >= 2) dice[1] = v;
  } else if (f && f.hp === 2 && Math.random() < 0.15) {
    const v = Math.ceil(Math.random()*4)+2;
    dice[0] = v;
    if (dice.length >= 2) dice[1] = v;
  }

  // Low HP quality boost: if at 1-2 HP, reroll the lowest die if it's below 3
  // Subtle — just nudges the floor up slightly so you're less likely to get crushed
  if (f && f.hp <= 2 && f.hp > 0 && dice.length >= 2) {
    const minIdx = dice.indexOf(Math.min(...dice));
    if (dice[minIdx] <= 2 && Math.random() < 0.30) {
      dice[minIdx] = Math.ceil(Math.random()*3)+3; // reroll to 4-6
    }
  }

  return dice.sort((a,b)=>a-b);
}

// AFK timer — pulse roll buttons after 5s of inactivity (Feature 10)
let afkTimer = null;
function resetAfkTimer() {
  clearTimeout(afkTimer);
  document.querySelectorAll('#rollRedBtn, #rollBlueBtn').forEach(b => b.classList.remove('pulse'));
  // At higher speeds, shave 1s off AFK pulse (5s→4s) — player still has plenty of time
  const afkDelay = getSpeedDivisor() > 1 ? 4000 : 5000;
  afkTimer = setTimeout(() => {
    if (B && B.phase === 'ready') {
      document.querySelectorAll('#rollRedBtn, #rollBlueBtn').forEach(b => {
        if (!b.disabled && !b.classList.contains('locked')) b.classList.add('pulse');
      });
    }
  }, afkDelay);
}

function classify(dice) {
  if (!dice||!dice.length) return {type:'none',value:0,damage:0};
  if (dice.length === 1) return {type:'singles',value:dice[0],damage:1};
  const c = {};
  dice.forEach(d=>c[d]=(c[d]||0)+1);
  const mx = Math.max(...Object.values(c));
  const vals = Object.entries(c).filter(([,v])=>v===mx).map(([k])=>+k);
  const mv = Math.max(...vals);
  if (mx>=6) return {type:mx+'-of-a-kind',value:mv,damage:mx};
  if (mx>=5) return {type:'penta',value:mv,damage:5};
  if (mx>=4) return {type:'quads',value:mv,damage:4};
  if (mx>=3) return {type:'triples',value:mv,damage:3};
  if (mx>=2) return {type:'doubles',value:mv,damage:2};
  return {type:'singles',value:Math.max(...dice),damage:1};
}

function describeRoll(r) {
  if (r.type.endsWith('-of-a-kind')) return `${r.damage} ${r.value}'s!!!`;
  if (r.type==='penta') return `five ${r.value}'s!`;
  if (r.type==='quads') return `four ${r.value}'s!`;
  if (r.type==='triples') return `three ${r.value}'s`;
  if (r.type==='doubles') return `two ${r.value}'s`;
  return `${r.value} high`;
}

function isTripleOrBetter(type) { return ['triples','quads','penta'].includes(type) || type.endsWith('-of-a-kind'); }

// Dark Fang (202) — Pressure: returns true if the OPPONENT has Dark Fang active, blocking healing for this team
function deathHowlBlocksHealing(teamName) {
  if (!B) return false;
  const oppTeamName = teamName === 'red' ? 'blue' : 'red';
  const oppActive = active(B[oppTeamName]);
  return oppActive && oppActive.id === 202 && !oppActive.ko;
}
// Masked Hero (55) — Underdog: immune to before-roll damage
function maskedHeroImmune(ghost) {
  return ghost && ghost.id === 55 && !ghost.ko;
}
// Dark Fang — guarded heal: adds HP only if not blocked. Returns true if heal went through.
function guardedHeal(ghost, amount, teamName) {
  if (deathHowlBlocksHealing(teamName)) {
    log(`<span class="log-ability">Dark Fang</span> — Pressure! ${ghost.name}'s healing blocked!`);
    return false;
  }
  ghost.hp += amount;
  return true;
}

function typeLabel(type) {
  if (type.endsWith('-of-a-kind')) return type.toUpperCase() + '!!!';
  if (type==='penta') return 'PENTA!!';
  if (type==='quads') return 'QUADS!';
  if (type==='triples') return 'TRIPLES!';
  if (type==='doubles') return 'DOUBLES!';
  return '';
}

// Helper: check if a team has a ghost with given id on sideline (alive)
function hasSideline(team, id) {
  const teamName = B && team === B.red ? 'red' : 'blue';
  const disabled = B && B.tysonDisabled ? B.tysonDisabled[teamName] : [];
  return team.ghosts.some((g,i) => i !== team.activeIdx && !g.ko && g.id === id && !disabled.includes(i));
}
// Helper: check if a team has a ghost with given id anywhere (sideline OR active, alive)
function hasOnTeam(team, id) {
  return hasSideline(team, id) || (active(team).id === id && !active(team).ko);
}
function getSidelineGhost(team, id) {
  const teamName = B && team === B.red ? 'red' : 'blue';
  const disabled = B && B.tysonDisabled ? B.tysonDisabled[teamName] : [];
  return team.ghosts.find((g,i) => i !== team.activeIdx && !g.ko && g.id === id && !disabled.includes(i));
}
function hasAlive(team, id) {
  return team.ghosts.some(g => !g.ko && g.id === id);
}
function isStraight(dice) {
  if (!dice || dice.length < 2) return false;
  const sorted = [...new Set(dice)].sort((a, b) => a - b);
  if (sorted.length !== dice.length) return false; // no repeats
  return sorted.every((v, i) => i === 0 || v === sorted[i - 1] + 1);
}

// Pop a sideline card to foreground when its ability triggers
function popSidelineCard(teamObj, ghostId) {
  const teamName = teamObj === B.red ? 'red' : 'blue';
  const sl = teamObj.ghosts.filter((g,i) => i !== teamObj.activeIdx);
  const slIdx = sl.findIndex(g => g.id === ghostId);
  if (slIdx < 0) return;
  const elId = slIdx === 0 ? `${teamName}-sl-left` : `${teamName}-sl-right`;
  const el = document.getElementById(elId);
  if (!el) return;
  el.classList.add('sideline-pop');
  setTimeout(() => el.classList.remove('sideline-pop'), spd(1300));
}

// Helper: check if opponent has Dylan (301) on sideline to negate before-roll effects
function dylanNegates(enemyTeam) {
  // Dylan (301) sideline OR Piper (107) active — both negate enemy before-rolling effects
  const enemyActive = active(enemyTeam);
  return hasSideline(enemyTeam, 301) || (enemyActive && enemyActive.id === 107 && !enemyActive.ko);
}

// Helper: count occurrences of a value in dice array
function countVal(dice, val) { return dice.filter(d => d === val).length; }

// Helper: check if dice contain doubles (at least two of same value)
function hasDoubles(dice) {
  const c = {};
  dice.forEach(d => c[d] = (c[d]||0)+1);
  return Object.values(c).some(v => v >= 2);
}

// Helper: check if dice have even doubles (2s, 4s, or 6s)
function hasEvenDoubles(dice) {
  const c = {};
  dice.forEach(d => c[d] = (c[d]||0)+1);
  return (c[2] >= 2) || (c[4] >= 2) || (c[6] >= 2);
}

// Boris (343) — Fortify: when surge is spent, Boris gains 2 HP (overclocks past maxHp)
function triggerBorisHook(team) {
  team.ghosts.forEach(g => {
    if (g.id === 343 && !g.ko) {
      const before = g.hp;
      g.hp += 2; // overclocks — no cap
      log(`<span class="log-heal">${g.name}</span> — Fortify! Surge spent → +2 HP (${before}→${g.hp}/${g.maxHp}${g.hp > g.maxHp ? ' · overclocked!' : ''}).`);
    }
  });
}

// Cameron (25) — Unstoppable Force: opponent uses a special → Cameron's team gains +1 die
// Called with the team that USED the special — Cameron must be on the OPPOSING team.
// immediate=true: post-roll context (Lucky Stone, Moonstone) — roll an extra die and add it NOW.
// immediate=false (default): pre-roll context — store for Phase 2 dice computation next roll.
function triggerCameronSpecialWatch(usingTeam, immediate) {
  if (!B) return;
  const oppTeamName = usingTeam === 'red' ? 'blue' : 'red';
  const oppTeam = B[oppTeamName];
  if (!oppTeam) return;
  const cameronAlive = oppTeam.ghosts.some(g => g.id === 25 && !g.ko);
  if (!cameronAlive) return;
  const camGhost = oppTeam.ghosts.find(g => g.id === 25 && !g.ko);
  const loc = oppTeam.ghosts[oppTeam.activeIdx]?.id === 25 ? 'active' : 'sideline';

  if (immediate && B.pendingResolve) {
    // Post-roll: immediately roll 1 extra die and splice it into Cameron's team dice
    const extraDie = Math.floor(Math.random() * 6) + 1;
    const diceKey = oppTeamName === 'red' ? 'redDice' : 'blueDice';
    const prKey = oppTeamName === 'red' ? 'redDice' : 'blueDice';
    const dice = B.pendingResolve[prKey] || B[diceKey] || [];
    dice.push(extraDie);
    dice.sort((a, b) => a - b);
    B.pendingResolve[prKey] = dice;
    B[diceKey] = dice;
    renderDice(B.redDice, B.blueDice);
    log(`<span class="log-ability">${camGhost.name}</span> (${loc}) — Unstoppable Force! Opponent used a special → <span class="log-ms">+1 die rolled immediately! [${extraDie}]</span>`);
    showAbilityCallout('UNSTOPPABLE FORCE!', 'var(--common)', `${camGhost.name} — +1 die! Rolled a ${extraDie}!`, oppTeamName);
  } else {
    // Pre-roll: store for next roll's Phase 2 dice computation
    if (!B.cameronBonusDice) B.cameronBonusDice = { red: 0, blue: 0 };
    B.cameronBonusDice[oppTeamName]++;
    log(`<span class="log-ability">${camGhost.name}</span> (${loc}) — Unstoppable Force! Opponent used a special → <span class="log-ms">+1 die next roll!</span> (${B.cameronBonusDice[oppTeamName]} stored)`);
  }
}

// ========================================
// RESOURCE SPENDING
// ========================================
// v729: broadcast resource/committed changes live so opponent sees pre-roll decisions
function pvpBroadcastCommitted(team) {
  if (!LIVE_PVP || !PVP_GAME_REF || !B || team !== PVP_SIDE) return;
  const t = B[team];
  const f = active(t);
  PVP_GAME_REF.child('committedUpdate').set({
    side: team,
    committed: { ...B.committed[team] },
    resources: { ...t.resources },
    activeHp: f ? f.hp : 0,
    // v735: include burn state so opponent's engine knows about burn placement
    burn: B.burn ? { red: { ...B.burn.red }, blue: { ...B.burn.blue } } : null,
    burnSource: B.burnSource ? JSON.parse(JSON.stringify(B.burnSource)) : null,
    ts: Date.now()
  });
}

function cycleCommit(team, type) {
  if (!isPreRollActive(team)) return;
  const t = B[team];
  const c = B.committed[team];
  const f = active(t);
  const total = t.resources[type] + c[type];
  if (total <= 0) return;
  // Sylvia (313) — Free Ice Shards: commit without consuming, but cap at actual ice count
  if (type === 'ice' && f && f.id === 313) {
    const sylviaIceMax = t.resources.ice; // actual ice held (never decremented for Sylvia)
    if (c.ice < sylviaIceMax) {
      c.ice++;
      // Don't decrement t.resources.ice — ice is free for Sylvia
    } else {
      c.ice = 0; // cycle back to zero (uncommit)
    }
  } else {
    c[type]++;
    t.resources[type]--;
    if (c[type] > total) {
      t.resources[type] = total;
      c[type] = 0;
    }
  }
  // Narrate what just happened
  const teamLabel = team.charAt(0).toUpperCase() + team.slice(1);
  if (c[type] === 0) {
    narrate(`<b class="${team}-text">${teamLabel}</b> cleared ${type === 'ice' ? 'Ice Shards' : type === 'fire' ? 'Sacred Fires' : 'Surge'}.`);
  } else if (type === 'ice') {
    narrate(`<b class="${team}-text">${teamLabel}</b> committed <b>${c[type]} Ice Shard${c[type]>1?'s':''}</b> — <b class="gold">+${c[type]} damage</b> if you win!`);
  } else if (type === 'fire') {
    narrate(`<b class="${team}-text">${teamLabel}</b> committed <b>${c[type]} Sacred Fire${c[type]>1?'s':''}</b> — <b class="gold">+${c[type]*3} damage</b> if you win!`);
  } else if (type === 'surge') {
    narrate(`<b class="${team}-text">${teamLabel}</b> committed <b>${c[type]} Surge</b> — <b class="gold">+${c[type]} ${c[type]>1?'dice':'die'}</b> this roll!`);
  }
  playSfx('sfxSpecial', 0.3);
  // Carpenter (449) — transforms into Welder when a Surge is committed
  if (type === 'surge' && c[type] > 0 && f && f.id === 449 && !f.ko) {
    carpenterTransform(team);
  }
  // Cameron (25) — Unstoppable Force: opponent committed a special → Cameron gains +1 die
  if (c[type] > 0) triggerCameronSpecialWatch(team);
  renderBattle();
  pvpBroadcastCommitted(team);
}

function refundCommitted() {
  ['red', 'blue'].forEach(team => {
    const t = B[team];
    const c = B.committed[team];
    const f = active(t);
    // Sylvia (313) — ice was never consumed, so don't refund it
    if (!(f && f.id === 313)) {
      t.resources.ice += c.ice;
    }
    t.resources.fire += c.fire;
    t.resources.surge += c.surge;
    t.resources.healingSeed += c.auntSusan + c.auntSusanHeal + c.harrison;
    B.committed[team] = { ice:0, fire:0, surge:0, auntSusan:0, auntSusanHeal:0, harrison:0, zainBlade:0 };
  });
}

function spendHealingSeed(team) {
  if (!isPreRollActive(team)) return;
  const t = B[team];
  const f = active(t);
  if (t.resources.healingSeed <= 0 || f.hp >= f.maxHp) return;
  // Dark Fang (202) — Pressure: enemy ghost cannot heal
  if (deathHowlBlocksHealing(team)) {
    t.resources.healingSeed--;
    log(`<span class="log-ability">Dark Fang</span> — Pressure! ${f.name}'s Healing Seed consumed but healing blocked!`);
    renderBattle();
    return;
  }
  t.resources.healingSeed--;
  f.hp = Math.min(f.maxHp, f.hp + 1);
  playSfx('sfxSpecial', 0.4);
  log(`<span class="log-heal">${f.name}</span> used a Healing Seed! Healed to ${f.hp} HP.`);

  // Young Cap (429) — Energize: when active uses a Healing Seed, +1 die this roll + 1 Ice Shard + 1 Surge
  if (f.id === 429 && !f.ko) {
    if (!f.youngCapDieBonus) f.youngCapDieBonus = 0;
    f.youngCapDieBonus++;
    t.resources.ice++;
    t.resources.surge++;
    showAbilityCallout('ENERGIZE!', 'var(--uncommon)', `${f.name} — Healing Seed used! +1 die, +1 Ice Shard, +1 Surge!`, team);
    log(`<span class="log-ability">${f.name}</span> — Energize! Healing Seed → +1 die this roll, <span class="log-ice">+1 Ice Shard</span>, <span class="log-ms">+1 Surge</span>.`);
  }

  // Boopies (419) — Boopie Magic: sideline — when active spends Healing Seed, gain 1 Lucky Stone
  if (hasSideline(t, 419)) {
    t.resources.luckyStone++;
    const boopiesG = getSidelineGhost(t, 419);
    const boopiesName = boopiesG ? boopiesG.name : 'Boopies';
    showAbilityCallout('BOOPIE MAGIC!', 'var(--common)', `${boopiesName} (sideline) — Healing Seed spent! +1 Lucky Stone!`, team);
    log(`<span class="log-ability">${boopiesName}</span> — Boopie Magic! Healing Seed spent → <span class="log-ms">+1 Lucky Stone!</span>`);
  }

  // Cameron (25) — Unstoppable Force: opponent used a special
  triggerCameronSpecialWatch(team);

  renderBattle();
  pvpBroadcastCommitted(team);
}

function sacrificeHappyCrystal(team) {
  if (!isPreRollActive(team)) return;
  const t = B[team];
  const f = active(t);
  if (f.id !== 208 || f.ko) return;
  f.hp = 0; f.ko = true; f.killedBy = -1; // self-sacrifice
  t.resources.moonstone++;
  showAbilityCallout('SPARK STRIKE!', 'var(--moonstone)', `${f.name} sacrificed for 1 Moonstone!`, team);
  log(`<span class="log-ability">${f.name}</span> sacrifices itself! Gained <span class="log-ms">1 Moonstone</span>!`);
  if (!handleKOs()) renderBattle();
}

function toggleAuntSusan(team) {
  if (!isPreRollActive(team)) return;
  const tName = team;
  const t = B[team];
  const f = active(t);
  if (f.id !== 309 || f.ko) return;
  // Each click adds another seed to damage commit (click again to remove one)
  if (t.resources.healingSeed > 0) {
    B.committed[tName].auntSusan++;
    t.resources.healingSeed--;
  }
  renderBattle();
  pvpBroadcastCommitted(team);
}

function uncommitAuntSusan(team) {
  if (!isPreRollActive(team)) return;
  const tName = team;
  const t = B[team];
  if (B.committed[tName].auntSusan > 0) {
    B.committed[tName].auntSusan--;
    t.resources.healingSeed++;
  }
  renderBattle();
  pvpBroadcastCommitted(team);
}

function toggleAuntSusanHeal(team) {
  if (!isPreRollActive(team)) return;
  const tName = team;
  const t = B[team];
  const f = active(t);
  if (f.id !== 309 || f.ko) return;
  if (t.resources.healingSeed > 0) {
    B.committed[tName].auntSusanHeal++;
    t.resources.healingSeed--;
  }
  renderBattle();
}

function uncommitAuntSusanHeal(team) {
  if (!isPreRollActive(team)) return;
  const tName = team;
  const t = B[team];
  if (B.committed[tName].auntSusanHeal > 0) {
    B.committed[tName].auntSusanHeal--;
    t.resources.healingSeed++;
  }
  renderBattle();
}

// ============================================================
// HARRISON (315) — opt-in: spend 1 Healing Seed for +1 die
// ============================================================
function toggleHarrison(team) {
  if (!isPreRollActive(team)) return;
  const t = B[team];
  const f = active(t);
  if (f.id !== 315 || f.ko) return;
  // Click = add another seed, right-click to remove (handled separately)
  if (t.resources.healingSeed > 0) {
    B.committed[team].harrison++;
    t.resources.healingSeed--;
  }
  renderBattle();
}

function useFinnFlameBlade(team) {
  if (!isPreRollActive(team)) return;
  const t = B[team];
  // Finn must be on sideline or active (alive)
  const finnOnTeam = t.ghosts.some(g => g.id === 204 && !g.ko);
  if (!finnOnTeam) return;
  if (B.flameBlade && B.flameBlade[team]) return; // already forged
  if ((t.resources.healingSeed || 0) < 1 || (t.resources.fire || 0) < 1) return;
  t.resources.healingSeed -= 1;
  t.resources.fire -= 1;
  if (!B.flameBlade) B.flameBlade = { red: false, blue: false };
  B.flameBlade[team] = true;
  creditGhost(team, 204, 'ms', 1); // Finn earns MVP credit for forging
  log(`<span class="log-ability">Finn</span> — Forge! 1 Healing Seed + 1 Sacred Fire → <span class="log-ms">Flame Blade!</span> (permanent item)`);
  showAbilityCallout('FLAME BLADE!', 'var(--rare)', 'Finn forges the Flame Blade!', team);
  playSfx('sfxSpecial', 0.5);
  renderBattle();
}

// Carpenter (449) → Welder (450) transform: called when Surge is committed while Carpenter is active
function carpenterTransform(team) {
  const t = B[team];
  const g = active(t);
  if (g.id !== 449 || g.ko) return;
  // Preserve original identity
  g.originalId = g.originalId || g.id;
  g.originalName = g.originalName || g.name;
  g.originalArt = g.originalArt || g.art;
  g.originalMaxHp = g.originalMaxHp || g.maxHp;
  g.originalAbility = g.originalAbility || g.ability;
  g.originalAbilityDesc = g.originalAbilityDesc || g.abilityDesc;
  g.originalRarity = g.originalRarity || g.rarity;
  // Transform into Welder
  const welderData = ghostData(450);
  g.id = 450; g.name = welderData.name; g.maxHp = welderData.maxHp;
  g.hp = welderData.maxHp; // Full heal on evolution
  g.ability = welderData.ability; g.abilityDesc = welderData.abilityDesc;
  g.art = welderData.art; g.rarity = welderData.rarity;
  // Leave behind Carpenter's Hammer
  if (!B.carpenterHammer) B.carpenterHammer = { red: false, blue: false };
  B.carpenterHammer[team] = true;
  queueAbility('TRANSFORMATION!', 'var(--rare)', `Carpenter transforms into the Welder! Carpenter's Hammer forged! (+2 singles, permanent)`, null, team);
  log(`<span class="log-ability">Carpenter</span> — Evolution! <span class="log-ms">WELDER rises!</span> Carpenter's Hammer left behind!`);
  checkRipagooTransform(team);
  renderBattle();
}

// Welder (450) → Foreman (451) transform: called when any die shows a 4
function welderTransform(team) {
  const t = B[team];
  const g = active(t);
  if (g.id !== 450 || g.ko) return;
  // Preserve original identity (may already have original from Carpenter stage)
  g.originalId = g.originalId || g.id;
  g.originalName = g.originalName || g.name;
  g.originalArt = g.originalArt || g.art;
  g.originalMaxHp = g.originalMaxHp || g.maxHp;
  g.originalAbility = g.originalAbility || g.ability;
  g.originalAbilityDesc = g.originalAbilityDesc || g.abilityDesc;
  g.originalRarity = g.originalRarity || g.rarity;
  // Transform into Foreman
  const foremanData = ghostData(451);
  g.id = 451; g.name = foremanData.name; g.maxHp = foremanData.maxHp;
  g.hp = foremanData.maxHp; // Full heal on evolution
  g.ability = foremanData.ability; g.abilityDesc = foremanData.abilityDesc;
  g.art = foremanData.art; g.rarity = foremanData.rarity;
  // Leave behind Welder's Torch
  if (!B.welderTorch) B.welderTorch = { red: false, blue: false };
  B.welderTorch[team] = true;
  queueAbility('TRANSFORMATION!', 'var(--rare)', `Welder transforms into the Foreman! Welder's Torch forged! (burns +1, wins give Burn, permanent)`, null, team);
  log(`<span class="log-ability">Welder</span> — Evolution! <span class="log-ms">FOREMAN rises!</span> Welder's Torch left behind!`);
  checkRipagooTransform(team);
  renderBattle();
}

// Ripagoo (452) — Chemical Y: sideline — if a card in play transforms, gain 2 Burn
function checkRipagooTransform(team) {
  const t = B[team];
  if (hasSideline(t, 452)) {
    if (!t.resources.burn) t.resources.burn = 0;
    t.resources.burn += 2;
    const rg = getSidelineGhost(t, 452);
    const rName = rg ? rg.name : 'Ripagoo';
    popSidelineCard(t, 452);
    showAbilityCallout('CHEMICAL Y!', 'var(--uncommon)', `${rName} (sideline) — Transformation detected! +2 Burn!`, team);
    log(`<span class="log-ability">${rName}</span> — Chemical Y! Transformation → <span class="log-burn">+2 Burn!</span>`);
    renderBattle();
  }
}

function toggleFlameBlade(team) {
  if (!isPreRollActive(team)) return;
  if (!B.flameBlade || !B.flameBlade[team]) return;
  if (!B.flameBladeSwing) B.flameBladeSwing = { red: false, blue: false };
  B.flameBladeSwing[team] = !B.flameBladeSwing[team];
  renderBattle();
}

function toggleIceBlade(team) {
  if (!isPreRollActive(team)) return;
  if (!B.iceBladeForgedPermanent || !B.iceBladeForgedPermanent[team]) return;
  if (!B.iceBladeSwing) B.iceBladeSwing = { red: false, blue: false };
  B.iceBladeSwing[team] = !B.iceBladeSwing[team];
  // Keep backward compat with committed.zainBlade toggle
  B.committed[team].zainBlade = B.iceBladeSwing[team] ? 1 : 0;
  renderBattle();
}

function useZainForge(team) {
  if (!isPreRollActive(team)) return;
  const t = B[team];
  // Zain can forge from sideline or active — find him wherever he is
  const zain = t.ghosts.find(g => g.id === 206 && !g.ko);
  if (!zain) return;
  if (zain.iceBladeForged) return; // already forged — permanent, can't re-forge
  if (B.iceBladeForgedPermanent[team]) return;
  if (t.resources.ice < 1 || t.resources.moonstone < 1) return;
  t.resources.ice -= 1;
  t.resources.moonstone -= 1;
  zain.iceBladeForged = true;
  B.iceBladeForgedPermanent[team] = true; // permanent +2 damage for the rest of the game
  log(`<span class="log-ability">${zain.name}</span> — Ice Blade forged! Spent <span class="log-ice">1 Ice Shard</span> + <span class="log-ms">1 Moonstone</span>. Permanent +2 damage on ALL winning rolls for the rest of the game!`);
  showAbilityCallout('ICE BLADE!', 'var(--ghost-rare)', `${zain.name} forges the Ice Blade — permanent +2 damage on ALL wins!`, team);
  playSfx('sfxSpecial', 0.5);
  renderBattle();
}

// Per-round commit toggle: Zain (forged) chooses whether to swing the blade this round
// Kept for backward compat — delegates to new toggleIceBlade
function toggleZainBlade(team) {
  toggleIceBlade(team);
}

function uncommitHarrison(team) {
  if (!isPreRollActive(team)) return;
  const t = B[team];
  if (B.committed[team].harrison > 0) {
    B.committed[team].harrison--;
    t.resources.healingSeed++;
  }
  renderBattle();
}

// ============================================================
// KNIGHT EFFECTS — Heavy Air (401) & Retribution (402)
// ============================================================
function checkKnightEffects(abilityTeamName, abilityGhostName, sidelineGhost, deferredHeavyAir) {
  // abilityTeamName = the team whose ability is triggering
  // sidelineGhost = optional: the sideline ghost using the ability (if not the active fighter)
  // deferredHeavyAir = optional array: if provided, Heavy Air damage is stored here instead of applied immediately
  // The OPPONENT of that team might have Heavy Air or Retribution
  const oppTeamName = abilityTeamName === 'red' ? 'blue' : 'red';
  const oppTeam = B[oppTeamName];
  const oppActive = active(oppTeam);

  // Heavy Air (401) — after opponent ability resolves, enemy active ghost loses 2 HP
  if (oppActive.id === 401 && !oppActive.ko) {
    const abilityTeam = B[abilityTeamName];
    const target = active(abilityTeam);
    if (!target.ko) {
      if (deferredHeavyAir) {
        // Deferred mode: store the hit, apply only if Knight Terror survives the round
        deferredHeavyAir.push({ target, targetName: target.name, oppTeamName });
      } else {
        target.hp = Math.max(0, target.hp - 2);
        if (target.hp <= 0) { target.ko = true; target.killedBy = 401; }
        const targetName = target.name;
        if (abilityQueueMode) {
          queueAbility('HEAVY AIR!', 'var(--rare)', `Knight Terror — ${targetName} loses 2 HP!`, null, oppTeamName);
        } else {
          showAbilityCallout('HEAVY AIR!', 'var(--rare)', `Knight Terror — ${targetName} loses 2 HP!`, oppTeamName);
        }
        log(`<span class="log-ability">Knight Terror</span> — Heavy Air! <span class="log-dmg">${targetName} loses 2 HP!</span> ${target.ko ? '<span class="log-ko">KO!</span>' : target.hp + ' HP left'}`);
      }
    }
  }

  // Retribution (402) — gain +1 die next roll when opponent uses ability
  if (oppActive.id === 402 && !oppActive.ko) {
    if (!B.retributionDice) B.retributionDice = { red: 0, blue: 0 };
    B.retributionDice[oppTeamName]++;
    if (abilityQueueMode) {
      queueAbility('RETRIBUTION!', 'var(--rare)', `Knight Light — opponent used ability! +1 die next roll!`, null, oppTeamName);
    } else {
      showAbilityCallout('RETRIBUTION!', 'var(--rare)', `Knight Light — opponent used ability! +1 die next roll!`, oppTeamName);
    }
    log(`<span class="log-ability">Knight Light</span> — Retribution! <span class="log-ms">+1 die next roll!</span> (${B.retributionDice[oppTeamName]} stored)`);
  }
}

// ============================================================
// BLACKOUT — Smudge (403): name a number
// ============================================================
function setBlackout(team, num) {
  if (!isPreRollActive(team)) return; // Blackout is pre-roll only
  if (!B.blackoutNum) B.blackoutNum = {};
  if (B.blackoutNum[team] === num) {
    delete B.blackoutNum[team]; // toggle off
  } else {
    B.blackoutNum[team] = num;
  }
  renderBattle();
}

// ============================================================
// TYSON HOP — manual pre-roll swap (Tyson 365)
// ============================================================
function useTysonHop(team) {
  if (!isPreRollActive(team)) return;
  const t = B[team];
  const f = active(t);
  if (f.id !== 365 || f.ko) return;

  const enemy = opp(t);
  if (dylanNegates(enemy)) {
    showAbilityCallout('BLOCKED!', 'var(--text2)', `Dylan's Scarecrow shuts down Tyson's Hop!`, team === B.red ? 'blue' : 'red');
    log(`<span class="log-ability">Tyson</span> — Hop blocked by <span class="log-ability">Dylan's Scarecrow</span>!`);
    return;
  }
  const aliveSideline = t.ghosts.filter((g,i) => i !== t.activeIdx && !g.ko);
  if (aliveSideline.length === 0) return;

  log(`<span class="log-ability">${f.name}</span> — Hop! Swapping out, no entry effects for incoming ghost.`);
  // Queue HOP! + any Knight reactions sequentially before opening the swap modal
  abilityQueueMode = true;
  queueAbility('HOP!', 'var(--common)', `${f.name} hops to the bench — no entry triggers!`, null, team);
  checkKnightEffects(team, f.name);
  abilityQueueMode = false;
  // Open the standard swap modal only after all callouts finish playing
  drainAbilityQueue(() => openSwap(team));
}

// ============================================================
// PRESSURE — manual pre-roll ability (Dark Fang 202)
// ============================================================
function usePressure(team) {
  if (!isPreRollActive(team)) return;
  const t = B[team];
  const f = active(t);
  const enemy = opp(t);
  const enemyTeamName = team === 'red' ? 'blue' : 'red';
  if (f.id !== 202 || f.ko || dylanNegates(enemy)) return;

  // Barnaby (326) — Stubborn: immune to forced swaps by opponent effects
  const _barnabyPressure = active(enemy);
  if (_barnabyPressure && _barnabyPressure.id === 326 && !_barnabyPressure.ko) {
    log(`<span class="log-ability">Barnaby</span> — Stubborn! Dark Fang's Pressure is blocked — ${_barnabyPressure.name} cannot be forced out.`);
    narrate(`<b class="${team}-text">Dark Fang</b> — Pressure blocked! <b>${_barnabyPressure.name}</b> refuses to leave!`);
    return;
  }

  const aliveSideline = enemy.ghosts.filter((g,i) => i !== enemy.activeIdx && !g.ko);
  if (aliveSideline.length === 0) return;

  // If only one option, auto-pick
  if (aliveSideline.length === 1) {
    doPressureSwap(team, enemy.ghosts.indexOf(aliveSideline[0]));
    return;
  }

  // Open pressure picker for the OPPONENT to choose who comes in
  const enemyLabel = enemyTeamName.charAt(0).toUpperCase() + enemyTeamName.slice(1);
  // Update the "who picks" banner with the correct team color
  const whoBanner = document.getElementById('pressureWho');
  whoBanner.className = `pm-who-banner ${enemyTeamName}`;
  whoBanner.textContent = `🎯 ${enemyLabel.toUpperCase()} PICKS`;
  document.getElementById('pressureTitle').textContent = `Pressure! — Dark Fang forces a swap`;
  document.getElementById('pressureSub').textContent = `${enemyLabel} team: choose which ghost enters the fight.`;
  document.getElementById('pressureOptions').innerHTML = aliveSideline.map(g => {
    const realIdx = enemy.ghosts.indexOf(g);
    const gd = ghostData(g.id);
    const hpRatio = g.hp / g.maxHp;
    const hpColor = hpRatio > 0.6 ? 'var(--hp-green)' : hpRatio > 0.3 ? 'var(--hp-yellow)' : 'var(--hp-red)';
    return `<div class="pressure-opt" onclick="doPressureSwap('${team}',${realIdx})">
      ${gd.art ? `<img src="${gd.art}" style="width:50px; height:50px; border-radius:6px; object-fit:cover; border:1px solid var(--${gd.rarity});">` : ''}
      <div>
        <div style="font-weight:700;">${g.name}</div>
        <div style="font-size:12px; color:var(--text2);"><span style="color:${hpColor}; font-weight:700;">&hearts; ${g.hp}/${g.maxHp}</span> &middot; <span style="color:var(--moonstone);">${gd.ability}</span></div>
      </div>
    </div>`;
  }).join('');
  // Lock out Roll buttons while the opponent picks — phase resets to 'ready' in doPressureSwap
  B.phase = 'pressure';
  B.pressurePickerTeam = enemyTeamName; // v728: track which team picks (for PvP auto-resolve)
  document.getElementById('pressureOverlay').classList.add('active');
}

function doPressureSwap(attackerTeam, targetIdx) {
  document.getElementById('pressureOverlay').classList.remove('active');
  // Lock roll buttons for the full PRESSURE! + entry callout chain.
  // Previously: immediately restored B.phase='ready' (or left it 'ready' in the auto-pick
  // path), which meant both roll buttons were live during the 1500ms PRESSURE! splash and
  // any subsequent entry callouts (LEVIATHAN!, BIG TARGET!, SLUMBER!, etc.) — players could
  // click Roll mid-callout.  Now we park in 'ko-pause' and only restore 'ready' AFTER the
  // full chain finishes (same pattern used by doKoSwap, Timber, Selene, etc.).
  B.phase = 'ko-pause';
  // Mark Pressure as used for this round — prevents double-use when opponent has 2 sideline ghosts
  if (!B.pressureUsed) B.pressureUsed = { red: false, blue: false };
  B.pressureUsed[attackerTeam] = true;
  const t = B[attackerTeam];
  const f = active(t);
  const enemy = opp(t);
  const oldGhost = active(enemy);
  const oldName = oldGhost.name;
  // Pressure is a forced swap by Dark Fang — NOT Tyson's voluntary Hop.
  // Entry effects always fire for the incoming ghost regardless of who was forced out.
  enemy.activeIdx = targetIdx;
  const newGhost = active(enemy);
  // Returning from sideline = full HP
  newGhost.hp = newGhost.maxHp;
  // Narrate the swap so there's textual context in the narrator div for BOTH the auto-pick path
  // (single sideline ghost — no modal, no prior narration) and the manual-pick path (modal closes
  // silently).  Without this, the player just sees the PRESSURE! splash with zero narrator context.
  const attackerCls = attackerTeam === 'red' ? 'red-text' : 'blue-text';
  narrate(`<b class="${attackerCls}">${f.name}</b> — Pressure! <b>${oldName}</b> forced to the sideline — <b>${newGhost.name}</b> enters at full HP!`);
  showAbilityCallout('PRESSURE!', 'var(--rare)', `${oldName} forced out — ${newGhost.name} enters!`, attackerTeam);
  log(`<span class="log-ability">${f.name}</span> — Pressure! Forced ${oldName} out, ${newGhost.name} enters at full HP!`);
  // Delay entry effects by 1500ms so PRESSURE! fully displays before the first entry callout
  // fires (triggerEntry's first setTimeout is at i=0 → ~0ms, which stomped PRESSURE! instantly).
  setTimeout(() => {
    const entryCalloutCount = triggerEntry(enemy, false);
    afterEntryWithJenkins(entryCalloutCount, () => {
      if (!handleKOs()) { startNextRound(); }
    });
  }, spd(1500));
}

// ============================================================
// SELENE — Heart of the Hills in-game choice modal
// ============================================================
function showSeleneModal() {
  const sp = B.selenePending;
  const f = active(sp.team);
  const tName = sp.tName;
  const teamLabel = tName.charAt(0).toUpperCase() + tName.slice(1);
  const bannerEl = document.getElementById('seleneBanner');
  if (bannerEl) {
    bannerEl.textContent = `⛰️ ${teamLabel.toUpperCase()} PICKS`;
    bannerEl.className = `selene-banner ${tName}`;
  }
  const titleEl = document.getElementById('seleneTitle');
  if (titleEl) titleEl.textContent = `${f.name} — Heart of the Hills!`;
  narrate(`<b class="${tName}-text">${f.name}</b>&nbsp;rolled <b class="gold">DOUBLES!</b>&nbsp;Choose your reward!`);
  document.getElementById('seleneOverlay').classList.add('active');
}

function doSeleneChoice(choice) {
  const sp = B.selenePending;
  if (!sp) return; // guard against double-click
  const cont = sp._continue;
  B.selenePending = null;
  document.getElementById('seleneOverlay').classList.remove('active');
  const f = active(sp.team);
  const _selTeam = sp.team;
  const _selName = f.name;
  const subtitle = choice === 'seed'
    ? `${f.name} — Doubles! Chose 🌱 2 Healing Seeds!`
    : `${f.name} — Doubles! Chose 🍀 3 Lucky Stones!`;
  // Queue mode: HEART OF THE HILLS first, then knight reactions, then drain sequentially.
  // Grant is deferred into onShow so the resource counter updates exactly when the callout
  // fires — same deferred-onShow pattern as Hank Tremor (v307), Natalia/Kaplan (v308).
  abilityQueueMode = true;
  queueAbility('HEART OF THE HILLS!', 'var(--legendary)', subtitle, () => {
    if (choice === 'seed') {
      _selTeam.resources.healingSeed += 2;
      log(`<span class="log-ability">${_selName}</span> — Heart of the Hills! Doubles → chose <span class="log-ms">2 Healing Seeds</span>!`);
    } else {
      _selTeam.resources.luckyStone += 3;
      // Update lsAvailable so the post-roll Lucky Stone window sees these new stones
      if (B.lsAvailable) B.lsAvailable[sp.tName] = (B.lsAvailable[sp.tName] || 0) + 3;
      log(`<span class="log-ability">${_selName}</span> — Heart of the Hills! Doubles → chose <span class="log-ms">3 Lucky Stones</span>!`);
    }
    renderBattle();
  }, sp.tName);
  checkKnightEffects(sp.tName, f.name); // queues HEAVY AIR! or RETRIBUTION! if applicable
  // Sandwiches (33) — Dependable: mirror the chosen resource to opponent if Sandwiches on sideline.
  // Capture totals at queue-build time (before any grant fires) so the preview subtitle is correct.
  if (hasOnTeam(opp(sp.team), 33)) {
    if (choice === 'seed') {
      const _sandSeedOpp = opp(sp.team);
      const _sandSeedTotal = _sandSeedOpp.resources.healingSeed + 2;
      queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Heart of the Hills! +2 Healing Seeds! (${_sandSeedTotal} total)`, () => { _sandSeedOpp.resources.healingSeed += 2; renderBattle(); }, sp.tName === 'red' ? 'blue' : 'red');
    } else {
      const _sandLSOpp = opp(sp.team);
      const _sandLSTotal = _sandLSOpp.resources.luckyStone + 3;
      queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Heart of the Hills! +3 Lucky Stones! (${_sandLSTotal} total)`, () => { _sandLSOpp.resources.luckyStone += 3; renderBattle(); }, sp.tName === 'red' ? 'blue' : 'red');
    }
  }
  abilityQueueMode = false;
  // drainAbilityQueue plays each splash 1300ms apart and calls cont() after all finish.
  drainAbilityQueue(() => { if (cont) cont(); });
}

// Pal Al (431) — Squall: show choice modal
function showWiseAlModal(resumeCallback) {
  const wp = B.wiseAlPending;
  if (!wp) { resumeCallback(); return; }
  wp.resume = resumeCallback;
  document.getElementById('wiseAlSub').textContent = `Deal ${wp.dmg} damage or gain 4 Ice Shards?`;
  document.getElementById('wiseAlDmgBtn').textContent = `⚔️ Deal ${wp.dmg} Damage`;
  document.getElementById('wiseAlOverlay').classList.add('active');
}

function doWiseAlChoice(choice) {
  const wp = B.wiseAlPending;
  if (!wp) return;
  B.wiseAlPending = null;
  document.getElementById('wiseAlOverlay').classList.remove('active');
  if (choice === 'ice') {
    wp.winTeam.resources.ice = (wp.winTeam.resources.ice || 0) + 4;
    checkKnightEffects(wp.winTeamName, wp.wF.name);
    log(`<span class="log-ability">${wp.wF.name}</span> — Squall! <span class="log-ice">+4 Ice Shards</span> instead of dealing damage!`);
    queueAbility('SQUALL!', 'var(--rare)', `${wp.wF.name} — +4 ❄️ Ice Shards instead of dealing damage!`, () => { renderBattle(); }, wp.winTeamName);
  } else {
    // Deal the stashed damage
    wp.lF.hp = Math.max(0, wp.lF.hp - wp.dmg);
    if (wp.lF.hp <= 0) { wp.lF.ko = true; wp.lF.killedBy = (wp.wF.originalId || wp.wF.id); }
    log(`<span class="log-dmg">${wp.wF.name} deals ${wp.dmg} to ${wp.lF.name}!</span> ${wp.lF.ko?'<span class="log-ko">KO!</span>':wp.lF.hp+' HP left'}`);
    renderBattle();
  }
  drainAbilityQueue(() => { if (wp.resume) wp.resume(); });
}

// Sophia (457) — Masquerade: show choice modal
function showSophiaModal(resumeCallback) {
  const sp = B.sophiaPending;
  if (!sp) { resumeCallback(); return; }
  sp.resume = resumeCallback;
  document.getElementById('sophiaSub').textContent = `Deal ${sp.dmg} damage or gain a mask (once per game)?`;
  document.getElementById('sophiaDmgBtn').textContent = `⚔️ Deal ${sp.dmg} Damage`;
  document.getElementById('sophiaOverlay').classList.add('active');
}

function doSophiaChoice(choice) {
  const sp = B.sophiaPending;
  if (!sp) return;
  B.sophiaPending = null;
  document.getElementById('sophiaOverlay').classList.remove('active');
  if (choice === 'day' || choice === 'night') {
    B.sophiaMask[sp.winTeamName] = choice;
    B.sophiaMaskActive[sp.winTeamName] = true;
    const maskName = choice === 'day' ? '☀️ Mask of Day' : '🌙 Mask of Night';
    const maskDesc = choice === 'day' ? 'Gain 1 Burn for each 1 or 2 you roll' : 'Roll the same number of dice as the enemy ghost, +1 damage';
    checkKnightEffects(sp.winTeamName, sp.wF.name);
    log(`<span class="log-ability">${sp.wF.name}</span> — Masquerade! Gained <b>${maskName}</b> instead of dealing damage! (${maskDesc})`);
    queueAbility('MASQUERADE!', 'var(--rare)', `${sp.wF.name} — ${maskName}! ${maskDesc}`, () => { renderBattle(); }, sp.winTeamName);
  } else {
    // Deal the stashed damage
    sp.lF.hp = Math.max(0, sp.lF.hp - sp.dmg);
    if (sp.lF.hp <= 0) { sp.lF.ko = true; sp.lF.killedBy = (sp.wF.originalId || sp.wF.id); }
    log(`<span class="log-dmg">${sp.wF.name} deals ${sp.dmg} to ${sp.lF.name}!</span> ${sp.lF.ko?'<span class="log-ko">KO!</span>':sp.lF.hp+' HP left'}`);
    renderBattle();
  }
  drainAbilityQueue(() => { if (sp.resume) sp.resume(); });
}

function toggleSophiaMask(team) {
  if (!isPreRollActive(team)) return;
  if (!B.sophiaMask[team]) return;
  B.sophiaMaskActive[team] = !B.sophiaMaskActive[team];
  renderBattle();
}

// Gordok (430) — River Terror: show choice modal
function showGordokModal(resumeCallback) {
  const gp = B.gordokPending;
  if (!gp) { resumeCallback(); return; }
  gp.resume = resumeCallback;
  document.getElementById('gordokSub').textContent = `Deal ${gp.dmg} damage or steal up to 2 resources?`;
  document.getElementById('gordokDmgBtn').textContent = `⚔️ Deal ${gp.dmg} Damage`;
  document.getElementById('gordokOverlay').classList.add('active');
}

function doGordokChoice(choice) {
  const gp = B.gordokPending;
  if (!gp) return;
  B.gordokPending = null;
  document.getElementById('gordokOverlay').classList.remove('active');
  if (choice === 'steal') {
    const gordokOppRes = gp.loseTeam.resources;
    const gordokResTypes = ['ice', 'fire', 'surge', 'luckyStone', 'moonstone', 'healingSeed'];
    let gordokStolen = 0;
    const gordokStolenList = [];
    for (let i = 0; i < 2 && gordokStolen < 2; i++) {
      const avail = gordokResTypes.filter(r => (gordokOppRes[r] || 0) > 0);
      if (avail.length === 0) break;
      const pick = avail[Math.floor(Math.random() * avail.length)];
      gordokOppRes[pick]--;
      gp.winTeam.resources[pick] = (gp.winTeam.resources[pick] || 0) + 1;
      gordokStolenList.push(pick);
      gordokStolen++;
    }
    if (!B.gordokDieBonus) B.gordokDieBonus = { red: 0, blue: 0 };
    B.gordokDieBonus[gp.winTeamName] = 1;
    gp.winTeam.resources.moonstone++;
    checkKnightEffects(gp.winTeamName, gp.wF.name);
    log(`<span class="log-ability">${gp.wF.name}</span> — River Terror! Stole ${gordokStolenList.join(', ')} instead of dealing damage! <span class="log-ice">+1 die next roll!</span> <span class="log-ms">+1 Moonstone!</span>`);
    queueAbility('RIVER TERROR!', 'var(--rare)', `${gp.wF.name} — stole resources instead of dealing damage! +1 Moonstone!`, () => { renderBattle(); }, gp.winTeamName);
  } else {
    // Deal the stashed damage
    gp.lF.hp = Math.max(0, gp.lF.hp - gp.dmg);
    if (gp.lF.hp <= 0) { gp.lF.ko = true; gp.lF.killedBy = (gp.wF.originalId || gp.wF.id); }
    log(`<span class="log-dmg">${gp.wF.name} deals ${gp.dmg} to ${gp.lF.name}!</span> ${gp.lF.ko?'<span class="log-ko">KO!</span>':gp.lF.hp+' HP left'}`);
    renderBattle();
  }
  drainAbilityQueue(() => { if (gp.resume) gp.resume(); });
}

// Timber (210) — Howl choice modal
function showTimberModal(tp, resumeCallback) {
  const oppLabel = tp.oppTeamName.charAt(0).toUpperCase() + tp.oppTeamName.slice(1);
  const bannerEl = document.getElementById('timberBanner');
  if (bannerEl) {
    bannerEl.textContent = `🐺 ${oppLabel.toUpperCase()} MUST CHOOSE`;
    bannerEl.className = `selene-banner ${tp.oppTeamName}`;
    bannerEl.style.background = 'linear-gradient(135deg,#4a2c0a,#7c4a1a)';
  }
  const titleEl = document.getElementById('timberTitle');
  if (titleEl) titleEl.textContent = `Timber — Howl!`;
  const subEl = document.getElementById('timberSub');
  if (subEl) subEl.textContent = `${oppLabel}: choose your fate!`;
  // Disable discard button if opponent has fewer than 2 specials — they must take the die penalty
  const discardBtn = document.getElementById('timberDiscardBtn');
  if (discardBtn) {
    const r = tp.team.resources;
    const totalSpecials = ['surge','ice','healingSeed','luckyStone','fire','moonstone']
      .reduce((sum, t) => sum + (r[t] || 0), 0);
    discardBtn.disabled = totalSpecials < 2;
  }
  narrate(`<b class="${tp.oppTeamName}-text">${oppLabel}</b>&nbsp;faces <b class="gold">TIMBER!</b>&nbsp;Discard 2 specials or lose a die!`);
  B.timberPending._resumeCallback = resumeCallback;
  document.getElementById('timberOverlay').classList.add('active');
}

function doTimberChoice(choice) {
  const tp = B.timberPending;
  if (!tp) return;
  const resume = tp._resumeCallback;
  const oppLabel = tp.oppTeamName.charAt(0).toUpperCase() + tp.oppTeamName.slice(1);
  const timberGhost = active(B[tp.timberTeam]);
  const timberName = timberGhost ? timberGhost.name : 'Timber';
  B.timberPending = null;
  document.getElementById('timberOverlay').classList.remove('active');
  let subtitle;
  if (choice === 'discard') {
    // Discard 2 specials from most abundant first
    const r = tp.team.resources;
    let toDiscard = 2;
    const types = ['surge','ice','healingSeed','luckyStone','fire','moonstone'];
    types.sort((a,b) => (r[b]||0) - (r[a]||0));
    for (const t of types) {
      while (toDiscard > 0 && (r[t]||0) > 0) {
        r[t]--;
        toDiscard--;
      }
    }
    subtitle = `${oppLabel} discards 2 specials to keep all dice!`;
    log(`<span class="log-ability">${oppLabel}</span> chose to discard 2 specials to avoid Timber's Howl!`);
  } else {
    // Lose 1 die
    if (tp.oppTeamName === 'red') B.preRoll.red.count = Math.max(1, B.preRoll.red.count - 1);
    else B.preRoll.blue.count = Math.max(1, B.preRoll.blue.count - 1);
    subtitle = `${oppLabel} rolls 1 fewer die!`;
    log(`<span class="log-ability">${oppLabel}</span> chose to roll 1 fewer die under Timber's Howl!`);
  }
  renderBattle();
  // Queue mode: HOWL! first, then any knight reactions (HEAVY AIR! / RETRIBUTION!),
  // then drain sequentially. Mirrors the doSeleneChoice pattern from v90.
  // _oppBtn unlocked and resume() called only after the full callout chain completes.
  abilityQueueMode = true;
  queueAbility('HOWL!', 'var(--legendary)', subtitle, null, tp.timberTeam);
  checkKnightEffects(tp.timberTeam, timberName); // queues HEAVY AIR! or RETRIBUTION! if applicable
  abilityQueueMode = false;
  drainAbilityQueue(() => {
    if (tp._oppBtn) { tp._oppBtn.classList.remove('locked'); tp._oppBtn.disabled = false; }
    if (resume) resume();
  });
}

// Ryder (456) — Toll choice modal
function showRiderModal(tp, resumeCallback) {
  const oppLabel = tp.oppTeamName.charAt(0).toUpperCase() + tp.oppTeamName.slice(1);
  const bannerEl = document.getElementById('riderBanner');
  if (bannerEl) {
    bannerEl.textContent = `⚔️ ${oppLabel.toUpperCase()} MUST CHOOSE`;
    bannerEl.className = `selene-banner ${tp.oppTeamName}`;
    bannerEl.style.background = 'linear-gradient(135deg,#1a1a2e,#4a1942)';
  }
  const titleEl = document.getElementById('riderTitle');
  if (titleEl) titleEl.textContent = `Ryder — Toll!`;
  const subEl = document.getElementById('riderSub');
  if (subEl) subEl.textContent = `${oppLabel}: pay the toll!`;
  narrate(`<b class="${tp.oppTeamName}-text">${oppLabel}</b>&nbsp;faces <b class="gold">RYDER!</b>&nbsp;Take 1 damage or give Ryder Sacred Fire!`);
  B.riderPending._resumeCallback = resumeCallback;
  document.getElementById('riderOverlay').classList.add('active');
}

function doRiderChoice(choice) {
  const tp = B.riderPending;
  if (!tp) return;
  const resume = tp._resumeCallback;
  const oppLabel = tp.oppTeamName.charAt(0).toUpperCase() + tp.oppTeamName.slice(1);
  const riderGhost = active(B[tp.riderTeam]);
  const riderName = riderGhost ? riderGhost.name : 'Ryder';
  B.riderPending = null;
  document.getElementById('riderOverlay').classList.remove('active');
  let subtitle;
  if (choice === 'damage') {
    // Opponent takes 1 damage
    const oppGhost = active(tp.team);
    if (oppGhost && !oppGhost.ko) {
      oppGhost.hp = Math.max(0, oppGhost.hp - 1);
      if (oppGhost.hp <= 0) { oppGhost.hp = 0; oppGhost.ko = true; oppGhost.killedBy = 456; }
      subtitle = `${oppLabel}'s ${oppGhost.name} takes 1 damage! (${oppGhost.hp}/${oppGhost.maxHp} HP)`;
      log(`<span class="log-ability">${oppLabel}</span> chose to take 1 damage from Ryder's Toll! ${oppGhost.name} → ${oppGhost.hp}/${oppGhost.maxHp} HP.`);
      // Simon (24) — Brew Time: gain 1 Sacred Fire when taking ANY damage
      if (oppGhost.id === 24 && !oppGhost.ko) {
        tp.team.resources.fire = (tp.team.resources.fire || 0) + 2;
        queueAbility('BREW TIME!', 'var(--uncommon)', `Simon — Took Toll damage → +2 Sacred Fire!`, tp.oppTeamName);
        log(`<span class="log-ability">Simon</span> — Brew Time! Took Toll damage → <span class="log-ms">+1 Sacred Fire!</span>`);
      }
      // Princess Shade (436) — Bounty: +1 additional damage on pre-roll chip, works from sideline OR active (blocked by Cornelius 45)
      if (!oppGhost.ko && hasAlive(B[tp.riderTeam], 436) && !hasSideline(tp.team, 45)) {
        oppGhost.hp = Math.max(0, oppGhost.hp - 1);
        if (oppGhost.hp <= 0) { oppGhost.hp = 0; oppGhost.ko = true; oppGhost.killedBy = 436; }
        queueAbility('BOUNTY!', 'var(--rare)', `Princess Shade — +1 additional damage to ${oppGhost.name}!`, tp.riderTeam);
        log(`<span class="log-ability">Princess Shade</span> — Bounty! <span class="log-dmg">+1 additional damage to ${oppGhost.name}!</span> ${oppGhost.ko?'<span class="log-ko">KO!</span>':oppGhost.hp+' HP left'}`);
        popSidelineCard(B[tp.riderTeam], 436);
        // Simon takes Bounty damage too
        if (oppGhost.id === 24 && !oppGhost.ko) {
          tp.team.resources.fire = (tp.team.resources.fire || 0) + 1;
          queueAbility('BREW TIME!', 'var(--uncommon)', `Simon — Took Bounty damage → +2 Sacred Fire!`, tp.oppTeamName);
          log(`<span class="log-ability">Simon</span> — Brew Time! Took Bounty damage → <span class="log-ms">+1 Sacred Fire!</span>`);
        }
      } else if (!oppGhost.ko && hasAlive(B[tp.riderTeam], 436) && hasSideline(tp.team, 45)) {
        const cornGhost = getSidelineGhost(tp.team, 45);
        queueAbility('ANTIDOTE!', 'var(--uncommon)', `${cornGhost ? cornGhost.name : 'Cornelius'} blocks Princess Shade's Bounty!`, tp.oppTeamName);
        log(`<span class="log-ability">Cornelius</span> (sideline) — Antidote! Princess Shade Bounty blocked!`);
      }
    }
  } else {
    // Give Ryder +1 Sacred Fire
    const riderTeamObj = B[tp.riderTeam];
    riderTeamObj.resources.fire = (riderTeamObj.resources.fire || 0) + 1;
    subtitle = `${riderName} gains +1 Sacred Fire! (${riderTeamObj.resources.fire} total)`;
    log(`<span class="log-ability">${oppLabel}</span> chose to give ${riderName} +1 Sacred Fire! (${riderTeamObj.resources.fire} total)`);
  }
  renderBattle();
  abilityQueueMode = true;
  queueAbility('TOLL!', 'var(--rare)', subtitle, null, tp.riderTeam);
  checkKnightEffects(tp.riderTeam, riderName);
  abilityQueueMode = false;
  drainAbilityQueue(() => {
    if (tp._oppBtn) { tp._oppBtn.classList.remove('locked'); tp._oppBtn.disabled = false; }
    if (resume) resume();
  });
}

// Sylvia (313) — Porpoise: when Sylvia loses a roll, player rolls 1 die.
// A 6 negates all damage. Player-driven dice reveal so there's real agency.
// Called from resolveRound right after winner determination, before any
// damage computation (which reads B.sylviaPendingResult at line ~8141).
function showSylviaModal(loseTeamName, resumeCallback) {
  const lF = active(B[loseTeamName]);
  B.phase = 'sylvia-roll';
  B.sylviaPendingResult = null; // cleared so Sylvia block at 8141 knows to wait for this modal
  B.sylviaResume = resumeCallback;
  B.sylviaTeamName = loseTeamName;

  const titleEl = document.getElementById('sylviaTitle');
  if (titleEl) titleEl.textContent = `${lF ? lF.name : 'Sylvia'} — Porpoise!`;
  const subEl = document.getElementById('sylviaSub');
  if (subEl) subEl.innerHTML = `Roll a <b>5 or 6</b> to dodge all damage!`;
  const dieEl = document.getElementById('sylviaDie');
  if (dieEl) {
    dieEl.textContent = '?';
    dieEl.style.transform = 'rotate(0deg)';
  }
  const btn = document.getElementById('sylviaRollBtn');
  if (btn) { btn.disabled = false; btn.textContent = '🌊 Roll the Die!'; }

  narrate(`<b class="${loseTeamName}-text">${lF ? lF.name : 'Sylvia'}</b>&nbsp;rolls for <b class="gold">PORPOISE!</b>&nbsp;5 or 6 dodges all damage!`);
  document.getElementById('sylviaOverlay').classList.add('active');
}

function doSylviaRoll() {
  const btn = document.getElementById('sylviaRollBtn');
  if (!btn || btn.disabled) return;
  btn.disabled = true;

  // Roll the actual die NOW (player click is the trigger)
  const finalValue = Math.floor(Math.random() * 6) + 1;
  const dieEl = document.getElementById('sylviaDie');
  if (!dieEl) { finishSylviaRoll(finalValue); return; }

  // Quick shuffle animation: flip through random values for ~800ms then reveal
  let ticks = 0;
  const totalTicks = 10;
  const tickMs = 70;
  const shuffle = setInterval(() => {
    ticks++;
    dieEl.textContent = String(Math.floor(Math.random() * 6) + 1);
    dieEl.style.transform = `rotate(${ticks * 36}deg)`;
    if (ticks >= totalTicks) {
      clearInterval(shuffle);
      dieEl.textContent = String(finalValue);
      dieEl.style.transform = 'rotate(0deg)';
      if (finalValue >= 5) { // 5 or 6 dodge
        dieEl.style.background = 'linear-gradient(135deg,#fde68a,#f59e0b)';
        dieEl.style.borderColor = '#f59e0b';
        dieEl.style.color = '#78350f';
      } else {
        dieEl.style.background = 'linear-gradient(135deg,#fecaca,#ef4444)';
        dieEl.style.borderColor = '#b91c1c';
        dieEl.style.color = '#7f1d1d';
      }
      setTimeout(() => finishSylviaRoll(finalValue), 850);
    }
  }, tickMs);
}

function finishSylviaRoll(value) {
  const dodged = (value >= 5); // 5 or 6 dodge
  B.sylviaPendingResult = { value, dodged };
  const resume = B.sylviaResume;
  B.sylviaResume = null;
  document.getElementById('sylviaOverlay').classList.remove('active');
  // Reset die visuals for next time
  const dieEl = document.getElementById('sylviaDie');
  if (dieEl) {
    dieEl.style.background = 'linear-gradient(135deg,#bae6fd,#e0f2fe)';
    dieEl.style.borderColor = '#0ea5e9';
    dieEl.style.color = '#0c4a6e';
  }
  if (resume) resume();
}

// ============================================================
// PRINCE BALATRON (113) — Party Time counter-die reveal
// ============================================================
// Counter-die value + post-counter HP are computed synchronously in
// _resolveRoundImpl so downstream KO-cascade logic sees the correct state.
// The modal is purely cinematic — it shuffles and lands on the pre-computed
// value, then applies the deferred wF.hp mutation so the bar drops the
// instant the reveal lands. B.balatronPending carries the precomputed data.
function showBalatronModal(resumeCallback) {
  const bp = B.balatronPending;
  if (!bp) { if (resumeCallback) resumeCallback(); return; }
  B.balatronResume = resumeCallback;

  const titleEl = document.getElementById('balatronTitle');
  if (titleEl) titleEl.textContent = `${bp.lFName} — Party Time!`;
  const subEl = document.getElementById('balatronSub');
  if (subEl) subEl.innerHTML = `${bp.lFName} lost the roll — but the party's not over.<br>Roll the counter die for damage to <b>${bp.wFName}</b>!`;
  const dieEl = document.getElementById('balatronDie');
  if (dieEl) {
    dieEl.textContent = '?';
    dieEl.style.transform = 'rotate(0deg)';
    dieEl.style.background = 'linear-gradient(135deg,#e9d5ff,#c4b5fd)';
    dieEl.style.borderColor = '#a855f7';
    dieEl.style.color = '#4c1d95';
  }
  const btn = document.getElementById('balatronRollBtn');
  if (btn) { btn.disabled = false; btn.textContent = '🎲 Roll the Counter Die!'; }

  narrate(`<b class="${bp.loseTeamName}-text">${bp.lFName}</b>&nbsp;retaliates — <b class="gold">PARTY TIME!</b>`);
  document.getElementById('balatronOverlay').classList.add('active');
}

function doBalatronRoll() {
  const btn = document.getElementById('balatronRollBtn');
  if (!btn || btn.disabled) return;
  btn.disabled = true;

  const bp = B.balatronPending;
  if (!bp) { finishBalatronRoll(); return; }
  const finalValue = bp.counterDie;

  const dieEl = document.getElementById('balatronDie');
  if (!dieEl) { finishBalatronRoll(); return; }

  // Shuffle animation — land on the pre-computed counter value
  let ticks = 0;
  const totalTicks = 10;
  const tickMs = 70;
  const shuffle = setInterval(() => {
    ticks++;
    dieEl.textContent = String(Math.floor(Math.random() * 6) + 1);
    dieEl.style.transform = `rotate(${ticks * 36}deg)`;
    if (ticks >= totalTicks) {
      clearInterval(shuffle);
      dieEl.textContent = String(finalValue);
      dieEl.style.transform = 'rotate(0deg)';
      // Color the die by hit size
      if (finalValue >= 5) {
        dieEl.style.background = 'linear-gradient(135deg,#fde68a,#f59e0b)';
        dieEl.style.borderColor = '#f59e0b';
        dieEl.style.color = '#78350f';
      } else if (finalValue >= 3) {
        dieEl.style.background = 'linear-gradient(135deg,#fbbf24,#d97706)';
        dieEl.style.borderColor = '#b45309';
        dieEl.style.color = '#78350f';
      } else {
        dieEl.style.background = 'linear-gradient(135deg,#fecaca,#ef4444)';
        dieEl.style.borderColor = '#b91c1c';
        dieEl.style.color = '#7f1d1d';
      }
      setTimeout(() => finishBalatronRoll(), 900);
    }
  }, tickMs);
}

function finishBalatronRoll() {
  const bp = B.balatronPending;
  const resume = B.balatronResume;
  B.balatronPending = null;
  B.balatronResume = null;
  document.getElementById('balatronOverlay').classList.remove('active');

  if (bp) {
    // Apply the deferred HP mutation + log so the bar drops exactly now.
    const wTeamName = bp.loseTeamName === 'red' ? 'blue' : 'red';
    const wTeamObj = B[wTeamName];
    const wF = wTeamObj ? active(wTeamObj) : null;
    if (wF && wF.name === bp.wFName) {
      wF.hp = bp.hpAfter;
    }
    log(`<span class="log-ability">${bp.lFName}</span> — Party Time! Counter die: <b>${bp.counterDie}</b> damage to ${bp.wFName}! ${bp.wasKo?'<span class="log-ko">KO!</span>':bp.hpAfter+' HP left'}`);
    renderBattle();
  }
  if (resume) resume();
}

// ============================================================
// ROMY (114) — Valley Guardian: pre-roll number prediction modal
// ============================================================
function doRomyPrediction(num) {
  document.getElementById('romyOverlay').classList.remove('active');
  const rp = B.romyPending;
  if (!rp) return;
  B.romyPending = null;
  if (B.romyPrediction) B.romyPrediction[rp.team] = num;
  narrate(`<b class="gold">${rp.ghostName} predicts... ${num}!</b> Valley Guardian ready!`);
  // Unlock this team's button and proceed to roll
  const myBtn = document.getElementById(rp.team === 'red' ? 'rollRedBtn' : 'rollBlueBtn');
  // Give the narration a beat to appear, then roll
  setTimeout(() => { doTeamRoll(rp.team, myBtn); }, 400);
}

// ============================================================
// TOBY (97) — Pure Heart: all-in declaration handler
// ============================================================
function doTobyPureHeart(declared) {
  document.getElementById('tobyOverlay').classList.remove('active');
  const tp = B.tobyPending;
  if (!tp) return;
  B.tobyPending = null;
  if (B.pureHeartDeclared) B.pureHeartDeclared[tp.team] = declared;
  const myBtn = document.getElementById(tp.team === 'red' ? 'rollRedBtn' : 'rollBlueBtn');
  if (declared) {
    narrate(`<b class="gold">PURE HEART!</b> Toby declares the final roll — a win ends it all! (Toby sacrifices next round)`);
  } else {
    narrate(`<b class="${tp.team}-text">Toby</b> stands down — not this round.`);
    if (B.pureHeartDeclared) B.pureHeartDeclared[tp.team] = false;
  }
  setTimeout(() => { doTeamRoll(tp.team, myBtn); }, 400);
}

// ============================================================
// TYLER (105) — Heating Up: opt-in 2 HP trade for +1 die
// ============================================================
function doTylerChoice(choice) {
  const tp = B.tylerPending;
  if (!tp) return;
  B.tylerPending = null;
  document.getElementById('tylerOverlay').classList.remove('active');
  const { team, btn } = tp;
  const f = active(B[team]);
  if (choice === 'yes' && f && !f.ko && f.hp >= 3) {
    const prevHp = f.hp;
    f.hp -= 2;
    // +1 die: bump the pre-roll count already stored by doPreRollSetup
    if (B.preRoll && B.preRoll[team]) {
      B.preRoll[team].count = Math.min(6, B.preRoll[team].count + 1);
    }
    showAbilityCallout('HEATING UP!', 'var(--ghost-rare)', `${f.name} — spends 2 HP for +1 die! (${prevHp} → ${f.hp} HP)`, team);
    log(`<span class="log-ability">${f.name}</span> — Heating Up! Spent 2 HP for +1 die (${prevHp} → ${f.hp} HP).`);
    renderBattle();
    // Short pause so the callout is visible before the dice roll
    setTimeout(() => { btn.disabled = false; btn.classList.remove('locked'); doTeamRoll(team, btn); }, spd(1500));
  } else {
    narrate(`<b class="${team}-text">Tyler</b> holds HP — rolling without the trade.`);
    setTimeout(() => { btn.disabled = false; btn.classList.remove('locked'); doTeamRoll(team, btn); }, spd(200));
  }
}

// ============================================================
// GUARDIAN FAIRY (99) — Wish: reactive damage swap handler
// ============================================================
let gfWishTimer = null;
function doGuardianFairyReactive(choice) {
  const gfp = B.guardianFairyReactivePending;
  if (!gfp) return;
  B.guardianFairyReactivePending = null;
  // Clear timer and hide button
  if (gfWishTimer) { clearInterval(gfWishTimer); gfWishTimer = null; }
  document.getElementById('gfWishBtn').style.display = 'none';
  const { loseTeamName, gfGhost, dmg, lF, resume } = gfp;
  const loseTeam = B[loseTeamName];
  if (choice === 'yes') {
    // Guardian Fairy takes the damage instead — heal to full first (entering from sideline)
    const gfIdx = loseTeam.ghosts.indexOf(gfGhost);
    gfGhost.hp = gfGhost.maxHp; // heal to full on entry
    gfGhost.hp = Math.max(0, gfGhost.hp - dmg);
    if (gfGhost.hp <= 0) { gfGhost.ko = true; gfGhost.killedBy = -1; }
    // Swap GF to active, original ghost to sideline at current HP
    if (gfIdx !== -1) loseTeam.activeIdx = gfIdx;
    const gfName = gfGhost.name || 'Guardian Fairy';
    queueAbility('WISH!', 'var(--ghost-rare)', `${gfName} — leaps in to absorb ${dmg} damage for ${lF.name}!${gfGhost.ko ? ' GF falls!' : ' ' + gfGhost.hp + ' HP left'}`, null, loseTeamName);
    log(`<span class="log-ability">${gfName}</span> — Wish! Absorbed ${dmg} damage for ${lF.name}! ${gfGhost.ko ? '<span class="log-ko">GF falls!</span>' : gfGhost.hp + ' HP left'}`);
    renderBattle();
    if (resume) setTimeout(resume, spd(1500));
  } else {
    // Damage applies to the original ghost
    lF.hp = Math.max(0, lF.hp - dmg);
    if (lF.hp <= 0) { lF.ko = true; lF.killedBy = gfp.wFId; }
    log(`<span class="log-dmg">${gfp.wFName} deals ${dmg} to ${lF.name}!</span> ${lF.ko?'<span class="log-ko">KO!</span>':lF.hp+' HP left'}`);
    renderBattle();
    if (resume) setTimeout(resume, 200);
  }
}

// Show GF Wish as a timed button with countdown — auto-declines on expiry
function showGfWishButton() {
  const gfp = B.guardianFairyReactivePending;
  if (!gfp) return;
  const gfG = gfp.gfGhost;
  const gfName = gfG.name || 'Guardian Fairy';
  const btn = document.getElementById('gfWishBtn');
  const cdEl = document.getElementById('gfWishCountdown');
  const subEl = document.getElementById('gfWishSub');
  subEl.innerHTML = `${gfName} absorbs ${gfp.dmg} dmg for ${gfp.lF.name}!`;
  btn.style.display = 'block';
  btn.onclick = () => doGuardianFairyReactive('yes');
  const secs = getSpecialsTimerSecs();
  let remaining = secs;
  cdEl.textContent = remaining;
  narrate(`<b class="${gfp.loseTeamName}-text">🧚 ${gfName}</b> can take this hit! Click to activate!`);
  if (gfWishTimer) clearInterval(gfWishTimer);
  gfWishTimer = setInterval(() => {
    remaining--;
    cdEl.textContent = remaining;
    if (remaining <= 0) {
      clearInterval(gfWishTimer); gfWishTimer = null;
      doGuardianFairyReactive('no'); // auto-decline
    }
  }, 1000);
}

// ============================================================
// CHOW (414) — Secret Ingredient: spend 1 Healing Seed for +2 dice
// ============================================================
function doChowChoice(choice) {
  const cp = B.chowPending;
  if (!cp) return;
  B.chowPending = null;
  document.getElementById('chowOverlay').classList.remove('active');
  const { team, btn } = cp;
  const f = active(B[team]);
  if (choice === 'yes' && f && f.id === 414 && !f.ko && B[team].resources.healingSeed >= 1) {
    B[team].resources.healingSeed--;
    B.chowExtraDie[team] = (B.chowExtraDie[team] || 0) + 2;
    // Boopies (419) — Boopie Magic: sideline Healing Seed spending = +1 Lucky Stone
    if (hasSideline(B[team], 419)) { B[team].resources.luckyStone = (B[team].resources.luckyStone || 0) + 1; }
    showAbilityCallout('SECRET INGREDIENT!', 'var(--uncommon)',
      `${f.name} — discarded 1 Healing Seed for +2 dice! (total +${B.chowExtraDie[team]})`, team);
    log(`<span class="log-ability">${f.name}</span> — Secret Ingredient! Discarded 1 Healing Seed → +${B.chowExtraDie[team]} dice total!`);
    renderBattle();
    // If more seeds available, allow another use (re-offer after callout clears)
    if (B[team].resources.healingSeed >= 1) {
      setTimeout(() => { btn.disabled = false; btn.classList.remove('locked'); doTeamRoll(team, btn); }, spd(1500));
    } else {
      B.chowDecided[team] = true;
      setTimeout(() => { btn.disabled = false; btn.classList.remove('locked'); doTeamRoll(team, btn); }, spd(1500));
    }
  } else {
    B.chowDecided[team] = true;
    setTimeout(() => { btn.disabled = false; btn.classList.remove('locked'); doTeamRoll(team, btn); }, spd(200));
  }
}

// ============================================================
// ZORK (463) — Stoke: discard all Burn for +1 die per Burn (button)
// ============================================================
function useZorkStoke(team) {
  const f = active(B[team]);
  if (!f || f.id !== 463 || f.ko) return;
  if (B.zorkDecided[team]) return;
  if (!B[team].resources.burn || B[team].resources.burn <= 0) return;
  const burnSpent = B[team].resources.burn;
  B[team].resources.burn = 0;
  B.zorkDecided[team] = true;
  if (!B.zorkExtraDie) B.zorkExtraDie = { red: 0, blue: 0 };
  B.zorkExtraDie[team] = (B.zorkExtraDie[team] || 0) + burnSpent;
  showAbilityCallout('SMOLDER!', 'var(--common)',
    `${f.name} — ${burnSpent} Burn → +${burnSpent} dice!`, team);
  log(`<span class="log-ability">${f.name}</span> — Smolder! Discarded ${burnSpent} Burn for +${burnSpent} dice!`);
  renderBattle();
}

// ============================================================
// MIYOSHI (433) — Bonzai!: sacrifice 4 HP for +5 dice
// ============================================================
// ============================================================
// KAYLEE (453) — Slipstream: interactive dice swap
// ============================================================
function showSlipstreamPicker(team, myDice, oppDice, callback) {
  B.slipstreamState = { team, myDice, oppDice, callback, myIdx: null, oppIdx: null, step: 1 };
  const myContainer = document.getElementById('slipstreamMyDice');
  const oppContainer = document.getElementById('slipstreamOppDice');
  const stepLabel = document.getElementById('slipstreamStep');
  stepLabel.textContent = "Step 1: Pick YOUR die to give away";

  // Render my dice as clickable buttons
  myContainer.innerHTML = myDice.map((d, i) =>
    `<button class="die" style="cursor:pointer;font-size:22px;min-width:44px;padding:8px 12px;" onclick="slipstreamPickMy(${i})" id="slipMy${i}">${d}</button>`
  ).join('');

  // Render opponent dice (not clickable yet)
  oppContainer.innerHTML = oppDice.map((d, i) =>
    `<button class="die" style="cursor:default;opacity:0.5;font-size:22px;min-width:44px;padding:8px 12px;" id="slipOpp${i}">${d}</button>`
  ).join('');

  document.getElementById('slipstreamOverlay').classList.add('active');
}

function slipstreamPickMy(idx) {
  const s = B.slipstreamState;
  if (!s || s.step !== 1) return;
  s.myIdx = idx;
  s.step = 2;
  // Highlight selected die
  for (let i = 0; i < s.myDice.length; i++) {
    const el = document.getElementById('slipMy' + i);
    if (el) el.style.opacity = i === idx ? '1' : '0.3';
  }
  // Enable opponent dice clicking
  document.getElementById('slipstreamStep').textContent = "Step 2: Pick OPPONENT's die to take";
  for (let i = 0; i < s.oppDice.length; i++) {
    const el = document.getElementById('slipOpp' + i);
    if (el) { el.style.cursor = 'pointer'; el.style.opacity = '1'; el.onclick = () => slipstreamPickOpp(i); }
  }
}

function slipstreamPickOpp(idx) {
  const s = B.slipstreamState;
  if (!s || s.step !== 2) return;
  s.oppIdx = idx;
  document.getElementById('slipstreamOverlay').classList.remove('active');

  // Perform the swap
  const gave = s.myDice[s.myIdx];
  const took = s.oppDice[s.oppIdx];
  s.myDice[s.myIdx] = took;
  s.oppDice[s.oppIdx] = gave;
  s.myDice.sort((a, b) => a - b);
  s.oppDice.sort((a, b) => a - b);

  const _slipF = active(B[s.team]);
  B.slipstreamStolen = { team: s.team, gave, took };
  showAbilityCallout('SLIPSTREAM!', 'var(--rare)', `${_slipF.name} — Swapped ${gave} for opponent's ${took}!`, s.team);
  log(`<span class="log-ability">${_slipF.name}</span> — Slipstream! <span class="log-dmg">Swapped ${gave} for opponent's ${took}!</span>`);
  renderDice(B.redDice, B.blueDice);

  B.slipstreamState = null;
  // Resume resolution after a brief delay for the callout
  setTimeout(() => s.callback(), spd(1500));
}

function doSlipstreamChoice(choice) {
  if (choice === 'skip') {
    document.getElementById('slipstreamOverlay').classList.remove('active');
    const s = B.slipstreamState;
    B.slipstreamState = null;
    if (s && s.callback) s.callback();
  }
}

// Bonzai pre-roll BUTTON handler (clicked before Roll)
function useTobyButton(team) {
  const f = active(B[team]);
  if (!f || f.id !== 97 || f.ko) return;
  if (!B.pureHeartDeclared || B.pureHeartDeclared[team] !== null) return;
  B.pureHeartDeclared[team] = true;
  showAbilityCallout('PURE HEART!', 'var(--ghost-rare)',
    `${f.name} — declares the final roll! Win = instant KO! Toby sacrifices next round.`, team);
  narrate(`<b class="gold">PURE HEART!</b> Toby declares the final roll — a win ends it all!`);
  log(`<span class="log-ability">${f.name}</span> — PURE HEART declared! Win this roll = instant KO. Toby sacrifices next round.`);
  renderBattle();
}

function useBonzaiButton(team) {
  const f = active(B[team]);
  if (!f || f.id !== 454 || f.ko || f.hp <= 4) return;
  if (B.bonzaiDecided[team]) return;
  const preHp = f.hp;
  f.hp -= 4;
  if (f.hp <= 0) { f.ko = true; f.killedBy = -1; }
  B.bonzaiDecided[team] = true;
  // Store the dice bonus for consumption during roll setup
  if (!B.bonzaiBtnDice) B.bonzaiBtnDice = { red: 0, blue: 0 };
  B.bonzaiBtnDice[team] = 5;
  showAbilityCallout('BONZAI!', 'var(--rare)',
    `${f.name} — sacrificed 4 HP for +5 dice! (${preHp} → ${f.hp} HP)`, team);
  log(`<span class="log-ability">${f.name}</span> — BONZAI! Sacrificed 4 HP → +5 dice! (${preHp} → ${f.hp} HP)`);
  playDamageSfx(3);
  hitDamage(team);
  renderBattle();
}

function doBonzaiChoice(choice) {
  const bp = B.bonzaiPending;
  if (!bp) return;
  B.bonzaiPending = null;
  document.getElementById('bonzaiOverlay').classList.remove('active');
  const { team, btn } = bp;
  const f = active(B[team]);
  if (choice === 'yes' && f && f.id === 454 && !f.ko && f.hp > 4) {
    const preHp = f.hp;
    f.hp -= 4;
    if (f.hp <= 0) { f.ko = true; f.killedBy = -1; }
    // Add dice directly to preRoll count so they apply to THIS roll, not next
    if (B.preRoll && B.preRoll[team]) {
      B.preRoll[team].count = Math.min(10, B.preRoll[team].count + 5);
    }
    showAbilityCallout('BONZAI!', 'var(--rare)',
      `${f.name} — sacrificed 4 HP for +5 dice! (${preHp} → ${f.hp} HP)`, team);
    log(`<span class="log-ability">${f.name}</span> — BONZAI! Sacrificed 3 HP → +5 dice! (${preHp} → ${f.hp} HP)`);
    playDamageSfx(3);
    hitDamage(team);
    renderBattle();
    B.bonzaiDecided[team] = true;
    setTimeout(() => { btn.disabled = false; btn.classList.remove('locked'); doTeamRoll(team, btn); }, spd(1500));
  } else {
    B.bonzaiDecided[team] = true;
    setTimeout(() => { btn.disabled = false; btn.classList.remove('locked'); doTeamRoll(team, btn); }, spd(200));
  }
}

// ============================================================
// CASTLE GARDENER (442) — Cultivate: discard 1 Healing Seed for 2 Sacred Fire (pre-roll button)
// ============================================================
function useCultivate(team) {
  const f = active(B[team]);
  if (!f || f.id !== 442 || f.ko) return;
  if (!B[team].resources || B[team].resources.healingSeed < 1) return;
  B[team].resources.healingSeed--;
  B[team].resources.fire = (B[team].resources.fire || 0) + 2;
  // Boopies (419) — Boopie Magic: sideline Healing Seed spending = +1 Lucky Stone
  if (hasSideline(B[team], 419)) { B[team].resources.luckyStone = (B[team].resources.luckyStone || 0) + 1; }
  showAbilityCallout('CULTIVATE!', 'var(--uncommon)',
    `${f.name} — discarded 1 Healing Seed → +2 Sacred Fire!`, team);
  log(`<span class="log-ability">${f.name}</span> — Cultivate! Discarded 1 Healing Seed → +2 Sacred Fire!`);
  renderBattle();
}
// Legacy wrapper for old overlay (no longer used)
function doCultivateChoice(choice) {
  document.getElementById('cultivateOverlay').classList.remove('active');
  if (choice === 'yes') {
    const cp = B.cultivatePending;
    if (cp) { B.cultivatePending = null; useCultivate(cp.team); }
  }
}

// ============================================================
// FOREST SPIRIT (446) — Hex: spend 1 Burn to remove 1 enemy die (pre-roll button)
// ============================================================
function useHex(team) {
  const f = active(B[team]);
  if (!f || f.id !== 446 || f.ko) return;
  if ((B[team].resources.burn || 0) < 1) return;

  const oppTeamName = team === 'red' ? 'blue' : 'red';
  B[team].resources.burn--;
  B.hexDieRemoval[oppTeamName] = (B.hexDieRemoval[oppTeamName] || 0) + 1;
  B[team].resources.fire = (B[team].resources.fire || 0) + 1;

  showAbilityCallout('HEX!', 'var(--uncommon)', `${f.name} — -1 Burn → -1 enemy die + 1 Sacred Fire!`, team);
  log(`<span class="log-ability">${f.name}</span> — Hex! -1 Burn → opponent -1 die + <span class="log-ms">+1 Sacred Fire!</span>`);
  renderBattle(); // re-renders the button with updated burn count
}

// ============================================================
// NICK & KNACK (409) — Knick Knack: steal 1 resource from opponent
// ============================================================
function showNickKnackPicker(team, oppTeam) {
  const oppRes = B[oppTeam].resources;
  const resTypes = [
    { key: 'ice', label: 'Ice Shard', emoji: '❄️' },
    { key: 'fire', label: 'Sacred Fire', emoji: '🔥' },
    { key: 'surge', label: 'Surge', emoji: '⚡' },
    { key: 'luckyStone', label: 'Lucky Stone', emoji: '🍀' },
    { key: 'moonstone', label: 'Moonstone', emoji: '💎' },
    { key: 'healingSeed', label: 'Healing Seed', emoji: '🌱' }
  ];
  const available = resTypes.filter(r => (oppRes[r.key] || 0) > 0);
  const optionsEl = document.getElementById('nickKnackOptions');
  let html = '';
  available.forEach(r => {
    html += `<button class="selene-opt" onclick="doNickKnackSteal('${team}','${r.key}')" style="background:linear-gradient(135deg,#065f46,#059669);">${r.emoji} ${r.label} (${oppRes[r.key]})</button>`;
  });
  html += `<button class="selene-opt" onclick="doNickKnackSteal('${team}','skip')" style="background:linear-gradient(135deg,#374151,#1f2937);">✖ Skip</button>`;
  optionsEl.innerHTML = html;
  document.getElementById('nickKnackOverlay').classList.add('active');
}

function doNickKnackSteal(team, resKey) {
  const nnp = B.nickKnackPending;
  if (!nnp) return;
  B.nickKnackPending = null;
  document.getElementById('nickKnackOverlay').classList.remove('active');
  const { btn, oppTeam } = nnp;
  B.nickKnackDecided[team] = true;
  if (resKey !== 'skip') {
    B[oppTeam].resources[resKey]--;
    B[team].resources[resKey] = (B[team].resources[resKey] || 0) + 1;
    const resLabel = resKey === 'luckyStone' ? 'Lucky Stone' : resKey === 'moonstone' ? 'Moonstone' : resKey === 'healingSeed' ? 'Healing Seed' : resKey === 'ice' ? 'Ice Shard' : resKey === 'fire' ? 'Sacred Fire' : 'Surge';
    const f = active(B[team]);
    // Nick & Knack gains +1 HP + 2 Burn on steal
    f.hp += 1;
    // Grant 2 Burn as resource (player places via burn picker during pre-roll)
    if (!B[team].resources.burn) B[team].resources.burn = 0;
    B[team].resources.burn += 2;
    showAbilityCallout('KNICK KNACK!', 'var(--uncommon)',
      `${f.name} — stole 1 ${resLabel}! +1 HP + 2 Burn!`, team);
    log(`<span class="log-ability">${f.name}</span> — Knick Knack! Stole 1 <span class="log-ms">${resLabel}</span>! <span class="log-heal">+1 HP</span> + 2 Burn!`);
    renderBattle();
    setTimeout(() => { btn.disabled = false; btn.classList.remove('locked'); doTeamRoll(team, btn); }, spd(1500));
  } else {
    setTimeout(() => { btn.disabled = false; btn.classList.remove('locked'); doTeamRoll(team, btn); }, spd(200));
  }
}

// ============================================================
// BURN — Place burn resource on enemy sideline ghost (pre-roll)
// ============================================================
function showBurnPicker(team) {
  const t = B[team];
  const burnCount = t.resources.burn || 0;
  if (burnCount <= 0) return;

  const enemyTeamName = team === 'red' ? 'blue' : 'red';
  const enemyTeam = B[enemyTeamName];

  // Find non-KO'd sideline ghosts on enemy team
  const sidelineGhosts = enemyTeam.ghosts
    .map((g, i) => ({ ghost: g, index: i }))
    .filter(x => x.index !== enemyTeam.activeIdx && !x.ghost.ko);

  if (sidelineGhosts.length === 0) {
    log('<span class="log-ability">BURN</span> — No enemy sideline ghosts to burn!');
    return;
  }

  B.burnPickerTeam = team;

  const optionsEl = document.getElementById('burnPickerOptions');
  let html = '';
  sidelineGhosts.forEach(({ ghost, index }) => {
    const gd = ghostData(ghost.id);
    const existingBurn = (B.burn && B.burn[enemyTeamName] && B.burn[enemyTeamName][index]) || 0;
    const burnLabel = existingBurn > 0 ? ` (${existingBurn} Burn already)` : '';
    html += `<button class="selene-opt" onclick="doBurnPlace('${team}',${index})" style="background:linear-gradient(135deg,#7c1a1a,#c0392b);">🔥 ${ghost.name} — ${ghost.hp}/${ghost.maxHp} HP${burnLabel}</button>`;
  });
  html += `<button class="selene-opt" onclick="closeBurnPicker()" style="background:linear-gradient(135deg,#374151,#1f2937);">✖ Cancel</button>`;
  optionsEl.innerHTML = html;
  document.getElementById('burnPickerSub').innerHTML = `You have <b>${burnCount}</b> Burn to place. Each Burn deals 1 damage when the ghost enters battle.`;
  document.getElementById('burnOverlay').classList.add('active');
}

function doBurnPlace(team, ghostIndex) {
  const t = B[team];
  const enemyTeamName = team === 'red' ? 'blue' : 'red';

  if (!t.resources.burn || t.resources.burn <= 0) { closeBurnPicker(); return; }

  t.resources.burn--;
  if (!B.burn) B.burn = { red: {}, blue: {} };
  if (!B.burn[enemyTeamName]) B.burn[enemyTeamName] = {};
  B.burn[enemyTeamName][ghostIndex] = (B.burn[enemyTeamName][ghostIndex] || 0) + 1;

  // Track which Spiritkin placed this burn for KO credit
  const burnPlacer = active(B[team]);
  const burnPlacerId = burnPlacer ? (burnPlacer.originalId || burnPlacer.id) : 0;
  if (!B.burnSource) B.burnSource = { red: {}, blue: {} };
  if (!B.burnSource[enemyTeamName]) B.burnSource[enemyTeamName] = {};
  if (!B.burnSource[enemyTeamName][ghostIndex]) B.burnSource[enemyTeamName][ghostIndex] = {};
  B.burnSource[enemyTeamName][ghostIndex][burnPlacerId] = (B.burnSource[enemyTeamName][ghostIndex][burnPlacerId] || 0) + 1;

  const targetGhost = B[enemyTeamName].ghosts[ghostIndex];
  const totalBurn = B.burn[enemyTeamName][ghostIndex];
  log(`<span class="log-ability">BURN!</span> placed on <span class="log-dmg">${targetGhost.name}</span>! (${totalBurn} total)`);
  showAbilityCallout('BURN!', 'var(--rare)', `${targetGhost.name} has been marked! ${totalBurn} Burn on entry!`, team);

  // Mable Stadango (446) — Hex: when you place Burn, enemy loses 1 die next roll (in play only)
  const mableActive = active(B[team]);
  if (mableActive && mableActive.id === 446 && !mableActive.ko) {
    if (!B.hexDieRemoval) B.hexDieRemoval = { red: 0, blue: 0 };
    B.hexDieRemoval[enemyTeamName] = (B.hexDieRemoval[enemyTeamName] || 0) + 1;
    log(`<span class="log-ability">${mableActive.name}</span> — Hex! Burn placed → enemy -1 die next roll!`);
    showAbilityCallout('HEX!', 'var(--uncommon)', `${mableActive.name} — Burn placed! Enemy -1 die next roll!`, team);
  }

  // Cameron (25) — Unstoppable Force: opponent used a special (Burn)
  triggerCameronSpecialWatch(team);

  renderBattle();
  // v735: broadcast burn state so opponent's engine knows about it
  pvpBroadcastCommitted(team);

  // If still have burn to place, re-open picker after a brief delay
  if (t.resources.burn > 0) {
    setTimeout(() => showBurnPicker(team), 800);
  } else {
    closeBurnPicker();
  }
}

function closeBurnPicker() {
  document.getElementById('burnOverlay').classList.remove('active');
  B.burnPickerTeam = null;
}

// ============================================================
// MAGIC FIREFLIES — Convert wildcard firefly to any resource
// ============================================================
function showFireflyPicker(team) {
  const t = B[team];
  const ffCount = t.resources.firefly || 0;
  if (ffCount <= 0) return;

  B.fireflyPickerTeam = team;

  const resources = [
    { key: 'fire', label: 'Sacred Fire', emoji: '🔥' },
    { key: 'ice', label: 'Ice Shard', emoji: '❄️' },
    { key: 'luckyStone', label: 'Lucky Stone', emoji: '🍀' },
    { key: 'moonstone', label: 'Moonstone', emoji: '🌙' },
    { key: 'healingSeed', label: 'Healing Seed', emoji: '🌱' },
    { key: 'surge', label: 'Surge', emoji: '⚡' },
    { key: 'burn', label: 'Burn', emoji: '🔥' }
  ];

  const optionsEl = document.getElementById('fireflyOptions');
  let html = '';
  resources.forEach(r => {
    // Hide Moonstone if already at cap (max 1)
    if (r.key === 'moonstone' && (t.resources.moonstone || 0) >= 1) return;
    html += `<button class="selene-opt" onclick="doFireflyConvert('${team}','${r.key}')" style="background:linear-gradient(135deg,#8b6914,#daa520);">${r.emoji} ${r.label}</button>`;
  });
  html += `<button class="selene-opt" onclick="closeFireflyPicker()" style="background:linear-gradient(135deg,#374151,#1f2937);">✖ Cancel</button>`;
  optionsEl.innerHTML = html;
  document.getElementById('fireflySub').innerHTML = `You have <b>${ffCount}</b> Magic Firefl${ffCount === 1 ? 'y' : 'ies'}. Each converts to 1 resource of your choice.`;
  document.getElementById('fireflyOverlay').classList.add('active');
}

function doFireflyConvert(team, resourceKey) {
  const t = B[team];
  if (!t.resources.firefly || t.resources.firefly <= 0) { closeFireflyPicker(); return; }

  // Block moonstone conversion if already at cap
  if (resourceKey === 'moonstone' && (t.resources.moonstone || 0) >= 1) {
    closeFireflyPicker();
    showFireflyPicker(team);
    return;
  }
  t.resources.firefly--;
  if (!t.resources[resourceKey]) t.resources[resourceKey] = 0;
  t.resources[resourceKey]++;

  const labelMap = { fire:'Sacred Fire', ice:'Ice Shard', luckyStone:'Lucky Stone', moonstone:'Moonstone', healingSeed:'Healing Seed', surge:'Surge', burn:'Burn' };
  const resLabel = labelMap[resourceKey] || resourceKey;
  log(`<span class="log-ability">MAGIC FIREFLIES!</span> Converted to <span class="log-ms">${resLabel}</span>!`);
  showAbilityCallout('MAGIC FIREFLIES!', '#ffd700', `Converted to ${resLabel}!`, team);

  renderBattle();

  // If still have fireflies, re-open picker after a brief delay
  if (t.resources.firefly > 0) {
    setTimeout(() => showFireflyPicker(team), 800);
  } else {
    closeFireflyPicker();
  }
}

function closeFireflyPicker() {
  document.getElementById('fireflyOverlay').classList.remove('active');
  B.fireflyPickerTeam = null;
}

// ============================================================
// JASPER (428) — Flame Dive: interactive bonus die reveal modal
// ============================================================
function showJasperModal(resumeCallback) {
  const jp = B.jasperPending;
  if (!jp) { if (resumeCallback) resumeCallback(); return; }
  B.jasperResume = resumeCallback;
  const titleEl = document.getElementById('jasperTitle');
  if (titleEl) titleEl.textContent = `${jp.wFName} — Flame Dive!`;
  const subEl = document.getElementById('jasperSub');
  if (subEl) subEl.innerHTML = `${jp.wFName} won — roll the bonus die for extra damage to <b>${jp.lFName}</b>!<br><i>Jasper takes 1 recoil damage.</i>`;
  const dieEl = document.getElementById('jasperDie');
  if (dieEl) { dieEl.textContent = '?'; dieEl.style.transform = 'rotate(0deg)'; }
  const btn = document.getElementById('jasperRollBtn');
  if (btn) { btn.disabled = false; btn.textContent = '🔥 Roll the Bonus Die!'; }
  narrate(`<b class="${jp.winTeamName}-text">${jp.wFName}</b>&nbsp;unleashes <b class="gold">FLAME DIVE!</b>`);
  document.getElementById('jasperOverlay').classList.add('active');
}

function doJasperRoll() {
  const btn = document.getElementById('jasperRollBtn');
  if (!btn || btn.disabled) return;
  btn.disabled = true;
  const jp = B.jasperPending;
  if (!jp) { finishJasperRoll(); return; }
  const finalValue = jp.bonusDie;
  const dieEl = document.getElementById('jasperDie');
  if (!dieEl) { finishJasperRoll(); return; }
  // Shuffle animation — same as Balatron
  let ticks = 0;
  const totalTicks = 10;
  const tickMs = 70;
  const shuffle = setInterval(() => {
    ticks++;
    dieEl.textContent = String(Math.floor(Math.random() * 6) + 1);
    dieEl.style.transform = `rotate(${ticks * 36}deg)`;
    if (ticks >= totalTicks) {
      clearInterval(shuffle);
      dieEl.textContent = String(finalValue);
      dieEl.style.transform = 'rotate(0deg)';
      if (finalValue >= 5) {
        dieEl.style.background = 'linear-gradient(135deg,#fde68a,#f59e0b)';
        dieEl.style.borderColor = '#f59e0b';
      } else if (finalValue >= 3) {
        dieEl.style.background = 'linear-gradient(135deg,#fbbf24,#d97706)';
        dieEl.style.borderColor = '#b45309';
      } else {
        dieEl.style.background = 'linear-gradient(135deg,#fecaca,#ef4444)';
        dieEl.style.borderColor = '#b91c1c';
      }
      setTimeout(() => finishJasperRoll(), 900);
    }
  }, tickMs);
}

function finishJasperRoll() {
  const jp = B.jasperPending;
  const resume = B.jasperResume;
  B.jasperPending = null;
  B.jasperResume = null;
  document.getElementById('jasperOverlay').classList.remove('active');
  if (jp) {
    const wTeamName = jp.winTeamName;
    const wTeamObj = B[wTeamName];
    const lTeamName = wTeamName === 'red' ? 'blue' : 'red';
    const lTeamObj = B[lTeamName];
    const wF = wTeamObj ? active(wTeamObj) : null;
    const lF = lTeamObj ? active(lTeamObj) : null;
    if (lF && lF.name === jp.lFName) {
      lF.hp = Math.max(0, lF.hp - jp.bonusDie);
      if (lF.hp <= 0 && !lF.ko) { lF.ko = true; lF.killedBy = 428; }
    }
    if (wF && wF.name === jp.wFName) {
      wF.hp = Math.max(0, wF.hp - 1);
      if (wF.hp <= 0) { wF.ko = true; wF.killedBy = -1; }
    }
    log(`<span class="log-ability">${jp.wFName}</span> — Flame Dive! Bonus die: <span class="log-dmg">${jp.bonusDie} extra damage</span> to ${jp.lFName}! Self-damage: <span class="log-dmg">1 HP</span>.`);
    renderBattle();
  }
  if (resume) setTimeout(resume, 300);
}

// ============================================================
// SKY (72) — Elusive: damage negated + interactive counter die
// ============================================================
function showSkyElusiveModal(resumeCallback) {
  const sp = B.skyElusivePending;
  if (!sp) { if (resumeCallback) resumeCallback(); return; }
  B.skyElusiveResume = resumeCallback;
  document.getElementById('skyElusiveTitle').textContent = `${sp.lFName} — Elusive!`;
  document.getElementById('skyElusiveSub').innerHTML = `Damage negated! Roll a counter die against <b>${sp.wFName}</b>!`;
  const dieEl = document.getElementById('skyElusiveDie');
  if (dieEl) { dieEl.textContent = '?'; dieEl.style.transform = 'rotate(0deg)'; }
  const btn = document.getElementById('skyElusiveRollBtn');
  if (btn) { btn.disabled = false; btn.textContent = '💨 Roll Counter Die!'; }
  document.getElementById('skyElusiveOverlay').classList.add('active');
}

function doSkyElusiveRoll() {
  const btn = document.getElementById('skyElusiveRollBtn');
  if (!btn || btn.disabled) return;
  btn.disabled = true;
  const sp = B.skyElusivePending;
  if (!sp) { finishSkyElusive(); return; }
  const finalValue = sp.counterDie;
  const dieEl = document.getElementById('skyElusiveDie');
  if (!dieEl) { finishSkyElusive(); return; }
  let ticks = 0;
  const totalTicks = 10;
  const shuffle = setInterval(() => {
    ticks++;
    dieEl.textContent = String(Math.floor(Math.random() * 6) + 1);
    dieEl.style.transform = `rotate(${ticks * 36}deg)`;
    if (ticks >= totalTicks) {
      clearInterval(shuffle);
      dieEl.textContent = String(finalValue);
      dieEl.style.transform = 'rotate(0deg)';
      dieEl.style.background = finalValue >= 4
        ? 'linear-gradient(135deg,#bfdbfe,#3b82f6)'
        : 'linear-gradient(135deg,#dbeafe,#93c5fd)';
      setTimeout(() => finishSkyElusive(), 900);
    }
  }, 70);
}

function finishSkyElusive() {
  const sp = B.skyElusivePending;
  const resume = B.skyElusiveResume;
  B.skyElusivePending = null;
  B.skyElusiveResume = null;
  document.getElementById('skyElusiveOverlay').classList.remove('active');
  if (sp) {
    const wTeamName = sp.winTeamName;
    const wTeamObj = B[wTeamName];
    const wF = wTeamObj ? active(wTeamObj) : null;
    if (wF && wF.name === sp.wFName) {
      wF.hp = Math.max(0, wF.hp - sp.counterDie);
      if (wF.hp <= 0 && !wF.ko) { wF.ko = true; wF.killedBy = 72; }
    }
    log(`<span class="log-ability">${sp.lFName}</span> — Elusive! Counter die: <span class="log-dmg">${sp.counterDie} damage</span> to ${sp.wFName}! ${wF && wF.ko ? '<span class="log-ko">KO!</span>' : (wF ? wF.hp + ' HP left' : '')}`);
    renderBattle();
  }
  if (resume) setTimeout(resume, 300);
}

// ============================================================
// JENKINS (94) — Greeting: interactive 4-dice entry roll modal
// ============================================================
function showJenkinsModal(resumeCallback) {
  const jp = B.jenkinsPending;
  if (!jp) { if (resumeCallback) resumeCallback(); return; }
  B.jenkinsResume = resumeCallback;
  document.getElementById('jenkinsTitle').textContent = `${jp.jenkinsName} — Greeting!`;
  document.getElementById('jenkinsSub').innerHTML = `${jp.jenkinsName} enters the fight — roll 4 dice for entry damage to <b>${jp.enemyName}</b>!`;
  document.getElementById('jenkinsResult').style.display = 'none';
  for (let i = 0; i < 4; i++) {
    const d = document.getElementById('jenkinsDie' + i);
    if (d) { d.textContent = '?'; d.style.transform = 'rotate(0deg)'; d.style.background = 'linear-gradient(135deg,#a7f3d0,#34d399)'; d.style.borderColor = '#10b981'; d.style.color = '#064e3b'; }
  }
  const btn = document.getElementById('jenkinsRollBtn');
  if (btn) { btn.disabled = false; btn.textContent = '👋 Roll the Greeting Dice!'; }
  narrate(`<b class="${jp.team}-text">${jp.jenkinsName}</b> — <b class="gold">GREETING!</b>`);
  document.getElementById('jenkinsOverlay').classList.add('active');
}

function doJenkinsRoll() {
  const btn = document.getElementById('jenkinsRollBtn');
  if (!btn || btn.disabled) return;
  btn.disabled = true;
  const jp = B.jenkinsPending;
  if (!jp) { finishJenkinsRoll(); return; }

  // Shuffle animation across all 4 dice, landing on pre-computed values
  // [shadow] perf: cache die elements before interval to avoid 4 getElementById calls per 65ms tick
  const jenkinsDieEls = Array.from({length: 4}, (_, i) => document.getElementById('jenkinsDie' + i));
  const jenkinsResultEl = document.getElementById('jenkinsResult');
  let ticks = 0;
  const totalTicks = 12;
  const tickMs = 65;
  const shuffle = setInterval(() => {
    ticks++;
    jenkinsDieEls.forEach(d => {
      if (d) {
        d.textContent = String(Math.floor(Math.random() * 6) + 1);
        d.style.transform = `rotate(${ticks * 30}deg)`;
      }
    });
    if (ticks >= totalTicks) {
      clearInterval(shuffle);
      // Land on final values
      jenkinsDieEls.forEach((d, i) => {
        if (d) {
          d.textContent = String(jp.dice[i]);
          d.style.transform = 'rotate(0deg)';
        }
      });
      // Color dice based on damage result
      const dmg = jp.damage;
      let bg, border, color;
      if (dmg >= 4) { bg = 'linear-gradient(135deg,#fde68a,#f59e0b)'; border = '#f59e0b'; color = '#78350f'; }
      else if (dmg >= 2) { bg = 'linear-gradient(135deg,#fbbf24,#d97706)'; border = '#b45309'; color = '#78350f'; }
      else { bg = 'linear-gradient(135deg,#a7f3d0,#34d399)'; border = '#10b981'; color = '#064e3b'; }
      jenkinsDieEls.forEach(d => {
        if (d) { d.style.background = bg; d.style.borderColor = border; d.style.color = color; }
      });
      // Show result label
      const rollLabel = describeRoll(jp.roll);
      if (jenkinsResultEl) {
        jenkinsResultEl.innerHTML = `<span style="color:var(--ghost-rare);">${rollLabel}</span> → <span style="color:var(--accent);">${dmg} damage</span> to ${jp.enemyName}!`;
        jenkinsResultEl.style.display = 'block';
      }
      setTimeout(() => finishJenkinsRoll(), 1200);
    }
  }, tickMs);
}

function finishJenkinsRoll() {
  const jp = B.jenkinsPending;
  const resume = B.jenkinsResume;
  B.jenkinsPending = null;
  B.jenkinsResume = null;
  document.getElementById('jenkinsOverlay').classList.remove('active');
  if (jp) {
    // Apply the deferred damage now
    const enemyTeam = B[jp.enemyTeam];
    const ef = enemyTeam ? active(enemyTeam) : null;
    if (ef && ef.name === jp.enemyName && !ef.ko) {
      ef.hp = Math.max(0, ef.hp - jp.damage);
      if (ef.hp <= 0) { ef.ko = true; ef.killedBy = 94; }
    }
    const rollLabel = describeRoll(jp.roll);
    log(`<span class="log-ability">${jp.jenkinsName}</span> — Greeting! Rolled [${jp.dice.join(', ')}] — ${rollLabel} → <span class="log-dmg">${jp.damage} entry damage to ${jp.enemyName}!</span> ${ef && ef.ko ? '<span class="log-ko">KO!</span>' : (ef ? ef.hp + ' HP left' : '')}`);
    playDamageSfx(jp.damage);
    hitDamage(jp.enemyTeam);
    renderBattle();
  }
  if (resume) setTimeout(resume, 300);
}

// Helper: after entry callouts finish, check for Jenkins modal before continuing
function afterEntryWithJenkins(entryCalloutCount, continuation) {
  const delay = entryCalloutCount > 0 ? entryCalloutCount * spd(1500) : 300;
  setTimeout(() => {
    if (B.jenkinsPending) {
      showJenkinsModal(continuation);
    } else {
      continuation();
    }
  }, delay);
}

// ============================================================
// ELOISE (85) — Change of Heart: swap HP with enemy for 1 Ice Shard
// ============================================================
function doEloiseChoice(choice) {
  const ep = B.eloisePending;
  if (!ep) return;
  B.eloisePending = null;
  document.getElementById('eloiseOverlay').classList.remove('active');
  const { team, btn } = ep;
  const f = active(B[team]);
  const oppTeam = team === 'red' ? 'blue' : 'red';
  const oppF = active(B[oppTeam]);
  if (choice === 'yes' && f && !f.ko && oppF && !oppF.ko && B[team].resources.ice >= 1) {
    // Spend 1 Ice Shard
    B[team].resources.ice -= 1;
    B.eloiseUsedThisRound[team] = true;
    // Swap HP values
    const myOldHp = f.hp;
    const oppOldHp = oppF.hp;
    f.hp = oppOldHp;
    oppF.hp = myOldHp;
    showAbilityCallout('CHANGE OF HEART!', 'var(--rare)', `${f.name} — HP swap! (${myOldHp} → ${f.hp}) vs enemy (${oppOldHp} → ${oppF.hp})`, team);
    log(`<span class="log-ability">${f.name}</span> — Change of Heart! Spent 1 Ice Shard. Swapped HP: ${myOldHp} → ${f.hp}, enemy ${oppOldHp} → ${oppF.hp}.`);
    renderBattle();
    setTimeout(() => { btn.disabled = false; btn.classList.remove('locked'); doTeamRoll(team, btn); }, spd(1500));
  } else {
    B.eloiseUsedThisRound[team] = true; // mark used so we don't re-offer on re-render
    narrate(`<b class="${team}-text">Eloise</b> holds — no swap this round.`);
    setTimeout(() => { btn.disabled = false; btn.classList.remove('locked'); doTeamRoll(team, btn); }, spd(200));
  }
}

// ============================================================
// MALLOW (89) — Dozy Cozy: spend 1 Sacred Fire to heal active ghost +3 HP
// ============================================================
function doMallowChoice(choice) {
  const mp = B.mallowPending;
  if (!mp) return;
  B.mallowPending = null;
  document.getElementById('mallowOverlay').classList.remove('active');
  const { team, btn } = mp;
  const f = active(B[team]);
  B.mallowDecided[team] = true;
  if (choice === 'yes' && f && !f.ko && B[team].resources && B[team].resources.fire >= 2) {
    B[team].resources.fire -= 2;
    const hpBefore = f.hp;
    const mallowSideG = getSidelineGhost(B[team], 89);
    const mallowName = mallowSideG ? mallowSideG.name : 'Mallow';
    // Mr Filbert (59) — Mask Merchant: healing on enemy's active ghost is flipped to damage
    const enemyTeamObj = B[team === 'red' ? 'blue' : 'red'];
    const filbertCursesMallow = hasSideline(enemyTeamObj, 59);
    if (filbertCursesMallow) {
      f.hp = Math.max(0, f.hp - 3);
      if (f.hp <= 0) { f.hp = 0; f.ko = true; f.killedBy = 59; }
      showAbilityCallout('MASK MERCHANT!', 'var(--uncommon)',
        `Mr Filbert — Dozy Cozy cursed! ${f.name} takes 3 damage! (${hpBefore} → ${f.hp} HP)`, team === 'red' ? 'blue' : 'red');
      log(`<span class="log-ability">Mr Filbert</span> — Mask Merchant! Dozy Cozy flipped to damage. ${f.name} ${hpBefore} → ${f.hp} HP.`);
    } else {
      f.hp += 3;
      const overMallow = f.hp > f.maxHp;
      // Grant 1 Burn as a resource (player places it via burn picker during pre-roll)
      if (!B[team].resources.burn) B[team].resources.burn = 0;
      B[team].resources.burn += 1;
      showAbilityCallout('DOZY COZY!', 'var(--rare)',
        `${mallowName} — spent 2 🔥! ${f.name} +3 HP (${hpBefore} → ${f.hp}${overMallow ? ' · overclocked!' : ''}) + 1 Burn!`, team);
      log(`<span class="log-ability">${mallowName}</span> — Dozy Cozy! Spent 2 Sacred Fire. ${f.name} +3 HP (${hpBefore} → ${f.hp}${overMallow ? ' · overclocked!' : ''}). +1 Burn!`);
    }
    renderBattle();
    if (f.ko) {
      // Ghost was KO'd by Filbert's Mask Merchant curse — trigger KO handling instead of rolling
      setTimeout(() => { if (!handleKOs()) renderBattle(); }, spd(1500));
    } else {
      setTimeout(() => { btn.disabled = false; btn.classList.remove('locked'); doTeamRoll(team, btn); }, spd(1500));
    }
  } else {
    log(`<span class="log-ability">Mallow</span> — holds the fire.`);
    setTimeout(() => { btn.disabled = false; btn.classList.remove('locked'); doTeamRoll(team, btn); }, spd(200));
  }
}

// ============================================================
// BOGEY (53) — Bogus: reactive reflect choice callback
// v430: Sylvia re-entry pattern. Called by bogeyOverlay buttons while
// resolveRound is paused at the damage-application decision point.
// ============================================================
function doBogeyReflectChoice(choice) {
  document.getElementById('bogeyOverlay').classList.remove('active');
  B.bogeyReflectChoice = choice;
  B.bogeyReflectResuming = true;
  resolveRound();
}

// ============================================================
// BOO BROTHERS (17) — Teamwork: trade 1 die for 1 HP before rolling
// ============================================================
function doBooChoice(choice) {
  const bp = B.booPending;
  if (!bp) return;
  B.booPending = null;
  document.getElementById('booOverlay').classList.remove('active');
  const { team, btn } = bp;
  const f = active(B[team]);
  if (choice === 'yes' && f && !f.ko && B.preRoll && B.preRoll[team] && B.preRoll[team].count >= 2) {
    // Flag: Boo Brothers used Teamwork this round → +1 damage bonus
    if (!B.booTeamworkDmgBonus) B.booTeamworkDmgBonus = { red: 0, blue: 0 };
    B.booTeamworkDmgBonus[team] = 1;
    const prevCount = B.preRoll[team].count;
    B.preRoll[team].count = Math.max(1, prevCount - 1);
    const prevHp = f.hp;
    // Mr Filbert (59) — Mask Merchant: healing on this ghost is flipped to damage
    const enemyTeamObj = B[team === 'red' ? 'blue' : 'red'];
    const filbertCursesTeamwork = hasSideline(enemyTeamObj, 59);
    if (filbertCursesTeamwork) {
      f.hp = Math.max(0, f.hp - 1);
      if (f.hp <= 0) { f.hp = 0; f.ko = true; f.killedBy = 59; }
      showAbilityCallout('MASK MERCHANT!', 'var(--uncommon)', `Mr Filbert — Teamwork cursed! ${f.name} takes 1 damage! (${prevHp} → ${f.hp} HP)`, team === 'red' ? 'blue' : 'red');
      log(`<span class="log-ability">Mr Filbert</span> — Mask Merchant! Teamwork flipped to damage. ${f.name} ${prevHp} → ${f.hp} HP.`);
    } else {
      f.hp += 1;
      const overTeam = f.hp > f.maxHp;
      showAbilityCallout('TEAMWORK!', 'var(--common)', `${f.name} — trade 1 die for +1 HP! (${prevCount} → ${B.preRoll[team].count} dice | ${prevHp} → ${f.hp} HP${overTeam ? ' · overclocked!' : ''})`, team);
      log(`<span class="log-ability">${f.name}</span> — Teamwork! Traded 1 die for +1 HP (${prevCount} → ${B.preRoll[team].count} dice, ${prevHp} → ${f.hp} HP${overTeam ? ' · overclocked!' : ''}).`);
    }
    renderBattle();
    if (f.ko) {
      // Ghost was KO'd by Filbert's Mask Merchant curse — trigger KO handling instead of rolling
      setTimeout(() => { if (!handleKOs()) renderBattle(); }, spd(1500));
    } else {
      setTimeout(() => { btn.disabled = false; btn.classList.remove('locked'); doTeamRoll(team, btn); }, spd(1500));
    }
  } else {
    narrate(`<b class="${team}-text">Boo Brothers</b> hold — keeping all dice.`);
    setTimeout(() => { btn.disabled = false; btn.classList.remove('locked'); doTeamRoll(team, btn); }, spd(200));
  }
}

// ============================================================
// GUS (31) — Gale Force: reactive post-win timed button (Guardian Fairy pattern)
// ============================================================
let gusGaleTimer = null;
function doGusGaleReactive(choice) {
  const gp = B.gusGaleReactivePending;
  if (!gp) return;
  B.gusGaleReactivePending = null;
  // Clear timer and hide button
  if (gusGaleTimer) { clearInterval(gusGaleTimer); gusGaleTimer = null; }
  document.getElementById('gusGaleBtn').style.display = 'none';
  const { winTeamName, loseTeamName, dmg, wF, lF, resume } = gp;
  const loseTeam = B[loseTeamName];
  const winTeam = B[winTeamName];
  if (choice === 'yes') {
    // Force swap — new ghost takes the damage via picker
    collectKC(winTeamName, wF.name);
    log(`<span class="log-ability">${wF.name}</span> — Gale Force! ${loseTeamName} must choose a replacement — the new ghost takes ${dmg} damage!`);
    queueAbility('GALE FORCE!', 'var(--common)', `${wF.name} — No damage! ${loseTeamName === 'red' ? 'Red' : 'Blue'} team must choose a replacement!`, null, winTeamName);
    // Cancel Guardian Fairy if it was pending (Gus swap takes priority)
    if (B.guardianFairyReactivePending) {
      B.guardianFairyReactivePending = null;
      if (gfWishTimer) { clearInterval(gfWishTimer); gfWishTimer = null; }
      document.getElementById('gfWishBtn').style.display = 'none';
    }
    // Set up gale force swap state for the picker
    B._gusGaleAccepted = true;
    B._gusGaleDmg = dmg;
    B._gusGaleWinTeam = winTeamName;
    B._gusGaleLoseTeam = loseTeamName;
    if (resume) setTimeout(resume, spd(1500));
  } else {
    // Player declined — damage applies to the current opponent now
    B._gusGaleAccepted = false;
    lF.hp = Math.max(0, lF.hp - dmg);
    if (lF.hp <= 0) { lF.ko = true; lF.killedBy = (wF.originalId || wF.id); }
    log(`<span class="log-dmg">${wF.name} deals ${dmg} to ${lF.name}!</span> ${lF.ko?'<span class="log-ko">KO!</span>':lF.hp+' HP left'}`);
    playDamageSfx(dmg);
    hitDamage(loseTeamName);
    renderBattle();
    if (resume) setTimeout(resume, 200);
  }
}

// Show Gus Gale Force as a timed button with countdown — auto-declines on expiry
function showGusGaleButton() {
  const gp = B.gusGaleReactivePending;
  if (!gp) return;
  const btn = document.getElementById('gusGaleBtn');
  const cdEl = document.getElementById('gusGaleCountdown');
  const subEl = document.getElementById('gusGaleSub');
  subEl.innerHTML = `Force ${gp.loseTeamName === 'red' ? 'Red' : 'Blue'} to swap — new ghost takes ${gp.dmg} dmg!`;
  btn.style.display = 'block';
  btn.onclick = () => doGusGaleReactive('yes');
  const secs = getSpecialsTimerSecs();
  let remaining = secs;
  cdEl.textContent = remaining;
  narrate(`<b class="${gp.winTeamName}-text">💨 ${gp.wF.name}</b> can force a swap! Click to activate!`);
  if (gusGaleTimer) clearInterval(gusGaleTimer);
  gusGaleTimer = setInterval(() => {
    remaining--;
    cdEl.textContent = remaining;
    if (remaining <= 0) {
      clearInterval(gusGaleTimer); gusGaleTimer = null;
      doGusGaleReactive('no'); // auto-decline
    }
  }, 1000);
}

// ============================================================
// RADITZ (62) — Hunt: entry forced-swap choice handlers
// ============================================================
function doRaditzHuntChoice(choice) {
  const rhp = B.raditzHuntPending;
  if (!rhp) return;
  B.raditzHuntPending = null;
  if (B.raditzHuntReady) B.raditzHuntReady[rhp.team] = false;
  document.getElementById('raditzHuntOverlay').classList.remove('active');
  const { team, btn, oppBtn } = rhp;

  if (choice === 'no') {
    narrate(`<b class="${team}-text">Raditz</b> — Hunt not used. Rolling as normal.`);
    // Unlock opponent's button so they can roll independently
    if (oppBtn) { oppBtn.disabled = false; oppBtn.classList.remove('locked'); }
    setTimeout(() => { btn.disabled = false; btn.classList.remove('locked'); doTeamRoll(team, btn); }, spd(200));
    return;
  }

  // YES — check for available sideline targets
  const enemyTeamName = team === 'red' ? 'blue' : 'red';
  const enemy = B[enemyTeamName];

  // Barnaby (326) — Stubborn: immune to opponent forced swaps
  const _barnabyHunt = active(enemy);
  if (_barnabyHunt && _barnabyHunt.id === 326 && !_barnabyHunt.ko) {
    narrate(`<b class="${team}-text">Raditz</b> — Hunt blocked! <b>${_barnabyHunt.name}</b> is Stubborn!`);
    log(`<span class="log-ability">Barnaby</span> — Stubborn! Raditz Hunt blocked — ${_barnabyHunt.name} cannot be forced out.`);
    if (oppBtn) { oppBtn.disabled = false; oppBtn.classList.remove('locked'); }
    setTimeout(() => { btn.disabled = false; btn.classList.remove('locked'); doTeamRoll(team, btn); }, spd(200));
    return;
  }

  const aliveSideline = enemy.ghosts.filter((g, i) => i !== enemy.activeIdx && !g.ko);

  if (aliveSideline.length === 0) {
    // No valid swap targets (shouldn't happen, but guard it)
    narrate(`<b class="${team}-text">Raditz</b> — Hunt! No sideline ghosts to swap in.`);
    if (oppBtn) { oppBtn.disabled = false; oppBtn.classList.remove('locked'); }
    setTimeout(() => { btn.disabled = false; btn.classList.remove('locked'); doTeamRoll(team, btn); }, spd(200));
    return;
  }

  // Store continuation for doRaditzHuntSwap
  B.raditzHuntCont = { team, btn, oppBtn };

  if (aliveSideline.length === 1) {
    // Auto-swap to the only option
    doRaditzHuntSwap(team, enemy.ghosts.indexOf(aliveSideline[0]));
    return;
  }

  // Multiple options — show pressureOverlay for opponent to pick who comes in
  const enemyLabel = enemyTeamName.charAt(0).toUpperCase() + enemyTeamName.slice(1);
  const whoBanner = document.getElementById('pressureWho');
  if (whoBanner) { whoBanner.className = `pm-who-banner ${enemyTeamName}`; whoBanner.textContent = `🎯 ${enemyLabel.toUpperCase()} PICKS`; }
  const pTitle = document.getElementById('pressureTitle');
  if (pTitle) pTitle.textContent = `Hunt! — Raditz forces a swap`;
  const pSub = document.getElementById('pressureSub');
  if (pSub) pSub.textContent = `${enemyLabel}: choose which ghost enters the fight.`;
  document.getElementById('pressureOptions').innerHTML = aliveSideline.map(g => {
    const realIdx = enemy.ghosts.indexOf(g);
    const gd = ghostData(g.id);
    const hpRatio = g.hp / g.maxHp;
    const hpColor = hpRatio > 0.6 ? 'var(--hp-green)' : hpRatio > 0.3 ? 'var(--hp-yellow)' : 'var(--hp-red)';
    return `<div class="pressure-opt" onclick="doRaditzHuntSwap('${team}',${realIdx})">
      ${gd.art ? `<img src="${gd.art}" style="width:50px;height:50px;border-radius:6px;object-fit:cover;border:1px solid var(--${gd.rarity});">` : ''}
      <div><div style="font-weight:700;">${g.name}</div>
      <div style="font-size:12px;color:var(--text2);"><span style="color:${hpColor};font-weight:700;">♥ ${g.hp}/${g.maxHp}</span> · <span style="color:var(--moonstone);">${gd.ability}</span></div></div>
    </div>`;
  }).join('');
  // B.phase stays 'rolling'; both buttons are still locked — pressureOverlay blocks input
  B.pressurePickerTeam = enemyTeamName; // v728: track which team picks (for PvP auto-resolve)
  document.getElementById('pressureOverlay').classList.add('active');
}

function doRaditzHuntSwap(attackerTeam, targetIdx) {
  document.getElementById('pressureOverlay').classList.remove('active');
  const cont = B.raditzHuntCont;
  B.raditzHuntCont = null;
  if (!cont) return;
  const { team, btn, oppBtn } = cont;

  const t = B[attackerTeam];
  const raditzG = active(t);
  const enemy = opp(t);
  const oldGhost = active(enemy);
  const oldName = oldGhost.name;

  // Perform the swap — incoming ghost returns at full HP
  enemy.activeIdx = targetIdx;
  const newGhost = active(enemy);
  newGhost.hp = newGhost.maxHp;
  renderBattle();

  const attackerCls = attackerTeam === 'red' ? 'red-text' : 'blue-text';
  narrate(`<b class="${attackerCls}">${raditzG.name}</b> — Hunt! <b>${oldName}</b> to the sideline — <b>${newGhost.name}</b> enters at full HP!`);
  showAbilityCallout('HUNT!', 'var(--rare)', `${oldName} forced out — ${newGhost.name} enters!`, attackerTeam);
  log(`<span class="log-ability">${raditzG.name}</span> — Hunt! ${oldName} sent to sideline, ${newGhost.name} enters at full HP.`);

  setTimeout(() => {
    const entryCalloutCount = triggerEntry(enemy, false);
    afterEntryWithJenkins(entryCalloutCount, () => {
      if (handleKOs()) return; // entry effect caused a KO — KO flow takes over
      renderBattle();
      // Unlock opponent's button — they can now roll independently
      if (oppBtn) { oppBtn.disabled = false; oppBtn.classList.remove('locked'); }
      // Raditz's team rolls
      btn.disabled = false;
      btn.classList.remove('locked');
      doTeamRoll(team, btn);
    });
  }, spd(1500));
}

// ============================================================
// DOUG (63) — Caution: once-per-game pre-roll swap for +1 die
// ============================================================
function doDougCautionChoice(choice) {
  const dp = B.dougCautionPending;
  if (!dp) return;
  B.dougCautionPending = null;
  document.getElementById('dougCautionOverlay').classList.remove('active');
  const { team, btn } = dp;

  if (choice === 'no') {
    // Mark as used so we don't re-offer (once-per-game skip counts as use)
    if (B.dougCautionUsed) B.dougCautionUsed[team] = true;
    narrate(`<b class="${team}-text">Doug</b> — Caution not used. Rolling as normal.`);
    setTimeout(() => { btn.disabled = false; btn.classList.remove('locked'); doTeamRoll(team, btn); }, spd(200));
    return;
  }
  // YES — show ghost picker (already rendered in the overlay)
  // doDougCautionSwap handles the actual swap
}

function doDougCautionSwap(targetIdx) {
  document.getElementById('dougCautionOverlay').classList.remove('active');
  const dp = B.dougCautionPending;
  B.dougCautionPending = null;
  if (!dp) return;
  const { team, btn } = dp;

  if (B.dougCautionUsed) B.dougCautionUsed[team] = true;

  const myTeam = B[team];
  const doug = active(myTeam); // Doug (currently active)
  const dougOldIdx = myTeam.activeIdx;
  const dougName = doug.name;

  // Swap Doug to sideline, bring in chosen ghost
  myTeam.activeIdx = targetIdx;
  const newGhost = active(myTeam);
  const newName = newGhost.name;

  renderBattle();

  const teamCls = `${team}-text`;
  narrate(`<b class="${teamCls}">${dougName}</b> — Caution! Swaps to sideline — <b>${newName}</b> enters (+1 die this roll)!`);
  showAbilityCallout('CAUTION!', 'var(--rare)', `${dougName} → sideline | ${newName} enters with +1 die!`, team);
  log(`<span class="log-ability">${dougName}</span> — Caution! Doug to sideline, ${newName} enters (+1 die this roll).`);

  setTimeout(() => {
    const entryCalloutCount = triggerEntry(myTeam, false);
    afterEntryWithJenkins(entryCalloutCount, () => {
      if (handleKOs()) return;
      // Apply +1 die bonus to the incoming ghost's roll.
      // During Duel Phase, B.preRoll doesn't exist yet (it's built later in
      // doPreRollSetup), so stash a promise that doPreRollSetup picks up.
      if (B.preRoll && B.preRoll[team]) {
        B.preRoll[team].count = Math.min(6, B.preRoll[team].count + 1);
      } else if (B.dougCautionDieBonus) {
        B.dougCautionDieBonus[team] = true;
      }
      renderBattle();
      btn.disabled = false;
      btn.classList.remove('locked');
      doTeamRoll(team, btn);
    });
  }, spd(1500));
}

// ============================================================
// JACKSON (50) — Regrow: post-roll spend 1 HP to reroll 1 die
// ============================================================
function checkJacksonRegrow(team, dice, continuation) {
  const f = active(B[team]);
  if (!f || f.id !== 50 || f.ko || f.hp < 2) {
    continuation();
    return;
  }
  B.jacksonPending = { team, dice: [...dice], continuation };
  document.getElementById('jacksonTitle').textContent = `Jackson — Regrow! (${f.hp} HP)`;
  document.getElementById('jacksonSub').textContent = `Spend 1 HP to reroll 1 die? (${f.hp} → ${f.hp - 1} HP)`;
  document.getElementById('jacksonDiePicker').style.display = 'none';
  document.getElementById('jacksonOverlay').classList.add('active');
}

function doJacksonChoice(choice) {
  const jp = B.jacksonPending;
  if (!jp) return;
  const { team, dice, continuation } = jp;
  const f = active(B[team]);
  if (choice === 'no' || !f || f.ko || f.hp < 2) {
    B.jacksonPending = null;
    document.getElementById('jacksonOverlay').classList.remove('active');
    narrate(`<b class="${team}-text">Jackson</b> holds HP — keeping dice as rolled.`);
    continuation();
    return;
  }
  // YES — show die picker with current dice values as buttons
  const diceButtons = document.getElementById('jacksonDiceButtons');
  diceButtons.innerHTML = dice.map((v, i) =>
    `<button onclick="pickJacksonDie(${i})" style="width:50px;height:50px;border-radius:10px;border:2px solid var(--uncommon);background:rgba(74,222,128,0.12);color:var(--uncommon);font-size:24px;font-weight:900;cursor:pointer;">${v}</button>`
  ).join('');
  document.getElementById('jacksonDiePicker').style.display = 'block';
}

function pickJacksonDie(idx) {
  const jp = B.jacksonPending;
  if (!jp) return;
  B.jacksonPending = null;
  const { team, continuation } = jp;
  const t = B[team];
  const f = active(t);
  document.getElementById('jacksonOverlay').classList.remove('active');
  if (!f || f.ko || f.hp < 2) { continuation(); return; }

  // Spend 1 HP
  const prevHp = f.hp;
  f.hp -= 1;
  // Mutate the preRoll dice array IN-PLACE so postRollDone's closure sees the change.
  // (Same pattern as Sonya v284 / Jeanie v285 / Dark Wing v285)
  // Creating a new array via [...B.redDice] does NOT work: postRollDone() closes over
  // B.preRoll.*.dice by reference, so its B.pendingResolve = { redDice, blueDice }
  // would silently overwrite Jackson's rerolled die before resolveRound ever sees it.
  const preRollDice = team === 'red' ? B.preRoll.red.dice : B.preRoll.blue.dice;
  const oldVal = preRollDice[idx];
  const newVal = Math.floor(Math.random() * 6) + 1;
  preRollDice[idx] = newVal;
  preRollDice.sort((a, b) => a - b);

  // Keep B.redDice/B.blueDice and B.pendingResolve in sync (pendingResolve may not exist yet)
  if (team === 'red') { B.redDice = preRollDice; if (B.pendingResolve) B.pendingResolve.redDice = preRollDice; }
  else               { B.blueDice = preRollDice; if (B.pendingResolve) B.pendingResolve.blueDice = preRollDice; }
  renderDice(B.redDice, B.blueDice);
  renderBattle();

  showAbilityCallout('REGROW!', 'var(--uncommon)', `${f.name} — die rerolled: ${oldVal} → ${newVal}! (${prevHp} → ${f.hp} HP)`, team);
  log(`<span class="log-ability">${f.name}</span> — Regrow! Spent 1 HP, rerolled die: ${oldVal} → ${newVal} (${prevHp} → ${f.hp} HP). New dice: [${preRollDice.join(', ')}]`);

  // Short pause for callout, then re-prompt if Jackson can go again
  setTimeout(() => {
    checkJacksonRegrow(team, [...preRollDice], continuation);
  }, 1200);
}

// ============================================================
// Jeanie (90) — Hidden Treasure: force opponent reroll (once per game)
// Fires post-roll (after Jackson), when Jeanie is on the sideline
// ============================================================
function checkJeanieHiddenTreasure(team, continuation) {
  // Team is Jeanie's team — they can force the OPPONENT to reroll
  if (!hasSideline(B[team], 90) || !B.jeanieUsed || B.jeanieUsed[team]) {
    continuation();
    return;
  }
  const jF = getSidelineGhost(B[team], 90);
  if (!jF || jF.ko) { continuation(); return; }

  const oppTeam = team === 'red' ? 'blue' : 'red';
  const oppF = active(B[oppTeam]);
  const oppLabel = oppTeam.charAt(0).toUpperCase() + oppTeam.slice(1);
  const oppDice = team === 'red' ? B.blueDice : B.redDice;

  B.jeaniePending = { team, oppTeam, continuation };
  document.getElementById('jeanieTitle').textContent = `Jeanie — Hidden Treasure! (${team.charAt(0).toUpperCase()+team.slice(1)})`;
  document.getElementById('jeanieSub').textContent = `Force ${oppLabel} (${oppF ? oppF.name : 'opponent'}) to reroll all ${oppDice.length} dice? (Once per game)`;
  document.getElementById('jeanieOverlay').classList.add('active');
}

function doJeanieChoice(choice) {
  const jp = B.jeaniePending;
  if (!jp) return;
  B.jeaniePending = null;
  document.getElementById('jeanieOverlay').classList.remove('active');

  const { team, oppTeam, continuation } = jp;
  const teamLabel = team.charAt(0).toUpperCase() + team.slice(1);
  const oppLabel = oppTeam.charAt(0).toUpperCase() + oppTeam.slice(1);

  if (choice === 'no') {
    narrate(`<b class="${team}-text">Jeanie</b> holds the treasure for now...`);
    continuation();
    return;
  }

  // YES — consume the once-per-game use
  B.jeanieUsed[team] = true;

  // Reroll ALL of the opponent's dice
  // Mutate the preRoll dice array IN-PLACE so the doPostRollAndResolve closure captures
  // the change. Creating a new array and assigning to B.pendingResolve does NOT work:
  // postRollDone() creates B.pendingResolve = { redDice, blueDice } using the closure
  // variables (which are B.preRoll.red/blue.dice) AFTER Jeanie runs, silently
  // overwriting any assignment to B.pendingResolve made here. (Same bug fixed for Sonya
  // in v284 and Dark Wing earlier.)
  const oldDice = oppTeam === 'red' ? [...B.preRoll.red.dice] : [...B.preRoll.blue.dice];
  const numDice = oldDice.length;
  const newDice = Array.from({length: numDice}, () => Math.floor(Math.random() * 6) + 1).sort((a,b)=>a-b);

  // Splice into the preRoll array in-place so the closure sees the new values
  const preRollDice = oppTeam === 'red' ? B.preRoll.red.dice : B.preRoll.blue.dice;
  preRollDice.splice(0, preRollDice.length, ...newDice);
  if (oppTeam === 'red') { B.redDice = preRollDice; if (B.pendingResolve) B.pendingResolve.redDice = preRollDice; }
  else                   { B.blueDice = preRollDice; if (B.pendingResolve) B.pendingResolve.blueDice = preRollDice; }
  renderDice(B.redDice, B.blueDice);
  renderBattle();

  const jF = getSidelineGhost(B[team], 90);
  showAbilityCallout('HIDDEN TREASURE!', 'var(--rare)',
    `${jF ? jF.name : 'Jeanie'} forces ${oppLabel} to reroll! [${oldDice.join(', ')}] → [${newDice.join(', ')}]`, team);
  log(`<span class="log-ability">Jeanie</span> — Hidden Treasure! ${teamLabel} forces ${oppLabel} to reroll: [${oldDice.join(', ')}] → [${newDice.join(', ')}].`);

  // Pause for callout splash then continue
  setTimeout(() => { continuation(); }, spd(1500));
}

// ============================================================
// SONYA (69) — Mesmerize: post-roll change one die to 2 (once per round, free)
// ============================================================
function checkSonyaMesmerize(team, continuation) {
  const f = active(B[team]);
  if (!f || f.id !== 69 || f.ko || (B.sonyaUsedThisRound && B.sonyaUsedThisRound[team])) {
    continuation();
    return;
  }
  B.sonyaPending = { team, continuation };
  document.getElementById('sonyaTitle').textContent = `Sonya — Mesmerize! (${team.charAt(0).toUpperCase()+team.slice(1)})`;
  document.getElementById('sonyaSub').textContent = `Change one of your dice to a 2? (Free — once per roll)`;
  document.getElementById('sonyaDiePicker').style.display = 'none';
  document.getElementById('sonyaOverlay').classList.add('active');
}

function doSonyaChoice(choice) {
  const sp = B.sonyaPending;
  if (!sp) return;
  const { team, continuation } = sp;
  if (choice === 'no') {
    B.sonyaPending = null;
    document.getElementById('sonyaOverlay').classList.remove('active');
    narrate(`<b class="${team}-text">Sonya</b> holds steady — keeping dice as rolled.`);
    continuation();
    return;
  }
  // YES — show die picker with current dice as clickable buttons
  const dice = team === 'red' ? [...B.redDice] : [...B.blueDice];
  const diceButtons = document.getElementById('sonyaDiceButtons');
  diceButtons.innerHTML = dice.map((v, i) =>
    `<button onclick="pickSonyaDie(${i})" style="width:50px;height:50px;border-radius:10px;border:2px solid #8b2fc9;background:rgba(139,47,201,0.15);color:#c084fc;font-size:24px;font-weight:900;cursor:pointer;">${v}</button>`
  ).join('');
  document.getElementById('sonyaDiePicker').style.display = 'block';
}

function pickSonyaDie(idx) {
  const sp = B.sonyaPending;
  if (!sp) return;
  B.sonyaPending = null;
  const { team, continuation } = sp;
  const f = active(B[team]);
  document.getElementById('sonyaOverlay').classList.remove('active');
  if (!f || f.ko) { continuation(); return; }

  // Mutate the preRoll dice array IN-PLACE so the doPostRollAndResolve closure captures
  // the change. Creating a new array via [...B.redDice] does NOT work: postRollDone()
  // captures B.preRoll.red.dice by reference, so when it later runs
  //   B.pendingResolve = { redDice, blueDice, ... }
  // it uses the original unmodified closure variable, silently discarding Sonya's edit.
  // Dark Wing uses the same in-place splice pattern (see doDarkWingChoice ~line 4386).
  const preRollDice = team === 'red' ? B.preRoll.red.dice : B.preRoll.blue.dice;
  const oldVal = preRollDice[idx];

  preRollDice[idx] = 2;
  preRollDice.sort((a, b) => a - b);
  if (B.sonyaUsedThisRound) B.sonyaUsedThisRound[team] = true;

  // Keep B.redDice/B.blueDice and B.pendingResolve in sync (pendingResolve may not exist yet)
  if (team === 'red') { B.redDice = preRollDice; if (B.pendingResolve) B.pendingResolve.redDice = preRollDice; }
  else               { B.blueDice = preRollDice; if (B.pendingResolve) B.pendingResolve.blueDice = preRollDice; }
  renderDice(B.redDice, B.blueDice);
  renderBattle();

  if (oldVal === 2) {
    showAbilityCallout('MESMERIZE!', 'var(--rare)', `${f.name} — die already showing 2, no change!`, team);
    log(`<span class="log-ability">${f.name}</span> — Mesmerize! Die already a 2, no change.`);
  } else {
    showAbilityCallout('MESMERIZE!', 'var(--rare)', `${f.name} — changed die: ${oldVal} → 2! New dice: [${preRollDice.join(', ')}]`, team);
    log(`<span class="log-ability">${f.name}</span> — Mesmerize! Changed die ${oldVal} → 2. Dice: [${preRollDice.join(', ')}]`);
  }

  setTimeout(() => { continuation(); }, 1200);
}

// ============================================================
// Dark Wing (76) — Precision: post-roll reroll all dice if not doubles
// Fires after drainAbilityQueue, before Jackson in the post-roll chain
// ============================================================
function checkDarkWingPrecision(team, continuation) {
  const f = active(B[team]);
  if (!f || f.id !== 76 || f.ko) { continuation(); return; }
  if (B.darkWingUsedThisGame && B.darkWingUsedThisGame[team]) { continuation(); return; }
  const dice = team === 'red' ? B.redDice : B.blueDice;
  // Skip the reroll offer if we already got doubles OR BETTER (triples/quads/penta).
  // Rerolling a triple is strictly worse — damage can only drop.
  if (classify(dice).damage >= 2) { continuation(); return; }
  // Offer reroll
  B.darkWingPending = { team, continuation };
  const tLabel = team.charAt(0).toUpperCase() + team.slice(1);
  document.getElementById('darkWingTitle').textContent = `Dark Wing — Precision! (${tLabel})`;
  document.getElementById('darkWingSub').textContent = `Rolled [${dice.join(', ')}] — no doubles. Reroll all ${dice.length} dice?`;
  document.getElementById('darkWingOverlay').classList.add('active');
}

function doDarkWingChoice(choice) {
  const dp = B.darkWingPending;
  if (!dp) return;
  B.darkWingPending = null;
  document.getElementById('darkWingOverlay').classList.remove('active');
  const { team, continuation } = dp;
  const f = active(B[team]);
  if (B.darkWingUsedThisGame) B.darkWingUsedThisGame[team] = true;

  if (choice === 'no' || !f || f.ko) {
    narrate(`<b class="${team}-text">Dark Wing</b> holds — keeping dice as rolled.`);
    continuation();
    return;
  }

  // YES — reroll all dice for this team
  const count = team === 'red' ? B.preRoll.red.count : B.preRoll.blue.count;
  const newDice = Array.from({ length: count }, () => Math.floor(Math.random() * 6) + 1).sort((a, b) => a - b);

  // Mutate the preRoll dice array in-place so the postRollDone closure sees the new values
  const preRollDice = team === 'red' ? B.preRoll.red.dice : B.preRoll.blue.dice;
  preRollDice.splice(0, preRollDice.length, ...newDice);
  if (team === 'red') B.redDice = preRollDice;
  else B.blueDice = preRollDice;
  renderDice(B.redDice, B.blueDice);
  renderBattle();

  const rollType = classify(newDice).type;
  showAbilityCallout('PRECISION!', 'var(--rare)', `${f.name} — rerolled! [${newDice.join(', ')}]${rollType === 'doubles' ? ' 🎯 Doubles!' : ''}`, team);
  log(`<span class="log-ability">${f.name}</span> — Precision! Rerolled all dice → [${newDice.join(', ')}]`);

  setTimeout(() => { continuation(); }, 1200);
}

// ============================================================
// Drizzle (328) — Rain Dance: auto-reroll all 1s from both teams (free, no modal)
// Fires before Dark Wing in the post-roll chain.
// Uses in-place splice/mutation so the postRollDone closure captures the new values.
// ============================================================
// Tommy Salami (30) — Regulator: when Tommy rolls a 6, gain +1 bonus die rolled immediately.
// Chains as long as bonus dice keep rolling 6s. Fires BEFORE Drizzle in the post-roll chain.
// Interactive modal version: each 6 triggers a click-to-roll bonus die. Chains on 6s.
// B.tommyRegulatorBonus[team] stores total bonus dice added (used for callouts/log only).
function checkTommyRegulator(continuation) {
  const rF = active(B.red), bF = active(B.blue);
  const tommyTeamName = (rF && rF.id === 30 && !rF.ko) ? 'red' : (bF && bF.id === 30 && !bF.ko) ? 'blue' : null;
  // Reset bonus both teams each round regardless of whether Tommy is active
  if (B.tommyRegulatorBonus) { B.tommyRegulatorBonus.red = 0; B.tommyRegulatorBonus.blue = 0; }
  if (!tommyTeamName) { continuation(); return; }
  const tommyF = tommyTeamName === 'red' ? rF : bF;
  const tommyDice = B.preRoll[tommyTeamName].dice;
  if (!tommyDice || tommyDice.length === 0) { continuation(); return; }
  // Count 6s in Tommy's initial roll
  const initialSixes = tommyDice.filter(d => d === 6).length;
  if (initialSixes === 0) { continuation(); return; }

  // AutoPlay: silent auto-roll (AI doesn't need the modal)
  if (autoPlayRunning) {
    let newSixes = initialSixes;
    let totalBonus = 0;
    while (newSixes > 0) {
      const bonusDice = [];
      for (let i = 0; i < newSixes; i++) {
        bonusDice.push(Math.floor(Math.random() * 6) + 1);
      }
      tommyDice.push(...bonusDice);
      totalBonus += bonusDice.length;
      newSixes = bonusDice.filter(d => d === 6).length;
    }
    if (totalBonus > 0) {
      B.tommyRegulatorBonus[tommyTeamName] = totalBonus;
      tommyDice.sort((a, b) => a - b);
      if (tommyTeamName === 'red') { B.redDice = tommyDice; }
      else { B.blueDice = tommyDice; }
      renderDice(B.redDice, B.blueDice);
      renderBattle();
    }
    continuation();
    return;
  }

  // Interactive modal: chain one die at a time
  B.tommyChainPending = {
    team: tommyTeamName,
    dice: tommyDice,
    pendingSixes: initialSixes,
    totalBonus: 0,
    tommyF: tommyF,
    continuation: continuation
  };
  // Show modal
  const sub = document.getElementById('tommySub');
  sub.textContent = `You rolled ${initialSixes} six${initialSixes > 1 ? 'es' : ''}! Roll a bonus die!`;
  const dieEl = document.getElementById('tommyDieDisplay');
  dieEl.textContent = '🎲';
  const btn = document.getElementById('tommyRollBtn');
  btn.disabled = false;
  btn.textContent = '🎲 Roll the Bonus Die!';
  document.getElementById('tommyOverlay').classList.add('active');
}

function doTommyRoll() {
  const btn = document.getElementById('tommyRollBtn');
  if (!btn || btn.disabled) return;
  btn.disabled = true;

  const tp = B.tommyChainPending;
  if (!tp) return;

  const finalValue = Math.floor(Math.random() * 6) + 1;
  const dieEl = document.getElementById('tommyDieDisplay');

  // Shuffle animation: cycle through random values for ~600ms then land
  let ticks = 0;
  const totalTicks = 10;
  const tickMs = 60;
  const shuffle = setInterval(() => {
    ticks++;
    dieEl.textContent = String(Math.floor(Math.random() * 6) + 1);
    dieEl.style.transform = `rotate(${ticks * 36}deg)`;
    if (ticks >= totalTicks) {
      clearInterval(shuffle);
      dieEl.textContent = String(finalValue);
      dieEl.style.transform = 'rotate(0deg) scale(1.3)';
      setTimeout(() => { dieEl.style.transform = 'rotate(0deg) scale(1)'; }, 200);

      // Add die to Tommy's array
      tp.dice.push(finalValue);
      tp.totalBonus++;
      tp.pendingSixes--;

      if (finalValue === 6) {
        // Chain continues! This 6 adds another pending roll
        tp.pendingSixes++;
      }

      const sub = document.getElementById('tommySub');
      if (tp.pendingSixes > 0) {
        // More rolls to do
        if (finalValue === 6) {
          sub.innerHTML = `<b>ANOTHER 6!</b> +${tp.totalBonus} bonus dice so far! Keep rolling!`;
        } else {
          sub.innerHTML = `Rolled a ${finalValue}! +${tp.totalBonus} bonus dice so far! ${tp.pendingSixes} more to roll!`;
        }
        btn.disabled = false;
        btn.textContent = '🎲 Roll the Bonus Die!';
      } else {
        // Chain ends
        if (finalValue === 6) {
          sub.innerHTML = `<b>ANOTHER 6!</b> +${tp.totalBonus} bonus dice total! Chain complete!`;
        } else {
          sub.innerHTML = `Rolled a ${finalValue}! Chain ends! <b>+${tp.totalBonus} bonus dice total!</b>`;
        }
        // Close modal after delay and finalize
        setTimeout(() => { finishTommyChain(); }, 1000);
      }
    }
  }, tickMs);
}

function finishTommyChain() {
  const tp = B.tommyChainPending;
  if (!tp) return;
  B.tommyChainPending = null;
  document.getElementById('tommyOverlay').classList.remove('active');

  const { team, dice, totalBonus, tommyF, continuation } = tp;
  B.tommyRegulatorBonus[team] = totalBonus;
  dice.sort((a, b) => a - b);
  if (team === 'red') { B.redDice = dice; }
  else { B.blueDice = dice; }
  renderDice(B.redDice, B.blueDice);
  renderBattle();
  showAbilityCallout('REGULATOR!', 'var(--common)',
    `${tommyF.name} — Rolled 6s! +${totalBonus} bonus dice! Now rolling [${dice.join(', ')}]`, team);
  log(`<span class="log-ability">${tommyF.name}</span> — Regulator! Rolled 6s → +${totalBonus} bonus dice! [${dice.join(', ')}]`);
  setTimeout(() => { continuation(); }, 800);
}

// ============================================================
// Calvin & Anna (91) — Toboggan: post-KO voluntary swap
// ============================================================
function showTobogganModal(winTeamName, sidelineGhosts, continuation) {
  const teamColor = winTeamName === 'red' ? 'red-text' : 'blue-text';
  const banner = document.getElementById('tobogganBanner');
  if (banner) {
    banner.className = 'pm-who-banner ' + winTeamName;
    banner.textContent = '🛷 TOBOGGAN!';
  }

  // Build ghost portrait options (sideline ghosts to swap C&A with)
  const opts = document.getElementById('tobogganOptions');
  if (opts) {
    opts.innerHTML = sidelineGhosts.map(g => {
      const gd = ghostData(g.id);
      const realIdx = B[winTeamName].ghosts.indexOf(g);
      const hpRatio = g.hp / g.maxHp;
      const hpColor = hpRatio > 0.6 ? 'var(--hp-green)' : hpRatio > 0.3 ? 'var(--hp-yellow)' : 'var(--hp-red)';
      return `<div class="pressure-opt" onclick="doTobogganChoice(${realIdx})">
        ${gd.art ? `<img src="${gd.art}" style="width:50px;height:50px;border-radius:6px;object-fit:cover;border:1px solid var(--${gd.rarity});">` : ''}
        <div>
          <div style="font-weight:700;">${g.name}</div>
          <div style="font-size:12px;color:var(--text2);"><span style="color:${hpColor};font-weight:700;">&hearts; ${g.hp}/${g.maxHp}</span> &middot; <span style="color:var(--moonstone);">${gd.ability}</span></div>
        </div>
      </div>`;
    }).join('');
  }

  // Store continuation for doTobogganChoice
  B.tobogganPending = { winTeamName, continuation };
  B.phase = 'ko-pause'; // keep roll buttons locked during modal
  document.getElementById('tobogganOverlay').classList.add('active');
}

function doTobogganChoice(idx) {
  const tp = B.tobogganPending;
  if (!tp) return;
  B.tobogganPending = null;
  document.getElementById('tobogganOverlay').classList.remove('active');

  const { winTeamName, continuation } = tp;
  const winTeam = B[winTeamName];
  const caGhost = active(winTeam); // Calvin & Anna (currently active)

  if (idx === -1) {
    // No — C&A stays in
    narrate(`<b class="${winTeamName}-text">Calvin &amp; Anna</b> stays in the fight!`);
    log(`Calvin & Anna — Toboggan declined. Staying in.`);
    continuation();
    return;
  }

  // YES — swap C&A to sideline, bring chosen ghost in
  const oldName = caGhost.name;
  const newGhost = winTeam.ghosts[idx];

  winTeam.activeIdx = idx;
  // Incoming ghost heals to full HP when entering from sideline
  newGhost.hp = newGhost.maxHp;
  renderBattle();

  const teamColor = winTeamName === 'red' ? 'red-text' : 'blue-text';
  narrate(`<b class="${teamColor}">${oldName}</b> — Toboggan! Slides to sideline — <b>${newGhost.name}</b> enters the fight!`);
  showAbilityCallout('TOBOGGAN!', 'var(--rare)', `${oldName} slides out — ${newGhost.name} enters!`, winTeamName);
  log(`<span class="log-ability">Calvin & Anna</span> — Toboggan! ${oldName} slides to sideline, ${newGhost.name} enters.`);

  // Fire entry effects for the newly-active ghost, then continue
  setTimeout(() => {
    const entryCount = triggerEntry(winTeam, false);
    afterEntryWithJenkins(entryCount, continuation);
  }, spd(1500));
}

// ============================================================
// Fang Outside (6) — Skillful Coward: post-win voluntary swap
// ============================================================
function showFangOutsideModal(winTeamName, sidelineGhosts, continuation) {
  const banner = document.getElementById('fangOutsideBanner');
  if (banner) {
    banner.className = 'pm-who-banner ' + winTeamName;
    banner.textContent = '💨 SKILLFUL COWARD!';
  }

  // Build ghost portrait options (sideline ghosts to swap Fang with)
  const opts = document.getElementById('fangOutsideOptions');
  if (opts) {
    opts.innerHTML = sidelineGhosts.map(g => {
      const gd = ghostData(g.id);
      const realIdx = B[winTeamName].ghosts.indexOf(g);
      const hpRatio = g.hp / g.maxHp;
      const hpColor = hpRatio > 0.6 ? 'var(--hp-green)' : hpRatio > 0.3 ? 'var(--hp-yellow)' : 'var(--hp-red)';
      return `<div class="pressure-opt" onclick="doFangOutsideChoice(${realIdx})">
        ${gd.art ? `<img src="${gd.art}" style="width:50px;height:50px;border-radius:6px;object-fit:cover;border:1px solid var(--${gd.rarity});">` : ''}
        <div>
          <div style="font-weight:700;">${g.name}</div>
          <div style="font-size:12px;color:var(--text2);"><span style="color:${hpColor};font-weight:700;">&hearts; ${g.hp}/${g.maxHp}</span> &middot; <span style="color:var(--moonstone);">${gd.ability}</span></div>
        </div>
      </div>`;
    }).join('');
  }

  B.fangOutsidePending = { winTeamName, continuation };
  B.phase = 'ko-pause';
  document.getElementById('fangOutsideOverlay').classList.add('active');
}

function doFangOutsideChoice(idx) {
  const fp = B.fangOutsidePending;
  if (!fp) return;
  B.fangOutsidePending = null;
  document.getElementById('fangOutsideOverlay').classList.remove('active');

  const { winTeamName, continuation } = fp;
  const winTeam = B[winTeamName];
  const fangGhost = active(winTeam); // Fang Outside (currently active)

  if (idx === -1) {
    // No — Fang stays in
    narrate(`<b class="${winTeamName}-text">Fang Outside</b> holds their ground!`);
    log(`Fang Outside — Skillful Coward declined. Staying in.`);
    continuation();
    return;
  }

  // YES — swap Fang to sideline, bring chosen ghost in
  const oldName = fangGhost.name;
  const newGhost = winTeam.ghosts[idx];

  winTeam.activeIdx = idx;
  // Fang retains their HP on the sideline; incoming ghost retains their sideline HP
  renderBattle();

  const teamColor = winTeamName === 'red' ? 'red-text' : 'blue-text';
  narrate(`<b class="${teamColor}">${oldName}</b> — Skillful Coward! Slips to sideline — <b>${newGhost.name}</b> enters the fight!`);
  showAbilityCallout('SKILLFUL COWARD!', 'var(--common)', `${oldName} slips out — ${newGhost.name} enters!`, winTeamName);
  log(`<span class="log-ability">Fang Outside</span> — Skillful Coward! ${oldName} to sideline, ${newGhost.name} enters.`);

  // Fire entry effects for the newly-active ghost, then continue
  setTimeout(() => {
    const entryCount = triggerEntry(winTeam, false);
    afterEntryWithJenkins(entryCount, continuation);
  }, spd(1500));
}

// Fang Undercover (7) — Skilled Coward: arm choice handler
function doFangUndercoverArmChoice(choice) {
  const fp = B.fangUndercoverPending;
  if (!fp) return;
  B.fangUndercoverPending = null;
  document.getElementById('fangUndercoverArmOverlay').classList.remove('active');
  const { team, btn } = fp;
  if (choice === 'yes') {
    B.fangUndercoverArmed[team] = true;
    showAbilityCallout('SKILLED COWARD!', 'var(--common)', `Fang Undercover armed — dodge incoming damage this round!`, team);
    log(`<span class="log-ability">Fang Undercover</span> — Skilled Coward armed!`);
  } else {
    log(`Fang Undercover — Skilled Coward declined. Fighting straight.`);
  }
  btn.classList.remove('locked');
  btn.disabled = false;
  doTeamRoll(team);
}

// Fang Undercover (7) — Skilled Coward: ghost-picker modal after dodge triggers
function showFangUndercoverSwapModal(loseTeamName, sidelineGhosts, continuation) {
  const banner = document.getElementById('fangUndercoverSwapBanner');
  if (banner) {
    banner.className = `pm-who-banner ${loseTeamName}`;
    banner.textContent = '🥷 SKILLED COWARD!';
  }
  const opts = document.getElementById('fangUndercoverSwapOptions');
  const fuTeam = B[loseTeamName];
  opts.innerHTML = sidelineGhosts.map(g => {
    const realIdx = fuTeam.ghosts.indexOf(g);
    const gd = ghostData(g.id);
    const hpRatio = g.hp / g.maxHp;
    const hpColor = hpRatio > 0.6 ? 'var(--hp-green)' : hpRatio > 0.3 ? 'var(--hp-yellow)' : 'var(--hp-red)';
    return `<div class="pressure-opt" onclick="doFangUndercoverSwapChoice(${realIdx})">
      ${gd.art ? `<img src="${gd.art}" style="width:50px;height:50px;border-radius:6px;object-fit:cover;border:1px solid var(--common);">` : ''}
      <div><div style="font-weight:700;">${g.name}</div>
      <div style="font-size:12px;color:var(--text2);"><span style="color:${hpColor};font-weight:700;">♥ ${g.hp}/${g.maxHp}</span> · <span style="color:var(--common);">${gd.ability}</span></div></div>
    </div>`;
  }).join('');
  B.fangUndercoverSwapData = { loseTeamName, continuation };
  document.getElementById('fangUndercoverSwapOverlay').classList.add('active');
}

function doFangUndercoverSwapChoice(idx) {
  const sd = B.fangUndercoverSwapData;
  if (!sd) return;
  B.fangUndercoverSwapData = null;
  document.getElementById('fangUndercoverSwapOverlay').classList.remove('active');
  const { loseTeamName, continuation } = sd;
  const fuTeam = B[loseTeamName];
  const fangGhost = active(fuTeam); // Fang Undercover (currently active, going to sideline)
  const oldName = fangGhost.name;
  const newGhost = fuTeam.ghosts[idx];
  const teamColor = loseTeamName === 'red' ? 'red-text' : 'blue-text';

  fuTeam.activeIdx = idx; // swap Fang to sideline, new ghost becomes active
  renderBattle();

  narrate(`<b class="${teamColor}">${oldName}</b> — Skilled Coward! Slips to sideline — <b>${newGhost.name}</b> enters the fight!`);
  showAbilityCallout('SKILLED COWARD!', 'var(--common)', `${oldName} slips out — ${newGhost.name} enters!`, loseTeamName);
  log(`<span class="log-ability">Fang Undercover</span> — Skilled Coward! ${oldName} to sideline, ${newGhost.name} enters.`);

  // Fire entry effects for the newly-active ghost, then continue
  setTimeout(() => {
    const entryCount = triggerEntry(fuTeam, false);
    afterEntryWithJenkins(entryCount, continuation);
  }, spd(1500));
}

// ============================================================
// Winston (15) — Scheme: post-doubles-win force opponent ghost swap
// ============================================================
function showWinstonSchemeModal(winTeamName, loseTeamName, sidelineGhosts, continuation) {
  const banner = document.getElementById('winstonSchemeBanner');
  if (banner) {
    banner.className = `pm-who-banner ${winTeamName}`;
    banner.textContent = '♟️ SCHEME!';
  }

  const loseTeam = B[loseTeamName];
  const opts = document.getElementById('winstonSchemeOptions');
  if (opts) {
    opts.innerHTML = sidelineGhosts.map(g => {
      const gd = ghostData(g.id);
      const realIdx = loseTeam.ghosts.indexOf(g);
      const hpRatio = g.hp / g.maxHp;
      const hpColor = hpRatio > 0.6 ? 'var(--hp-green)' : hpRatio > 0.3 ? 'var(--hp-yellow)' : 'var(--hp-red)';
      return `<div class="pressure-opt" onclick="doWinstonSchemeChoice(${realIdx})">
        ${gd.art ? `<img src="${gd.art}" style="width:50px;height:50px;border-radius:6px;object-fit:cover;border:1px solid var(--${gd.rarity});">` : ''}
        <div>
          <div style="font-weight:700;">${g.name}</div>
          <div style="font-size:12px;color:var(--text2);"><span style="color:${hpColor};font-weight:700;">&hearts; ${g.hp}/${g.maxHp}</span> &middot; <span style="color:var(--${gd.rarity});">${gd.ability}</span></div>
        </div>
      </div>`;
    }).join('');
  }

  B.winstonSchemePending = { winTeamName, loseTeamName, continuation };
  B.phase = 'ko-pause';
  document.getElementById('winstonSchemeOverlay').classList.add('active');
}

function doWinstonSchemeChoice(idx) {
  const sp = B.winstonSchemePending;
  if (!sp) return;
  B.winstonSchemePending = null;
  document.getElementById('winstonSchemeOverlay').classList.remove('active');

  const { winTeamName, loseTeamName, continuation } = sp;
  const loseTeam = B[loseTeamName];
  const winTeamColor = winTeamName === 'red' ? 'red-text' : 'blue-text';
  const loseTeamColor = loseTeamName === 'red' ? 'red-text' : 'blue-text';

  // Winston always gains +2 dice next roll on win (whether swap or skip)
  B.winstonDiceBonus[winTeamName] = (B.winstonDiceBonus[winTeamName] || 0) + 2;

  if (idx === -1) {
    // Skip — keep current opponent ghost, still get dice
    narrate(`<b class="${winTeamColor}">Winston</b> — Scheme skipped. +2 dice next roll!`);
    log(`Winston — Scheme declined. <span class="log-ms">+2 dice next roll!</span>`);
    continuation();
    return;
  }

  // Force opponent swap: active ghost goes to sideline, chosen sideline ghost enters
  const oldGhost = active(loseTeam);
  const oldName = oldGhost.name;
  const newGhost = loseTeam.ghosts[idx];

  loseTeam.activeIdx = idx; // old active goes to sideline, chosen ghost becomes active
  renderBattle();

  narrate(`<b class="${winTeamColor}">Winston</b> — Scheme! <b class="${loseTeamColor}">${oldName}</b> forced to sideline — <b class="${loseTeamColor}">${newGhost.name}</b> enters!`);
  showAbilityCallout('SCHEME!', 'var(--common)', `${oldName} forced out — ${newGhost.name} enters!`, winTeamName);
  log(`<span class="log-ability">Winston</span> — Scheme! Forced ${oldName} to sideline, ${newGhost.name} enters. <span class="log-ms">+2 dice next roll!</span>`);

  // Fire entry effects for the newly-active enemy ghost, then continue
  setTimeout(() => {
    const entryCount = triggerEntry(loseTeam, false);
    afterEntryWithJenkins(entryCount, continuation);
  }, spd(1500));
}

// ============================================================
// Tyson (365) — Hop: choose enemy sideline ghost to disable
// ============================================================
function showTysonHopPicker(winTeamName, loseTeamName, sidelineGhosts, continuation) {
  const banner = document.getElementById('tysonHopBanner');
  if (banner) {
    banner.className = `pm-who-banner ${winTeamName}`;
    banner.textContent = '🔥 HOP!';
  }
  const loseTeam = B[loseTeamName];
  const disabled = B.tysonDisabled[loseTeamName];
  const opts = document.getElementById('tysonHopOptions');
  if (opts) {
    opts.innerHTML = sidelineGhosts.filter(g => {
      const idx = loseTeam.ghosts.indexOf(g);
      return !disabled.includes(idx); // don't show already-disabled ghosts
    }).map(g => {
      const gd = ghostData(g.id);
      const realIdx = loseTeam.ghosts.indexOf(g);
      return `<div class="pressure-opt" onclick="doTysonHopChoice('${loseTeamName}', ${realIdx})">
        ${gd.art ? `<img src="${gd.art}" style="width:50px;height:50px;border-radius:6px;object-fit:cover;border:1px solid var(--${gd.rarity});">` : ''}
        <div>
          <div style="font-weight:700;">${g.name}</div>
          <div style="font-size:12px;color:var(--text2);"><span style="color:var(--${gd.rarity});">${gd.ability}: ${gd.abilityDesc ? gd.abilityDesc.substring(0, 60) : ''}...</span></div>
        </div>
      </div>`;
    }).join('');
  }
  B.tysonPickerPending = { winTeamName, loseTeamName, continuation };
  B.phase = 'ko-pause';
  document.getElementById('tysonHopOverlay').classList.add('active');
}

function doTysonHopChoice(loseTeamName, ghostIdx) {
  const tp = B.tysonPickerPending;
  if (!tp) return;
  B.tysonPickerPending = null;
  document.getElementById('tysonHopOverlay').classList.remove('active');

  const { winTeamName, continuation } = tp;
  const loseTeam = B[loseTeamName];
  const targetGhost = loseTeam.ghosts[ghostIdx];
  const gd = ghostData(targetGhost.id);

  B.tysonDisabled[loseTeamName].push(ghostIdx);

  const winColor = winTeamName === 'red' ? 'red-text' : 'blue-text';
  narrate(`<b class="${winColor}">Tyson</b> — Hop! <b>${targetGhost.name}</b>'s sideline ability disabled!`);
  showAbilityCallout('HOP!', 'var(--common)', `${targetGhost.name}'s ${gd.ability} disabled!`, winTeamName);
  log(`<span class="log-ability">Tyson</span> — Hop! ${targetGhost.name}'s sideline ability (${gd.ability}) disabled until it enters play.`);

  continuation();
}

// ============================================================
// Laura (79) — Catchy Tune: die picker after each roll
// ============================================================
function showCatchyTunePicker(teamName, dice, continuation) {
  const banner = document.getElementById('catchyTuneBanner');
  if (banner) {
    banner.className = `pm-who-banner ${teamName}`;
    banner.textContent = '🎵 CATCHY TUNE!';
  }
  const opts = document.getElementById('catchyTuneDiceOptions');
  opts.innerHTML = dice.map((d, i) =>
    `<button onclick="doCatchyTuneChoice('${teamName}', ${d}, ${JSON.stringify(dice)}, this)" style="width:60px;height:60px;font-size:28px;font-weight:bold;border-radius:12px;border:2px solid rgba(255,255,255,0.3);background:linear-gradient(135deg,#4f46e5,#7c3aed);color:#fff;cursor:pointer;transition:transform 0.1s;">${d}</button>`
  ).join('');
  B.catchyTunePending = { teamName, continuation };
  B.phase = 'ko-pause';
  document.getElementById('catchyTuneOverlay').classList.add('active');
}

function doCatchyTuneChoice(teamName, dieValue, allDice, btnEl) {
  const ct = B.catchyTunePending;
  if (!ct) return;
  B.catchyTunePending = null;
  document.getElementById('catchyTuneOverlay').classList.remove('active');
  B.catchyTuneLockedDie[teamName] = dieValue;
  const teamColor = teamName === 'red' ? 'red-text' : 'blue-text';
  narrate(`<b class="${teamColor}">Catchy Tune</b> — locked a <b>${dieValue}</b> for next roll!`);
  log(`<span class="log-ability">Laura</span> — Catchy Tune! Locked die: <span class="log-ms">${dieValue}</span> for next roll.`);
  showAbilityCallout('LOCKED!', 'var(--rare)', `Die ${dieValue} locked for next roll!`, teamName);
  ct.continuation();
}

// ============================================================
// Gus (31) — Gale Force Picker: losing player chooses which sideline ghost to swap in
// ============================================================
function showGaleForcePickerModal(winTeamName, loseTeamName, sidelineGhosts, continuation) {
  const banner = document.getElementById('galeForcePickerBanner');
  if (banner) {
    banner.className = `pm-who-banner ${loseTeamName}`;
    banner.textContent = '💨 GALE FORCE!';
  }
  const loseTeam = B[loseTeamName];
  const opts = document.getElementById('galeForcePickerOptions');
  if (opts) {
    opts.innerHTML = sidelineGhosts.map(g => {
      const gd = ghostData(g.id);
      const realIdx = loseTeam.ghosts.indexOf(g);
      const hpRatio = g.hp / g.maxHp;
      const hpColor = hpRatio > 0.6 ? 'var(--hp-green)' : hpRatio > 0.3 ? 'var(--hp-yellow)' : 'var(--hp-red)';
      return `<div class="pressure-opt" onclick="doGaleForcePickerChoice(${realIdx})">
        ${gd.art ? `<img src="${gd.art}" style="width:50px;height:50px;border-radius:6px;object-fit:cover;border:1px solid var(--${gd.rarity});">` : ''}
        <div>
          <div style="font-weight:700;">${g.name}</div>
          <div style="font-size:12px;color:var(--text2);"><span style="color:${hpColor};font-weight:700;">&hearts; ${g.hp}/${g.maxHp}</span> &middot; <span style="color:var(--${gd.rarity});">${gd.ability}</span></div>
        </div>
      </div>`;
    }).join('');
  }
  B.galeForcePicker = { winTeamName, loseTeamName, continuation, dmg: B._galeForceDmg || 0 };
  B.phase = 'ko-pause';
  document.getElementById('galeForcePickerOverlay').classList.add('active');
}

function doGaleForcePickerChoice(idx) {
  const gfp = B.galeForcePicker;
  if (!gfp) return;
  B.galeForcePicker = null;
  document.getElementById('galeForcePickerOverlay').classList.remove('active');

  const { winTeamName, loseTeamName, continuation, dmg } = gfp;
  const loseTeam = B[loseTeamName];
  const winTeamColor = winTeamName === 'red' ? 'red-text' : 'blue-text';
  const loseTeamColor = loseTeamName === 'red' ? 'red-text' : 'blue-text';

  const oldName = active(loseTeam).name;
  const newGhost = loseTeam.ghosts[idx];

  loseTeam.activeIdx = idx;

  // Apply stashed damage to the NEW ghost
  if (dmg > 0) {
    newGhost.hp = Math.max(0, newGhost.hp - dmg);
    if (newGhost.hp <= 0) { newGhost.hp = 0; newGhost.ko = true; newGhost.killedBy = 31; }
    playDamageSfx(dmg);
  }
  renderBattle();

  narrate(`<b class="${winTeamColor}">Gus</b> — Gale Force! <b class="${loseTeamColor}">${newGhost.name}</b> blown in — takes ${dmg} damage!${newGhost.ko ? ' <b>KO!</b>' : ''}`);
  log(`<span class="log-ability">Gus</span> — Gale Force! ${oldName} forced to bench — ${newGhost.name} enters and takes <span class="log-dmg">${dmg} damage!</span>${newGhost.ko ? ' <span class="log-ko">KO!</span>' : ' ' + newGhost.hp + ' HP left'}`);

  // Fire entry effects for the newly-active ghost, then continue
  setTimeout(() => {
    const entryCount = triggerEntry(loseTeam, false);
    afterEntryWithJenkins(entryCount, continuation);
  }, spd(1500));
}

// ============================================================
// TWO-BUTTON ROLL SYSTEM — each side rolls independently
// ============================================================
function rollReady(team) {
  if (!B) return;
  // Live PvP routing:
  // - Blue player clicking Blue Roll → send "ready" signal, don't run engine
  // - Red player clicking Red Roll → runs normally (Red's engine)
  // - Red's engine rolling Blue (from Firebase listener) → allowed through
  if (LIVE_PVP) {
    if (PVP_SIDE === 'blue' && team === 'blue') {
      // v725: Blue runs pre-roll setup locally so pre-roll modals fire (Timber, Romy, Tyler, etc.)
      if (B.phase === 'ready') {
        doPreRollSetup();
        if (B.phase !== 'ready') return; // pre-roll interrupted
        B.phase = 'rolling';
        renderBattle();
      }
      // Blue player: send committed resources + ready signal to Red's engine
      const blueActive = active(B.blue);
      pvpBlueResolvedLocally = false; // v725: reset for this round
      PVP_GAME_REF.child('blueReady').set({
        ready: true,
        committed: B.committed.blue,
        resources: B.blue.resources,
        activeHp: blueActive ? blueActive.hp : 0,
        ts: Date.now()
      });
      const btn2 = document.getElementById('rollBlueBtn');
      if (btn2) { btn2.disabled = true; btn2.textContent = 'Waiting...'; }
      // v723: show local rolling animation so Blue feels responsive
      const blueDiceCount = B.preRoll ? B.preRoll.blue.count : (ghostData(blueActive.id)?.dice ?? 3);
      showRolling('blue', blueDiceCount);
      playSfx('sfxDiceRoll');
      narrate(`<b class="blue-text">${blueActive.name}</b> rolls...`);
      return;
    }
    if (PVP_SIDE === 'blue' && team === 'red') {
      // Blue client trying to roll Red — block
      return;
    }
    // v726: Red waits for Blue to be ready before generating dice.
    // This ensures Blue has time to commit resources (Ice Shards, Fire, etc.)
    if (PVP_SIDE === 'red' && team === 'red') {
      // Run pre-roll setup (abilities, modals) but DON'T generate dice yet
      if (B.phase === 'ready') {
        const cc = doPreRollSetup();
        if (B.phase !== 'ready') return;
        B.phase = 'rolling';
        renderBattle();
        // Send Red's ready signal with committed resources
        const preDelay = cc > 0 ? cc * spd(1500) : 0;
        setTimeout(() => {
          const redActive = active(B.red);
          PVP_GAME_REF.child('redReady').set({
            ready: true,
            committed: B.committed.red,
            resources: B.red.resources,
            activeHp: redActive ? redActive.hp : 0,
            ts: Date.now()
          });
          pvpRedReady = true;
          const btn = document.getElementById('rollRedBtn');
          if (btn) { btn.disabled = true; btn.textContent = 'Waiting...'; }
          narrate(`<b class="red-text">${redActive.name}</b> is ready...`);
          // If Blue is already ready, generate dice now
          pvpTryGenerateDice();
        }, preDelay);
      }
      return; // Don't fall through to normal engine
    }
    // Red's engine rolling Blue (from pvpTryGenerateDice) → allowed through
  }
  // v733: async MP — when Red clicks READY, signal the AI to roll Blue after a short delay
  if (MP_MODE && !LIVE_PVP && team === 'red') {
    pvpRedClickedRoll = true;
  }
  // Duel Phase locks rolls until both players click Done
  if (B.phase === 'duel-1' || B.phase === 'duel-2') return;
  if (B.phase !== 'ready' && B.phase !== 'rolling') return;
  const btn = document.getElementById(team === 'red' ? 'rollRedBtn' : 'rollBlueBtn');
  if (btn.classList.contains('locked')) return;

  // Remove pulse and reset AFK timer on click
  document.querySelectorAll('#rollRedBtn, #rollBlueBtn').forEach(b => b.classList.remove('pulse'));
  resetAfkTimer();

  // First click: do pre-roll setup (abilities, dice counts)
  // calloutCount is HOISTED here (let, not const) so the modal-delay checks AFTER
  // this if-block can read it on BOTH first-click (we set it from doPreRollSetup)
  // and second-click paths (we compute the remaining wait from preRollCalloutEndTime).
  // Without this hoist, second-team clicks throw ReferenceError when any of the
  // post-`if` modal checks (Bogey, Gus, Hunt, Doug, Fang Undercover, etc.) reference
  // calloutCount — exact same bug class as the v305 teamLabel freeze.
  let calloutCount = 0;
  let preRollDelay = 0;
  if (B.phase === 'ready') {
    calloutCount = doPreRollSetup();
    if (B.phase !== 'ready') return; // pre-roll interrupted — KO-swap, game-over, or other phase change
    B.phase = 'rolling';
    // Re-render immediately so consumed status tags (Retribution, etc.) clear from fighter cards
    renderBattle();
    // If pre-roll callouts were queued (via setTimeout), wait for all of them to fully play
    // before dice roll — last callout starts at (N-1)*1500 and lasts ~1400ms, so N*1500 is exact
    if (calloutCount > 0) {
      preRollDelay = calloutCount * spd(1500);
      // Store the absolute end-time so the second team's click can also wait for callouts to finish
      B.preRollCalloutEndTime = Date.now() + calloutCount * spd(1500);
    }

    // Timber choice modal — pause rolling until opponent picks
    if (B.timberPending) {
      const tp = B.timberPending;
      const timberDelay = (tp.preRollCalloutCount || 0) * 1500;
      // Lock BOTH roll buttons — the modal must be resolved before anyone rolls,
      // regardless of which team clicked first. If we only locked the clicking button
      // and the opponent-calculated button, they could be the same element (when the
      // opponent clicks first), leaving Timber's team free to roll during the modal.
      const rBtn = document.getElementById('rollRedBtn');
      const bBtn = document.getElementById('rollBlueBtn');
      if (rBtn) { rBtn.classList.add('locked'); rBtn.disabled = true; }
      if (bBtn) { bBtn.classList.add('locked'); bBtn.disabled = true; }
      // Stash the NON-clicking button so doTimberChoice can unlock it after the choice
      // (the clicking button stays locked — doTeamRoll fires immediately after the choice)
      const otherBtnId = team === 'red' ? 'rollBlueBtn' : 'rollRedBtn';
      tp._oppBtn = document.getElementById(otherBtnId); // stash for cleanup in doTimberChoice
      setTimeout(() => {
        showTimberModal(tp, () => {
          // Resume rolling after choice
          setTimeout(() => { doTeamRoll(team, btn); }, 0);
        });
      }, timberDelay);
      return;
    }

    // Ryder (456) — Toll choice modal — pause rolling until opponent picks
    if (B.riderPending) {
      const tp = B.riderPending;
      const riderDelay = (tp.preRollCalloutCount || 0) * 1500;
      const rBtn = document.getElementById('rollRedBtn');
      const bBtn = document.getElementById('rollBlueBtn');
      if (rBtn) { rBtn.classList.add('locked'); rBtn.disabled = true; }
      if (bBtn) { bBtn.classList.add('locked'); bBtn.disabled = true; }
      const otherBtnId = team === 'red' ? 'rollBlueBtn' : 'rollRedBtn';
      tp._oppBtn = document.getElementById(otherBtnId);
      setTimeout(() => {
        showRiderModal(tp, () => {
          setTimeout(() => { doTeamRoll(team, btn); }, 0);
        });
      }, riderDelay);
      return;
    }

    // Piper (107) — Slick Coat: negate Romy's Valley Guardian prediction modal
    // If Romy is about to predict but the enemy has Piper active, suppress the modal
    // by setting romyPrediction to -1 (sentinel; no die value equals -1 → +3 bonus never fires).
    {
      const romyCheckG = active(B[team]);
      if (romyCheckG && romyCheckG.id === 114 && !romyCheckG.ko &&
          B.romyPrediction && B.romyPrediction[team] == null) {
        const piperOppName = team === 'red' ? 'blue' : 'red';
        const piperG = active(B[piperOppName]);
        if (piperG && piperG.id === 107 && !piperG.ko) {
          B.romyPrediction[team] = -1; // blocked — no die matches -1
          log(`<span class="log-ability">Piper</span> — Slick Coat! <span class="log-ability">${romyCheckG.name}'s</span> Valley Guardian prediction is negated!`);
          // Fall through — Romy modal block below sees romyPrediction != null and skips
        }
      }
    }

    // Romy (114) — Valley Guardian: show prediction modal before rolling
    // Only intercepts when Romy's OWN team clicks their roll button.
    const romyActive = active(B[team]);
    if (romyActive && romyActive.id === 114 && !romyActive.ko &&
        B.romyPrediction && B.romyPrediction[team] == null) {
      // Lock only Romy's button — opponent can still roll independently
      btn.classList.add('locked');
      btn.disabled = true;
      B.romyPending = { team, btn, ghostName: romyActive.name };
      const romyDelay = (calloutCount > 0) ? calloutCount * 1500 : 0;
      setTimeout(() => {
        document.getElementById('romyOverlay').classList.add('active');
      }, romyDelay);
      return;
    }

    // Toby (97) — Pure Heart: now handled by pre-roll ability button (useTobyButton)
    // If Toby hasn't declared yet, auto-set to false (skip) so roll proceeds.
    if (active(B[team])?.id === 97 && !active(B[team]).ko &&
        B.pureHeartDeclared && B.pureHeartDeclared[team] === null) {
      B.pureHeartDeclared[team] = false; // default to not declaring if button wasn't pressed
    }

    // Tyler (105) — Heating Up: opt-in 2 HP trade for +1 die
    // Only offered when Tyler has ≥ 3 HP (prevents self-KO via trade)
    // v429: skip if already decided in Duel Phase (tylerDecidedThisRound flag, Raditz pattern)
    const tylerActiveG = active(B[team]);
    if (tylerActiveG && tylerActiveG.id === 105 && !tylerActiveG.ko && tylerActiveG.hp >= 3 &&
        !(B.tylerDecidedThisRound && B.tylerDecidedThisRound[team])) {
      btn.classList.add('locked');
      btn.disabled = true;
      B.tylerPending = { team, btn };
      const tylerDelay = (calloutCount > 0) ? calloutCount * 1500 : 0;
      setTimeout(() => {
        const tF = active(B[team]);
        document.getElementById('tylerSub').textContent = `Spend 2 HP for +1 die this roll? (${tF.hp} HP → ${tF.hp - 2} HP)`;
        document.getElementById('tylerOverlay').classList.add('active');
      }, tylerDelay);
      return;
    }

    // Chow (414) — Secret Ingredient: spend 1 Healing Seed for +2 dice (interactive button)
    {
      const chowG = active(B[team]);
      if (chowG && chowG.id === 414 && !chowG.ko && B.chowDecided && !B.chowDecided[team] &&
          B[team].resources && B[team].resources.healingSeed >= 1) {
        btn.classList.add('locked');
        btn.disabled = true;
        B.chowPending = { team, btn };
        const chowDelay = (calloutCount > 0) ? calloutCount * 1500 : 0;
        setTimeout(() => {
          const cF = active(B[team]);
          document.getElementById('chowSub').innerHTML =
            `Discard 1 🌱 Healing Seed for +2 dice this roll?<br>` +
            `(Seeds: ${B[team].resources.healingSeed} | Current bonus dice: +${B.chowExtraDie[team] || 0})`;
          document.getElementById('chowOverlay').classList.add('active');
        }, chowDelay);
        return;
      }
    }

    // Zork (463) — Stoke: now handled by pre-roll ability button (useZorkStoke)

    // Miyoshi (454) — Bonzai!: now handled by pre-roll ability button (useBonzaiButton)

    // Castle Gardener (442) — Cultivate: now handled by pre-roll ability button (useCultivate)

    // Forest Spirit (446) — Hex: now handled by pre-roll button (useHex)

    // Nick & Knack (409) — Knick Knack: steal 1 resource from opponent → +1 HP + 2 Burn
    {
      const nnG = active(B[team]);
      const oppTeamNN = team === 'red' ? 'blue' : 'red';
      if (nnG && nnG.id === 409 && !nnG.ko && B.nickKnackDecided && !B.nickKnackDecided[team]) {
        const oppRes = B[oppTeamNN].resources;
        const resTypes = ['ice', 'fire', 'surge', 'luckyStone', 'moonstone', 'healingSeed'];
        const available = resTypes.filter(r => (oppRes[r] || 0) > 0);
        if (available.length > 0) {
          btn.classList.add('locked');
          btn.disabled = true;
          B.nickKnackPending = { team, btn, oppTeam: oppTeamNN };
          const nnDelay = (calloutCount > 0) ? calloutCount * 1500 : 0;
          setTimeout(() => {
            showNickKnackPicker(team, oppTeamNN);
          }, nnDelay);
          return;
        } else {
          B.nickKnackDecided[team] = true;
        }
      }
    }

    // Guardian Fairy (99) — Wish: now reactive (post-damage modal), no pre-roll standby needed

    // Eloise (85) — Change of Heart: spend 1 Ice Shard to swap HP with enemy before rolling
    // Offered once per round when Eloise is active and team has ≥1 Ice Shard.
    {
      const eloiseG = active(B[team]);
      const oppTeam = team === 'red' ? 'blue' : 'red';
      const oppF = active(B[oppTeam]);
      if (eloiseG && eloiseG.id === 85 && !eloiseG.ko &&
          B.eloiseUsedThisRound && !B.eloiseUsedThisRound[team] &&
          B[team].resources && B[team].resources.ice >= 1 && oppF && !oppF.ko) {
        btn.classList.add('locked');
        btn.disabled = true;
        B.eloisePending = { team, btn };
        const eloiseDelay = (calloutCount > 0) ? calloutCount * 1500 : 0;
        setTimeout(() => {
          document.getElementById('eloiseSub').innerHTML =
            `Spend 1 ❄️ Ice Shard to swap HP?<br>` +
            `<b>Your HP:</b> ${eloiseG.hp} → <b>${oppF.hp}</b> &nbsp;|&nbsp; ` +
            `<b>Enemy HP:</b> ${oppF.hp} → <b>${eloiseG.hp}</b>`;
          document.getElementById('eloiseOverlay').classList.add('active');
        }, eloiseDelay);
        return;
      }
    }

    // Mallow (89) — Dozy Cozy: spend 2 Sacred Fire for +3 HP + 2 Burn to active ghost (sideline)
    // Offered once per round when Mallow is on the sideline and team has ≥2 Sacred Fire.
    if (hasSideline(B[team], 89) && B.mallowDecided && !B.mallowDecided[team] &&
        B[team].resources && B[team].resources.fire >= 2) {
      btn.classList.add('locked');
      btn.disabled = true;
      B.mallowPending = { team, btn };
      const mallowDelay = (calloutCount > 0) ? calloutCount * 1500 : 0;
      setTimeout(() => {
        const mF = active(B[team]);
        const mallowHpAfter = mF ? mF.hp + 3 : '?';
        const mallowOver = mF && (mF.hp + 3 > mF.maxHp) ? ' <i>· overclocks!</i>' : '';
        document.getElementById('mallowSub').innerHTML =
          `Spend 2 🔥 Sacred Fire to give <b>${mF ? mF.name : 'your ghost'}</b> +3 HP and gain 1 🔥 Burn?<br>` +
          `(${mF ? mF.hp : '?'} HP → ${mallowHpAfter} HP${mallowOver} &nbsp;|&nbsp; 🔥 ${B[team].resources.fire} → ${B[team].resources.fire - 2})`;
        document.getElementById('mallowOverlay').classList.add('active');
      }, mallowDelay);
      return;
    }

    // Boo Brothers (17) — Teamwork: trade 1 die for 1 HP before rolling
    // Offered each round when Boo Brothers is active and has ≥ 2 dice.
    // NOTE: NO hp < maxHp gate — trading at full HP overclocks (v294 Hard Rule #9).
    // Do NOT re-add a maxHp cap here. Overclock is intentional by design.
    // v429: skip if already decided in Duel Phase (booTeamworkDecidedThisRound, Raditz pattern)
    {
      const booG = active(B[team]);
      if (booG && booG.id === 17 && !booG.ko && B.preRoll && B.preRoll[team] &&
          B.preRoll[team].count >= 2 &&
          !(B.booTeamworkDecidedThisRound && B.booTeamworkDecidedThisRound[team])) {
        btn.classList.add('locked');
        btn.disabled = true;
        B.booPending = { team, btn };
        const booDelay = (calloutCount > 0) ? calloutCount * 1500 : 0;
        setTimeout(() => {
          const bF = active(B[team]);
          document.getElementById('booSub').innerHTML =
            `Remove 1 die to gain +1 HP?<br>` +
            `<b>${B.preRoll[team].count}</b> dice → <b>${B.preRoll[team].count - 1}</b> dice` +
            `&nbsp;|&nbsp;<b>${bF.hp}</b> HP → <b>${bF.hp + 1}</b> HP${bF.hp + 1 > bF.maxHp ? ' <i>· overclocks!</i>' : ''}`;
          document.getElementById('booOverlay').classList.add('active');
        }, booDelay);
        return;
      }
    }
  }

  // Second-click path: pre-roll setup already ran, but pre-roll callouts may still
  // be in-flight. Compute remaining callout count from B.preRollCalloutEndTime so
  // the modal delays below still wait for them to clear.
  if (B.preRollCalloutEndTime && Date.now() < B.preRollCalloutEndTime) {
    calloutCount = Math.max(0, Math.ceil((B.preRollCalloutEndTime - Date.now()) / 1500));
  }

  // Miyoshi (454) — Bonzai!: now handled by pre-roll ability button (useBonzaiButton)

  // Gus (31) — Gale Force: now reactive post-win (no pre-roll modal)

  {
    // Raditz (62) — Hunt: one-time forced-swap on first roll after entry
    // Fires when Raditz's team clicks Roll for the first time after Raditz enters play.
    if (B.raditzHuntReady && B.raditzHuntReady[team]) {
      // Lock BOTH buttons — swap must complete before either team rolls
      const rBtn2 = document.getElementById('rollRedBtn');
      const bBtn2 = document.getElementById('rollBlueBtn');
      if (rBtn2) { rBtn2.classList.add('locked'); rBtn2.disabled = true; }
      if (bBtn2) { bBtn2.classList.add('locked'); bBtn2.disabled = true; }
      const oppBtn2 = team === 'red' ? bBtn2 : rBtn2;
      B.raditzHuntPending = { team, btn, oppBtn: oppBtn2 };
      const huntDelay = (calloutCount > 0) ? calloutCount * 1500 : 0;
      setTimeout(() => {
        const huntEnemyName = team === 'red' ? 'blue' : 'red';
        const huntActiveEnemy = active(B[huntEnemyName]);
        document.getElementById('raditzHuntSub').textContent =
          `Force ${huntActiveEnemy ? huntActiveEnemy.name : 'the opponent'} to the sideline and bring in a different ghost?`;
        document.getElementById('raditzHuntOverlay').classList.add('active');
      }, huntDelay);
      return;
    }
  }

    // Doug (63) — Caution: once-per-game pre-roll swap out for +1 die to incoming ghost
    {
      const dougG = active(B[team]);
      if (dougG && dougG.id === 63 && !dougG.ko &&
          B.dougCautionUsed && !B.dougCautionUsed[team]) {
        const mySideline = B[team].ghosts.filter((g, i) => i !== B[team].activeIdx && !g.ko);
        if (mySideline.length > 0) {
          btn.classList.add('locked');
          btn.disabled = true;
          B.dougCautionPending = { team, btn };
          const dougDelay = (calloutCount > 0) ? calloutCount * 1500 : 0;
          setTimeout(() => {
            const teamCls = team === 'red' ? 'red' : 'blue';
            document.getElementById('dougCautionBanner').className = `pm-who-banner ${teamCls}`;
            document.getElementById('dougCautionSub').textContent =
              `Switch Doug to the sideline and bring in a sideline ghost? They gain +1 die this roll. (Once per game)`;
            const dougOptions = document.getElementById('dougCautionOptions');
            dougOptions.innerHTML = mySideline.map(g => {
              const realIdx = B[team].ghosts.indexOf(g);
              const gd = ghostData(g.id);
              const hpRatio = g.hp / g.maxHp;
              const hpColor = hpRatio > 0.6 ? 'var(--hp-green)' : hpRatio > 0.3 ? 'var(--hp-yellow)' : 'var(--hp-red)';
              return `<div class="pressure-opt" onclick="doDougCautionSwap(${realIdx})">
                ${gd.art ? `<img src="${gd.art}" style="width:50px;height:50px;border-radius:6px;object-fit:cover;border:1px solid var(--rare);">` : ''}
                <div><div style="font-weight:700;">${g.name}</div>
                <div style="font-size:12px;color:var(--text2);"><span style="color:${hpColor};font-weight:700;">♥ ${g.hp}/${g.maxHp}</span> · <span style="color:var(--moonstone);">${gd.ability}</span></div></div>
              </div>`;
            }).join('');
            document.getElementById('dougCautionOverlay').classList.add('active');
          }, dougDelay);
          return;
        }
      }
    }

  // Fang Undercover (7) — Skilled Coward: arm dodge before rolling
  // Offered each round when Fang Undercover is active with alive sideline ghosts.
  {
    const fuG = active(B[team]);
    const fuHasSideline = B[team].ghosts.some((g, i) => i !== B[team].activeIdx && !g.ko);
    if (fuG && fuG.id === 7 && !fuG.ko && fuHasSideline &&
        B.fangUndercoverArmed && !B.fangUndercoverArmed[team]) {
      btn.classList.add('locked');
      btn.disabled = true;
      B.fangUndercoverPending = { team, btn };
      const fuDelay = (calloutCount > 0) ? calloutCount * 1500 : 0;
      setTimeout(() => {
        const teamCls = team === 'red' ? 'red' : 'blue';
        document.getElementById('fangUndercoverArmSub').textContent =
          `Arm the dodge? If Fang takes damage this round, they swap to the sideline and negate all damage.`;
        document.getElementById('fangUndercoverArmOverlay').classList.add('active');
      }, fuDelay);
      return;
    }
  }

  // Lock this button
  btn.classList.add('locked');
  btn.disabled = true;

  // Second-click guard: if the first click started pre-roll callouts that are still playing,
  // wait for whatever time is left so the second team's roll animation doesn't stomp them.
  // (First-click path already has the full delay computed above; this only matters when
  //  preRollDelay is still 0, i.e. when this is the second team's click.)
  if (preRollDelay === 0 && B.preRollCalloutEndTime) {
    preRollDelay = Math.max(0, B.preRollCalloutEndTime - Date.now());
  }

  // Delay roll if pre-roll ability just showed a callout
  setTimeout(() => { doTeamRoll(team, btn); }, preRollDelay);
}

function doTeamRoll(team, btn) {
  // Guard: B or preRoll may have been cleared (round-end, raid sync, etc.)
  if (!B || !B.preRoll || !B.preRoll[team]) return;

  // Duel Phase intercept: if a modal primer resolved during Duel Phase, the
  // choice handler calls doTeamRoll() as its "proceed" signal. We catch that
  // here, re-enable the Ready button (so the player can commit resources),
  // and return without rolling. The player clicks Ready when they're done.
  if (B && (B.phase === 'duel-1' || B.phase === 'duel-2') && B.duelActiveTeam === team) {
    const doneId = team === 'red' ? 'duelDoneRedBtn' : 'duelDoneBlueBtn';
    const doneBtn = document.getElementById(doneId);
    if (doneBtn) { doneBtn.disabled = false; doneBtn.classList.remove('locked'); }
    return;
  }
  // Roll this team's dice (weighted for cinematic clutch moments)
  let diceCount = B.preRoll[team].count;
  const override = B.preRoll[team].override;
  // Laura (79) — Catchy Tune: if unlocked, one die is locked from last roll
  const lockedDie = (B.catchyTuneUnlocked && B.catchyTuneUnlocked[team] && B.catchyTuneLockedDie && B.catchyTuneLockedDie[team] !== null && diceCount > 0) ? B.catchyTuneLockedDie[team] : null;
  const rollCount = lockedDie !== null ? Math.max(0, diceCount - 1) : diceCount;
  const dice = override ? [1,2,3] : weightedRoll(team, rollCount);
  if (lockedDie !== null && !override) dice.push(lockedDie);
  dice.sort((a,b) => a-b);
  B.preRoll[team].dice = dice;
  B.lastRollDiceCount[team] = diceCount; // Frederick (27) — track for next round
  if (team === 'red') { B.redDice = dice; } else { B.blueDice = dice; }

  if (lockedDie !== null && !override) log(`<span class="log-ability">Laura</span> — Catchy Tune! Locked die: <span class="log-ms">${lockedDie}</span> carried over.`);
  if (override) log(`<span class="log-ability">Bouril</span> — Slumber! Auto-rolled [1,2,3]!`);

  // Animate: show rolling then reveal
  const f = active(B[team]);
  const cls = team === 'red' ? 'red-text' : 'blue-text';
  showRolling(team, diceCount);
  if (diceCount > 0) playSfx('sfxDiceRoll');
  if (diceCount === 0) {
    narrate(`<b class="${cls}">${f.name}</b> doesn't roll — <b class="gold">Stone Form!</b>`);
  } else {
    narrate(`<b class="${cls}">${f.name}</b> rolls...`);
  }

  setTimeout(() => {
    revealDice(team, dice);
    const roll = classify(dice);
    const tl = typeLabel(roll.type);
    narrate(`<b class="${cls}">${f.name}</b>&nbsp;rolled [${dice.join(', ')}]${tl ? '&nbsp;<b class="gold">'+tl+'</b>' : ''}`);
    if (isTripleOrBetter(roll.type)) showTriplesEffect(team, roll.type);

    // Check if both have rolled — guard against double-resolution
    if (B.preRoll && B.preRoll.red.dice && B.preRoll.blue.dice && !B.preRoll.resolved) {
      B.preRoll.resolved = true;
      // Use 1800ms if EITHER team rolled triples/quads/penta — the banner for the
      // first roller fires at T+700ms and lasts 1700ms (1200ms show + 500ms fade),
      // so resolution must not start until T+700+1800=T+2500ms regardless of which
      // team triggered the resolution check.
      const otherTeam = team === 'red' ? 'blue' : 'red';
      const otherRoll = classify(B.preRoll[otherTeam].dice);
      const eitherTripled = isTripleOrBetter(roll.type) || isTripleOrBetter(otherRoll.type);
      setTimeout(() => {
        doPostRollAndResolve(B.preRoll.red.dice, B.preRoll.blue.dice);
      }, spd(eitherTripled ? 1800 : 1400));
    }
  }, spd(700));
}

// ============================================================
// DUEL PHASE — sequenced pre-roll commits
// "Loser of previous exchange goes first. Round 1 uses lower max HP (underdog)."
// Dice rolls remain simultaneous; only pre-roll DECISIONS are ordered.
// ============================================================
const _RARITY_RANK = { 'common':0, 'uncommon':1, 'rare':2, 'ghost-rare':3, 'legendary':4 };

// -----------------------------------------------------------------------
// hasAnyDecision(team) — returns true if the team has anything to do
// during their Duel Phase turn: a modal primer that needs input, or a
// committable resource tile. Used by computeDuelPriority (skip-if-both-
// empty) and enterDuelPhase/_runDuelTeamTurn (auto-advance single team).
// v429: Tyler (105) and Boo Brothers (17) now included — Approach B decouples
//       their gates from B.preRoll (uses ghostData base dice ?? 3 instead).
// -----------------------------------------------------------------------
function hasAnyDecision(team) {
  if (!B) return false;
  const f = active(B[team]);
  if (!f || f.ko) return false;
  const oppTeamName = team === 'red' ? 'blue' : 'red';
  const oppF = active(B[oppTeamName]);
  const r = B[team].resources;
  const c = B.committed && B.committed[team];

  // — Modal primers —
  // Romy (114) — Valley Guardian
  if (f.id === 114 && B.romyPrediction && B.romyPrediction[team] == null) return true;
  // Toby (97) — Pure Heart
  if (f.id === 97 && B.pureHeartDeclared && B.pureHeartDeclared[team] === null &&
      !(B.pureHeartScheduledKO && B.pureHeartScheduledKO[team])) return true;
  // Guardian Fairy (99) — Wish: now reactive (post-damage), no pre-roll check needed
  // Eloise (85) — Change of Heart
  if (f.id === 85 && B.eloiseUsedThisRound && !B.eloiseUsedThisRound[team] &&
      r && r.ice >= 1 && oppF && !oppF.ko) return true;
  // Mallow (89) — Dozy Cozy (sideline) — costs 2 Sacred Fire
  if (hasSideline(B[team], 89) && B.mallowDecided && !B.mallowDecided[team] &&
      r && r.fire >= 2) return true;
  // Gus (31) — Gale Force: now reactive post-win (no pre-roll check)
  // Raditz (62) — Hunt
  if (B.raditzHuntReady && B.raditzHuntReady[team]) return true;
  // Doug (63) — Caution
  if (f.id === 63 && B.dougCautionUsed && !B.dougCautionUsed[team] &&
      B[team].ghosts.some((g, i) => i !== B[team].activeIdx && !g.ko)) return true;
  // Fang Undercover (7) — Skilled Coward
  if (f.id === 7 && B.fangUndercoverArmed && !B.fangUndercoverArmed[team] &&
      B[team].ghosts.some((g, i) => i !== B[team].activeIdx && !g.ko)) return true;
  // Tyler (105) — Heating Up: spend 2 HP for +1 die
  if (f.id === 105 && !f.ko && f.hp >= 3 &&
      !(B.tylerDecidedThisRound && B.tylerDecidedThisRound[team])) return true;
  // Boo Brothers (17) — Teamwork: trade 1 die for +1 HP (gate uses base dice, no preRoll dep)
  if (f.id === 17 && !f.ko && (ghostData(17)?.dice ?? 3) >= 2 &&
      !(B.booTeamworkDecidedThisRound && B.booTeamworkDecidedThisRound[team])) return true;

  // — Committable resource tiles (interactive during Duel Phase via isPreRollActive) —
  if (r && c) {
    if ((r.ice + c.ice) > 0) return true;
    if ((r.fire + c.fire) > 0) return true;
    if ((r.surge + c.surge) > 0) return true;
  }
  // Healing Seed (usable when HP below max)
  if (r && r.healingSeed > 0 && f.hp < f.maxHp) return true;
  // Happy Crystal (208) — sacrifice for Moonstone
  if (f.id === 208 && !f.ko) return true;
  // Aunt Susan (309) — commit seeds for damage or heal
  if (f.id === 309 && !f.ko && r &&
      (r.healingSeed > 0 || (c && (c.auntSusan > 0 || c.auntSusanHeal > 0)))) return true;

  return false;
}

// -----------------------------------------------------------------------
// _installDuelPhasePreRollWrapper — single-use doPreRollSetup wrapper that
// applies deferred die adjustments from Duel Phase Tyler/Boo Brothers choices.
// Tyler's +1 die and Boo Brothers' -1 die are captured via getter/setter
// interceptors on the pre-initialized B.preRoll[team] objects, then stored
// in B.tylerHeatUpDieBonus / B.booTeamworkDieDebt. This wrapper applies them
// AFTER doPreRollSetup initializes the real B.preRoll. Idempotent — safe to
// call from both Tyler and Boo Brothers sections in the same round.
// -----------------------------------------------------------------------
function _installDuelPhasePreRollWrapper() {
  if (window._duelDiePatchInstalled) return; // already installed this round
  window._duelDiePatchInstalled = true;
  const _origDPS = doPreRollSetup;
  window.doPreRollSetup = function() {
    window.doPreRollSetup = _origDPS;        // restore before calling (single-use)
    window._duelDiePatchInstalled = false;
    const result = _origDPS.apply(this, arguments);
    // Apply deferred die adjustments AFTER doPreRollSetup has initialized B.preRoll
    if (B && B.preRoll) {
      ['red', 'blue'].forEach(t => {
        if (!B.preRoll[t]) return;
        if (B.tylerHeatUpDieBonus && B.tylerHeatUpDieBonus[t] > 0) {
          B.preRoll[t].count = Math.min(6, B.preRoll[t].count + B.tylerHeatUpDieBonus[t]);
          B.tylerHeatUpDieBonus[t] = 0;
        }
        if (B.booTeamworkDieDebt && B.booTeamworkDieDebt[t] > 0) {
          B.preRoll[t].count = Math.max(1, B.preRoll[t].count - B.booTeamworkDieDebt[t]);
          B.booTeamworkDieDebt[t] = 0;
        }
      });
    }
    return result;
  };
}

// -----------------------------------------------------------------------
// openDuelPhasePrimers(team) — opens the first applicable modal primer
// for the team's active fighter during their Duel Phase turn. Disables
// the "✓ Ready" button until the player resolves the primer.
// Returns true if a primer was opened; false if nothing to open.
// The choice handlers call doTeamRoll() on resolution — the doTeamRoll
// Duel Phase intercept (below) catches that call and re-enables Ready
// so the player can commit resources before clicking Ready manually.
// -----------------------------------------------------------------------
function openDuelPhasePrimers(team) {
  if (!B) return false;
  const f = active(B[team]);
  if (!f || f.ko) return false;
  const oppTeamName = team === 'red' ? 'blue' : 'red';
  const doneId = team === 'red' ? 'duelDoneRedBtn' : 'duelDoneBlueBtn';
  const doneBtn = document.getElementById(doneId);
  const disableDone = () => { if (doneBtn) { doneBtn.disabled = true; doneBtn.classList.add('locked'); } };

  // — ROMY (114) — Valley Guardian: predict a die value before rolling
  if (f.id === 114 && B.romyPrediction && B.romyPrediction[team] == null) {
    // Check Piper (107) — Slick Coat suppresses the prediction
    const piperOppG = active(B[oppTeamName]);
    if (piperOppG && piperOppG.id === 107 && !piperOppG.ko) {
      B.romyPrediction[team] = -1; // sentinel: -1 never matches any die
      narrate(`<b class="${oppTeamName}-text">Piper</b> — Slick Coat! Romy's Valley Guardian is negated!`);
      log(`<span class="log-ability">Piper</span> — Slick Coat! Romy's Valley Guardian prediction negated in Duel Phase.`);
      // fall through to next primer check
    } else {
      disableDone();
      B.romyPending = { team, btn: doneBtn, ghostName: f.name };
      document.getElementById('romyOverlay').classList.add('active');
      return true;
    }
  }

  // — TOBY (97) — Pure Heart: now handled by pre-roll ability button (useTobyButton)
  // No modal intercept needed — button is in ability panel

  // — CHOW (414) — Secret Ingredient: spend 1 Healing Seed for +2 dice (Duel Phase)
  if (f.id === 414 && !f.ko && B.chowDecided && !B.chowDecided[team] &&
      B[team].resources && B[team].resources.healingSeed >= 1) {
    disableDone();
    B.chowPending = { team, btn: doneBtn };
    document.getElementById('chowSub').innerHTML =
      `Discard 1 🌱 Healing Seed for +2 dice this roll?<br>` +
      `(Seeds: ${B[team].resources.healingSeed} | Current bonus dice: +${B.chowExtraDie[team] || 0})`;
    document.getElementById('chowOverlay').classList.add('active');
    return true;
  }

  // — ZORK (463) — Stoke: now handled by pre-roll ability button (useZorkStoke)

  // — Miyoshi (454) — Bonzai!: now handled by pre-roll ability button (useBonzaiButton)

  // — CASTLE GARDENER (442) — Cultivate: now handled by pre-roll ability button (useCultivate)

  // — FOREST SPIRIT (446) — Hex: now handled by pre-roll button (useHex)

  // — NICK & KNACK (409) — Knick Knack: steal 1 resource → +1 HP + 2 Burn (Duel Phase)
  if (f.id === 409 && !f.ko && B.nickKnackDecided && !B.nickKnackDecided[team]) {
    const nnOppRes = B[oppTeamName].resources;
    const nnResTypes = ['ice', 'fire', 'surge', 'luckyStone', 'moonstone', 'healingSeed'];
    const nnAvailable = nnResTypes.filter(r => (nnOppRes[r] || 0) > 0);
    if (nnAvailable.length > 0) {
      disableDone();
      B.nickKnackPending = { team, btn: doneBtn, oppTeam: oppTeamName };
      showNickKnackPicker(team, oppTeamName);
      return true;
    } else {
      B.nickKnackDecided[team] = true;
    }
  }

  // Guardian Fairy (99) — Wish: now reactive (post-damage modal), no pre-roll standby

  // — ELOISE (85) — Change of Heart: spend 1 Ice Shard to swap HP
  {
    const oppF = active(B[oppTeamName]);
    if (f.id === 85 && B.eloiseUsedThisRound && !B.eloiseUsedThisRound[team] &&
        B[team].resources && B[team].resources.ice >= 1 && oppF && !oppF.ko) {
      disableDone();
      B.eloisePending = { team, btn: doneBtn };
      document.getElementById('eloiseSub').innerHTML =
        `Spend 1 ❄️ Ice Shard to swap HP?<br>` +
        `<b>Your HP:</b> ${f.hp} → <b>${oppF.hp}</b> &nbsp;|&nbsp; ` +
        `<b>Enemy HP:</b> ${oppF.hp} → <b>${f.hp}</b>`;
      document.getElementById('eloiseOverlay').classList.add('active');
      return true;
    }
  }

  // — MALLOW (89) — Dozy Cozy: spend 2 Sacred Fire for +3 HP + 2 Burn (sideline)
  if (hasSideline(B[team], 89) && B.mallowDecided && !B.mallowDecided[team] &&
      B[team].resources && B[team].resources.fire >= 2) {
    disableDone();
    B.mallowPending = { team, btn: doneBtn };
    const mallowHpAfter = f.hp + 3;
    const mallowOver = (f.hp + 3 > f.maxHp) ? ' <i>· overclocks!</i>' : '';
    document.getElementById('mallowSub').innerHTML =
      `Spend 2 🔥 Sacred Fire to give <b>${f.name}</b> +3 HP and gain 1 🔥 Burn?<br>` +
      `(${f.hp} HP → ${mallowHpAfter} HP${mallowOver} &nbsp;|&nbsp; 🔥 ${B[team].resources.fire} → ${B[team].resources.fire - 2})`;
    document.getElementById('mallowOverlay').classList.add('active');
    return true;
  }

  // — GUS (31) — Gale Force: now reactive post-win (no pre-roll Done check)

  // — RADITZ (62) — Hunt: force opponent's active ghost to the sideline (one-time on entry)
  if (B.raditzHuntReady && B.raditzHuntReady[team]) {
    B.raditzHuntReady[team] = false; // clear NOW so rollReady never double-fires this
    const enemy = B[oppTeamName];
    const huntTargetActive = active(enemy);
    const aliveSideline = enemy.ghosts.filter((g, i) => i !== enemy.activeIdx && !g.ko);

    // Auto-skip: opponent has no alive sideline ghosts
    if (aliveSideline.length === 0) {
      narrate(`<b class="${team}-text">Raditz</b> — Hunt primed, but the opponent has no sideline ghosts to swap in.`);
      log(`Raditz — Hunt skipped in Duel Phase: opponent has no alive sideline.`);
      return false; // auto-skipped, no primer opened
    }

    disableDone();
    B.raditzHuntPending = { team, btn: doneBtn, oppBtn: null };
    document.getElementById('raditzHuntSub').textContent =
      `Force ${huntTargetActive ? huntTargetActive.name : 'the opponent'} to the sideline and bring in a different ghost?`;
    document.getElementById('raditzHuntOverlay').classList.add('active');
    return true;
  }

  // — DOUG (63) — Caution: once-per-game pre-roll self-swap for +1 die to incoming ghost
  if (f.id === 63 && B.dougCautionUsed && !B.dougCautionUsed[team]) {
    const mySideline = B[team].ghosts.filter((g, i) => i !== B[team].activeIdx && !g.ko);
    if (mySideline.length > 0) {
      disableDone();
      B.dougCautionPending = { team, btn: doneBtn };
      const teamCls = team === 'red' ? 'red' : 'blue';
      document.getElementById('dougCautionBanner').className = `pm-who-banner ${teamCls}`;
      document.getElementById('dougCautionSub').textContent =
        `Switch Doug to the sideline and bring in a sideline ghost? They gain +1 die this roll. (Once per game)`;
      const dougOptions = document.getElementById('dougCautionOptions');
      dougOptions.innerHTML = mySideline.map(g => {
        const realIdx = B[team].ghosts.indexOf(g);
        const gd = ghostData(g.id);
        const hpRatio = g.hp / g.maxHp;
        const hpColor = hpRatio > 0.6 ? 'var(--hp-green)' : hpRatio > 0.3 ? 'var(--hp-yellow)' : 'var(--hp-red)';
        return `<div class="pressure-opt" onclick="doDougCautionSwap(${realIdx})">
          ${gd.art ? `<img src="${gd.art}" style="width:50px;height:50px;border-radius:6px;object-fit:cover;border:1px solid var(--${gd.rarity});">` : ''}
          <div><div style="font-weight:700;">${g.name}</div>
          <div style="font-size:12px;color:var(--text2);"><span style="color:${hpColor};font-weight:700;">♥ ${g.hp}/${g.maxHp}</span> · <span style="color:var(--moonstone);">${gd.ability}</span></div></div>
        </div>`;
      }).join('');
      document.getElementById('dougCautionOverlay').classList.add('active');
      return true;
    }
  }

  // — FANG UNDERCOVER (7) — Skilled Coward: arm dodge before rolling
  if (f.id === 7 && B.fangUndercoverArmed && !B.fangUndercoverArmed[team] &&
      B[team].ghosts.some((g, i) => i !== B[team].activeIdx && !g.ko)) {
    disableDone();
    B.fangUndercoverPending = { team, btn: doneBtn };
    document.getElementById('fangUndercoverArmSub').textContent =
      `Arm the dodge? If Fang takes damage this round, they swap to the sideline and negate all damage.`;
    document.getElementById('fangUndercoverArmOverlay').classList.add('active');
    return true;
  }

  // — TYLER (105) — Heating Up: spend 2 HP for +1 die (Approach B: gate uses hp, not preRoll)
  // Raditz pattern: set tylerDecidedThisRound BEFORE opening so rollReady skips after Duel Phase.
  // Pre-initialize B.preRoll[team] with a getter/setter interceptor so doTylerChoice's count
  // write is captured into B.tylerHeatUpDieBonus; the _installDuelPhasePreRollWrapper applies
  // it after doPreRollSetup initializes the real B.preRoll object.
  if (f.id === 105 && !f.ko && f.hp >= 3 &&
      !(B.tylerDecidedThisRound && B.tylerDecidedThisRound[team])) {
    if (B.tylerDecidedThisRound) B.tylerDecidedThisRound[team] = true; // clear — Raditz pattern
    if (!B.preRoll) B.preRoll = { red: null, blue: null };
    if (!B.preRoll[team]) {
      const _tylerTeam = team; // capture for setter closure
      const _baseDiceT = ghostData(f.id)?.dice ?? 3;
      B.preRoll[team] = {
        _count: _baseDiceT, override: false, dice: null,
        get count() { return this._count; },
        set count(v) {
          const delta = v - this._count;
          if (delta > 0 && B && B.tylerHeatUpDieBonus)
            B.tylerHeatUpDieBonus[_tylerTeam] = (B.tylerHeatUpDieBonus[_tylerTeam] || 0) + delta;
          this._count = v;
        }
      };
      _installDuelPhasePreRollWrapper();
    }
    disableDone();
    B.tylerPending = { team, btn: doneBtn };
    document.getElementById('tylerSub').textContent =
      `Spend 2 HP for +1 die this roll? (${f.hp} HP → ${f.hp - 2} HP)`;
    document.getElementById('tylerOverlay').classList.add('active');
    return true;
  }

  // — BOO BROTHERS (17) — Teamwork: trade 1 die for +1 HP (Approach B: gate uses base dice)
  // Auto-skip if the ghost's base dice count < 2 — can't trade a die they don't have.
  // Raditz pattern: set booTeamworkDecidedThisRound BEFORE opening so rollReady skips.
  // Pre-initialize B.preRoll[team] interceptor; doBooChoice's count write is captured
  // into B.booTeamworkDieDebt; the _installDuelPhasePreRollWrapper applies it post-setup.
  {
    const _baseDiceBoo = ghostData(17)?.dice ?? 3;
    if (f.id === 17 && !f.ko &&
        !(B.booTeamworkDecidedThisRound && B.booTeamworkDecidedThisRound[team])) {
      if (B.booTeamworkDecidedThisRound) B.booTeamworkDecidedThisRound[team] = true; // Raditz pattern
      if (_baseDiceBoo < 2) {
        // Auto-skip: no dice to trade
        narrate(`<b class="${team}-text">Boo Brothers</b> — Teamwork ready, but base dice (${_baseDiceBoo}) too low to trade.`);
        log(`Boo Brothers — Teamwork auto-skipped in Duel Phase: base dice ${_baseDiceBoo} < 2.`);
        return false;
      }
      if (!B.preRoll) B.preRoll = { red: null, blue: null };
      if (!B.preRoll[team]) {
        const _booTeam = team; // capture for setter closure
        B.preRoll[team] = {
          _count: _baseDiceBoo, override: false, dice: null,
          get count() { return this._count; },
          set count(v) {
            const delta = this._count - v;
            if (delta > 0 && B && B.booTeamworkDieDebt)
              B.booTeamworkDieDebt[_booTeam] = (B.booTeamworkDieDebt[_booTeam] || 0) + delta;
            this._count = v;
          }
        };
        _installDuelPhasePreRollWrapper();
      }
      disableDone();
      B.booPending = { team, btn: doneBtn };
      document.getElementById('booSub').innerHTML =
        `Remove 1 die to gain +1 HP?<br>` +
        `<b>${_baseDiceBoo}</b> dice → <b>${_baseDiceBoo - 1}</b> dice` +
        `&nbsp;|&nbsp;<b>${f.hp}</b> HP → <b>${f.hp + 1}</b> HP${f.hp + 1 > f.maxHp ? ' <i>· overclocks!</i>' : ''}`;
      document.getElementById('booOverlay').classList.add('active');
      return true;
    }
  }

  return false; // no primer matched
}

// -----------------------------------------------------------------------
// _runDuelTeamTurn(team) — called at the start of each team's Duel Phase
// slot (from enterDuelPhase and from the duel-1→duel-2 transition).
// 1. Opens any applicable primer modal (disables Ready until resolved).
// 2. If no primer AND no decisions at all → auto-advance after a short beat.
// -----------------------------------------------------------------------
function _runDuelTeamTurn(team) {
  if (!B) return;
  if (openDuelPhasePrimers(team)) return; // primer opened — Ready disabled, wait for player
  if (!hasAnyDecision(team)) {
    // Nothing to do — auto-fire Ready after a narrator beat
    const f = active(B[team]);
    const name = f ? f.name : team;
    setTimeout(() => {
      narrate(`<b class="${team}-text">${name}</b> has nothing to commit — rolling!`);
      setTimeout(() => { duelPhaseReady(team); }, spd(350));
    }, 250);
  }
  // else: team has resources to commit — leave Ready enabled, wait for manual click
}

function computeDuelPriority() {
  if (!B || B.duelPhaseMode === false) return null;
  // Skip Duel Phase entirely when neither team has any decisions to make —
  // saves ~3s per round and avoids pointless Ready clicks (Issue #2).
  if (!hasAnyDecision('red') && !hasAnyDecision('blue')) return null;
  // Unified rule: "previous round loser goes first."
  // Round 1 has no previous loser, so it uses lower max HP (the underdog strikes).
  // Ties of any kind (R1 HP tie, mirror match, R2+ tie round) fall through to
  // B.duelLastLoser — which is NULL in round 1 (→ simultaneous) but STICKY in R2+
  // (the previous NON-TIE loser carries forward through tie rounds).
  const rF = active(B.red);
  const bF = active(B.blue);
  if (!rF || !bF || rF.ko || bF.ko) return B.duelLastLoser || null;
  const isRoundOne = (B.round === 1);
  if (isRoundOne && rF.id !== bF.id && rF.maxHp !== bF.maxHp) {
    return rF.maxHp < bF.maxHp ? 'red' : 'blue';
  }
  return B.duelLastLoser || null;
}

function isPreRollActive(team) {
  if (!B) return false;
  if (B.phase === 'ready') return true;
  if (B.phase === 'duel-1' || B.phase === 'duel-2') {
    return B.duelActiveTeam === team;
  }
  return false;
}

function enterDuelPhase(priority) {
  if (!B) return;
  B.phase = 'duel-1';
  B.duelPriority = priority;
  B.duelActiveTeam = priority;
  // Lock both roll buttons — rolls don't unlock until both players click Done
  const r = document.getElementById('rollRedBtn');
  const b = document.getElementById('rollBlueBtn');
  if (r) { r.classList.add('locked'); r.classList.remove('pulse'); r.disabled = true; }
  if (b) { b.classList.add('locked'); b.classList.remove('pulse'); b.disabled = true; }
  const activeF = active(B[priority]);
  const activeName = activeF ? activeF.name : priority;
  const oppName = priority === 'red' ? 'blue' : 'red';
  // Narrator framing: R1 is "underdog", R2+ is "wounded"
  const isR1 = (B.round === 1);
  const msg = isR1
    ? `<b class="${priority}-text">${activeName}</b> stands as the underdog — first move!`
    : `<b class="${priority}-text">${activeName}</b> licks their wounds — first move this round!`;
  narrate(msg);
  log(`<span class="log-ability">DUEL PHASE</span> — ${activeName} (${priority}) moves first.`);
  renderBattle();
  renderDuelUI();
  _runDuelTeamTurn(priority);
}

function duelPhaseReady(team) {
  if (!B) return;
  if (B.phase !== 'duel-1' && B.phase !== 'duel-2') return;
  if (team !== B.duelActiveTeam) return;
  if (B.phase === 'duel-1') {
    // Advance to phase 2 — opponent's turn
    const nextTeam = team === 'red' ? 'blue' : 'red';
    B.phase = 'duel-2';
    B.duelActiveTeam = nextTeam;
    const nextActive = active(B[nextTeam]);
    const nextName = nextActive ? nextActive.name : nextTeam;
    narrate(`<b class="${nextTeam}-text">${nextName}</b> — your response!`);
    log(`<span class="log-ability">DUEL PHASE</span> — ${nextName} (${nextTeam}) responds.`);
    renderBattle();
    renderDuelUI();
    _runDuelTeamTurn(nextTeam);
  } else {
    // End Duel Phase — unlock rolls for simultaneous resolution
    endDuelPhase();
  }
}

function endDuelPhase() {
  if (!B) return;
  B.phase = 'ready';
  B.duelActiveTeam = null;
  narrate(`<b class="gold">Both ready!</b> Roll the dice!`);
  resetRollButtons();
  renderBattle();
  renderDuelUI();
}

function renderDuelUI() {
  // Show/hide Done buttons and apply .duel-locked class to the inactive team column
  const inDuel = (B && (B.phase === 'duel-1' || B.phase === 'duel-2'));
  const rDone = document.getElementById('duelDoneRedBtn');
  const bDone = document.getElementById('duelDoneBlueBtn');
  const rCol = document.getElementById('red-team-column');
  const bCol = document.getElementById('blue-team-column');
  if (rDone) rDone.style.display = (inDuel && B.duelActiveTeam === 'red') ? 'block' : 'none';
  if (bDone) bDone.style.display = (inDuel && B.duelActiveTeam === 'blue') ? 'block' : 'none';
  if (rCol) rCol.classList.toggle('duel-locked', inDuel && B.duelActiveTeam !== 'red');
  if (bCol) bCol.classList.toggle('duel-locked', inDuel && B.duelActiveTeam !== 'blue');
}

// startNextRound — called from every "round ends" site instead of the direct
// B.phase = 'ready'; resetRollButtons(); pattern. Checks for Duel Phase priority
// and either enters the Duel Phase or falls back to simultaneous ready.
function startNextRound() {
  if (!B) return;

  // Laura (79) — Catchy Tune: if unlocked, show die picker before next round
  if (!B.catchyTuneUnlocked) B.catchyTuneUnlocked = { red: false, blue: false };
  if (!B.catchyTuneLockedDie) B.catchyTuneLockedDie = { red: null, blue: null };
  if (!B.lastRollDiceCount) B.lastRollDiceCount = { red: 3, blue: 3 };
  if (!B.tysonDisabled) B.tysonDisabled = { red: [], blue: [] };
  if (!B.winstonDiceBonus) B.winstonDiceBonus = { red: 0, blue: 0 };
  const ctRed = B.catchyTuneUnlocked.red && B.redDice && B.redDice.length > 0;
  const ctBlue = B.catchyTuneUnlocked.blue && B.blueDice && B.blueDice.length > 0;
  if (ctRed || ctBlue) {
    const proceedAfterPickers = () => { _doStartNextRound(); };
    if (ctRed && ctBlue) {
      showCatchyTunePicker('red', B.redDice, () => {
        showCatchyTunePicker('blue', B.blueDice, proceedAfterPickers);
      });
    } else if (ctRed) {
      showCatchyTunePicker('red', B.redDice, proceedAfterPickers);
    } else {
      showCatchyTunePicker('blue', B.blueDice, proceedAfterPickers);
    }
    return;
  }
  _doStartNextRound();
}
function _doStartNextRound() {
  if (!B) return;
  // Reset per-round Bonzai state for the new round
  B.bonzaiDecided = { red: false, blue: false };
  B.bonzaiBtnDice = { red: 0, blue: 0 };

  // Live PvP state sync: Red is authoritative — broadcasts full state after each round.
  if (B.phase !== 'over') pvpBroadcastState({ event: 'roundEnd' });
  // v726: reset ready flags for next round
  if (LIVE_PVP) { pvpRedReady = false; PVP_OPPONENT_READY = false; }

  // Hand Limit check — force discards BEFORE Duel Phase or roll buttons unlock
  checkHandLimits(() => {
    const priority = computeDuelPriority();
    if (priority) {
      enterDuelPhase(priority);
    } else {
      B.phase = 'ready';
      B.duelActiveTeam = null;
      B.duelPriority = null;
      resetRollButtons();
      renderBattle();
      renderDuelUI();
    }
  });
}

function resetRollButtons() {
  // Fire registered hooks — if any hook returns true, skip default behavior
  for (const fn of _resetRollHooks) {
    try { if (fn()) return; } catch(e) { console.error('[resetRollButtons hook error]', e); }
  }
  const r = document.getElementById('rollRedBtn');
  const b = document.getElementById('rollBlueBtn');
  if (r) { r.classList.remove('locked', 'pulse'); r.disabled = false; r.textContent = 'Red Roll'; }
  if (b) { b.classList.remove('locked', 'pulse'); b.disabled = false; b.textContent = 'Blue Roll'; }
  // v733: async MP — Red button says "READY" (commit signal), Blue is AI-controlled
  if (MP_MODE && !LIVE_PVP) {
    if (r) r.textContent = 'READY';
    if (b) b.style.display = 'none'; // hide Blue's button — AI rolls it
    pvpRedClickedRoll = false; // reset each round
  }
  // Live PvP: hide opponent's button, label ours properly
  if (LIVE_PVP) {
    const oppSide = PVP_SIDE === 'red' ? 'blue' : 'red';
    const oppBtn = document.getElementById(oppSide === 'red' ? 'rollRedBtn' : 'rollBlueBtn');
    if (oppBtn) oppBtn.style.display = 'none';
    const myBtn = document.getElementById(PVP_SIDE === 'red' ? 'rollRedBtn' : 'rollBlueBtn');
    if (myBtn) myBtn.textContent = 'ROLL';
  }
  // Clear dice display between rounds — no leftover numbers from last roll
  ['red', 'blue'].forEach(t => {
    const el = document.getElementById(t + '-dice');
    if (el) el.innerHTML = '';
  });
  // Start AFK pulse timer — if player doesn't roll within 5s, buttons start pulsing
  resetAfkTimer();
}

function disableRollButtons() {
  const r = document.getElementById('rollRedBtn');
  const b = document.getElementById('rollBlueBtn');
  if (r) r.disabled = true;
  if (b) b.disabled = true;
}

// ============================================================
// HAND LIMIT MODE — cap specials at B.HAND_LIMIT (default 3)
// ============================================================
const HAND_RESOURCE_KEYS = ['moonstone','ice','fire','surge','healingSeed','luckyStone','firefly','burn'];
const HAND_RESOURCE_LABELS = {
  moonstone: { emoji:'🌙', name:'Moonstone' },
  ice:       { emoji:'❄️', name:'Ice Shard' },
  fire:      { emoji:'🔥', name:'Sacred Fire' },
  surge:     { emoji:'⚡', name:'Surge' },
  healingSeed:{ emoji:'🌱', name:'Healing Seed' },
  luckyStone:{ emoji:'🍀', name:'Lucky Stone' },
  firefly:   { emoji:'✨', name:'Firefly' },
  burn:      { emoji:'💥', name:'Burn' },
};

function getHandSize(team) {
  let total = 0;
  for (const k of HAND_RESOURCE_KEYS) total += (team.resources[k] || 0);
  return total;
}

// Check both teams after a round resolves. If over limit, show discard modal then call callback.
function checkHandLimits(callback) {
  if (!B || !B.handLimitMode) { callback(); return; }
  // Check red first, then blue, then proceed
  checkTeamHandLimit('red', () => {
    checkTeamHandLimit('blue', callback);
  });
}

function checkTeamHandLimit(teamName, callback) {
  const team = B[teamName];
  if (getHandSize(team) <= B.HAND_LIMIT) { callback(); return; }
  // Show discard modal
  B.handLimitPending = { team: teamName, callback };
  renderHandLimitModal(teamName);
  document.getElementById('handLimitOverlay').classList.add('active');
}

function renderHandLimitModal(teamName) {
  const team = B[teamName];
  const handSize = getHandSize(team);
  const over = handSize - B.HAND_LIMIT;
  const label = teamName === 'red' ? 'Red' : 'Blue';
  document.getElementById('handLimitTitle').textContent = `${label} Team — Discard to ${B.HAND_LIMIT}`;
  document.getElementById('handLimitSub').textContent = `${handSize} specials (${over} over limit). Tap one to destroy it.`;
  const container = document.getElementById('handLimitItems');
  container.innerHTML = '';
  for (const k of HAND_RESOURCE_KEYS) {
    const count = team.resources[k] || 0;
    if (count <= 0) continue;
    const info = HAND_RESOURCE_LABELS[k];
    for (let i = 0; i < count; i++) {
      const btn = document.createElement('button');
      btn.className = 'selene-opt';
      btn.style.cssText = 'background:linear-gradient(135deg,#374151,#1f2937);min-width:100px;margin:0;padding:8px 14px;font-size:14px;';
      btn.textContent = `${info.emoji} ${info.name}`;
      btn.onclick = () => doHandLimitDiscard(teamName, k);
      container.appendChild(btn);
    }
  }
}

function doHandLimitDiscard(teamName, resourceKey) {
  const team = B[teamName];
  if ((team.resources[resourceKey] || 0) <= 0) return;
  team.resources[resourceKey]--;
  const info = HAND_RESOURCE_LABELS[resourceKey];
  log(`<span class="log-ability">Hand Limit</span> — ${teamName === 'red' ? 'Red' : 'Blue'} discards ${info.emoji} ${info.name}! (${getHandSize(team)}/${B.HAND_LIMIT})`);
  renderBattle();
  // Still over? Re-render the modal
  if (getHandSize(team) > B.HAND_LIMIT) {
    renderHandLimitModal(teamName);
    return;
  }
  // Done — close modal and proceed
  document.getElementById('handLimitOverlay').classList.remove('active');
  const pending = B.handLimitPending;
  B.handLimitPending = null;
  if (pending?.callback) pending.callback();
}

// Pre-roll setup — called once when the first player clicks Roll
function doPreRollSetup() {
  if (!B || B.phase !== 'ready') return;
  const rF = active(B.red), bF = active(B.blue);
  if (rF.ko || bF.ko) return;
  // MVP snapshot: capture team resources + ghost HPs so we can credit deltas at round end
  snapshotRound();

  // Collect pre-roll callouts — drained sequentially after setup so none stomp each other
  const preRollCallouts = [];

  // Snapshot Lucky Stones + Moonstones available BEFORE this round
  // (can't use resources gained during the same roll)
  B.lsAvailable = {
    red: B.red.resources.luckyStone,
    blue: B.blue.resources.luckyStone
  };
  B.msAvailable = {
    red: B.red.resources.moonstone,
    blue: B.blue.resources.moonstone
  };

  // Reset per-round flags
  [B.red, B.blue].forEach(team => {
    active(team).usedMagicTouch = false;
  });
  // v640 — Piper (107) Slick Coat reactive: flag true when an auto-fire before-roll ability
  // is negated this round. Only then does Piper apply the -1 enemy die penalty.
  // Prevents the old behavior where Slick Coat fired unconditionally every round.
  B.piperBlockedThisRound = { red: false, blue: false };

  // ========================================
  // PHASE 1: PRE-ROLL TRIGGERS
  // ========================================

  // Moonstone Sickness — pre-roll damage (once per turn, does NOT hit replacement if KO)
  if (!B.moonstoneSicknessFiredThisTurn) {
    B.moonstoneSicknessFiredThisTurn = true;
    const msMode = document.getElementById('moonstoneModeSelect')?.value || 'D';
    ['red', 'blue'].forEach(teamKey => {
      const t = B[teamKey];
      let msDmg = 0;
      if (msMode === 'A' && t.moonstoneSickness > 0) {
        msDmg = t.moonstoneSickness * 2;
      } else if ((msMode === 'D' || msMode === 'G') && t.moonstoneSickness > 0) {
        msDmg = t.moonstoneSickness * 1;
      } else if ((msMode === 'B' || msMode === 'C') && t.moonstoneSicknessPending > 0) {
        msDmg = t.moonstoneSicknessPending;
        t.moonstoneSicknessPending = 0; // clear after applying
      }
      if (msDmg > 0) {
        const f = active(t);
        if (f && !f.ko) {
          f.hp = Math.max(0, f.hp - msDmg);
          if (f.hp <= 0) { f.ko = true; f.killedBy = -1; }
          log(`<span class="log-dmg">Moonstone Sickness!</span> ${f.name} takes ${msDmg} damage! ${f.ko ? '<span class="log-ko">KO!</span>' : f.hp + ' HP left'}`);
          narrate(`<b style="color:var(--moonstone)">Moonstone Sickness!</b> <b class="${teamKey}-text">${f.name}</b> takes ${msDmg} damage!${f.ko ? ' <b>KO!</b>' : ''}`);
          preRollCallouts.push(['MOONSTONE SICKNESS!', 'var(--moonstone)', `${f.name} takes ${msDmg} damage!`, teamKey]);
          playDamageSfx(msDmg);
          hitDamage(teamKey);
          renderBattle();
        }
      }
    });
  }

  // v687: Pre-roll chip damage abilities fire ONCE per turn. If they KO a ghost and
  // a replacement swaps in, doPreRollSetup re-runs — but the replacement is NOT hit
  // again. The flag is set before the first ability fires and checked on re-entry.
  const preRollAlreadyFired = B.preRollAbilitiesFiredThisTurn.red && B.preRollAbilitiesFiredThisTurn.blue;
  if (!preRollAlreadyFired) {
  B.preRollAbilitiesFiredThisTurn.red = true;
  B.preRollAbilitiesFiredThisTurn.blue = true;

  // Frederick (27) — Careful: deal 2 damage per extra die enemy rolled above 3 last round
  [B.red, B.blue].forEach(team => {
    const fFred = active(team);
    const enemyFred = opp(team);
    const tNameFred = team === B.red ? 'red' : 'blue';
    const enemyNameFred = enemyFred === B.red ? 'red' : 'blue';
    if (fFred.id === 27 && !fFred.ko) {
      const enemyLastDice = B.lastRollDiceCount[enemyNameFred] || 3;
      const extraDice = Math.max(0, enemyLastDice - 3);
      if (extraDice > 0) {
        const fredDmg = extraDice * 2;
        const ef = active(enemyFred);
        if (!ef.ko) {
          ef.hp = Math.max(0, ef.hp - fredDmg);
          if (ef.hp <= 0) { ef.hp = 0; ef.ko = true; ef.killedBy = 27; }
          preRollCallouts.push(['CAREFUL!', 'var(--common)', `${fFred.name} — Enemy rolled ${enemyLastDice} dice last round! ${extraDice} extra × 2 = ${fredDmg} damage!`, tNameFred]);
          log(`<span class="log-ability">${fFred.name}</span> — Careful! Enemy rolled ${enemyLastDice} dice (${extraDice} extra) → <span class="log-dmg">${fredDmg} damage to ${ef.name}!</span> ${ef.ko ? '<span class="log-ko">KO!</span>' : ef.hp + ' HP left'}`);
          playDamageSfx(fredDmg);
          hitDamage(enemyNameFred);
        }
      }
    }
  });

  // Ember Force (304) — deal 1 damage to enemy active (negated by Dylan)
  // Phase 4: Masked Hero (55) Underdog fires BEFORE pre-roll damage — if attacker KO'd, skip damage
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const enemy = opp(team);
    const tNamePre = team === B.red ? 'red' : 'blue';
    if (f.id === 304 && !f.ko && !dylanNegates(enemy)) {
      const ef = active(enemy);
      if (!ef.ko) {
        const enemyName = enemy === B.red ? 'red' : 'blue';
        // Masked Hero (55) — Underdog: immune to before-roll damage
        if (maskedHeroImmune(ef)) {
          preRollCallouts.push(['UNDERDOG!', 'var(--uncommon)', `${ef.name} — immune to before-roll damage!`, enemyName]);
          log(`<span class="log-ability">${ef.name}</span> — Underdog! Immune to ${f.name}'s Swarm!`);
          return;
        }
        ef.hp = Math.max(0, ef.hp - 1);
        if (ef.hp <= 0) { ef.ko = true; ef.killedBy = (f.originalId || f.id); }
        preRollCallouts.push(['SWARM!', 'var(--uncommon)', `${f.name} — 1 damage to ${ef.name}!`, tNamePre]);
        log(`<span class="log-ability">${f.name}</span> — Swarm! <span class="log-dmg">1 damage to ${ef.name}!</span> ${ef.ko?'<span class="log-ko">KO!</span>':ef.hp+' HP left'}`);
        playDamageSfx(1);
        hitDamage(enemyName);
        // Simon (24) — Brew Time: gain 1 Sacred Fire when taking ANY damage
        if (ef.id === 24 && !ef.ko) {
          B[enemyName].resources.fire += 2;
          preRollCallouts.push(['BREW TIME!', 'var(--uncommon)', `Simon — Took pre-roll damage → +2 Sacred Fire!`, enemyName]);
          log(`<span class="log-ability">Simon</span> — Brew Time! Took pre-roll damage → <span class="log-ms">+2 Sacred Fire!</span>`);
        }
        // Collect Knight reactions via temp queue mode so they splice AFTER SWARM! in preRollCallouts
        const _swarmSavedKQ = abilityQueue;
        abilityQueue = [];
        abilityQueueMode = true;
        checkKnightEffects(tNamePre, f.name);
        abilityQueueMode = false;
        abilityQueue.forEach(item => preRollCallouts.push([item.name, item.color, item.desc, item.team]));
        abilityQueue = _swarmSavedKQ;
        // Princess Shade (436) — Bounty: +1 additional damage on pre-roll chip, works from sideline OR active (blocked by Cornelius)
        if (!ef.ko && hasAlive(B[tNamePre], 436) && !hasSideline(B[enemyName], 45)) {
          const psPreHp = ef.hp;
          ef.hp = Math.max(0, ef.hp - 1);
          if (ef.hp <= 0) { ef.ko = true; ef.killedBy = 436; }
          preRollCallouts.push(['BOUNTY!', 'var(--rare)', `Princess Shade — +1 additional damage to ${ef.name}!`, tNamePre]);
          log(`<span class="log-ability">Princess Shade</span> — Bounty! <span class="log-dmg">+1 additional damage to ${ef.name}!</span> ${ef.ko?'<span class="log-ko">KO!</span>':ef.hp+' HP left'}`);
          playDamageSfx(1);
          hitDamage(enemyName);
          popSidelineCard(B[tNamePre], 436);
          if (ef.id === 24 && !ef.ko) {
            B[enemyName].resources.fire += 2;
            preRollCallouts.push(['BREW TIME!', 'var(--uncommon)', `Simon — Took pre-roll damage → +2 Sacred Fire!`, enemyName]);
            log(`<span class="log-ability">Simon</span> — Brew Time! Took pre-roll damage → <span class="log-ms">+1 Sacred Fire!</span>`);
          }
        } else if (!ef.ko && hasAlive(B[tNamePre], 436) && hasSideline(B[enemyName], 45)) {
          const cornGhostPS = getSidelineGhost(B[enemyName], 45);
          preRollCallouts.push(['ANTIDOTE!', 'var(--uncommon)', `${cornGhostPS ? cornGhostPS.name : 'Cornelius'} blocks Princess Shade's Bounty!`, enemyName]);
          log(`<span class="log-ability">Cornelius</span> (sideline) — Antidote! Princess Shade Bounty blocked!`);
        }
      }
    } else if (f.id === 304 && !f.ko && dylanNegates(enemy)) {
      log(`<span class="log-ability">${f.name}</span> — Swarm blocked by <span class="log-ability">Dylan's Scarecrow</span>!`);
      B.piperBlockedThisRound[tNamePre] = true; // v640: Slick Coat gate
    }
  });

  // Shade's Shadow (205) — sideline: deal 1 dmg before each roll IF enemy active < 4 HP (negated by Dylan or Cornelius)
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const enemy = opp(team);
    const tNameShade = team === B.red ? 'red' : 'blue';
    const corneliusBlocksShadow = hasSideline(enemy, 45);
    if (hasSideline(team, 205) && !dylanNegates(enemy) && !corneliusBlocksShadow) {
      const shadeGhost = getSidelineGhost(team, 205);
      const ef = active(enemy);
      if (!ef.ko && ef.hp < 4) {
        // Masked Hero (55) — immune to before-roll damage
        if (maskedHeroImmune(ef)) {
          preRollCallouts.push(['UNDERDOG!', 'var(--uncommon)', `${ef.name} — immune to Meltdown!`, tNameShade]);
          log(`<span class="log-ability">${ef.name}</span> — Underdog! Immune to Shade's Shadow Meltdown!`);
          return;
        }
        const preHp = ef.hp;
        ef.hp = Math.max(0, ef.hp - 1);
        if (ef.hp <= 0) { ef.ko = true; ef.killedBy = 205; }
        const enemyName = enemy === B.red ? 'red' : 'blue';
        const meltMsg = ef.ko
          ? `Shade's Shadow finishes ${ef.name}! (${preHp} HP → KO!)`
          : `Shade's Shadow chips ${ef.name}! (${preHp} → ${ef.hp} HP)`;
        preRollCallouts.push(['MELTDOWN!', 'var(--rare)', meltMsg, tNameShade]);
        log(`<span class="log-ability">Shade's Shadow</span> (sideline) — Meltdown! Enemy below 4 HP — <span class="log-dmg">1 damage to ${ef.name}!</span> ${ef.ko?'<span class="log-ko">KO!</span>':ef.hp+' HP left'}`);
        playDamageSfx(1);
        hitDamage(enemyName);
        popSidelineCard(team, 205);
        // Simon (24) — Brew Time: gain 1 Sacred Fire when taking ANY damage
        if (ef.id === 24 && !ef.ko) {
          B[enemyName].resources.fire += 2;
          preRollCallouts.push(['BREW TIME!', 'var(--uncommon)', `Simon — Took pre-roll damage → +2 Sacred Fire!`, enemyName]);
          log(`<span class="log-ability">Simon</span> — Brew Time! Took pre-roll damage → <span class="log-ms">+2 Sacred Fire!</span>`);
        }
        // Collect Knight reactions via temp queue mode so they splice AFTER MELTDOWN! in preRollCallouts
        // (not in queue mode → checkKnightEffects fires showAbilityCallout directly, stomping MELTDOWN!)
        const _meltSavedKQ = abilityQueue;
        abilityQueue = [];
        abilityQueueMode = true;
        checkKnightEffects(tNameShade, "Shade's Shadow", shadeGhost);
        abilityQueueMode = false;
        abilityQueue.forEach(item => preRollCallouts.push([item.name, item.color, item.desc, item.team]));
        abilityQueue = _meltSavedKQ;
        // Princess Shade (436) — Bounty: +1 additional damage on pre-roll chip, works from sideline OR active (blocked by Cornelius)
        if (!ef.ko && hasAlive(B[tNameShade], 436) && !hasSideline(enemy, 45)) {
          const psPreHp2 = ef.hp;
          ef.hp = Math.max(0, ef.hp - 1);
          if (ef.hp <= 0) { ef.ko = true; ef.killedBy = 436; }
          preRollCallouts.push(['BOUNTY!', 'var(--rare)', `Princess Shade — +1 additional damage to ${ef.name}!`, tNameShade]);
          log(`<span class="log-ability">Princess Shade</span> — Bounty! <span class="log-dmg">+1 additional damage to ${ef.name}!</span> ${ef.ko?'<span class="log-ko">KO!</span>':ef.hp+' HP left'}`);
          playDamageSfx(1);
          hitDamage(enemyName);
          popSidelineCard(B[tNameShade], 436);
          // Simon (24) — Brew Time: gain 1 Sacred Fire when taking ANY damage
          if (ef.id === 24 && !ef.ko) {
            B[enemyName].resources.fire += 2;
            preRollCallouts.push(['BREW TIME!', 'var(--uncommon)', `Simon — Took pre-roll damage → +2 Sacred Fire!`, enemyName]);
            log(`<span class="log-ability">Simon</span> — Brew Time! Took pre-roll damage → <span class="log-ms">+1 Sacred Fire!</span>`);
          }
        } else if (!ef.ko && hasAlive(B[tNameShade], 436) && hasSideline(enemy, 45)) {
          const cornGhostPS2 = getSidelineGhost(enemy, 45);
          preRollCallouts.push(['ANTIDOTE!', 'var(--uncommon)', `${cornGhostPS2 ? cornGhostPS2.name : 'Cornelius'} blocks Princess Shade's Bounty!`, enemyName]);
          log(`<span class="log-ability">Cornelius</span> (sideline) — Antidote! Princess Shade Bounty blocked!`);
        }
      }
    } else if (hasSideline(team, 205) && dylanNegates(enemy)) {
      log(`<span class="log-ability">Shade's Shadow</span> — Meltdown blocked by <span class="log-ability">Dylan's Scarecrow</span>!`);
      B.piperBlockedThisRound[tNameShade] = true; // v640: Slick Coat gate
    } else if (hasSideline(team, 205) && corneliusBlocksShadow) {
      const cornGhostSS = getSidelineGhost(enemy, 45);
      const enemyNameSS = enemy === B.red ? 'red' : 'blue';
      preRollCallouts.push(['ANTIDOTE!', 'var(--uncommon)', `${cornGhostSS ? cornGhostSS.name : 'Cornelius'} blocks Shade's Shadow Meltdown!`, enemyNameSS]);
      log(`<span class="log-ability">Cornelius</span> (sideline) — Antidote! <span class="log-ability">Shade's Shadow</span> Meltdown blocked!`);
      B.piperBlockedThisRound[tNameShade] = true; // v640: Slick Coat gate
    }
  });

  // Shade (111) — active: deal 1 damage to enemy active before each roll INCLUDING round 1 (negated by Dylan)
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const enemy = opp(team);
    const tNameHaunt = team === B.red ? 'red' : 'blue';
    if (f.id === 111 && !f.ko && f._rolledOnce && !dylanNegates(enemy)) {
      const ef = active(enemy);
      if (!ef.ko) {
        // Piper (107) — Slick Coat: negates Haunt
        if (ef.id === 107 && !ef.ko) {
          log(`<span class="log-ability">Piper</span> — Slick Coat! Shade's Haunt is negated.`);
        } else {
          const enemyName = enemy === B.red ? 'red' : 'blue';
          // Masked Hero (55) — immune to before-roll damage
          if (maskedHeroImmune(ef)) {
            preRollCallouts.push(['UNDERDOG!', 'var(--uncommon)', `${ef.name} — immune to Haunt!`, enemyName]);
            log(`<span class="log-ability">${ef.name}</span> — Underdog! Immune to Shade's Haunt!`);
            return;
          }
          const preHp = ef.hp;
          ef.hp = Math.max(0, ef.hp - 1);
          if (ef.hp <= 0) { ef.ko = true; ef.killedBy = 111; }
          const hauntMsg = ef.ko
            ? `Shade haunts ${ef.name}! (${preHp} HP → KO!)`
            : `Shade haunts ${ef.name}! (${preHp} → ${ef.hp} HP)`;
          preRollCallouts.push(['HAUNT!', 'var(--legendary)', hauntMsg, tNameHaunt]);
          log(`<span class="log-ability">Shade</span> — Haunt! <span class="log-dmg">1 damage to ${ef.name}!</span> ${ef.ko?'<span class="log-ko">KO!</span>':ef.hp+' HP left'}`);
          playDamageSfx(1);
          hitDamage(enemyName);
          // Simon (24) — Brew Time: gain 1 Sacred Fire when taking ANY damage
          if (ef.id === 24 && !ef.ko) {
            B[enemyName].resources.fire += 2;
            preRollCallouts.push(['BREW TIME!', 'var(--uncommon)', `Simon — Took pre-roll damage → +2 Sacred Fire!`, enemyName]);
            log(`<span class="log-ability">Simon</span> — Brew Time! Took pre-roll damage → <span class="log-ms">+1 Sacred Fire!</span>`);
          }
          // Collect Knight reactions via temp queue mode so they splice AFTER HAUNT! in preRollCallouts
          const _hauntSavedKQ = abilityQueue;
          abilityQueue = [];
          abilityQueueMode = true;
          checkKnightEffects(tNameHaunt, f.name);
          abilityQueueMode = false;
          abilityQueue.forEach(item => preRollCallouts.push([item.name, item.color, item.desc, item.team]));
          abilityQueue = _hauntSavedKQ;
          // Princess Shade (436) — Bounty: +1 additional damage on pre-roll chip, works from sideline OR active (blocked by Cornelius)
          if (!ef.ko && hasAlive(B[tNameHaunt], 436) && !hasSideline(enemy, 45)) {
            const psPreHp3 = ef.hp;
            ef.hp = Math.max(0, ef.hp - 1);
            if (ef.hp <= 0) { ef.ko = true; ef.killedBy = 436; }
            preRollCallouts.push(['BOUNTY!', 'var(--rare)', `Princess Shade — +1 additional damage to ${ef.name}!`, tNameHaunt]);
            log(`<span class="log-ability">Princess Shade</span> — Bounty! <span class="log-dmg">+1 additional damage to ${ef.name}!</span> ${ef.ko?'<span class="log-ko">KO!</span>':ef.hp+' HP left'}`);
            playDamageSfx(1);
            hitDamage(enemyName);
            popSidelineCard(B[tNameHaunt], 436);
            if (ef.id === 24 && !ef.ko) {
              B[enemyName].resources.fire += 2;
              preRollCallouts.push(['BREW TIME!', 'var(--uncommon)', `Simon — Took pre-roll damage → +2 Sacred Fire!`, enemyName]);
              log(`<span class="log-ability">Simon</span> — Brew Time! Took pre-roll damage → <span class="log-ms">+1 Sacred Fire!</span>`);
            }
          } else if (!ef.ko && hasAlive(B[tNameHaunt], 436) && hasSideline(enemy, 45)) {
            const cornGhostPS3 = getSidelineGhost(enemy, 45);
            const enemyNameHaunt = enemy === B.red ? 'red' : 'blue';
            preRollCallouts.push(['ANTIDOTE!', 'var(--uncommon)', `${cornGhostPS3 ? cornGhostPS3.name : 'Cornelius'} blocks Princess Shade's Bounty!`, enemyNameHaunt]);
            log(`<span class="log-ability">Cornelius</span> (sideline) — Antidote! Princess Shade Bounty blocked!`);
          }
        }
      }
    } else if (f.id === 111 && !f.ko && dylanNegates(enemy)) {
      log(`<span class="log-ability">Shade</span> — Haunt blocked by <span class="log-ability">Dylan's Scarecrow</span>!`);
      B.piperBlockedThisRound[tNameHaunt] = true; // v640: Slick Coat gate
    }
  });

  // Lucy (108) — Blue Fire: pending tick from the previous round's win.
  // Lucy's "Win a roll: opponent takes 1 damage before their next roll" arrives here
  // as a separate beat — NOT bundled with the winning roll's damage. The flag is
  // Delayed damage: set by Lucy (108, 1 dmg) or Humar (336, 2 dmg) via B.pendingLucyDmg
  // Consumed before this round's roll. Target is the team holding the pending flag.
  [B.red, B.blue].forEach(team => {
    const tNameLucyTarget = team === B.red ? 'red' : 'blue';
    if (!(B.pendingLucyDmg && B.pendingLucyDmg[tNameLucyTarget] > 0)) return;
    const pendingDmg = B.pendingLucyDmg[tNameLucyTarget];
    const tNameLucyActor = tNameLucyTarget === 'red' ? 'blue' : 'red';
    const isHumar = pendingDmg >= 2;
    const abilityLabel = isHumar ? 'Meteor' : 'Blue Fire';
    const splashName = isHumar ? 'METEOR!' : 'BLUE FIRE!';
    const splashColor = 'var(--legendary)';
    if (!dylanNegates(team)) {
      const f = active(team);
      if (!f.ko) {
        // Phase 4: Masked Hero (55) Underdog fires BEFORE Lucy/Humar delayed damage
        if (f.id === 55 && !f.ko) {
          const lucyAttacker = active(B[tNameLucyActor]);
          if (lucyAttacker && !lucyAttacker.ko) {
            const undPreL = lucyAttacker.hp;
            lucyAttacker.hp = Math.max(0, lucyAttacker.hp - 3);
            if (lucyAttacker.hp <= 0) { lucyAttacker.ko = true; lucyAttacker.killedBy = 55; }
            const undMsgL = lucyAttacker.ko
              ? `${f.name} counters! 3 damage to ${lucyAttacker.name}! (${undPreL} HP → KO!)`
              : `${f.name} counters! 3 damage to ${lucyAttacker.name}! (${undPreL} → ${lucyAttacker.hp} HP)`;
            preRollCallouts.push(['UNDERDOG!', 'var(--uncommon)', undMsgL, tNameLucyTarget]);
            log(`<span class="log-ability">${f.name}</span> — Underdog! 3 counter-damage to ${lucyAttacker.name}!`);
            playDamageSfx(3);
            hitDamage(tNameLucyActor);
            if (lucyAttacker.ko) {
              B.pendingLucyDmg[tNameLucyTarget] = 0; // consume the flag
              return; // Attacker KO'd by Underdog — skip Lucy/Humar damage
            }
          }
        }
        const preHp = f.hp;
        f.hp = Math.max(0, f.hp - pendingDmg);
        if (f.hp <= 0) { f.ko = true; f.killedBy = isHumar ? 336 : 108; }
        const lucyMsg = f.ko
          ? `${abilityLabel} burns ${f.name}! (${preHp} HP → KO!)`
          : `${abilityLabel} burns ${f.name}! (${preHp} → ${f.hp} HP)`;
        preRollCallouts.push([splashName, splashColor, lucyMsg, tNameLucyActor]);
        log(`<span class="log-ability">${abilityLabel}</span> — <span class="log-dmg">${pendingDmg} damage to ${f.name}!</span> ${f.ko?'<span class="log-ko">KO!</span>':f.hp+' HP left'}`);
        playDamageSfx(pendingDmg);
        hitDamage(tNameLucyTarget);
        // Simon (24) — Brew Time: gain 1 Sacred Fire when taking ANY damage
        if (f.id === 24 && !f.ko) {
          B[tNameLucyTarget].resources.fire += 2;
          preRollCallouts.push(['BREW TIME!', 'var(--uncommon)', `Simon — Took pre-roll damage → +2 Sacred Fire!`, tNameLucyTarget]);
          log(`<span class="log-ability">Simon</span> — Brew Time! Took pre-roll damage → <span class="log-ms">+1 Sacred Fire!</span>`);
        }
        // Princess Shade (436) — Bounty: +1 additional damage on pre-roll chip, works from sideline OR active (blocked by Cornelius)
        if (!f.ko && hasAlive(B[tNameLucyActor], 436) && !hasSideline(B[tNameLucyTarget], 45)) {
          const psPreHpL = f.hp;
          f.hp = Math.max(0, f.hp - 1);
          if (f.hp <= 0) { f.ko = true; f.killedBy = 436; }
          preRollCallouts.push(['BOUNTY!', 'var(--rare)', `Princess Shade — +1 additional damage to ${f.name}!`, tNameLucyActor]);
          log(`<span class="log-ability">Princess Shade</span> — Bounty! <span class="log-dmg">+1 additional damage to ${f.name}!</span> ${f.ko?'<span class="log-ko">KO!</span>':f.hp+' HP left'}`);
          playDamageSfx(1);
          hitDamage(tNameLucyTarget);
          popSidelineCard(B[tNameLucyActor], 436);
          // Simon (24) — Brew Time: gain 1 Sacred Fire when taking ANY damage
          if (f.id === 24 && !f.ko) {
            B[tNameLucyTarget].resources.fire++;
            preRollCallouts.push(['BREW TIME!', 'var(--uncommon)', `Simon — Took pre-roll damage → +2 Sacred Fire!`, tNameLucyTarget]);
            log(`<span class="log-ability">Simon</span> — Brew Time! Took pre-roll damage → <span class="log-ms">+1 Sacred Fire!</span>`);
          }
        } else if (!f.ko && hasAlive(B[tNameLucyActor], 436) && hasSideline(B[tNameLucyTarget], 45)) {
          const cornGhostPSL = getSidelineGhost(B[tNameLucyTarget], 45);
          preRollCallouts.push(['ANTIDOTE!', 'var(--uncommon)', `${cornGhostPSL ? cornGhostPSL.name : 'Cornelius'} blocks Princess Shade's Bounty!`, tNameLucyTarget]);
          log(`<span class="log-ability">Cornelius</span> (sideline) — Antidote! Princess Shade Bounty blocked!`);
        }
        // Knight reactions on Lucy's side (the actor). Temp queue mode so reactions
        // splice AFTER BLUE FIRE! in preRollCallouts instead of stomping it.
        const _lucySavedKQ = abilityQueue;
        abilityQueue = [];
        abilityQueueMode = true;
        checkKnightEffects(tNameLucyActor, 'Lucy');
        abilityQueueMode = false;
        abilityQueue.forEach(item => preRollCallouts.push([item.name, item.color, item.desc, item.team]));
        abilityQueue = _lucySavedKQ;
      }
    } else {
      log(`<span class="log-ability">Lucy</span> — Blue Fire blocked by <span class="log-ability">Dylan's Scarecrow</span>!`);
      B.piperBlockedThisRound[tNameLucyActor] = true; // v640: Slick Coat gate
    }
    B.pendingLucyDmg[tNameLucyTarget] = 0; // consume regardless (applied, negated, or target KO'd)
  });

  // Splinter (101) — Toxic Fumes: once activated (first win), deal 1 chip damage to enemy before every roll
  // Negated by Dylan's Scarecrow (same as Haunt). Stops naturally when Splinter is KO'd (no longer active).
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const enemy = opp(team);
    const tNameSplinter = team === B.red ? 'red' : 'blue';
    if (f.id === 101 && !f.ko && B.splinterActivated && B.splinterActivated[tNameSplinter]) {
      const ef = active(enemy);
      if (!ef.ko) {
        if (dylanNegates(enemy)) {
          log(`<span class="log-ability">Splinter</span> — Toxic Fumes blocked by <span class="log-ability">Dylan's Scarecrow</span>!`);
          B.piperBlockedThisRound[tNameSplinter] = true; // v640: Slick Coat gate
        } else {
          const enemyName = enemy === B.red ? 'red' : 'blue';
          // Masked Hero (55) — immune to before-roll damage
          if (maskedHeroImmune(ef)) {
            preRollCallouts.push(['UNDERDOG!', 'var(--uncommon)', `${ef.name} — immune to Toxic Fumes!`, enemyName]);
            log(`<span class="log-ability">${ef.name}</span> — Underdog! Immune to Splinter's Toxic Fumes!`);
            return;
          }
          const preHp = ef.hp;
          ef.hp = Math.max(0, ef.hp - 1);
          if (ef.hp <= 0) { ef.ko = true; ef.killedBy = 101; }
          const fumesMsg = ef.ko
            ? `Toxic Fumes choke ${ef.name}! (${preHp} HP → KO!)`
            : `Toxic Fumes choke ${ef.name}! (${preHp} → ${ef.hp} HP)`;
          preRollCallouts.push(['TOXIC FUMES!', 'var(--ghost-rare)', fumesMsg, tNameSplinter]);
          log(`<span class="log-ability">Splinter</span> — Toxic Fumes! <span class="log-dmg">1 damage to ${ef.name}!</span> ${ef.ko?'<span class="log-ko">KO!</span>':ef.hp+' HP left'}`);
          playDamageSfx(1);
          hitDamage(enemyName);
          if (ef.id === 24 && !ef.ko) {
            B[enemyName].resources.fire += 2;
            preRollCallouts.push(['BREW TIME!', 'var(--uncommon)', `Simon — Took pre-roll damage → +2 Sacred Fire!`, enemyName]);
            log(`<span class="log-ability">Simon</span> — Brew Time! Took pre-roll damage → <span class="log-ms">+1 Sacred Fire!</span>`);
          }
          const _splinterSavedKQ = abilityQueue;
          abilityQueue = [];
          abilityQueueMode = true;
          checkKnightEffects(tNameSplinter, f.name);
          abilityQueueMode = false;
          abilityQueue.forEach(item => preRollCallouts.push([item.name, item.color, item.desc, item.team]));
          abilityQueue = _splinterSavedKQ;
          // Princess Shade (436) — Bounty: +1 additional damage on pre-roll chip, works from sideline OR active (blocked by Cornelius)
          if (!ef.ko && hasAlive(B[tNameSplinter], 436) && !hasSideline(enemy, 45)) {
            const psPreHp4 = ef.hp;
            ef.hp = Math.max(0, ef.hp - 1);
            if (ef.hp <= 0) { ef.ko = true; ef.killedBy = 436; }
            preRollCallouts.push(['BOUNTY!', 'var(--rare)', `Princess Shade — +1 additional damage to ${ef.name}!`, tNameSplinter]);
            log(`<span class="log-ability">Princess Shade</span> — Bounty! <span class="log-dmg">+1 additional damage to ${ef.name}!</span> ${ef.ko?'<span class="log-ko">KO!</span>':ef.hp+' HP left'}`);
            playDamageSfx(1);
            hitDamage(enemyName);
            popSidelineCard(B[tNameSplinter], 436);
            if (ef.id === 24 && !ef.ko) {
              B[enemyName].resources.fire += 2;
              preRollCallouts.push(['BREW TIME!', 'var(--uncommon)', `Simon — Took pre-roll damage → +2 Sacred Fire!`, enemyName]);
              log(`<span class="log-ability">Simon</span> — Brew Time! Took pre-roll damage → <span class="log-ms">+1 Sacred Fire!</span>`);
            }
          } else if (!ef.ko && hasAlive(B[tNameSplinter], 436) && hasSideline(enemy, 45)) {
            const cornGhostPS4 = getSidelineGhost(enemy, 45);
            preRollCallouts.push(['ANTIDOTE!', 'var(--uncommon)', `${cornGhostPS4 ? cornGhostPS4.name : 'Cornelius'} blocks Princess Shade's Bounty!`, enemyName]);
            log(`<span class="log-ability">Cornelius</span> (sideline) — Antidote! Princess Shade Bounty blocked!`);
          }
        }
      }
    }
  });

  } // end pre-roll once-per-turn guard (v687)

  // Toby (97) — Pure Heart: if declared last round, KO Toby before rolling (the sacrifice)
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const tNameToby = team === B.red ? 'red' : 'blue';
    if (f.id === 97 && !f.ko && B.pureHeartScheduledKO && B.pureHeartScheduledKO[tNameToby]) {
      B.pureHeartScheduledKO[tNameToby] = false;
      f.hp = 0;
      f.ko = true;
      f.killedBy = 97; // self-sacrifice
      preRollCallouts.push(['PURE HEART!', 'var(--ghost-rare)', `${f.name} — The sacrifice is complete. The final roll was played.`, tNameToby]);
      log(`<span class="log-ability">${f.name}</span> — Pure Heart! Toby is defeated before rolling (sacrifice).`);
    }
  });

  // Wandering Sue (84) — Hidden Weakness: if enemy active ghost has 12+ HP, destroy them before rolling
  // Anti-overclock assassin — punishes opponents who stack HP via Seeker, Boris Fortify, etc.
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    if (f.id === 84 && !f.ko) {
      const enemy = opp(team);
      const ef = active(enemy);
      if (!ef.ko && ef.hp >= 12) {
        const preHp = ef.hp;
        ef.hp = 0;
        ef.ko = true;
        ef.killedBy = 84;
        preRollCallouts.push(['HIDDEN WEAKNESS!', 'var(--rare)', `${ef.name} has ${preHp} HP — exposed and destroyed!`, team === B.red ? 'red' : 'blue']);
        log(`<span class="log-ability">${f.name}</span> — Hidden Weakness! ${ef.name} had ${preHp} HP (≥12) — <span class="log-ko">instant KO!</span>`);
      }
    }
  });

  // If a pre-roll ability (Swarm / Meltdown / Haunt / Pure Heart / Hidden Weakness) caused a KO, flush any pending
  // callouts (e.g. MELTDOWN!) BEFORE the swap modal opens — previously the early
  // return discarded them and the callout silently never played.
  const preRollKO = [B.red, B.blue].some(t => active(t).ko);
  if (preRollKO && preRollCallouts.length > 0) {
    // Park phase NOW so rollReady's `if (B.phase !== 'ready') return;` guard fires
    // and prevents rolling from starting while MELTDOWN! is on screen. Without this,
    // doPreRollSetup returns undefined, the phase stays 'ready', rollReady sets it to
    // 'rolling', and dice fly mid-callout — then handleKOs() opens the swap modal
    // mid-resolution. 'ko-pause' is the correct holding state (used by doPressureSwap,
    // doKoSwap, etc.) — handleKOs() will transition to 'ko-swap' when it fires.
    B.phase = 'ko-pause';
    preRollCallouts.forEach((c, i) => {
      setTimeout(() => showAbilityCallout(c[0], c[1], c[2], c[3]), i * spd(1500));
    });
    refundCommitted();
    setTimeout(() => handleKOs(), preRollCallouts.length * 1500);
    return;
  }
  if (handleKOs()) {
    // No pending callouts — swap flow opens immediately
    refundCommitted();
    return;
  }

  // Harrison (315) — opt-in: spend seeds for extra dice (1 per seed)
  B.harrisonExtraDie = { red: 0, blue: 0 };
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const tName = team === B.red ? 'red' : 'blue';
    if (f.id === 315 && !f.ko && B.committed[tName].harrison > 0) {
      B.harrisonExtraDie[tName] = B.committed[tName].harrison;
      const cnt = B.committed[tName].harrison;
      B.committed[tName].harrison = 0; // reset after use
      preRollCallouts.push(['ASCEND!', 'var(--rare)', `${f.name} — ${cnt} seed${cnt>1?'s':''} → +${cnt} dice!`, team === B.red ? 'red' : 'blue']);
      log(`<span class="log-ability">${f.name}</span> — Ascend! Spent ${cnt} Healing Seed${cnt>1?'s':''} for +${cnt} extra dice!`);
      // Knight reactions to Ascend — collect via temporary queue then splice into preRollCallouts
      // so HEAVY AIR! / RETRIBUTION! plays sequentially AFTER ASCEND!, not as a simultaneous stomp
      const _savedAscendAQ = abilityQueue;
      abilityQueue = [];
      abilityQueueMode = true;
      checkKnightEffects(tName, f.name);
      abilityQueueMode = false;
      abilityQueue.forEach(item => preRollCallouts.push([item.name, item.color, item.desc, item.team]));
      abilityQueue = _savedAscendAQ;
    }
  });

  // Nick & Knack (409) — Knick Knack: steal 1 resource → +1 HP + 2 Burn
  B.nickKnackDecided = { red: false, blue: false };

  // Chow (414) — Secret Ingredient: reset decided flag only, NOT chowExtraDie
  // chowExtraDie persists until consumed in the dice count section (lines ~8207-8208)
  // Resetting it here would kill the bonus before the roll uses it
  if (!B.chowExtraDie) B.chowExtraDie = { red: 0, blue: 0 };
  B.chowDecided = { red: false, blue: false };

  // Zork (463) — Stoke: reset decided flag, zorkExtraDie persists until consumed
  if (!B.zorkExtraDie) B.zorkExtraDie = { red: 0, blue: 0 };
  B.zorkDecided = { red: false, blue: false };

  // Miyoshi (454) — Bonzai!: sacrifice HP for dice
  // bonzaiDecided and bonzaiBtnDice are set by the pre-roll button (useBonzaiButton)
  // Do NOT reset here — they persist from button click through to dice consumption
  if (!B.bonzaiExtraDie) B.bonzaiExtraDie = { red: 0, blue: 0 };
  if (!B.bonzaiBtnDice) B.bonzaiBtnDice = { red: 0, blue: 0 };
  if (!B.bonzaiDecided) B.bonzaiDecided = { red: false, blue: false };

  // Castle Gardener (442) — Cultivate: reset per round
  B.cultivateDecided = { red: false, blue: false };

  // Forest Spirit (446) — Hex: NOT reset here — set by doBurnPlace, consumed at lines 8676-8687
  if (!B.hexDieRemoval) B.hexDieRemoval = { red: 0, blue: 0 };

  // Aunt Susan (309)
  B.auntSusanBonus = { red: false, blue: false };
  B.auntSusanHealBonus = { red: false, blue: false };
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const tName = team === B.red ? 'red' : 'blue';
    if (f.id === 309 && B.committed[tName].auntSusan > 0) {
      B.auntSusanBonus[tName] = B.committed[tName].auntSusan;
      log(`<span class="log-ability">${f.name}</span> — Harvest Dance! Spent ${B.committed[tName].auntSusan} Healing Seed${B.committed[tName].auntSusan>1?'s':''} for +${B.committed[tName].auntSusan * 2} damage!`);
    }
    if (f.id === 309 && B.committed[tName].auntSusanHeal > 0) {
      B.auntSusanHealBonus[tName] = B.committed[tName].auntSusanHeal;
      log(`<span class="log-ability">${f.name}</span> — Harvest Dance! Spent ${B.committed[tName].auntSusanHeal} Healing Seed${B.committed[tName].auntSusanHeal>1?'s':''} for +${B.committed[tName].auntSusanHeal * 2} HP!`);
    }
  });

  // Finn (204) — Flame Blade: opt-in forge button (see useFinnFlameBlade), no auto-conversion

  // Zippa (423) — Glimmer: REWORKED — now passive +1 damage per Healing Seed held (applied in damage calc section)

  // ========================================
  // PHASE 2: COMPUTE DICE COUNTS (rolled later per-click)
  // ========================================
  let redCount = 3, blueCount = 3;
  // Doug (63) Caution duel-phase swap promised the incoming ghost +1 die — apply now.
  if (B.dougCautionDieBonus && B.dougCautionDieBonus.red) { redCount++; B.dougCautionDieBonus.red = false; }
  if (B.dougCautionDieBonus && B.dougCautionDieBonus.blue) { blueCount++; B.dougCautionDieBonus.blue = false; }

  // Knight Light Retribution — bonus dice from opponent abilities
  // Guard: only apply if KL (402) is still the active ghost on that team — if KL was KO'd
  // mid-round the stored dice are silently discarded (not inherited by the replacement ghost).
  if (B.retributionDice) {
    if (B.retributionDice.red > 0) {
      const klRed = active(B.red);
      if (klRed.id === 402 && !klRed.ko) {
        redCount += B.retributionDice.red;
        log(`<span class="log-ability">Knight Light</span> — Retribution! <span class="log-ms">+${B.retributionDice.red} bonus dice!</span>`);
      }
    }
    if (B.retributionDice.blue > 0) {
      const klBlue = active(B.blue);
      if (klBlue.id === 402 && !klBlue.ko) {
        blueCount += B.retributionDice.blue;
        log(`<span class="log-ability">Knight Light</span> — Retribution! <span class="log-ms">+${B.retributionDice.blue} bonus dice!</span>`);
      }
    }
    B.retributionDice = { red: 0, blue: 0 };
  }

  // Cameron (25) — Unstoppable Force: bonus dice from opponent special usage
  if (B.cameronBonusDice) {
    ['red', 'blue'].forEach(tName => {
      if (B.cameronBonusDice[tName] > 0) {
        const camTeam = B[tName];
        const camAlive = camTeam.ghosts.some(g => g.id === 25 && !g.ko);
        if (camAlive) {
          if (tName === 'red') redCount += B.cameronBonusDice.red;
          else blueCount += B.cameronBonusDice.blue;
          const camG = camTeam.ghosts.find(g => g.id === 25 && !g.ko);
          const loc = camTeam.ghosts[camTeam.activeIdx]?.id === 25 ? 'active' : 'sideline';
          preRollCallouts.push(['UNSTOPPABLE FORCE!', 'var(--common)', `${camG.name} (${loc}) — Opponent used specials! +${B.cameronBonusDice[tName]} bonus dice!`, tName]);
          log(`<span class="log-ability">${camG.name}</span> — Unstoppable Force! <span class="log-ms">+${B.cameronBonusDice[tName]} bonus dice</span> from opponent specials!`);
        }
        B.cameronBonusDice[tName] = 0;
      }
    });
  }

  // Bouril (201) — first roll override
  let hankOverride = { red: false, blue: false };
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const tName = team === B.red ? 'red' : 'blue';
    if (f.id === 201 && f.hankFirstRoll) {
      hankOverride[tName] = true;
      f.hankFirstRoll = false;
    }
  });

  // Maximo (302) — first roll 1 die
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const tName = team === B.red ? 'red' : 'blue';
    if (f.id === 302 && f.maximoFirstRoll) {
      if (tName === 'red') redCount = 1;
      else blueCount = 1;
      f.maximoFirstRoll = false;
      preRollCallouts.push(['NAP!', 'var(--common)', `${f.name} — still napping, rolling only 1 die!`, tName]);
      log(`<span class="log-ability">${f.name}</span> is still napping — rolling only 1 die!`);
    }
  });

  // Redd (98) — Notorious: +2 dice on first roll after entry
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const tName = team === B.red ? 'red' : 'blue';
    if (f.id === 98 && f.reddFirstRoll) {
      if (tName === 'red') redCount += 2;
      else blueCount += 2;
      f.reddFirstRoll = false;
      log(`<span class="log-ability">${f.name}</span> — Notorious! Rolling with +2 bonus dice!`);
    }
  });

  // Dallas (60) — Quick Draw: steal 1 enemy die for first 2 rolls after entering from sideline
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const tName = team === B.red ? 'red' : 'blue';
    const enemyTName = tName === 'red' ? 'blue' : 'red';
    if (f.id === 60 && !f.ko && f.dallasQuickDraw > 0) {
      if (enemyTName === 'red') redCount = Math.max(1, redCount - 1);
      else blueCount = Math.max(1, blueCount - 1);
      if (tName === 'red') redCount += 1; else blueCount += 1; // steal: transfer the die to Dallas
      f.dallasQuickDraw--;
      const rollsLeft = f.dallasQuickDraw;
      preRollCallouts.push(['QUICK DRAW!', 'var(--uncommon)', `${f.name} — stole 1 die from opponent! (${rollsLeft} roll${rollsLeft !== 1 ? 's' : ''} of Quick Draw left)`, team === B.red ? 'red' : 'blue']);
      log(`<span class="log-ability">${f.name}</span> — Quick Draw! Opponent rolls 1 fewer die. (${rollsLeft} uses left)`);
    }
  });

  // Timber (210) — Howl: opponent chooses discard 2 specials OR -1 die
  // Choice is resolved via modal before dice are stored. timberDieReduction tracks result.
  B.timberDieReduction = { red: false, blue: false };
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    if (f.id === 210 && !f.ko) {
      const oppTeamName = team === B.red ? 'blue' : 'red';
      const oppTeam = team === B.red ? B.blue : B.red;
      // Dylan (301) Scarecrow / Piper (107) Slick Coat: negate all enemy before-rolling effects
      if (dylanNegates(oppTeam)) {
        const oppLabel = oppTeamName.charAt(0).toUpperCase() + oppTeamName.slice(1);
        preRollCallouts.push(['BLOCKED!', 'var(--text2)', `${oppLabel} — Scarecrow/Slick Coat negates Timber's Howl!`, oppTeamName]);
        log(`<span class="log-ability">${oppLabel}</span> — Dylan/Piper negates Timber's Howl!`);
        B.piperBlockedThisRound[team === B.red ? 'red' : 'blue'] = true; // v640: Slick Coat gate
        return;
      }
      const r = oppTeam.resources;
      const totalSpecials = (r.ice||0) + (r.fire||0) + (r.surge||0) + (r.moonstone||0) + (r.healingSeed||0) + (r.luckyStone||0);
      if (totalSpecials < 2) {
        // Not enough specials — forced to lose die
        B.timberDieReduction[oppTeamName] = true;
        if (oppTeamName === 'red') redCount = Math.max(1, redCount - 1);
        else blueCount = Math.max(1, blueCount - 1);
        const oppLabel = oppTeamName.charAt(0).toUpperCase() + oppTeamName.slice(1);
        preRollCallouts.push(['HOWL!', 'var(--legendary)', `${oppLabel} has no specials — forced to roll 1 fewer die!`, team === B.red ? 'red' : 'blue']);
        log(`<span class="log-ability">${oppLabel}</span> has no specials — forced to roll 1 fewer die under Timber's Howl!`);
        // Knight reactions to forced Howl — collect via temporary queue then splice into preRollCallouts
        const timberTeamName = team === B.red ? 'red' : 'blue';
        const _savedKQ = abilityQueue;
        abilityQueue = [];
        abilityQueueMode = true;
        checkKnightEffects(timberTeamName, f.name);
        abilityQueueMode = false;
        abilityQueue.forEach(item => preRollCallouts.push([item.name, item.color, item.desc, item.team]));
        abilityQueue = _savedKQ;
      } else {
        // Opponent has resources — queue the choice modal
        const timberTeamName = team === B.red ? 'red' : 'blue';
        B.timberPending = { team: oppTeam, oppTeamName, timberTeam: timberTeamName, redCount, blueCount };
      }
    }
  });

  // Ryder (456) — Toll: opponent chooses take 1 damage or give Ryder +1 Sacred Fire
  // Choice resolved via modal before dice are rolled. Negated by Dylan/Piper.
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    if (f.id === 456 && !f.ko) {
      const oppTeamName = team === B.red ? 'blue' : 'red';
      const oppTeam = team === B.red ? B.blue : B.red;
      if (dylanNegates(oppTeam)) {
        const oppLabel = oppTeamName.charAt(0).toUpperCase() + oppTeamName.slice(1);
        preRollCallouts.push(['BLOCKED!', 'var(--text2)', `${oppLabel} — Scarecrow/Slick Coat negates Ryder's Toll!`, oppTeamName]);
        log(`<span class="log-ability">${oppLabel}</span> — Dylan/Piper negates Ryder's Toll!`);
        B.piperBlockedThisRound[team === B.red ? 'red' : 'blue'] = true;
        return;
      }
      const riderTeamName = team === B.red ? 'red' : 'blue';
      B.riderPending = { team: oppTeam, oppTeamName, riderTeam: riderTeamName };
    }
  });

  // Piper (107) — Slick Coat: -1 enemy die IF an enemy auto-fire before-roll ability was
  // actually negated this round. v640 (Wyatt 2026-04-11): reactive, not unconditional.
  // Previously Slick Coat fired the -1 die every single round whenever Piper was active,
  // even when the enemy had nothing to negate — Wyatt's playtest observation.
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const tName = team === B.red ? 'red' : 'blue';
    const oppTeamName = tName === 'red' ? 'blue' : 'red';
    if (f.id === 107 && !f.ko && B.piperBlockedThisRound[oppTeamName]) {
      if (oppTeamName === 'red') redCount = Math.max(1, redCount - 1);
      else blueCount = Math.max(1, blueCount - 1);
      preRollCallouts.push(['SLICK COAT!', 'var(--ghost-rare)', `${f.name} — negation + enemy rolls 1 fewer die!`, team === B.red ? 'red' : 'blue']);
      log(`<span class="log-ability">${f.name}</span> — Slick Coat! Negated enemy effect + -1 enemy die.`);
    }
  });

  // Cyboo (100) — Spark: while on the sideline, active ghost gains +1 die if it has < 3 HP
  // Negated by Cornelius (45) — Antidote: if the enemy team has Cornelius on their sideline, Spark is blocked.
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const tName = team === B.red ? 'red' : 'blue';
    const enemyTeamObj = team === B.red ? B.blue : B.red;
    const corneliusBlocksSpark = hasSideline(enemyTeamObj, 45);
    if (!f.ko && f.hp < 3 && hasSideline(team, 100)) {
      if (corneliusBlocksSpark) {
        const cornGhost = getSidelineGhost(enemyTeamObj, 45);
        log(`<span class="log-ability">Cornelius</span> (sideline) — Antidote! <span class="log-ability">Cyboo</span> Spark blocked for ${f.name}!`);
        const blockedByName = cornGhost ? cornGhost.name : 'Cornelius';
        preRollCallouts.push(['ANTIDOTE!', 'var(--uncommon)', `${blockedByName} blocks Cyboo's Spark on ${f.name}!`, tName === 'red' ? 'blue' : 'red']);
      } else {
        if (tName === 'red') redCount += 1;
        else blueCount += 1;
        const cybGhost = getSidelineGhost(team, 100);
        preRollCallouts.push(['SPARK!', 'var(--ghost-rare)', `${cybGhost ? cybGhost.name : 'Cyboo'} (sideline) — ${f.name} is at ${f.hp} HP! +1 bonus die!`, tName]);
        log(`<span class="log-ability">Cyboo</span> (sideline) — Spark! ${f.name} at ${f.hp} HP → +1 die!`);
      }
    }
  });

  // Explorer Jeff (455) — Treasure Hunter: sideline & in play, if holding 3+ different specials, +1 die
  // Negated by Cornelius (45) — Antidote (only when on sideline)
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const tName = team === B.red ? 'red' : 'blue';
    const enemyTeamObj = team === B.red ? B.blue : B.red;
    const ejOnSideline = hasSideline(team, 455);
    const ejActive = f.id === 455 && !f.ko;
    if (!f.ko && (ejOnSideline || ejActive)) {
      const res = B[tName].resources;
      const types = ['moonstone','ice','fire','surge','healingSeed','luckyStone','firefly','burn'].filter(r => (res[r] || 0) > 0).length;
      if (types >= 3) {
        // Cornelius only blocks sideline abilities, not in-play
        if (ejOnSideline && hasSideline(enemyTeamObj, 45)) {
          const cornGhost = getSidelineGhost(enemyTeamObj, 45);
          preRollCallouts.push(['ANTIDOTE!', 'var(--uncommon)', `${cornGhost ? cornGhost.name : 'Cornelius'} blocks Explorer Jeff's Treasure Hunter!`, tName === 'red' ? 'blue' : 'red']);
          log(`<span class="log-ability">Cornelius</span> — Antidote! Explorer Jeff Treasure Hunter blocked.`);
        } else {
          if (tName === 'red') redCount += 1;
          else blueCount += 1;
          const loc = ejActive ? 'in play' : 'sideline';
          preRollCallouts.push(['TREASURE HUNTER!', 'var(--uncommon)', `Explorer Jeff (${loc}) — ${types} specials held! +1 die!`, tName]);
          log(`<span class="log-ability">Explorer Jeff</span> (${loc}) — Treasure Hunter! ${types} different specials → +1 die!`);
        }
      }
    }
  });

  // Shoo (13) — Alpine Air: while on the sideline, the active ghost gains +2 HP when HP < 4. Once per ghost.
  // Negated by Cornelius (45) — Antidote: if the enemy team has Cornelius on sideline, Alpine Air is blocked (once-per-ghost use NOT consumed).
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const enemyTeamObj = team === B.red ? B.blue : B.red;
    if (!f.ko && f.hp < 4 && hasSideline(team, 13) && !f.shooAlpineUsed) {
      const shooGhost = getSidelineGhost(team, 13);
      // Cornelius (45) — Antidote: block before consuming the once-per-ghost use
      if (hasSideline(enemyTeamObj, 45)) {
        const cornGhostShoo = getSidelineGhost(enemyTeamObj, 45);
        preRollCallouts.push(['ANTIDOTE!', 'var(--uncommon)', `${cornGhostShoo ? cornGhostShoo.name : 'Cornelius'} (sideline) — blocks Shoo's Alpine Air on ${f.name}!`, team === B.red ? 'blue' : 'red']);
        log(`<span class="log-ability">Cornelius</span> (sideline) — Antidote! Shoo Alpine Air blocked for ${f.name}.`);
      } else {
        const shooHpBefore = f.hp;
        f.shooAlpineUsed = true;
        // Mr Filbert (59) — Mask Merchant: flip heal to damage when Filbert is on the enemy sideline
        if (hasSideline(enemyTeamObj, 59)) {
          f.hp = Math.max(0, f.hp - 2);
          if (f.hp <= 0) { f.hp = 0; f.ko = true; f.killedBy = 59; }
          preRollCallouts.push(['MASK MERCHANT!', 'var(--uncommon)', `Mr Filbert — Alpine Air cursed! ${f.name} takes 2 damage! (${shooHpBefore}→${f.hp} HP)`, team === B.red ? 'blue' : 'red']);
          log(`<span class="log-ability">Mr Filbert</span> — Mask Merchant! Alpine Air flipped to damage. ${f.name} ${shooHpBefore} → ${f.hp} HP.`);
        } else {
          f.hp += 2;
          const overShoo = f.hp > f.maxHp;
          preRollCallouts.push(['ALPINE AIR!', 'var(--common)', `${shooGhost ? shooGhost.name : 'Shoo'} (sideline) — ${f.name} below 4 HP! +2 HP! (${shooHpBefore}→${f.hp}/${f.maxHp}${overShoo ? ' · overclocked!' : ''})`, team === B.red ? 'red' : 'blue']);
          log(`<span class="log-ability">Shoo</span> (sideline) — Alpine Air! ${f.name} at ${shooHpBefore} HP → +2 HP (${f.hp}/${f.maxHp}${overShoo ? ' overclocked!' : ''}). Used!`);
        }
      }
    }
  });

  // Needle (21) — Big Bro: while on the sideline, if Buttons (ID 8) is the active ghost, +1 die
  // Negated by Cornelius (45) — Antidote: if the enemy team has Cornelius on their sideline, Big Bro is blocked.
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const tName = team === B.red ? 'red' : 'blue';
    const enemyTeamObjNeedle = team === B.red ? B.blue : B.red;
    if (!f.ko && f.id === 8 && hasSideline(team, 21)) {
      if (hasSideline(enemyTeamObjNeedle, 45)) {
        const cornGhostNeedle = getSidelineGhost(enemyTeamObjNeedle, 45);
        preRollCallouts.push(['ANTIDOTE!', 'var(--uncommon)', `${cornGhostNeedle ? cornGhostNeedle.name : 'Cornelius'} (sideline) — blocks Needle's Big Bro on ${f.name}!`, tName === 'red' ? 'blue' : 'red']);
        log(`<span class="log-ability">Cornelius</span> (sideline) — Antidote! Needle Big Bro blocked for ${f.name}.`);
      } else {
        if (tName === 'red') redCount += 1;
        else blueCount += 1;
        const needleGhost = getSidelineGhost(team, 21);
        preRollCallouts.push(['BIG BRO!', 'var(--common)', `${needleGhost ? needleGhost.name : 'Needle'} (sideline) — ${f.name} is in play! +1 bonus die!`, tName]);
        log(`<span class="log-ability">Needle</span> (sideline) — Big Bro! ${f.name} is in play → +1 die!`);
      }
    }
  });

  // Harrison extra die
  if (B.harrisonExtraDie.red) redCount += B.harrisonExtraDie.red;
  if (B.harrisonExtraDie.blue) blueCount += B.harrisonExtraDie.blue;

  // Chow (414) — Secret Ingredient: +2 dice from discarded seed, then consume
  if (B.chowExtraDie && B.chowExtraDie.red > 0) { redCount += B.chowExtraDie.red; B.chowExtraDie.red = 0; }
  if (B.chowExtraDie && B.chowExtraDie.blue > 0) { blueCount += B.chowExtraDie.blue; B.chowExtraDie.blue = 0; }

  // Miyoshi (454) — Bonzai!: +5 dice from pre-roll button click
  // Dylan (301) / Piper (107) negate Bonzai — refund the 4 HP sacrifice
  ['red', 'blue'].forEach(tName => {
    if (B.bonzaiBtnDice && B.bonzaiBtnDice[tName] > 0) {
      const team = tName === 'red' ? B.red : B.blue;
      const enemyTeam = tName === 'red' ? B.blue : B.red;
      const f = active(team);
      if (dylanNegates(enemyTeam)) {
        // Negate: refund HP and cancel dice
        if (f && f.id === 454 && !f.ko) {
          f.hp += 4;
        } else if (f && f.id === 454 && f.ko && f.killedBy === -1) {
          // Bonzai self-KO — revive
          f.ko = false; f.killedBy = null; f.hp = 4;
        }
        const enemyTName = tName === 'red' ? 'blue' : 'red';
        preRollCallouts.push(['BLOCKED!', 'var(--text2)', `${enemyTName.charAt(0).toUpperCase() + enemyTName.slice(1)} — Scarecrow/Slick Coat negates Bonzai!`, enemyTName]);
        log(`<span class="log-ability">${enemyTName.charAt(0).toUpperCase() + enemyTName.slice(1)}</span> — Dylan/Piper negates Miyoshi's Bonzai! HP refunded.`);
        B.piperBlockedThisRound[tName] = true;
        B.bonzaiBtnDice[tName] = 0;
      } else {
        if (tName === 'red') redCount += B.bonzaiBtnDice.red; else blueCount += B.bonzaiBtnDice.blue;
        B.bonzaiBtnDice[tName] = 0;
      }
    }
  });

  // Twyla (417) — Lucky Dance: MOVED to doLuckyReroll (v675) — bonus dice + seeds granted live when each stone is spent

  // Gordok (430) — River Terror: +1 die next roll after stealing (consumed after use)
  if (B.gordokDieBonus && B.gordokDieBonus.red > 0) {
    redCount += B.gordokDieBonus.red;
    preRollCallouts.push(['RIVER TERROR!', 'var(--rare)', `Gordok — stolen resources! +${B.gordokDieBonus.red} bonus die!`, 'red']);
    log(`<span class="log-ability">Gordok</span> — River Terror! +${B.gordokDieBonus.red} bonus die this roll.`);
    B.gordokDieBonus.red = 0;
  }
  if (B.gordokDieBonus && B.gordokDieBonus.blue > 0) {
    blueCount += B.gordokDieBonus.blue;
    preRollCallouts.push(['RIVER TERROR!', 'var(--rare)', `Gordok — stolen resources! +${B.gordokDieBonus.blue} bonus die!`, 'blue']);
    log(`<span class="log-ability">Gordok</span> — River Terror! +${B.gordokDieBonus.blue} bonus die this roll.`);
    B.gordokDieBonus.blue = 0;
  }

  // Foreman (451) — Blueprint: +1 die from previous win (consumed after use)
  if (B.foremanDieBonus && B.foremanDieBonus.red > 0) {
    redCount += B.foremanDieBonus.red;
    preRollCallouts.push(['BLUEPRINT!', 'var(--rare)', `Foreman — Win bonus! +${B.foremanDieBonus.red} die!`, 'red']);
    log(`<span class="log-ability">Foreman</span> — Blueprint! +${B.foremanDieBonus.red} bonus die this roll.`);
    B.foremanDieBonus.red = 0;
  }
  if (B.foremanDieBonus && B.foremanDieBonus.blue > 0) {
    blueCount += B.foremanDieBonus.blue;
    preRollCallouts.push(['BLUEPRINT!', 'var(--rare)', `Foreman — Win bonus! +${B.foremanDieBonus.blue} die!`, 'blue']);
    log(`<span class="log-ability">Foreman</span> — Blueprint! +${B.foremanDieBonus.blue} bonus die this roll.`);
    B.foremanDieBonus.blue = 0;
  }

  // Zork (463) — Stoke: consume committed dice from doZorkChoice
  if (B.zorkExtraDie && B.zorkExtraDie.red > 0) { redCount += B.zorkExtraDie.red; B.zorkExtraDie.red = 0; }
  if (B.zorkExtraDie && B.zorkExtraDie.blue > 0) { blueCount += B.zorkExtraDie.blue; B.zorkExtraDie.blue = 0; }

  // Flame Blade item: when swinging, +1 die
  if (B.flameBladeSwing && B.flameBladeSwing.red) {
    redCount += 1;
    preRollCallouts.push(['FLAME BLADE!', 'var(--rare)', `Flame Blade swinging — +1 die this roll!`, 'red']);
    log(`<span class="log-ability">Flame Blade</span> — swinging! <span class="log-ms">+1 die</span> this roll.`);
  }
  if (B.flameBladeSwing && B.flameBladeSwing.blue) {
    blueCount += 1;
    preRollCallouts.push(['FLAME BLADE!', 'var(--rare)', `Flame Blade swinging — +1 die this roll!`, 'blue']);
    log(`<span class="log-ability">Flame Blade</span> — swinging! <span class="log-ms">+1 die</span> this roll.`);
  }

  // Young Cap (429) — Energize: +1 die per Healing Seed spent this pre-roll
  const ycRed = active(B.red);
  if (ycRed && ycRed.id === 429 && !ycRed.ko && ycRed.youngCapDieBonus > 0) {
    redCount += ycRed.youngCapDieBonus;
    ycRed.youngCapDieBonus = 0;
  }
  const ycBlue = active(B.blue);
  if (ycBlue && ycBlue.id === 429 && !ycBlue.ko && ycBlue.youngCapDieBonus > 0) {
    blueCount += ycBlue.youngCapDieBonus;
    ycBlue.youngCapDieBonus = 0;
  }

  // Kairan (68) — Let's Dance: +1 die from previous round's doubles bonus
  // Guard: only apply the bonus if Kairan is STILL the active ghost — die is personal to Kairan,
  // not the team. If Kairan was KO'd or swapped since earning the bonus, the die is lost.
  if (B.letsDanceBonus && B.letsDanceBonus.red > 0) {
    if (active(B.red).id === 68 && !active(B.red).ko) {
      redCount += B.letsDanceBonus.red;
      preRollCallouts.push(["LET'S DANCE!", 'var(--rare)', `${active(B.red).name} — Last round's doubles! +${B.letsDanceBonus.red} bonus die!`, 'red']);
      log(`<span class="log-ability">${active(B.red).name}</span> — Let's Dance! +${B.letsDanceBonus.red} bonus die from last doubles!`);
    }
    B.letsDanceBonus.red = 0;
  }
  if (B.letsDanceBonus && B.letsDanceBonus.blue > 0) {
    if (active(B.blue).id === 68 && !active(B.blue).ko) {
      blueCount += B.letsDanceBonus.blue;
      preRollCallouts.push(["LET'S DANCE!", 'var(--rare)', `${active(B.blue).name} — Last round's doubles! +${B.letsDanceBonus.blue} bonus die!`, 'blue']);
      log(`<span class="log-ability">${active(B.blue).name}</span> — Let's Dance! +${B.letsDanceBonus.blue} bonus die from last doubles!`);
    }
    B.letsDanceBonus.blue = 0;
  }

  // Winston (15) — Scheme: +2 dice from last round's win
  if (B.winstonDiceBonus && B.winstonDiceBonus.red > 0) {
    if (active(B.red).id === 15 && !active(B.red).ko) {
      redCount += B.winstonDiceBonus.red;
      preRollCallouts.push(['SCHEME!', 'var(--common)', `Winston — +${B.winstonDiceBonus.red} bonus dice!`, 'red']);
      log(`<span class="log-ability">Winston</span> — Scheme! +${B.winstonDiceBonus.red} bonus dice from last win!`);
    }
    B.winstonDiceBonus.red = 0;
  }
  if (B.winstonDiceBonus && B.winstonDiceBonus.blue > 0) {
    if (active(B.blue).id === 15 && !active(B.blue).ko) {
      blueCount += B.winstonDiceBonus.blue;
      preRollCallouts.push(['SCHEME!', 'var(--common)', `Winston — +${B.winstonDiceBonus.blue} bonus dice!`, 'blue']);
      log(`<span class="log-ability">Winston</span> — Scheme! +${B.winstonDiceBonus.blue} bonus dice from last win!`);
    }
    B.winstonDiceBonus.blue = 0;
  }

  // Lucas (433) — Kindling: +1 die next roll after Miracle resurrection (consumed after use)
  if (B.lucasKindlingBonus && B.lucasKindlingBonus.red > 0) {
    redCount += B.lucasKindlingBonus.red;
    preRollCallouts.push(['KINDLING!', 'var(--rare)', `Lucas — Kindling! +${B.lucasKindlingBonus.red} bonus die!`, 'red']);
    log(`<span class="log-ability">Lucas</span> — Kindling! +${B.lucasKindlingBonus.red} bonus die this roll.`);
    B.lucasKindlingBonus.red = 0;
  }
  if (B.lucasKindlingBonus && B.lucasKindlingBonus.blue > 0) {
    blueCount += B.lucasKindlingBonus.blue;
    preRollCallouts.push(['KINDLING!', 'var(--rare)', `Lucas — Kindling! +${B.lucasKindlingBonus.blue} bonus die!`, 'blue']);
    log(`<span class="log-ability">Lucas</span> — Kindling! +${B.lucasKindlingBonus.blue} bonus die this roll.`);
    B.lucasKindlingBonus.blue = 0;
  }

  // Haywire (78) — Wild Chords: permanent +1 die bonus (awarded once per game on triples, always applied)
  if (B.haywireBonus && B.haywireBonus.red > 0) redCount += B.haywireBonus.red;
  if (B.haywireBonus && B.haywireBonus.blue > 0) blueCount += B.haywireBonus.blue;

  // Pip (418) — Toasted: permanent die removal applied to opponent
  if (B.pipDieRemoval && B.pipDieRemoval.red > 0) redCount = Math.max(1, redCount - B.pipDieRemoval.red);
  if (B.pipDieRemoval && B.pipDieRemoval.blue > 0) blueCount = Math.max(1, blueCount - B.pipDieRemoval.blue);

  // Mable Stadango (446) — Hex: consume die removal from Burn spend (applied to opponent's count)
  // FIX: callout name corrected from "Forest Spirit" to "Mable Stadango"
  if (B.hexDieRemoval && B.hexDieRemoval.red > 0) {
    redCount = Math.max(1, redCount - B.hexDieRemoval.red);
    preRollCallouts.push(['HEX!', 'var(--uncommon)', `Mable Stadango — Hex! Red loses ${B.hexDieRemoval.red} die this roll!`, 'blue']);
    log(`<span class="log-ability">Mable Stadango</span> — Hex! <span class="log-dmg">Red loses ${B.hexDieRemoval.red} die this roll!</span>`);
    B.hexDieRemoval.red = 0;
  }
  if (B.hexDieRemoval && B.hexDieRemoval.blue > 0) {
    blueCount = Math.max(1, blueCount - B.hexDieRemoval.blue);
    preRollCallouts.push(['HEX!', 'var(--uncommon)', `Mable Stadango — Hex! Blue loses ${B.hexDieRemoval.blue} die this roll!`, 'red']);
    log(`<span class="log-ability">Mable Stadango</span> — Hex! <span class="log-dmg">Blue loses ${B.hexDieRemoval.blue} die this roll!</span>`);
    B.hexDieRemoval.blue = 0;
  }

  // Professor Hawking (447) — Wisdom: +2 dice while holding a Moonstone (not consumed)
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const tName = team === B.red ? 'red' : 'blue';
    if (f.id === 447 && !f.ko && team.resources.moonstone > 0) {
      if (tName === 'red') redCount += 2; else blueCount += 2;
      preRollCallouts.push(['WISDOM!', 'var(--rare)', `${f.name} — Holding Moonstone! +2 dice!`, tName]);
      log(`<span class="log-ability">${f.name}</span> — Wisdom! Holding <span class="log-ms">Moonstone</span> → +2 dice!`);
    }
  });

  // Willow (435) — Joy of Painting: Sideline & In Play: +1 die if you lost the last roll
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const tNameW = team === B.red ? 'red' : 'blue';
    const enemyName = tNameW === 'red' ? 'blue' : 'red';
    const enemy = B[enemyName];
    const hasWillowActive = f.id === 435 && !f.ko;
    const hasWillowSideline = hasSideline(team, 435);

    // Cornelius (45) on enemy sideline negates Willow's sideline effect (not active)
    if (hasWillowSideline && !hasWillowActive && hasSideline(enemy, 45)) {
      if (B.willowLostLast[tNameW]) {
        const cornG = getSidelineGhost(enemy, 45);
        preRollCallouts.push(['ANTIDOTE!', 'var(--uncommon)', `${cornG ? cornG.name : 'Cornelius'} blocks Willow's Joy of Painting!`, enemyName]);
        log(`<span class="log-ability">Cornelius</span> (sideline) — Antidote! Willow Joy of Painting blocked!`);
      }
      // Skip — Cornelius negates
    } else if ((hasWillowActive || hasWillowSideline) && B.willowLostLast[tNameW]) {
      if (tNameW === 'red') redCount++; else blueCount++;
      const wName = hasWillowActive ? f.name : (getSidelineGhost(team, 435) || {}).name || 'Willow';
      const wLabel = hasWillowActive ? '' : ' (sideline)';
      preRollCallouts.push(['JOY OF PAINTING!', 'var(--ghost-rare)', `${wName}${wLabel} — Lost last roll! +1 die!`, tNameW]);
      log(`<span class="log-ability">${wName}${wLabel}</span> — Joy of Painting! Lost last roll → +1 die!`);
      // Knight Terror (401) / Knight Light (402) react to this ability
      checkKnightEffects(tNameW, wName);
    }
  });

  // Dream Cat (28) — Jinx: consume last round's both-doubles bonus
  if (B.dreamCatBonus && B.dreamCatBonus.red > 0) {
    const dcRed = active(B.red);
    redCount += B.dreamCatBonus.red;
    if (dcRed && dcRed.id === 28 && !dcRed.ko) {
      preRollCallouts.push(['JINX!', 'var(--common)', `${dcRed.name} — Both rolled doubles! +${B.dreamCatBonus.red} bonus die!`, 'red']);
      log(`<span class="log-ability">${dcRed.name}</span> — Jinx! Both doubles → +${B.dreamCatBonus.red} bonus die this round.`);
    }
    B.dreamCatBonus.red = 0;
  }
  if (B.dreamCatBonus && B.dreamCatBonus.blue > 0) {
    const dcBlue = active(B.blue);
    blueCount += B.dreamCatBonus.blue;
    if (dcBlue && dcBlue.id === 28 && !dcBlue.ko) {
      preRollCallouts.push(['JINX!', 'var(--common)', `${dcBlue.name} — Both rolled doubles! +${B.dreamCatBonus.blue} bonus die!`, 'blue']);
      log(`<span class="log-ability">${dcBlue.name}</span> — Jinx! Both doubles → +${B.dreamCatBonus.blue} bonus die this round.`);
    }
    B.dreamCatBonus.blue = 0;
  }

  // Nick & Knack (409) — Knick Knack: dice bonus removed (ability is pre-roll steal now)

  // Zach (87) — Craftsman: while on sideline, Guard Thomas gets +1 die each turn
  // Negated by Cornelius (45) — Antidote: if the enemy team has Cornelius on their sideline, die bonus is blocked.
  ['red', 'blue'].forEach(tNameZ => {
    const teamZ = B[tNameZ];
    const fZ = active(teamZ);
    const enemyTeamObjZ = teamZ === B.red ? B.blue : B.red;
    if (fZ.id === 41 && !fZ.ko && hasSideline(teamZ, 87)) {
      if (hasSideline(enemyTeamObjZ, 45)) {
        const cornGhostZ = getSidelineGhost(enemyTeamObjZ, 45);
        preRollCallouts.push(['ANTIDOTE!', 'var(--uncommon)', `${cornGhostZ ? cornGhostZ.name : 'Cornelius'} blocks Zach's Craftsman die bonus!`, tNameZ === 'red' ? 'blue' : 'red']);
        log(`<span class="log-ability">Cornelius</span> (sideline) — Antidote! Zach Craftsman die bonus blocked for ${fZ.name}.`);
      } else {
        if (tNameZ === 'red') redCount++; else blueCount++;
        preRollCallouts.push(['CRAFTSMAN!', 'var(--rare)', `Zach (sideline) — Guard Thomas +1 die!`, tNameZ]);
        log(`<span class="log-ability">Zach</span> (sideline) — Craftsman! Guard Thomas +1 die.`);
      }
    }
  });

  // Wandering Sue (84) — Hidden Weakness: +1 die if enemy has more HP
  ['red', 'blue'].forEach(tNameSue => {
    const fSue = active(B[tNameSue]);
    if (fSue.id === 84 && !fSue.ko) {
      const oppSue = active(B[tNameSue === 'red' ? 'blue' : 'red']);
      if (oppSue && oppSue.hp > fSue.hp) {
        if (tNameSue === 'red') redCount++; else blueCount++;
        preRollCallouts.push(['HIDDEN WEAKNESS!', 'var(--uncommon)', `${fSue.name} — enemy has more HP! +1 die!`, tNameSue]);
        log(`<span class="log-ability">${fSue.name}</span> — Hidden Weakness! Enemy HP (${oppSue.hp}) > Sue (${fSue.hp}) → +1 die!`);
      }
    }
  });

  // Scallywags (19) — Frenzy: consume last round's all-under-4 bonus
  if (B.scallywagsFrenzyBonus && B.scallywagsFrenzyBonus.red > 0) {
    const scRed = active(B.red);
    redCount += B.scallywagsFrenzyBonus.red;
    if (scRed && scRed.id === 19 && !scRed.ko) {
      preRollCallouts.push(['FRENZY!', 'var(--common)', `${scRed.name} — All dice were under 4! +${B.scallywagsFrenzyBonus.red} bonus die!`, 'red']);
      log(`<span class="log-ability">${scRed.name}</span> — Frenzy! All dice under 4 last round → +${B.scallywagsFrenzyBonus.red} bonus die.`);
    }
    B.scallywagsFrenzyBonus.red = 0;
  }
  if (B.scallywagsFrenzyBonus && B.scallywagsFrenzyBonus.blue > 0) {
    const scBlue = active(B.blue);
    blueCount += B.scallywagsFrenzyBonus.blue;
    if (scBlue && scBlue.id === 19 && !scBlue.ko) {
      preRollCallouts.push(['FRENZY!', 'var(--common)', `${scBlue.name} — All dice were under 4! +${B.scallywagsFrenzyBonus.blue} bonus die!`, 'blue']);
      log(`<span class="log-ability">${scBlue.name}</span> — Frenzy! All dice under 4 last round → +${B.scallywagsFrenzyBonus.blue} bonus die.`);
    }
    B.scallywagsFrenzyBonus.blue = 0;
  }

  // Committed Surge: +1 die per surge
  if (B.committed.red.surge > 0) {
    redCount += B.committed.red.surge;
    log(`<span class="log-ability">Red</span> committed <span class="log-ms">${B.committed.red.surge} Surge</span> → +${B.committed.red.surge} dice!`);
    const borisRedG = B.red.ghosts.find(g => g.id === 343 && !g.ko);
    if (borisRedG) {
      const borisRedPre = borisRedG.hp;
      if (hasSideline(B.blue, 59)) {
        // Mr Filbert (59) — Mask Merchant: flip Boris Fortify heal to damage
        borisRedG.hp = Math.max(0, borisRedG.hp - 2);
        if (borisRedG.hp <= 0) { borisRedG.hp = 0; borisRedG.ko = true; borisRedG.killedBy = 59; }
        preRollCallouts.push(['MASK MERCHANT!', 'var(--uncommon)', `Mr Filbert — Fortify cursed! ${borisRedG.name} takes 2 damage! (${borisRedPre}→${borisRedG.hp} HP)`, 'blue']);
        log(`<span class="log-ability">Mr Filbert</span> — Mask Merchant! Boris Fortify flipped to damage. ${borisRedG.name} ${borisRedPre} → ${borisRedG.hp} HP.`);
      } else {
        triggerBorisHook(B.red);
        const oc = borisRedG.hp > borisRedG.maxHp;
        preRollCallouts.push(['FORTIFY!', 'var(--uncommon)', `${borisRedG.name} — Surge spent! +2 HP (${borisRedPre}→${borisRedG.hp}/${borisRedG.maxHp}${oc ? ' · overclocked!' : ''})`, 'red']);
      }
    }
  }
  if (B.committed.blue.surge > 0) {
    blueCount += B.committed.blue.surge;
    log(`<span class="log-ability">Blue</span> committed <span class="log-ms">${B.committed.blue.surge} Surge</span> → +${B.committed.blue.surge} dice!`);
    const borisBlueG = B.blue.ghosts.find(g => g.id === 343 && !g.ko);
    if (borisBlueG) {
      const borisBlueRePre = borisBlueG.hp;
      if (hasSideline(B.red, 59)) {
        // Mr Filbert (59) — Mask Merchant: flip Boris Fortify heal to damage
        borisBlueG.hp = Math.max(0, borisBlueG.hp - 2);
        if (borisBlueG.hp <= 0) { borisBlueG.hp = 0; borisBlueG.ko = true; borisBlueG.killedBy = 59; }
        preRollCallouts.push(['MASK MERCHANT!', 'var(--uncommon)', `Mr Filbert — Fortify cursed! ${borisBlueG.name} takes 2 damage! (${borisBlueRePre}→${borisBlueG.hp} HP)`, 'red']);
        log(`<span class="log-ability">Mr Filbert</span> — Mask Merchant! Boris Fortify flipped to damage. ${borisBlueG.name} ${borisBlueRePre} → ${borisBlueG.hp} HP.`);
      } else {
        triggerBorisHook(B.blue);
        const oc = borisBlueG.hp > borisBlueG.maxHp;
        preRollCallouts.push(['FORTIFY!', 'var(--uncommon)', `${borisBlueG.name} — Surge spent! +2 HP (${borisBlueRePre}→${borisBlueG.hp}/${borisBlueG.maxHp}${oc ? ' · overclocked!' : ''})`, 'blue']);
      }
    }
  }

  // Ice Blade item: when swinging (toggle or committed), +1 die (in addition to post-roll +2 dmg on win)
  if (B.committed.red.zainBlade > 0 || (B.iceBladeSwing && B.iceBladeSwing.red)) {
    if (B.iceBladeForgedPermanent && B.iceBladeForgedPermanent.red) {
      redCount += 1;
      preRollCallouts.push(['ICE BLADE!', 'var(--ghost-rare)', `Ice Blade swinging — +1 die this roll!`, 'red']);
      log(`<span class="log-ability">Ice Blade</span> — swinging! <span class="log-ice">+1 die</span> this roll (and +2 damage on win).`);
    }
  }
  if (B.committed.blue.zainBlade > 0 || (B.iceBladeSwing && B.iceBladeSwing.blue)) {
    if (B.iceBladeForgedPermanent && B.iceBladeForgedPermanent.blue) {
      blueCount += 1;
      preRollCallouts.push(['ICE BLADE!', 'var(--ghost-rare)', `Ice Blade swinging — +1 die this roll!`, 'blue']);
      log(`<span class="log-ability">Ice Blade</span> — swinging! <span class="log-ice">+1 die</span> this roll (and +2 damage on win).`);
    }
  }

  // Katrina (70) — Seeker: before rolling, if Katrina has less HP than the enemy active ghost, gain 1 HP
  // Mr Filbert (59) — Mask Merchant: flip the +1 HP heal to -1 damage when Filbert is on the enemy sideline.
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    if (f.id === 70 && !f.ko) {
      const oppG = team === B.red ? active(B.blue) : active(B.red);
      if (f.hp < oppG.hp) {
        const seekerHpBefore = f.hp;
        const enemyTeamObj = team === B.red ? B.blue : B.red;
        if (hasSideline(enemyTeamObj, 59)) {
          f.hp = Math.max(0, f.hp - 1);
          if (f.hp <= 0) { f.hp = 0; f.ko = true; f.killedBy = 59; }
          preRollCallouts.push(['MASK MERCHANT!', 'var(--uncommon)', `Mr Filbert — Seeker cursed! ${f.name} takes 1 damage! (${seekerHpBefore}→${f.hp} HP)`, team === B.red ? 'blue' : 'red']);
          log(`<span class="log-ability">Mr Filbert</span> — Mask Merchant! Seeker flipped to damage. ${f.name} ${seekerHpBefore} → ${f.hp} HP.`);
        } else {
          f.hp += 1;
          const seekerOver = f.hp > f.maxHp;
          preRollCallouts.push(['SEEKER!', 'var(--rare)', `${f.name} — HP below enemy! +1 HP (${seekerHpBefore}→${f.hp}/${f.maxHp}${seekerOver ? ' · overclocked!' : ''})`, team === B.red ? 'red' : 'blue']);
          log(`<span class="log-ability">${f.name}</span> — Seeker! HP below enemy → +1 HP (${f.hp}/${f.maxHp}${seekerOver ? ' overclocked!' : ''})`);
        }
      }
    }
  });

  // Eli (459) — Steady: before rolling, gain +1 Lucky Stone
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    if (f.id === 459 && !f.ko) {
      const tName = team === B.red ? 'red' : 'blue';
      team.resources.luckyStone = (team.resources.luckyStone || 0) + 1;
      preRollCallouts.push(['STEADY!', 'var(--common)', `${f.name} — +1 Lucky Stone! (${team.resources.luckyStone} total)`, tName]);
      log(`<span class="log-ability">${f.name}</span> — Steady! +1 Lucky Stone (${team.resources.luckyStone} total)`);
      collectKC(tName, f.name);
      // Sandwiches (33) — Dependable: opponent mirrors the Lucky Stone gain
      if (hasOnTeam(opp(team), 33)) {
        const _sandOpp = opp(team);
        _sandOpp.resources.luckyStone = (_sandOpp.resources.luckyStone || 0) + 1;
        preRollCallouts.push(['DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Steady! +1 Lucky Stone! (${_sandOpp.resources.luckyStone} total)`, tName === 'red' ? 'blue' : 'red']);
      }
    }
  });

  // Yawn Eater (464) — Feast: +1 die for each sideline ability on the enemy sideline
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const tName = team === B.red ? 'red' : 'blue';
    if (f.id === 464 && !f.ko) {
      const enemyTeam = opp(team);
      // Count enemy sideline ghosts that have sideline abilities
      const sidelineCount = enemyTeam.ghosts.filter((g, i) => {
        if (i === enemyTeam.activeIdx || g.ko) return false;
        const gd = ghostData(g.id);
        return gd && gd.abilityDesc && (gd.abilityDesc.includes('Sideline') || gd.abilityDesc.includes('sideline'));
      }).length;
      if (sidelineCount > 0) {
        if (tName === 'red') redCount += sidelineCount;
        else blueCount += sidelineCount;
        preRollCallouts.push(['FEAST!', 'var(--uncommon)', `${f.name} — ${sidelineCount} enemy sideline effect${sidelineCount > 1 ? 's' : ''}! +${sidelineCount} dice!`, tName]);
        log(`<span class="log-ability">${f.name}</span> — Feast! ${sidelineCount} enemy sideline effect${sidelineCount > 1 ? 's' : ''} → +${sidelineCount} dice!`);
      }
    }
  });

  // Antoinette (82) — Grace: roll as many dice as your opponent rolls. +1 damage on doubles.
  // Applied last so all other modifiers (Surge, Piper, Redd, etc.) are already baked into counts
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const tName = team === B.red ? 'red' : 'blue';
    if (f.id === 82 && !f.ko) {
      const myCount   = tName === 'red' ? redCount  : blueCount;
      const oppCount  = tName === 'red' ? blueCount : redCount;
      if (oppCount > myCount) {
        if (tName === 'red') redCount  = oppCount;
        else                 blueCount = oppCount;
        preRollCallouts.push(['GRACE!', 'var(--rare)', `${f.name} — matching opponent's ${oppCount} dice!`, tName]);
        log(`<span class="log-ability">${f.name}</span> — Grace! Matching opponent's ${oppCount} dice!`);
      }
    }
  });

  // Outlaw (43) — Thief: consume stolen-die penalty from last round (applied AFTER Grace so it can't be mirrored back)
  [B.red, B.blue].forEach(team => {
    const tName = team === B.red ? 'red' : 'blue';
    if (B.outlawStolenDie && B.outlawStolenDie[tName] > 0) {
      // This team's Outlaw removes an enemy die — decrement enemy count
      // intentional: spec says "remove", not "steal" — no transfer to Outlaw; subtract-only is correct
      const enemyTName = tName === 'red' ? 'blue' : 'red';
      if (enemyTName === 'red') redCount = Math.max(1, redCount - B.outlawStolenDie[tName]);
      else blueCount = Math.max(1, blueCount - B.outlawStolenDie[tName]);
      const outF = active(team);
      const enemyF = active(enemyTName === 'red' ? B.red : B.blue);
      preRollCallouts.push(['THIEF!', 'var(--uncommon)', `${outF.name} — removed 1 die from ${enemyF.name}! They roll 1 fewer die!`, tName]);
      log(`<span class="log-ability">${outF.name}</span> — Thief! ${enemyF.name} rolls 1 fewer die this round!`);
      B.outlawStolenDie[tName] = 0;
    }
  });

  // Suspicious Jeff (61) — Snicker: sideline die-theft from last round's win (stacks with Outlaw)
  // Cornelius (45) Antidote blocks the die theft if on the enemy's sideline.
  [B.red, B.blue].forEach(team => {
    const tName = team === B.red ? 'red' : 'blue';
    if (B.jeffSnicker && B.jeffSnicker[tName] > 0) {
      const enemyTName = tName === 'red' ? 'blue' : 'red';
      const enemyTeamObj = enemyTName === 'red' ? B.red : B.blue;
      const cornBlocksJeff = hasSideline(enemyTeamObj, 45);
      if (cornBlocksJeff) {
        const cornF = getSidelineGhost(enemyTeamObj, 45);
        const cornName = cornF ? cornF.name : 'Cornelius';
        preRollCallouts.push(['ANTIDOTE!', 'var(--uncommon)', `${cornName} neutralizes Suspicious Jeff's Snicker — die theft blocked!`, enemyTName]);
        log(`<span class="log-ability">Cornelius</span> — Antidote! Suspicious Jeff's Snicker die theft blocked!`);
      } else {
        if (enemyTName === 'red') redCount = Math.max(1, redCount - B.jeffSnicker[tName]);
        else blueCount = Math.max(1, blueCount - B.jeffSnicker[tName]);
        if (tName === 'red') redCount += B.jeffSnicker[tName];
        else blueCount += B.jeffSnicker[tName];
        const jeffF = getSidelineGhost(team, 61);
        const enemyF = active(enemyTeamObj);
        const jeffName = jeffF ? jeffF.name : 'Suspicious Jeff';
        preRollCallouts.push(['SNICKER!', 'var(--uncommon)', `${jeffName} (sideline) — Win stole 1 die from ${enemyF ? enemyF.name : 'opponent'}! They roll 1 fewer die!`, tName]);
        log(`<span class="log-ability">${jeffName}</span> — Snicker! ${enemyF ? enemyF.name : 'Opponent'} rolls 1 fewer die this round!`);
      }
      B.jeffSnicker[tName] = 0;
    }
  });

  // Hugo (52) — Wreckage: consume die penalty for attacking Hugo last round (applied after Outlaw so both stack correctly)
  [B.red, B.blue].forEach(team => {
    const tName = team === B.red ? 'red' : 'blue';
    if (B.hugoWreckage && B.hugoWreckage[tName] > 0) {
      // This team attacked Hugo — pay the die cost
      if (tName === 'red') redCount = Math.max(1, redCount - B.hugoWreckage[tName]);
      else blueCount = Math.max(1, blueCount - B.hugoWreckage[tName]);
      const hugoF = active(opp(team)); // Hugo is on the opposing team
      const penF = active(team);
      preRollCallouts.push(['WRECKAGE!', 'var(--uncommon)', `${hugoF ? hugoF.name + ' — Wreckage!' : 'Wreckage!'} ${penF.name} rolls 1 fewer die for attacking Hugo!`, tName === 'red' ? 'blue' : 'red']);
      log(`<span class="log-ability">Hugo</span> — Wreckage! ${penF.name} rolls 1 fewer die this round!`);
      B.hugoWreckage[tName] = 0;
    }
  });

  // Floop (20) — Muck: consume die penalty for rolling doubles last round while Floop was watching (stacks with Outlaw/Jeff/Hugo)
  [B.red, B.blue].forEach(team => {
    const tName = team === B.red ? 'red' : 'blue';
    if (B.floopMuck && B.floopMuck[tName] > 0) {
      // This team rolled doubles last round while Floop was the opponent — pay the die cost
      if (tName === 'red') redCount = Math.max(1, redCount - B.floopMuck[tName]);
      else blueCount = Math.max(1, blueCount - B.floopMuck[tName]);
      const floopF = active(opp(team)); // Floop is on the opposing team
      const penF = active(team);
      preRollCallouts.push(['MUCK!', 'var(--common)', `${floopF ? floopF.name + ' — Muck!' : 'Muck!'} ${penF.name} rolled doubles last round — they lose 1 die!`, tName === 'red' ? 'blue' : 'red']);
      log(`<span class="log-ability">${floopF ? floopF.name : 'Floop'}</span> — Muck! ${penF.name} rolled doubles → 1 fewer die this round.`);
      B.floopMuck[tName] = 0;
    }
  });

  // Marcus (57) — Glacial Pounding: consume bonus dice from last round's big hit (applied last so it can't be stolen by Outlaw)
  // Bonus goes to the PLAYER — whoever is active gets the dice, even if Marcus died from the hit
  [B.red, B.blue].forEach(team => {
    const tName = team === B.red ? 'red' : 'blue';
    if (B.marcusGlacialBonus && B.marcusGlacialBonus[tName] > 0) {
      const curF = active(team);
      if (curF && !curF.ko) {
        const bonus = B.marcusGlacialBonus[tName];
        if (tName === 'red') redCount += bonus;
        else blueCount += bonus;
        preRollCallouts.push(['GLACIAL POUNDING!', 'var(--uncommon)', `Marcus's revenge! ${curF.name} gets +${bonus} bonus dice!`, tName]);
        log(`<span class="log-ability">Marcus</span> — Glacial Pounding! ${curF.name} gets +${bonus} bonus dice from last round's big hit!`);
      }
      B.marcusGlacialBonus[tName] = 0;
    }
  });

  // Logey (26) — Heinous: reduce this team's die count by locked dice from last round
  [B.red, B.blue].forEach(team => {
    const tName = team === B.red ? 'red' : 'blue';
    if (B.logeyLockout && B.logeyLockout[tName] > 0) {
      const locked = B.logeyLockout[tName];
      if (tName === 'red') redCount = Math.max(1, redCount - locked);
      else blueCount = Math.max(1, blueCount - locked);
      const f = active(team);
      const loF = active(opp(team));
      preRollCallouts.push(['HEINOUS!', 'var(--common)', `${f.name} — ${locked} dice locked out by ${loF ? loF.name + "'s" : ''} Heinous! Rolling fewer dice!`, tName === 'red' ? 'blue' : 'red']);
      log(`<span class="log-ability">${f.name}</span> — Heinous lockout! ${locked} dice unavailable this round.`);
      B.logeyLockout[tName] = 0;
    }
  });

  // Sophia (457) — Mask of Night: roll the same number of dice as the enemy ghost
  ['red', 'blue'].forEach(tName => {
    if (B.sophiaMask[tName] === 'night' && B.sophiaMaskActive[tName]) {
      const myCount = tName === 'red' ? redCount : blueCount;
      const oppCount = tName === 'red' ? blueCount : redCount;
      if (myCount !== oppCount) {
        if (tName === 'red') redCount = oppCount;
        else blueCount = oppCount;
        const f = active(B[tName]);
        preRollCallouts.push(['MASK OF NIGHT!', 'var(--rare)', `🌙 Mask of Night — ${f.name} mirrors the enemy! Rolling ${oppCount} dice!`, tName]);
        log(`<span class="log-ability">Mask of Night</span> — ${f.name} rolls ${oppCount} dice (matching opponent)!`);
      }
    }
  });

  // Fredrick (27) — Careful: when Fredrick is active, opponent may only roll up to 3 dice (applied last so it overrides all bonuses)
  [B.red, B.blue].forEach(team => {
    const fredF = active(team);
    if (fredF && fredF.id === 27 && !fredF.ko) {
      const enemyTName = (team === B.red) ? 'blue' : 'red';
      const currentEnemyCount = enemyTName === 'red' ? redCount : blueCount;
      if (currentEnemyCount > 3) {
        if (enemyTName === 'red') redCount = 3;
        else blueCount = 3;
        const enemyF = active(team === B.red ? B.blue : B.red);
        preRollCallouts.push(['CAREFUL!', 'var(--common)', `${fredF.name} — Careful! ${enemyF ? enemyF.name : 'Opponent'} capped at 3 dice!`, enemyTName === 'red' ? 'blue' : 'red']);
        log(`<span class="log-ability">${fredF.name}</span> — Careful! Opponent capped at 3 dice this round.`);
      }
    }
  });

  // Patrick (10) — Stone Form: "Don't roll." Forced LAST so no other modifier restores dice.
  // With 0 dice, classify returns type:'none' which auto-loses to any real roll. The existing
  // Stone Form singles-counter at resolveRound ~8055 still fires: when opponent rolled singles,
  // Patrick negates the damage and deals 3 back; other roll types deal normal damage to Patrick.
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const tName = team === B.red ? 'red' : 'blue';
    if (f.id === 10 && !f.ko) {
      if (tName === 'red') redCount = 0;
      else blueCount = 0;
      preRollCallouts.push(['STONE FORM!', 'var(--common)', `${f.name} — Don't roll! Singles → negate + 3 counter!`, tName]);
      log(`<span class="log-ability">${f.name}</span> — Stone Form! Doesn't roll this round.`);
    }
  });

  // Late pre-roll KO guard — Boris Fortify and Katrina Seeker run AFTER the early preRollKO
  // check at line 6070, so a Filbert (59) curse that KOs the active ghost during those blocks
  // would fall through to the roll phase with a dead ghost. This second check mirrors the
  // early guard exactly: flush callouts → ko-pause → handleKOs().
  const latePreRollKO = [B.red, B.blue].some(t => active(t).ko);
  if (latePreRollKO && preRollCallouts.length > 0) {
    B.phase = 'ko-pause';
    preRollCallouts.forEach((c, i) => {
      setTimeout(() => showAbilityCallout(c[0], c[1], c[2], c[3]), i * spd(1500));
    });
    refundCommitted();
    setTimeout(() => handleKOs(), preRollCallouts.length * 1500);
    return;
  }
  if (latePreRollKO && handleKOs()) {
    refundCommitted();
    return;
  }

  // Store pre-roll data for per-click rolling
  B.preRoll = {
    red: { count: redCount, override: hankOverride.red, dice: null },
    blue: { count: blueCount, override: hankOverride.blue, dice: null }
  };

  // If Timber pending, update the stored counts reference so modal callback can adjust
  if (B.timberPending) {
    B.timberPending.preRollCalloutCount = preRollCallouts.length;
  }

  // If Ryder pending, update callout count so modal shows after callouts finish
  if (B.riderPending) {
    B.riderPending.preRollCalloutCount = preRollCallouts.length;
  }

  // Drain pre-roll callouts sequentially — each plays for 1.4s before the next fires
  preRollCallouts.forEach((c, i) => {
    setTimeout(() => showAbilityCallout(c[0], c[1], c[2], c[3]), i * spd(1500));
  });

  renderBattle();
  return preRollCallouts.length; // caller uses this to defer dice until all callouts clear
}

// ========================================
// POST-ROLL TRIGGERS (split out for staged timing)
// ========================================
function doPostRollAndResolve(redDice, blueDice) {
  // Queue post-roll ability callouts so they play one at a time
  abilityQueue = [];
  abilityQueueMode = true;

  // Shade's Shadow (205) — MOVED TO PRE-ROLL (doPreRollSetup)

  // Maisie (458) — Lucky: all 1s count as 5s (mutate dice FIRST, before any other post-roll reads them)
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const tName = team === B.red ? 'red' : 'blue';
    if (f.id === 458 && !f.ko) {
      const dice = tName === 'red' ? redDice : blueDice;
      let converted = 0;
      for (let i = 0; i < dice.length; i++) {
        if (dice[i] === 1) { dice[i] = 5; converted++; }
      }
      dice.sort((a, b) => a - b);
      if (converted > 0) {
        queueAbility('LUCKY!', 'var(--ghost-rare)', `${f.name} — ${converted} one${converted > 1 ? 's' : ''} became 5${converted > 1 ? 's' : ''}! 🍀`, () => { renderDice(redDice, blueDice); renderBattle(); }, tName);
        log(`<span class="log-ability">${f.name}</span> — Lucky! ${converted} one${converted > 1 ? 's' : ''} → 5${converted > 1 ? 's' : ''}! 🍀`);
      }
    }
  });

  // Sophia (457) — Mask of Day: gain 1 Burn for each 1 or 2 you roll
  ['red', 'blue'].forEach(tName => {
    if (B.sophiaMask[tName] === 'day' && B.sophiaMaskActive[tName]) {
      const team = tName === 'red' ? B.red : B.blue;
      const dice = tName === 'red' ? redDice : blueDice;
      const lowRolls = countVal(dice, 1) + countVal(dice, 2);
      if (lowRolls > 0) {
        const _modLow = lowRolls;
        const _modTeam = team;
        const _modTName = tName;
        const f = active(team);
        queueAbility('MASK OF DAY!', 'var(--rare)', `☀️ Mask of Day — ${f.name} rolled ${lowRolls} low die${lowRolls>1?'s':''}! +${lowRolls} Burn!`, () => {
          _modTeam.resources.burn = (_modTeam.resources.burn || 0) + _modLow;
          log(`<span class="log-ability">Mask of Day</span> — Rolled ${_modLow} low die${_modLow>1?'s':''}! <span class="log-dmg">+${_modLow} Burn!</span>`);
          renderBattle();
        }, _modTName);
      }
    }
  });

  // Hank (207) — each 4 rolled: gain 1 Lucky Stone (Tremor)
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const dice = team === B.red ? redDice : blueDice;
    const tNameHank = team === B.red ? 'red' : 'blue';
    if (f.id === 207 && !f.ko) {
      const fours = countVal(dice, 4);
      if (fours > 0) {
        const _tremFours = fours;
        const _tremTeam = team;
        const _tremName = f.name;
        queueAbility('TREMOR!', 'var(--common)', `${f.name} — rolled ${fours} four${fours>1?'s':''}! +${fours} Lucky Stone${fours>1?'s':''}!`, () => {
          _tremTeam.resources.luckyStone += _tremFours;
          // Update lsAvailable so post-roll Lucky Stone window sees new stones
          if (B.lsAvailable) B.lsAvailable[tNameHank] = (B.lsAvailable[tNameHank] || 0) + _tremFours;
          log(`<span class="log-ability">${_tremName}</span> — Tremor! Gained <span class="log-ms">${_tremFours} Lucky Stone${_tremFours>1?'s':''}</span>!`);
          renderBattle();
        }, tNameHank);
        checkKnightEffects(tNameHank, f.name);
        if (hasOnTeam(opp(team), 33)) {
          const _sandOpp = opp(team);
          const _sandTotal = _sandOpp.resources.luckyStone + fours;
          queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Tremor! +${fours} Lucky Stone${fours>1?'s':''}! (${_sandTotal} total)`, () => { _sandOpp.resources.luckyStone += _tremFours; renderBattle(); }, tNameHank === 'red' ? 'blue' : 'red');
        }
      }
    }
  });

  // Selene (305) — doubles: choose 1 Healing Seed OR 2 Lucky Stones (deferred modal)
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const dice = team === B.red ? redDice : blueDice;
    const tNameSel = team === B.red ? 'red' : 'blue';
    if (f.id === 305 && !f.ko && classify(dice).type === 'doubles') {
      B.selenePending = { team, tName: tNameSel };
    }
  });

  // Natalia (327) — even doubles (2s, 4s, 6s): gain 1 Moonstone (v799 — removed Lucky Stone)
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const dice = team === B.red ? redDice : blueDice;
    const tNameNat = team === B.red ? 'red' : 'blue';
    if (f.id === 327 && !f.ko && hasEvenDoubles(dice)) {
      const _natTeam = team;
      const _natName = f.name;
      const _natSandOpp = opp(team);
      queueAbility('MATERIALIZATION!', 'var(--ghost-rare)', `${f.name} — Even doubles! +1 Moonstone!`, () => {
        _natTeam.resources.moonstone = Math.min((_natTeam.resources.moonstone || 0) + 1, 1);
        log(`<span class="log-ability">${_natName}</span> — Materialization! Even doubles → <span class="log-ms">+1 Moonstone</span>!`);
        renderBattle();
      }, tNameNat);
      checkKnightEffects(tNameNat, f.name);
      if (hasOnTeam(opp(team), 33)) {
        queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Materialization! +1 Moonstone!`, () => { _natSandOpp.resources.moonstone = Math.min((_natSandOpp.resources.moonstone || 0) + 1, 1); renderBattle(); }, tNameNat === 'red' ? 'blue' : 'red');
      }
    }
  });

  // Kaplan (308) — when OPPONENT rolls doubles: gain 1 Healing Seed
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const oppDice = team === B.red ? blueDice : redDice;
    const tNameKap = team === B.red ? 'red' : 'blue';
    if (f.id === 308 && !f.ko && classify(oppDice).type === 'doubles') {
      const _kapTeam = team;
      const _kapName = f.name;
      const _kapSandOpp = opp(team);
      const _kapSandTotal = _kapSandOpp.resources.healingSeed + 1;
      queueAbility('POLLINATE!', 'var(--uncommon)', `${f.name} — opponent's doubles = free Healing Seed!`, () => {
        _kapTeam.resources.healingSeed++;
        log(`<span class="log-ability">${_kapName}</span> — Pollinate! Opponent rolled doubles → gained <span class="log-ms">1 Healing Seed</span>!`);
        renderBattle();
      }, tNameKap);
      checkKnightEffects(tNameKap, f.name);
      if (hasOnTeam(opp(team), 33)) {
        queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Pollinate! +1 Healing Seed! (${_kapSandTotal} total)`, () => { _kapSandOpp.resources.healingSeed++; renderBattle(); }, tNameKap === 'red' ? 'blue' : 'red');
      }
    }
  });

  // Gom Gom Gom (440) — REMOVED from post-roll (moved to WIN-path only in v685)

  // Captain James (443) — Final Strike: Sideline & In Play — triples+ → gain 2 Sacred Fires (win or lose)
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const dice = team === B.red ? redDice : blueDice;
    const tNameCJ = team === B.red ? 'red' : 'blue';
    const cjActive = f.id === 443 && !f.ko;
    const cjSideline = hasSideline(team, 443);
    if ((cjActive || cjSideline) && ['triples','quads','penta'].includes(classify(dice).type)) {
      const _cjTeam = team;
      const cjGhost = cjActive ? f : getSidelineGhost(team, 443);
      const _cjName = cjGhost ? cjGhost.name : 'Captain James';
      const cjLabel = cjSideline && !cjActive ? `${_cjName} (sideline)` : _cjName;
      queueAbility('FINAL STRIKE!', 'var(--rare)', `${cjLabel} — Triples! +2 Sacred Fires!`, () => {
        _cjTeam.resources.fire += 2;
        log(`<span class="log-ability">${cjLabel}</span> — Final Strike! Triples+ → gained <span class="log-ms">2 Sacred Fires</span>!`);
        if (cjSideline && !cjActive) popSidelineCard(team, 443);
        renderBattle();
      }, tNameCJ);
      checkKnightEffects(tNameCJ, _cjName, cjSideline ? cjGhost : undefined);
    }
  });

  // Champ (438) — Thrill (B): +1 Surge on any doubles+ (either team)
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const tNameChamp = team === B.red ? 'red' : 'blue';
    if (f.id === 438 && !f.ko) {
      const redRoll = classify(redDice);
      const blueRoll = classify(blueDice);
      const eitherDoubles = ['doubles','triples','quads','penta'].includes(redRoll.type) || ['doubles','triples','quads','penta'].includes(blueRoll.type);
      if (eitherDoubles) {
        const _champTeam = team;
        const _champName = f.name;
        queueAbility('THRILL!', 'var(--ghost-rare)', `${f.name} — Doubles detected! +1 Surge!`, () => {
          _champTeam.resources.surge++;
          log(`<span class="log-ability">${_champName}</span> — Thrill! Doubles → gained <span class="log-ms">1 Surge</span>!`);
          renderBattle();
        }, tNameChamp);
        checkKnightEffects(tNameChamp, f.name);
      }
    }
  });

  // Simon (24) — Brew Time: gain 2 Sacred Fire when enemy rolls triples or better
  [B.red, B.blue].forEach(team => {
    const fSimon = active(team);
    const tNameSimon = team === B.red ? 'red' : 'blue';
    const enemyNameSimon = tNameSimon === 'red' ? 'blue' : 'red';
    const enemyDiceSimon = tNameSimon === 'red' ? blueDice : redDice;
    if (fSimon.id === 24 && !fSimon.ko && enemyDiceSimon) {
      const enemyRollType = classify(enemyDiceSimon).type;
      if (isTripleOrBetter(enemyRollType)) {
        team.resources.fire = (team.resources.fire || 0) + 2;
        queueAbility('BREW TIME!', 'var(--uncommon)', `Simon — Enemy rolled ${enemyRollType}! +2 Sacred Fire!`, null, tNameSimon);
        log(`<span class="log-ability">Simon</span> — Brew Time! Enemy rolled ${enemyRollType} → <span class="log-ms">+2 Sacred Fire!</span>`);
        collectKC(tNameSimon, fSimon.name);
      }
    }
  });

  // Masked Hero (55) — Underdog: gain +1 Burn for each 3 rolled (win or lose)
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const tNameMH = team === B.red ? 'red' : 'blue';
    const mhDice = team === B.red ? redDice : blueDice;
    if (f.id === 55 && !f.ko && mhDice) {
      const threeCount = mhDice.filter(d => d === 3).length;
      if (threeCount > 0) {
        if (!team.resources.burn) team.resources.burn = 0;
        team.resources.burn += threeCount;
        queueAbility('UNDERDOG!', 'var(--uncommon)', `${f.name} — ${threeCount} three${threeCount > 1 ? 's' : ''} rolled! +${threeCount} Burn!`, null, tNameMH);
        log(`<span class="log-ability">${f.name}</span> — Underdog! Rolled ${threeCount} three${threeCount > 1 ? 's' : ''} → <span class="log-dmg">+${threeCount} Burn!</span>`);
        collectKC(tNameMH, f.name);
      }
    }
  });

  // Ronan (461) — Mixup: if you roll doubles+ → gain +1 Ice Shard & +1 Burn (win or lose)
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const tNameRonan = team === B.red ? 'red' : 'blue';
    const ronanDice = team === B.red ? redDice : blueDice;
    if (f.id === 461 && !f.ko && ['doubles','triples','quads','penta'].includes(classify(ronanDice).type)) {
      const _rTeam = team;
      const _rName = f.name;
      queueAbility('MIXUP!', 'var(--common)', `${f.name} — Doubles! +1 Ice Shard & +1 Burn!`, () => {
        if (!_rTeam.resources.ice) _rTeam.resources.ice = 0;
        _rTeam.resources.ice += 1;
        if (!_rTeam.resources.burn) _rTeam.resources.burn = 0;
        _rTeam.resources.burn += 1;
        log(`<span class="log-ability">${_rName}</span> — Mixup! Doubles → gained <span class="log-ms">1 Ice Shard</span> & <span class="log-dmg">1 Burn</span>!`);
        renderBattle();
      }, tNameRonan);
      checkKnightEffects(tNameRonan, f.name);
    }
  });

  abilityQueueMode = false;

  // Drain post-roll callouts sequentially, THEN check moonstone/KOs
  const postRollDone = () => {
    if (handleKOs()) return;

    // ========================================
    // MOONSTONE CHECK
    // ========================================
    B.pendingResolve = { redDice, blueDice, redUsedMs:false, blueUsedMs:false };

  // Only offer moonstones that existed BEFORE this round (not gained during roll)
  const redMsAvail = B.msAvailable ? B.msAvailable.red : 0;
  const blueMsAvail = B.msAvailable ? B.msAvailable.blue : 0;

    // Cross-type simultaneous: one team has exactly MS, other has exactly LS
    // (saves ~5s when neither acts vs the old 5s+5s sequential wait)
    const _redLsCtx = B.lsAvailable ? B.lsAvailable.red : 0;
    const _blueLsCtx = B.lsAvailable ? B.lsAvailable.blue : 0;
    const _redHasLS = _redLsCtx > 0 && B.red.resources.luckyStone > 0;
    const _blueHasLS = _blueLsCtx > 0 && B.blue.resources.luckyStone > 0;
    const _redHasMS  = redMsAvail > 0 && B.red.resources.moonstone > 0;
    const _blueHasMS = blueMsAvail > 0 && B.blue.resources.moonstone > 0;

    // v728: PvP — each side only shows their OWN specials windows.
    // Opponent's specials are skipped (can't make their choices).
    if (LIVE_PVP && PVP_SIDE === 'blue' && pvpBlueResolvedLocally) {
      // Blue's local resolution: show Blue's specials only
      if (_blueHasMS && _blueHasLS) {
        startSameTeamSpecialsWindow('blue', () => checkLuckyStones());
        return;
      }
      if (_blueHasMS) {
        B.phase = 'moonstone-blue';
        showMoonstoneChoice('blue', blueDice);
        return;
      }
      // No Blue moonstone — fall through to Lucky Stone check
      checkLuckyStones();
      return;
    }
    if (LIVE_PVP && PVP_SIDE === 'red') {
      // Red's engine: show Red's specials only
      if (_redHasMS && _redHasLS) {
        startSameTeamSpecialsWindow('red', () => checkLuckyStones());
        return;
      }
      if (_redHasMS) {
        B.phase = 'moonstone-red';
        showMoonstoneChoice('red', redDice);
        return;
      }
      // No Red moonstone — fall through to Lucky Stone check
      checkLuckyStones();
      return;
    }

    if (_redHasMS && _blueHasLS && !_blueHasMS && !_redHasLS) {
      startCrossTypeSpecialsWindow('red', 'blue');
      return;
    }
    if (_blueHasMS && _redHasLS && !_redHasMS && !_blueHasLS) {
      startCrossTypeSpecialsWindow('blue', 'red');
      return;
    }

    // Both teams have Moonstone — show simultaneously (saves up to 5s vs 5s+5s sequential)
    if (_redHasMS && _blueHasMS) {
      startSimultaneousMoonstoneWindows();
      return;
    }

    // Same-team unified specials: one team has BOTH Moonstone + Lucky Stone
    // Show a single reaction window with both resource tiles highlighted, one shared timer.
    if (_redHasMS && _redHasLS) {
      startSameTeamSpecialsWindow('red', () => {
        // After red's unified window, check if blue has anything
        if (_blueHasLS) checkLuckyStones();
        else resolveRound();
      });
      return;
    }
    if (_blueHasMS && _blueHasLS) {
      startSameTeamSpecialsWindow('blue', () => {
        // After blue's unified window, check if red has anything
        if (_redHasLS) checkLuckyStones();
        else resolveRound();
      });
      return;
    }

  if (_redHasMS) {
    B.phase = 'moonstone-red';
    showMoonstoneChoice('red', redDice);
    return;
  }
  if (_blueHasMS) {
    B.phase = 'moonstone-blue';
    showMoonstoneChoice('blue', blueDice);
    return;
  }

    checkLuckyStones();
  };

  // Drain post-roll ability callouts, then check for KOs (Shade's Shadow can KO during queue),
  // then continue to moonstone/lucky stones
  drainAbilityQueue(() => {
    if (handleKOs()) return; // Shade's Shadow or other queued ability caused a KO — swap flow takes over

    // Jackson (50) — Regrow: post-roll HP-for-reroll modal (before moonstone)
    // → then Sonya (69) — Mesmerize: change one die to 2 (free, once per round)
    // → then Jeanie (90) — Hidden Treasure: sideline force-opponent-reroll (once per game)
    // → then Selene → postRollDone
    const afterJeanie = () => {
      if (B.selenePending) {
        B.selenePending._continue = postRollDone;
        showSeleneModal();
        return;
      }
      postRollDone();
    };
    const afterSonya = () => {
      // Jeanie (90) chain: offer Red first, then Blue, then continue
      if (hasSideline(B.red, 90) && B.jeanieUsed && !B.jeanieUsed.red) {
        checkJeanieHiddenTreasure('red', () => {
          if (hasSideline(B.blue, 90) && B.jeanieUsed && !B.jeanieUsed.blue) {
            checkJeanieHiddenTreasure('blue', afterJeanie);
          } else {
            afterJeanie();
          }
        });
        return;
      }
      if (hasSideline(B.blue, 90) && B.jeanieUsed && !B.jeanieUsed.blue) {
        checkJeanieHiddenTreasure('blue', afterJeanie);
        return;
      }
      afterJeanie();
    };
    const afterJackson = () => {
      // Sonya (69) — Mesmerize chain: red first, then blue, then continue
      const sRed  = active(B.red);
      const sBlue = active(B.blue);
      if (sRed  && sRed.id  === 69 && !sRed.ko  && B.sonyaUsedThisRound && !B.sonyaUsedThisRound.red) {
        checkSonyaMesmerize('red',  afterSonya); return;
      }
      if (sBlue && sBlue.id === 69 && !sBlue.ko && B.sonyaUsedThisRound && !B.sonyaUsedThisRound.blue) {
        checkSonyaMesmerize('blue', afterSonya); return;
      }
      afterSonya();
    };
    // Dark Wing (76) — Precision: reroll all dice if not doubles
    const afterDarkWing = () => {
      const jRed  = active(B.red);
      const jBlue = active(B.blue);
      if (jRed  && jRed.id  === 50 && !jRed.ko  && jRed.hp  >= 2) {
        checkJacksonRegrow('red',  [...B.redDice],  afterJackson); return;
      }
      if (jBlue && jBlue.id === 50 && !jBlue.ko && jBlue.hp >= 2) {
        checkJacksonRegrow('blue', [...B.blueDice], afterJackson); return;
      }
      afterJackson();
    };
    // Drizzle (328) — Rain Dance fires AFTER Tommy (before Dark Wing), then DW, then Jackson
    const afterDrizzle = () => {
      const dwRed  = active(B.red);
      const dwBlue = active(B.blue);
      if (dwRed  && dwRed.id  === 76 && !dwRed.ko  && B.darkWingUsedThisGame && !B.darkWingUsedThisGame.red) {
        checkDarkWingPrecision('red',  afterDarkWing); return;
      }
      if (dwBlue && dwBlue.id === 76 && !dwBlue.ko && B.darkWingUsedThisGame && !B.darkWingUsedThisGame.blue) {
        checkDarkWingPrecision('blue', afterDarkWing); return;
      }
      afterDarkWing();
    };
    // Tommy Salami (30) — Regulator: fires FIRST so 5s/6s are suppressed before Drizzle, Dark Wing, etc.
    checkTommyRegulator(afterDrizzle);
  });
}

// ============================================================
// SKIP SPECIALS BUTTON — lets players skip the countdown window
// ============================================================
function showSkipBtn(callback) {
  B.skipSpecialsCallback = callback;
  if (!document.getElementById('skipBtnCheckbox')?.checked) return;
  const btn = document.getElementById('skipSpecialsBtn');
  if (btn) btn.style.display = '';
}
function hideSkipBtn() {
  B.skipSpecialsCallback = null;
  const btn = document.getElementById('skipSpecialsBtn');
  if (btn) btn.style.display = 'none';
}
function doSkipSpecials() {
  if (!B || !B.skipSpecialsCallback) return;
  const cb = B.skipSpecialsCallback;
  hideSkipBtn();
  cb();
}

// Moonstone Sickness — balance experiment
function applyMoonstoneSickness(team) {
  const mode = document.getElementById('moonstoneModeSelect')?.value || 'D';
  const t = B[team];
  if (mode === 'A') {
    t.moonstoneSickness = (t.moonstoneSickness || 0) + 1;
    const totalPerTurn = t.moonstoneSickness * 2;
    log(`<span class="log-dmg">Moonstone Sickness!</span> ${team.toUpperCase()} will take ${totalPerTurn} damage before every roll for the rest of the game.`);
    narrate(`<b class="${team}-text" style="color:var(--moonstone)">Moonstone Sickness!</b> ${totalPerTurn} damage before every roll!`);
  } else if (mode === 'D' || mode === 'G') {
    t.moonstoneSickness = (t.moonstoneSickness || 0) + 1;
    const totalPerTurn = t.moonstoneSickness * 1;
    const clearNote = mode === 'G' ? ' (clears on KO)' : '';
    log(`<span class="log-dmg">Moonstone Sickness!</span> ${team.toUpperCase()} will take ${totalPerTurn} damage before every roll${clearNote}.`);
    narrate(`<b class="${team}-text" style="color:var(--moonstone)">Moonstone Sickness!</b> ${totalPerTurn} damage before every roll!${clearNote}`);
  } else if (mode === 'B') {
    t.moonstoneSicknessCount = (t.moonstoneSicknessCount || 0) + 1;
    t.moonstoneSicknessPending = t.moonstoneSicknessCount * 2;
    log(`<span class="log-dmg">Moonstone Sickness!</span> ${team.toUpperCase()} will take ${t.moonstoneSicknessPending} damage before next roll.`);
    narrate(`<b class="${team}-text" style="color:var(--moonstone)">Moonstone Sickness!</b> ${t.moonstoneSicknessPending} damage before next roll!`);
  } else if (mode === 'C') {
    t.moonstoneSicknessPending = 3;
    log(`<span class="log-dmg">Moonstone Sickness!</span> ${team.toUpperCase()} will take 3 damage before next roll.`);
    narrate(`<b class="${team}-text" style="color:var(--moonstone)">Moonstone Sickness!</b> 3 damage before next roll!`);
  }
}

// Moonstone — timed window like Lucky Stone (3s countdown, click die to change)
let msCountdownTimer = null;

function showMoonstoneChoice(team, dice) {
  // Blue AI: auto-use moonstone
  if (AI_ACTIVE && team === 'blue') {
    const aiMsMode = document.getElementById('moonstoneModeSelect')?.value || 'D';
    B.pendingMoonstone = { team, dice: [...dice], dieIndex: null, phase: 'pick-resource' };

    if (aiMsMode === 'F') {
      // Toggle F AI: roll die, deal damage to opponent
      B[team].resources.moonstone--;
      const roll = Math.floor(Math.random() * 6) + 1;
      const oppTeam = team === 'red' ? 'blue' : 'red';
      const oppF = active(B[oppTeam]);
      if (oppF && !oppF.ko) {
        oppF.hp = Math.max(0, oppF.hp - roll);
        if (oppF.hp <= 0) { oppF.ko = true; oppF.killedBy = -1; }
        log(`<span class="log-ms">Moonstone Blast!</span> Blue rolled <b>${roll}</b> — ${oppF.name} takes <span class="log-dmg">${roll} damage!</span>${oppF.ko ? ' <span class="log-ko">KO!</span>' : ' ' + oppF.hp + ' HP left'}`);
        narrate(`<b style="color:var(--moonstone)">Moonstone Blast!</b> <b class="blue-text">Blue</b> rolled <b class="gold">${roll}</b> — <b class="red-text">${oppF.name}</b> takes ${roll} damage!`);
        playDamageSfx(roll);
        hitDamage(oppTeam);
      }
      B.pendingMoonstone = null;
      renderBattle();
      setTimeout(() => {
        if (B.pendingResolve) { const pr = B.pendingResolve; B.pendingResolve = null; doResolve(pr.redDice || B.redDice, pr.blueDice || B.blueDice, pr.redRoll, pr.blueRoll); }
        else checkLuckyStonePhase();
      }, spd(800));
      return;
    }

    if (aiMsMode === 'E') {
      // Toggle E AI: pick a random item
      B[team].resources.moonstone--;
      const pick = MS_ITEM_LIST[Math.floor(Math.random() * MS_ITEM_LIST.length)];
      if (pick.key === 'iceBlade') { if (!B.iceBladeForgedPermanent) B.iceBladeForgedPermanent={red:false,blue:false}; B.iceBladeForgedPermanent[team]=true; }
      else if (pick.key === 'flameBlade') { if (!B.flameBlade) B.flameBlade={red:false,blue:false}; B.flameBlade[team]=true; }
      else if (pick.key === 'maskOfDay') { if (!B.sophiaMask) B.sophiaMask={red:null,blue:null}; if (!B.sophiaMaskActive) B.sophiaMaskActive={red:false,blue:false}; B.sophiaMask[team]='day'; B.sophiaMaskActive[team]=true; }
      else if (pick.key === 'maskOfNight') { if (!B.sophiaMask) B.sophiaMask={red:null,blue:null}; if (!B.sophiaMaskActive) B.sophiaMaskActive={red:false,blue:false}; B.sophiaMask[team]='night'; B.sophiaMaskActive[team]=true; }
      else if (pick.key === 'hammer') { if (!B.carpenterHammer) B.carpenterHammer={red:false,blue:false}; B.carpenterHammer[team]=true; }
      else if (pick.key === 'torch') { if (!B.welderTorch) B.welderTorch={red:false,blue:false}; B.welderTorch[team]=true; }
      log(`<span class="log-ms">Moonstone → Item!</span> Blue receives <b>${pick.name}</b>! ${pick.desc}`);
      narrate(`<b style="color:var(--moonstone)">Moonstone → Item!</b> <b class="blue-text">Blue</b> receives <b>${pick.name}</b>!`);
      B.pendingMoonstone = null;
      renderBattle();
      setTimeout(() => {
        if (B.pendingResolve) { const pr = B.pendingResolve; B.pendingResolve = null; doResolve(pr.redDice || B.redDice, pr.blueDice || B.blueDice, pr.redRoll, pr.blueRoll); }
        else checkLuckyStonePhase();
      }, spd(800));
      return;
    }

    // Default modes A-D: change lowest die to 6
    // Find lowest die
    let worstIdx = 0, worstVal = 7;
    dice.forEach((d, i) => { if (d < worstVal) { worstVal = d; worstIdx = i; } });
    // Auto-use: change lowest die to 6
    B.pendingMoonstone.dieIndex = worstIdx;
    const newDice = [...dice];
    newDice[worstIdx] = 6;
    newDice.sort((a, b) => a - b);
    B[team === 'red' ? 'redDice' : 'blueDice'] = newDice;
    B.pendingMoonstone.dice = newDice;
    B[team].resources.moonstone--;
    applyMoonstoneSickness(team);
    triggerCameronSpecialWatch(team, true); // Cameron (25) — Unstoppable Force (immediate post-roll die)
    log(`<span class="log-ms">${team.toUpperCase()} uses Moonstone!</span> Changed die ${worstVal} → 6!`);
    narrate(`<b class="${team}-text">Blue</b> uses <b style="color:var(--moonstone)">Moonstone!</b> ${worstVal} → 6!`);
    B.pendingMoonstone = null;
    renderDice(B.redDice, B.blueDice);
    renderBattle();
    // Continue to resolve
    setTimeout(() => {
      if (B.pendingResolve) {
        const pr = B.pendingResolve;
        B.pendingResolve = null;
        doResolve(pr.redDice || B.redDice, pr.blueDice || B.blueDice, pr.redRoll, pr.blueRoll);
      } else {
        checkLuckyStonePhase();
      }
    }, spd(800));
    return;
  }

  // Toggle F: Roll die 1-6, deal that as damage to opponent
  const msModeF = document.getElementById('moonstoneModeSelect')?.value;
  if (msModeF === 'F') {
    B.pendingMoonstone = { team, dice: [...dice], dieIndex: null, phase: 'pick-resource' };
    renderDice(B.redDice, B.blueDice);
    renderBattle();
    const teamLabel = team.charAt(0).toUpperCase() + team.slice(1);
    narrate(`<b class="${team}-text">${teamLabel}</b> has a <b style="color:var(--moonstone)">Moonstone!</b>&nbsp;Click it to use!`);
    log(`<span class="log-ms">${team.toUpperCase()} has a Moonstone!</span> Click it to use — 5 seconds!`);
    showSkipBtn(() => skipMoonstone());
    const resEl = document.getElementById(team + '-resources');
    const msEl = resEl.querySelector('.res-tile.moonstone');
    if (msEl) {
      msEl.classList.add('rerollable');
      msEl.style.cursor = 'pointer';
      let remaining = getSpecialsTimerSecs();
      showLsCountdown(msEl, remaining);
      msEl.onclick = () => {
        hideSkipBtn();
        clearInterval(msCountdownTimer);
        clearMsCountdown(msEl);
        msEl.classList.remove('rerollable');
        msEl.onclick = null;
        // Consume moonstone
        const t = B[team];
        const f = active(t);
        let magicTouchFired = false;
        if (f.id === 203 && !f.usedMagicTouch) {
          f.usedMagicTouch = true;
          magicTouchFired = true;
          showAbilityCallout('MAGIC TOUCH!', 'var(--moonstone)', `${f.name} — Moonstone used without discarding!`, team);
          log(`<span class="log-ability">${f.name}</span> — Magic Touch! Used Moonstone without discarding it!`);
        } else {
          t.resources.moonstone--;
          playSfx('sfxSpecial', 0.5);
        }
        // Roll 1-6
        const roll = Math.floor(Math.random() * 6) + 1;
        const oppTeam = team === 'red' ? 'blue' : 'red';
        const oppF = active(B[oppTeam]);
        if (oppF && !oppF.ko) {
          oppF.hp = Math.max(0, oppF.hp - roll);
          if (oppF.hp <= 0) { oppF.ko = true; oppF.killedBy = -1; }
          showAbilityCallout('MOONSTONE BLAST!', 'var(--moonstone)', `Rolled a ${roll} — ${oppF.name} takes ${roll} damage!`, team);
          log(`<span class="log-ms">Moonstone Blast!</span> Rolled <b>${roll}</b> — ${oppF.name} takes <span class="log-dmg">${roll} damage!</span>${oppF.ko ? ' <span class="log-ko">KO!</span>' : ' ' + oppF.hp + ' HP left'}`);
          narrate(`<b style="color:var(--moonstone)">Moonstone Blast!</b> Rolled <b class="gold">${roll}</b> — <b class="${oppTeam}-text">${oppF.name}</b> takes ${roll} damage!${oppF.ko ? ' <b>KO!</b>' : ''}`);
          playDamageSfx(roll);
          hitDamage(oppTeam);
        }
        renderBattle();
        B.pendingMoonstone = null;
        setTimeout(() => {
          const blueMsLeft = B.msAvailable ? B.msAvailable.blue : 0;
          if (team === 'red' && blueMsLeft > 0 && B.blue.resources.moonstone > 0) {
            B.phase = 'moonstone-blue';
            showMoonstoneChoice('blue', B.blueDice);
            return;
          }
          if (B.afterMoonstoneCallback) { const _cb = B.afterMoonstoneCallback; delete B.afterMoonstoneCallback; _cb(); return; }
          checkLuckyStones();
        }, magicTouchFired ? 1600 : 1200);
      };
      clearInterval(msCountdownTimer);
      msCountdownTimer = setInterval(() => {
        remaining--;
        if (remaining <= 0) {
          clearInterval(msCountdownTimer);
          clearMsCountdown(msEl);
          if (msEl) { msEl.classList.remove('rerollable'); msEl.onclick = null; }
          skipMoonstone();
        } else {
          showLsCountdown(msEl, remaining);
        }
      }, 1000);
    }
    return;
  }

  // Toggle E: Choose an item instead of changing a die
  const msModeE = document.getElementById('moonstoneModeSelect')?.value;
  if (msModeE === 'E') {
    B.pendingMoonstone = { team, dice: [...dice], dieIndex: null, phase: 'pick-resource' };
    renderDice(B.redDice, B.blueDice);
    renderBattle();
    const teamLabel = team.charAt(0).toUpperCase() + team.slice(1);
    narrate(`<b class="${team}-text">${teamLabel}</b> has a <b style="color:var(--moonstone)">Moonstone!</b>&nbsp;Click it to choose an item!`);
    log(`<span class="log-ms">${team.toUpperCase()} has a Moonstone!</span> Click it to choose an item — 5 seconds!`);
    showSkipBtn(() => skipMoonstone());
    const resEl = document.getElementById(team + '-resources');
    const msEl = resEl.querySelector('.res-tile.moonstone');
    if (msEl) {
      msEl.classList.add('rerollable');
      msEl.style.cursor = 'pointer';
      let remaining = getSpecialsTimerSecs();
      showLsCountdown(msEl, remaining);
      msEl.onclick = () => {
        hideSkipBtn();
        clearInterval(msCountdownTimer);
        clearMsCountdown(msEl);
        msEl.classList.remove('rerollable');
        msEl.onclick = null;
        showMoonstoneItemPicker(team);
      };
      clearInterval(msCountdownTimer);
      msCountdownTimer = setInterval(() => {
        remaining--;
        if (remaining <= 0) {
          clearInterval(msCountdownTimer);
          clearMsCountdown(msEl);
          if (msEl) { msEl.classList.remove('rerollable'); msEl.onclick = null; }
          skipMoonstone();
        } else {
          showLsCountdown(msEl, remaining);
        }
      }, 1000);
    }
    return;
  }

  renderDice(B.redDice, B.blueDice);
  renderBattle();
  B.pendingMoonstone = { team, dice: [...dice], dieIndex:null, phase:'pick-resource' };
  showSkipBtn(() => skipMoonstone());

  const teamLabel = team.charAt(0).toUpperCase() + team.slice(1);
  narrate(`<b class="${team}-text">${teamLabel}</b> has a <b style="color:var(--moonstone)">Moonstone!</b>&nbsp;Click it to use!`);
  log(`<span class="log-ms">${team.toUpperCase()} has a Moonstone!</span> Click it to use — 5 seconds!`);

  const diceEl = document.getElementById(team + '-dice');
  const resEl = document.getElementById(team + '-resources');

  // Scroll dice area into view so the Moonstone UI is visible
  const arenaEl = document.getElementById('arena') || diceEl;
  arenaEl.scrollIntoView({ behavior:'smooth', block:'center' });
  const msEl = resEl.querySelector('.res-tile.moonstone') || diceEl;

  // Highlight the Moonstone resource — player clicks IT first
  if (msEl && msEl !== diceEl) {
    msEl.classList.add('rerollable');
    msEl.style.cursor = 'pointer';
    msEl.onclick = () => {
      // Player clicked Moonstone — clear the countdown and start fresh for die picking
      hideSkipBtn();
      clearInterval(msCountdownTimer);
      clearMsCountdown(msEl);
      msEl.classList.remove('rerollable');
      msEl.onclick = null;
      B.pendingMoonstone.phase = 'pick-die';
      narrate(`<b class="${team}-text">${teamLabel}</b> — pick a die to change!`);
      const dieDivs = diceEl.querySelectorAll('.die');
      dieDivs.forEach((d, i) => {
        d.classList.add('rerollable');
        d.style.borderColor = 'var(--moonstone)';
        d.onclick = () => pickMsDie(i);
      });
      sync3dDiceClickable(team);
      // Fresh 5s countdown for picking which die
      let pickRemaining = getSpecialsTimerSecs();
      showLsCountdown(diceEl, pickRemaining);
      msCountdownTimer = setInterval(() => {
        pickRemaining--;
        if (pickRemaining <= 0) {
          clearInterval(msCountdownTimer);
          clearMsCountdown(diceEl);
          clearDiceClickable(team);
          skipMoonstone();
        } else {
          showLsCountdown(diceEl, pickRemaining);
        }
      }, 1000);
    };
  } else {
    // No resource tile — fall back to direct dice click
    B.pendingMoonstone.phase = 'pick-die';
    const dieDivs = diceEl.querySelectorAll('.die');
    dieDivs.forEach((d, i) => {
      d.classList.add('rerollable');
      d.style.borderColor = 'var(--moonstone)';
      d.onclick = () => pickMsDie(i);
    });
    sync3dDiceClickable(team);
  }

  // Start countdown — auto-skip if not used
  let remaining = getSpecialsTimerSecs();
  showLsCountdown(msEl, remaining);

  clearInterval(msCountdownTimer);
  msCountdownTimer = setInterval(() => {
    remaining--;
    if (remaining <= 0) {
      clearInterval(msCountdownTimer);
      clearMsCountdown(msEl);
      clearDiceClickable(team);
      if (msEl) { msEl.classList.remove('rerollable'); msEl.onclick = null; }
      skipMoonstone();
    } else {
      showLsCountdown(msEl, remaining);
    }
  }, 1000);
}

function clearMsCountdown(el) {
  if (el) { const cd = el.querySelector('.reroll-countdown'); if (cd) cd.remove(); }
}

function pickMsDie(idx) {
  if (!B || !B.pendingMoonstone || B.pendingMoonstone.phase !== 'pick-die') return;
  hideSkipBtn();
  clearInterval(msCountdownTimer);
  msCountdownTimer = null; // prevent any queued interval callbacks from firing
  const team = B.pendingMoonstone.team;
  B.pendingMoonstone.dieIndex = idx;
  B.pendingMoonstone.phase = 'pick-value';

  // Clear die clickability and countdowns immediately
  clearDiceClickable(team);
  const diceEl = document.getElementById(team + '-dice');
  const resEl = document.getElementById(team + '-resources');
  const msEl = resEl.querySelector('.res-tile.moonstone') || diceEl;
  clearMsCountdown(msEl);
  clearMsCountdown(diceEl);
  document.querySelectorAll('.reroll-countdown').forEach(el => el.remove());

  narrate(`Die ${idx+1} selected — pick a new value!`);

  // Hide the full-screen overlay, show inline picker in arena center
  document.getElementById('msPicker').classList.remove('active');
  const inlinePicker = document.getElementById('msInlinePicker');
  const inlineOpts = document.getElementById('msInlineOptions');
  inlineOpts.innerHTML = [1,2,3,4,5,6].map(v => `<div class="ms-die-option" onclick="pickMsValue(${v})">${v}</div>`).join('');
  inlinePicker.classList.add('active');

  // Scroll arena center into view
  const arenaCenter = inlinePicker.parentElement;
  if (arenaCenter) arenaCenter.scrollIntoView({ behavior:'smooth', block:'center' });

  // Auto-skip after 7s if no value picked
  let remaining = 7;
  showLsCountdown(inlinePicker, remaining);
  msCountdownTimer = setInterval(() => {
    remaining--;
    if (remaining <= 0) {
      clearInterval(msCountdownTimer);
      inlinePicker.classList.remove('active');
      clearMsCountdown(inlinePicker);
      skipMoonstone();
    } else {
      showLsCountdown(inlinePicker, remaining);
    }
  }, 1000);
}

function pickMsValue(val) {
  clearInterval(msCountdownTimer);
  const ms = B.pendingMoonstone;
  if (!ms) return;
  const team = ms.team;
  const t = B[team];
  const f = active(t);

  const el = document.getElementById('msPicker');
  el.classList.remove('active');
  clearMsCountdown(el);
  document.getElementById('msInlinePicker').classList.remove('active');
  clearMsCountdown(document.getElementById('msInlinePicker'));

  // Benjamin (203) — Magic Touch: once per turn, don't decrement moonstone
  let magicTouchFired = false;
  if (f.id === 203 && !f.usedMagicTouch) {
    f.usedMagicTouch = true;
    magicTouchFired = true;
    showAbilityCallout('MAGIC TOUCH!', 'var(--moonstone)', `${f.name} — Moonstone used without discarding!`, team);
    log(`<span class="log-ability">${f.name}</span> — Magic Touch! Used Moonstone without discarding it!`);
  } else {
    t.resources.moonstone--;
    playSfx('sfxSpecial', 0.5);
  }
  applyMoonstoneSickness(team); // Moonstone Sickness — fires on USE (including Magic Touch)
  triggerCameronSpecialWatch(team, true); // Cameron (25) — Unstoppable Force (immediate post-roll die)

  ms.dice[ms.dieIndex] = val;
  ms.dice.sort((a,b)=>a-b);

  if (team==='red') B.pendingResolve.redDice = ms.dice;
  else B.pendingResolve.blueDice = ms.dice;

  B.redDice = B.pendingResolve.redDice;
  B.blueDice = B.pendingResolve.blueDice;
  renderDice(B.redDice, B.blueDice);

  const teamLabel = team.charAt(0).toUpperCase() + team.slice(1);
  log(`<span class="log-ms">Moonstone used!</span> ${team.toUpperCase()} changed die to ${val} → [${ms.dice.join(', ')}]`);
  narrate(`<b style="color:var(--moonstone)">Moonstone!</b>&nbsp;<b class="${team}-text">${teamLabel}</b> changes die to <b class="gold">${val}</b>! → [${ms.dice.join(', ')}]`);
  B.pendingMoonstone = null;

  // v731: broadcast Moonstone choice to Red's engine so it resolves with correct dice
  if (LIVE_PVP && PVP_SIDE === 'blue' && PVP_GAME_REF && team === 'blue') {
    PVP_GAME_REF.child('specialsChoice').push({
      type: 'moonstone',
      side: 'blue',
      dieIndex: ms.dieIndex,
      chosenValue: val,
      dice: ms.dice.slice(),
      ts: Date.now()
    });
  }

  // Bigsby (424) — Omen: if Bigsby is the active ghost when a Moonstone is used,
  // Bigsby MUST be sacrificed and replaced with Doom (id 112). Mandatory transformation.
  if (f.id === 424 && !f.ko) {
    const g = f; // mutate the ghost object in-place
    // Preserve original identity for MVP/results/resurrection/standings
    g.originalId = g.id;
    g.originalName = g.name;
    g.originalArt = g.art;
    g.originalMaxHp = g.maxHp;
    g.originalAbility = g.ability;
    g.originalAbilityDesc = g.abilityDesc;
    g.originalRarity = g.rarity;
    g.id = 112; g.name = "Doom"; g.maxHp = 7; g.hp = 7;
    g.ability = "Fiendship"; g.abilityDesc = "+2 bonus damage!";
    g.art = "art/originals/doom.jpg"; g.rarity = "legendary"; g.ko = false;
    queueAbility('TRANSFORMATION!', 'var(--legendary)', 'Bigsby sacrifices himself — DOOM rises!', null, team);
    log(`<span class="log-ability">Bigsby</span> — Omen! <span class="log-dmg">DOOM has arrived!</span>`);
    checkRipagooTransform(team);
    renderBattle();
  }

  // When Magic Touch fired, showAbilityCallout is on screen for 1400ms — wait 1600ms
  // so the splash fully clears before the next picker / Lucky Stones appear.
  // Without Magic Touch, only a visual dice update happened — 1200ms is enough.
  const msPostDelay = magicTouchFired ? 1600 : 1200;

  // Pause to let the changed dice register visually before continuing
  setTimeout(() => {
    // Check if other team also has moonstone (pre-round only)
    const blueMsLeft = B.msAvailable ? B.msAvailable.blue : 0;
    if (team==='red' && blueMsLeft > 0 && B.blue.resources.moonstone > 0) {
      B.phase = 'moonstone-blue';
      showMoonstoneChoice('blue', B.blueDice);
      return;
    }

    // Cross-type window callback: after MS resolves, offer LS to the other team
    if (B.afterMoonstoneCallback) {
      const _cb = B.afterMoonstoneCallback;
      delete B.afterMoonstoneCallback;
      _cb();
      return;
    }

    checkLuckyStones();
  }, msPostDelay);
}

// Toggle E: Moonstone item picker — choose an item from the game
const MS_ITEM_LIST = [
  { key: 'iceBlade', name: 'Ice Blade', emoji: '🗡️', desc: '+1 die, +2 damage on wins when swinging', color: 'var(--ghost-rare)' },
  { key: 'flameBlade', name: 'Flame Blade', emoji: '🔥', desc: '+1 die, +3 Burn on wins when swinging', color: 'var(--rare)' },
  { key: 'maskOfDay', name: 'Mask of Day', emoji: '☀️', desc: 'Gain 1 Burn for each 1 or 2 you roll', color: '#ffd700' },
  { key: 'maskOfNight', name: 'Mask of Night', emoji: '🌙', desc: 'Roll same dice as enemy, +1 damage on wins', color: '#4a4a8a' },
  { key: 'hammer', name: "Carpenter's Hammer", emoji: '🔨', desc: '+2 damage on Singles', color: 'var(--moonstone)' },
  { key: 'torch', name: "Welder's Torch", emoji: '🔦', desc: 'Burns deal +1 extra damage, wins grant 1 Burn', color: '#ff6b35' }
];

function showMoonstoneItemPicker(team) {
  clearInterval(msCountdownTimer);
  const inlinePicker = document.getElementById('msInlinePicker');
  const inlineOpts = document.getElementById('msInlineOptions');
  const h4 = inlinePicker.querySelector('h4');
  if (h4) h4.textContent = '💎 Choose an Item';
  inlineOpts.innerHTML = MS_ITEM_LIST.map((item, i) =>
    `<div class="ms-die-option" style="width:auto;height:auto;padding:8px 14px;font-size:13px;display:flex;flex-direction:column;align-items:center;gap:2px;" onclick="pickMoonstoneItem('${item.key}','${team}')" title="${item.desc}">
      <span style="font-size:20px;">${item.emoji}</span>
      <span style="font-size:11px;color:${item.color};font-weight:700;">${item.name}</span>
    </div>`
  ).join('');
  inlinePicker.classList.add('active');
  const arenaCenter = inlinePicker.parentElement;
  if (arenaCenter) arenaCenter.scrollIntoView({ behavior:'smooth', block:'center' });
  let remaining = 10;
  showLsCountdown(inlinePicker, remaining);
  msCountdownTimer = setInterval(() => {
    remaining--;
    if (remaining <= 0) {
      clearInterval(msCountdownTimer);
      inlinePicker.classList.remove('active');
      clearMsCountdown(inlinePicker);
      skipMoonstone();
    } else {
      showLsCountdown(inlinePicker, remaining);
    }
  }, 1000);
}

function pickMoonstoneItem(key, team) {
  clearInterval(msCountdownTimer);
  const inlinePicker = document.getElementById('msInlinePicker');
  inlinePicker.classList.remove('active');
  clearMsCountdown(inlinePicker);

  const t = B[team];
  const f = active(t);
  const item = MS_ITEM_LIST.find(i => i.key === key);
  if (!item) { skipMoonstone(); return; }

  // Consume moonstone (Benjamin Magic Touch check)
  let magicTouchFired = false;
  if (f.id === 203 && !f.usedMagicTouch) {
    f.usedMagicTouch = true;
    magicTouchFired = true;
    showAbilityCallout('MAGIC TOUCH!', 'var(--moonstone)', `${f.name} — Moonstone used without discarding!`, team);
    log(`<span class="log-ability">${f.name}</span> — Magic Touch! Used Moonstone without discarding it!`);
  } else {
    t.resources.moonstone--;
    playSfx('sfxSpecial', 0.5);
  }

  // Grant the item
  if (key === 'iceBlade') {
    if (!B.iceBladeForgedPermanent) B.iceBladeForgedPermanent = { red: false, blue: false };
    B.iceBladeForgedPermanent[team] = true;
  } else if (key === 'flameBlade') {
    if (!B.flameBlade) B.flameBlade = { red: false, blue: false };
    B.flameBlade[team] = true;
  } else if (key === 'maskOfDay') {
    if (!B.sophiaMask) B.sophiaMask = { red: null, blue: null };
    if (!B.sophiaMaskActive) B.sophiaMaskActive = { red: false, blue: false };
    B.sophiaMask[team] = 'day';
    B.sophiaMaskActive[team] = true;
  } else if (key === 'maskOfNight') {
    if (!B.sophiaMask) B.sophiaMask = { red: null, blue: null };
    if (!B.sophiaMaskActive) B.sophiaMaskActive = { red: false, blue: false };
    B.sophiaMask[team] = 'night';
    B.sophiaMaskActive[team] = true;
  } else if (key === 'hammer') {
    if (!B.carpenterHammer) B.carpenterHammer = { red: false, blue: false };
    B.carpenterHammer[team] = true;
  } else if (key === 'torch') {
    if (!B.welderTorch) B.welderTorch = { red: false, blue: false };
    B.welderTorch[team] = true;
  }

  showAbilityCallout(item.emoji + ' ' + item.name.toUpperCase() + '!', item.color, `${f.name} receives ${item.name}!`, team);
  log(`<span class="log-ms">Moonstone → Item!</span> ${team.toUpperCase()} receives <b>${item.name}</b>! ${item.desc}`);
  narrate(`<b style="color:var(--moonstone)">Moonstone → Item!</b> <b class="${team}-text">${f.name}</b> receives <b style="color:${item.color}">${item.name}</b>!`);
  renderBattle();
  B.pendingMoonstone = null;

  const msPostDelay = magicTouchFired ? 1600 : 1200;
  setTimeout(() => {
    const blueMsLeft = B.msAvailable ? B.msAvailable.blue : 0;
    if (team === 'red' && blueMsLeft > 0 && B.blue.resources.moonstone > 0) {
      B.phase = 'moonstone-blue';
      showMoonstoneChoice('blue', B.blueDice);
      return;
    }
    if (B.afterMoonstoneCallback) { const _cb = B.afterMoonstoneCallback; delete B.afterMoonstoneCallback; _cb(); return; }
    checkLuckyStones();
  }, msPostDelay);
}

function skipMoonstone() {
  if (!B.pendingMoonstone) return;
  hideSkipBtn();
  const team = B.pendingMoonstone.team;
  clearInterval(msCountdownTimer);
  document.getElementById('msPicker').classList.remove('active');
  document.getElementById('msInlinePicker').classList.remove('active');
  clearDiceClickable(team);
  // Also clear the resource tile highlight + countdown badge
  const resEl = document.getElementById(team + '-resources');
  const msEl = resEl && resEl.querySelector('.res-tile.moonstone');
  if (msEl) { msEl.classList.remove('rerollable'); msEl.onclick = null; msEl.style.cursor = ''; clearMsCountdown(msEl); }
  log(`<span style="color:var(--text2)">${team.toUpperCase()} holds their Moonstone.</span>`);
  B.pendingMoonstone = null;

  const blueMsSkip = B.msAvailable ? B.msAvailable.blue : 0;
  if (team==='red' && blueMsSkip > 0 && B.blue.resources.moonstone > 0) {
    B.phase = 'moonstone-blue';
    showMoonstoneChoice('blue', B.blueDice);
    return;
  }
  if (B.afterMoonstoneCallback) {
    const _cb = B.afterMoonstoneCallback;
    delete B.afterMoonstoneCallback;
    _cb();
    return;
  }
  checkLuckyStones();
}

// ============================================================
// SIMULTANEOUS MOONSTONE WINDOW
// Both teams have a Moonstone — show both tiles highlighted at once.
// Shared 5s countdown. Whoever clicks first goes; the other follows.
// If Red acts first → existing red→blue sequential chain handles Blue.
// If Blue acts first → afterMoonstoneCallback offers Red afterward.
// If neither acts in 5s → both skip → checkLuckyStones().
// Saves up to 5s per round vs the old 5s+5s sequential wait.
// ============================================================
function startSimultaneousMoonstoneWindows() {
  B.phase = 'moonstone-shared';
  narrate(`<b class="red-text">Red</b> and <b class="blue-text">Blue</b> both have a <b style="color:var(--moonstone)">Moonstone!</b> Click yours to use it!`);
  log(`<span class="log-ms">Both teams have Moonstones!</span> Click yours to use — 5 seconds!`);

  const redResEl = document.getElementById('red-resources');
  const blueResEl = document.getElementById('blue-resources');
  const redMsTile  = redResEl  && redResEl.querySelector('.res-tile.moonstone');
  const blueMsTile = blueResEl && blueResEl.querySelector('.res-tile.moonstone');

  const state = { closed: false };

  const closeShared = () => {
    if (state.closed) return;
    state.closed = true;
    clearInterval(lsSharedTimer); lsSharedTimer = null;
    [redMsTile, blueMsTile].forEach(tile => {
      if (!tile) return;
      tile.classList.remove('rerollable');
      tile.onclick = null;
      tile.style.cursor = '';
    });
    document.querySelectorAll('.ls-shared-cd').forEach(el => el.remove());
  };

  const updateBadges = (r) => {
    [redMsTile, blueMsTile].forEach(tile => {
      if (!tile) return;
      let cd = tile.querySelector('.ls-shared-cd');
      if (!cd) {
        cd = document.createElement('div');
        cd.className = 'reroll-countdown ls-shared-cd';
        tile.style.position = 'relative';
        tile.appendChild(cd);
      }
      cd.textContent = r;
    });
  };

  let remaining = getSpecialsTimerSecs();
  updateBadges(remaining);
  clearInterval(lsSharedTimer); lsSharedTimer = null;
  lsSharedTimer = setInterval(() => {
    remaining--;
    if (remaining <= 0 || state.closed) {
      clearInterval(lsSharedTimer); lsSharedTimer = null;
      if (!state.closed) {
        closeShared();
        log(`<span style="color:var(--text2)">Both teams passed on their Moonstones.</span>`);
        checkLuckyStones();
      }
    } else {
      updateBadges(remaining);
    }
  }, 1000);

  // Red tile click — Red goes first; existing red→blue chain in skipMoonstone/pickMsValue
  // automatically offers Blue afterward (no afterMoonstoneCallback needed).
  if (redMsTile) {
    redMsTile.classList.add('rerollable');
    redMsTile.style.cursor = 'pointer';
    redMsTile.onclick = () => {
      if (state.closed) return;
      closeShared();
      showMoonstoneChoice('red', B.pendingResolve.redDice || B.redDice);
    };
  }

  // Blue tile click — Blue goes first; afterMoonstoneCallback offers Red afterward.
  // Zero out B.msAvailable.blue before showing Red's window so the red→blue chain
  // in skipMoonstone/pickMsValue doesn't re-offer Blue (she already had her window).
  if (blueMsTile) {
    blueMsTile.classList.add('rerollable');
    blueMsTile.style.cursor = 'pointer';
    blueMsTile.onclick = () => {
      if (state.closed) return;
      closeShared();
      showMoonstoneChoice('blue', B.pendingResolve.blueDice || B.blueDice);
      B.afterMoonstoneCallback = () => {
        delete B.afterMoonstoneCallback;
        const redMsLeft = B.msAvailable ? B.msAvailable.red : 0;
        if (redMsLeft > 0 && B.red.resources.moonstone > 0) {
          if (B.msAvailable) B.msAvailable.blue = 0; // prevent double-offer of Blue
          showMoonstoneChoice('red', B.redDice);
          // After Red: skipMoonstone/pickMsValue see Blue=0 → fall to checkLuckyStones ✓
        } else {
          checkLuckyStones();
        }
      };
    };
  }
}

// ============================================================
// SAME-TEAM UNIFIED SPECIALS WINDOW
// One team has BOTH Moonstone + Lucky Stone(s).
// Show a single reaction window with both tiles highlighted, one shared timer.
// Player can use Moonstone once AND Lucky Stones multiple times, all in the same window.
// Timer resets briefly after each action (3s extension).
// ============================================================
function startSameTeamSpecialsWindow(team, finalCallback) {
  B.phase = 'specials-unified-' + team;
  showSkipBtn(() => closeWindow());
  const tLabel = team.charAt(0).toUpperCase() + team.slice(1);
  narrate(`<b class="${team}-text">${tLabel}</b> has a <b style="color:var(--moonstone)">Moonstone</b> and a <b class="gold">Lucky Stone!</b> Click either to use!`);

  const dice = team === 'red' ? B.pendingResolve.redDice : B.pendingResolve.blueDice;
  const diceEl = document.getElementById(team + '-dice');
  const resEl = document.getElementById(team + '-resources');
  const msTile = resEl && resEl.querySelector('.res-tile.moonstone');
  const lsTile = resEl && resEl.querySelector('.res-tile.luckyStone');

  const state = { closed: false, msUsed: false, picking: false, lsUsedCount: 0 };
  let sharedTimer = null;

  // Helper to get fresh DOM refs (renderBattle rebuilds innerHTML, stale refs break)
  const getMsTile = () => { const el = document.getElementById(team + '-resources'); return el && el.querySelector('.res-tile.moonstone'); };
  const getLsTile = () => { const el = document.getElementById(team + '-resources'); return el && el.querySelector('.res-tile.luckyStone'); };

  const updateBadge = (tile, val) => {
    if (!tile) return;
    let cd = tile.querySelector('.unified-cd');
    if (!cd) { cd = document.createElement('div'); cd.className = 'reroll-countdown unified-cd'; tile.style.position = 'relative'; tile.appendChild(cd); }
    cd.textContent = val;
    cd.style.animation = 'none'; requestAnimationFrame(() => { cd.style.animation = ''; });
  };
  const updateAllBadges = (val) => {
    const ms = getMsTile(); const ls = getLsTile();
    if (!state.msUsed && ms && ms.classList.contains('rerollable')) updateBadge(ms, val);
    if (ls && ls.classList.contains('rerollable')) updateBadge(ls, val);
  };
  const clearAllBadges = () => { document.querySelectorAll('.unified-cd').forEach(el => el.remove()); };

  const closeWindow = () => {
    if (state.closed) return;
    state.closed = true;
    hideSkipBtn();
    clearInterval(sharedTimer); sharedTimer = null;
    clearAllBadges();
    const ms = getMsTile(); const ls = getLsTile();
    if (ms) { ms.classList.remove('rerollable'); ms.onclick = null; ms.style.cursor = ''; clearMsCountdown(ms); }
    if (ls) { ls.classList.remove('rerollable'); ls.onclick = null; ls.style.cursor = ''; }
    clearDiceClickable(team);
    document.querySelectorAll('.reroll-countdown').forEach(el => el.remove());
    finalCallback();
  };

  const startTimer = (secs) => {
    clearInterval(sharedTimer); sharedTimer = null;
    clearAllBadges();
    let remaining = secs;
    updateAllBadges(remaining);
    sharedTimer = setInterval(() => {
      remaining--;
      if (remaining <= 0 || state.closed) {
        clearInterval(sharedTimer); sharedTimer = null;
        if (!state.closed) {
          log(`<span style="color:var(--text2)">${team.toUpperCase()} specials window expired.</span>`);
          closeWindow();
        }
      } else {
        updateAllBadges(remaining);
      }
    }, 1000);
  };

  // Check if LS is still available and re-activate tile (with onclick re-bound)
  const refreshLsTile = () => {
    const ls = getLsTile();
    const lsAvail = B.lsAvailable ? B.lsAvailable[team] : 0;
    if (lsAvail > 0 && B[team].resources.luckyStone > 0 && ls) {
      ls.classList.add('rerollable');
      ls.style.cursor = 'pointer';
      ls.onclick = lsTileClick; // re-bind the click handler
    } else if (ls) {
      ls.classList.remove('rerollable');
      ls.onclick = null;
      ls.style.cursor = '';
    }
  };

  // Check if any action is still available, if not close
  const checkStillAvailable = () => {
    const hasMs = !state.msUsed && B[team].resources.moonstone > 0;
    const lsAvail = B.lsAvailable ? B.lsAvailable[team] : 0;
    const hasLs = lsAvail > 0 && B[team].resources.luckyStone > 0;
    if (!hasMs && !hasLs) {
      setTimeout(closeWindow, 400);
      return false;
    }
    return true;
  };

  // ─── Moonstone tile click ───
  const msTileClick = () => {
      if (state.closed || state.picking || state.msUsed) return;
      state.picking = true;
      clearInterval(sharedTimer); sharedTimer = null;
      clearAllBadges();
      const msCur = getMsTile();
      if (msCur) { msCur.classList.remove('rerollable'); msCur.onclick = null; msCur.style.cursor = ''; }

      // Enter die-pick phase for Moonstone
      B.pendingMoonstone = { team, dice: [...dice], dieIndex: null, phase: 'pick-die' };
      narrate(`<b class="${team}-text">${tLabel}</b> — pick a die to change!`);
      diceEl.querySelectorAll('.die').forEach((d, i) => {
        d.classList.add('rerollable');
        d.style.borderColor = 'var(--moonstone)';
        d.onclick = () => {
          clearInterval(msCountdownTimer);
          clearMsCountdown(diceEl);
          clearDiceClickable(team);
          document.querySelectorAll('.reroll-countdown').forEach(el => el.remove());

          // Now pick value via the standard picker
          B.pendingMoonstone.dieIndex = i;
          B.pendingMoonstone.phase = 'pick-value';
          narrate(`Die ${i+1} selected — pick a new value!`);
          document.getElementById('msPicker').classList.remove('active');
          const inlinePkr = document.getElementById('msInlinePicker');
          const inlineOps = document.getElementById('msInlineOptions');
          inlineOps.innerHTML = [1,2,3,4,5,6].map(v => `<div class="ms-die-option" onclick="pickMsValueUnified(${v})">${v}</div>`).join('');
          inlinePkr.classList.add('active');
          const arenaC = inlinePkr.parentElement;
          if (arenaC) arenaC.scrollIntoView({ behavior:'smooth', block:'center' });

          let valRem = 7;
          showLsCountdown(inlinePkr, valRem);
          msCountdownTimer = setInterval(() => {
            valRem--;
            if (valRem <= 0) {
              clearInterval(msCountdownTimer);
              el.classList.remove('active');
              clearMsCountdown(el);
              // Skip moonstone, mark as used phase
              state.msUsed = true;
              state.picking = false;
              B.pendingMoonstone = null;
              log(`<span style="color:var(--text2)">${team.toUpperCase()} holds their Moonstone.</span>`);
              if (checkStillAvailable()) {
                refreshLsTile();
                startTimer(Math.max(3, getSpecialsTimerSecs() - 2));
              }
            } else {
              showLsCountdown(el, valRem);
            }
          }, 1000);
        };
      });
      sync3dDiceClickable(team);

      // Die-pick countdown
      let pickRem = 5;
      showLsCountdown(diceEl, pickRem);
      clearInterval(msCountdownTimer);
      msCountdownTimer = setInterval(() => {
        pickRem--;
        if (pickRem <= 0) {
          clearInterval(msCountdownTimer);
          clearMsCountdown(diceEl);
          clearDiceClickable(team);
          state.msUsed = true;
          state.picking = false;
          B.pendingMoonstone = null;
          log(`<span style="color:var(--text2)">${team.toUpperCase()} holds their Moonstone.</span>`);
          if (checkStillAvailable()) {
            refreshLsTile();
            startTimer(Math.max(3, getSpecialsTimerSecs() - 2));
          }
        } else {
          showLsCountdown(diceEl, pickRem);
        }
      }, 1000);
  };

  if (msTile) {
    msTile.classList.add('rerollable');
    msTile.style.cursor = 'pointer';
    msTile.onclick = msTileClick;
  }

  // ─── Lucky Stone tile click ───
  const lsTileClick = () => {
    if (state.closed || state.picking) return;
    state.picking = true;
    clearInterval(sharedTimer); sharedTimer = null;
    clearAllBadges();
    const lsCur = getLsTile();
    if (lsCur) { lsCur.classList.remove('rerollable'); lsCur.onclick = null; lsCur.style.cursor = ''; }

    narrate(`<b class="${team}-text">${tLabel}</b> — pick a die to reroll!`);
    const liveDice = team === 'red' ? B.pendingResolve.redDice : B.pendingResolve.blueDice;
    diceEl.querySelectorAll('.die').forEach((d, i) => {
      d.classList.add('rerollable');
      d.onclick = () => {
        clearLsCountdown();
        clearDiceClickable(team);

        // Perform the reroll (prevent doLuckyReroll's own chaining — we handle it here)
        const savedAvail = B.lsAvailable ? B.lsAvailable[team] : 0;
        if (B.lsAvailable) B.lsAvailable[team] = 0;

        doLuckyReroll(team, i, liveDice, () => {
          state.picking = false;
          state.lsUsedCount++;
          if (B.lsAvailable) B.lsAvailable[team] = Math.max(0, savedAvail - 1);
          if (checkStillAvailable()) {
            refreshLsTile();
            // Re-activate MS tile if not used yet
            if (!state.msUsed && B[team].resources.moonstone > 0) {
              const msR = getMsTile();
              if (msR) { msR.classList.add('rerollable'); msR.style.cursor = 'pointer'; msR.onclick = msTileClick; }
            }
            startTimer(Math.max(3, getSpecialsTimerSecs() - 2));
          }
        });
      };
    });
    sync3dDiceClickable(team);

    let pickRem = Math.max(3, getSpecialsTimerSecs() - 2);
    showLsCountdown(diceEl, pickRem);
    clearInterval(lsCountdownTimer); lsCountdownTimer = null;
    lsCountdownTimer = setInterval(() => {
      pickRem--;
      if (pickRem <= 0) {
        clearInterval(lsCountdownTimer); lsCountdownTimer = null;
        clearLsCountdown();
        clearDiceClickable(team);
        state.picking = false;
        log(`<span style="color:var(--text2)">${team.toUpperCase()} didn't pick a die in time.</span>`);
        if (checkStillAvailable()) {
          refreshLsTile();
          if (!state.msUsed && B[team].resources.moonstone > 0) {
            const msR2 = getMsTile();
            if (msR2) { msR2.classList.add('rerollable'); msR2.style.cursor = 'pointer'; msR2.onclick = msTileClick; }
          }
          startTimer(Math.max(3, getSpecialsTimerSecs() - 2));
        }
      } else {
        showLsCountdown(diceEl, pickRem);
      }
    }, 1000);
  };

  if (lsTile) {
    lsTile.classList.add('rerollable');
    lsTile.style.cursor = 'pointer';
    lsTile.onclick = lsTileClick;
  }

  // Listen for Moonstone value selection completion
  const onMsDone = (e) => {
    if (e.detail.team !== team || state.closed) return;
    document.removeEventListener('unifiedMsDone', onMsDone);
    state.msUsed = true;
    state.picking = false;
    renderBattle();
    if (checkStillAvailable()) {
      refreshLsTile();
      startTimer(Math.max(3, getSpecialsTimerSecs() - 2));
    }
  };
  document.addEventListener('unifiedMsDone', onMsDone);

  // Start the initial shared timer
  startTimer(getSpecialsTimerSecs());
}

// Moonstone value picker callback for the unified specials window
// (separate from pickMsValue to avoid interfering with the standard MS flow)
function pickMsValueUnified(val) {
  clearInterval(msCountdownTimer);
  const ms = B.pendingMoonstone;
  if (!ms) return;
  const team = ms.team;
  const t = B[team];
  const f = active(t);

  const el = document.getElementById('msPicker');
  el.classList.remove('active');
  clearMsCountdown(el);
  document.getElementById('msInlinePicker').classList.remove('active');
  clearMsCountdown(document.getElementById('msInlinePicker'));

  // Benjamin (203) — Magic Touch: once per turn, don't decrement moonstone
  let magicTouchFired = false;
  if (f.id === 203 && !f.usedMagicTouch) {
    f.usedMagicTouch = true;
    magicTouchFired = true;
    showAbilityCallout('MAGIC TOUCH!', 'var(--moonstone)', `${f.name} — Moonstone used without discarding!`, team);
    log(`<span class="log-ability">${f.name}</span> — Magic Touch! Used Moonstone without discarding it!`);
  } else {
    t.resources.moonstone--;
    playSfx('sfxSpecial', 0.5);
  }
  applyMoonstoneSickness(team); // Moonstone Sickness — fires on USE (including Magic Touch)
  triggerCameronSpecialWatch(team, true); // Cameron (25) — Unstoppable Force (immediate post-roll die)

  ms.dice[ms.dieIndex] = val;
  ms.dice.sort((a,b)=>a-b);

  if (team==='red') B.pendingResolve.redDice = ms.dice;
  else B.pendingResolve.blueDice = ms.dice;
  B.redDice = B.pendingResolve.redDice;
  B.blueDice = B.pendingResolve.blueDice;
  renderDice(B.redDice, B.blueDice);

  const teamLabel = team.charAt(0).toUpperCase() + team.slice(1);
  log(`<span class="log-ms">Moonstone used!</span> ${team.toUpperCase()} changed die to ${val} → [${ms.dice.join(', ')}]`);
  narrate(`<b style="color:var(--moonstone)">Moonstone!</b>&nbsp;<b class="${team}-text">${teamLabel}</b> changes die to <b class="gold">${val}</b>! → [${ms.dice.join(', ')}]`);
  B.pendingMoonstone = null;

  // v731: broadcast Moonstone choice to Red's engine
  if (LIVE_PVP && PVP_SIDE === 'blue' && PVP_GAME_REF && team === 'blue') {
    PVP_GAME_REF.child('specialsChoice').push({
      type: 'moonstone',
      side: 'blue',
      dieIndex: ms.dieIndex,
      chosenValue: val,
      dice: ms.dice.slice(),
      ts: Date.now()
    });
  }

  // Bigsby (424) — Omen: if Bigsby is the active ghost when a Moonstone is used
  if (f.id === 424 && !f.ko) {
    const g = f;
    g.originalId = g.id; g.originalName = g.name; g.originalArt = g.art;
    g.originalMaxHp = g.maxHp; g.originalAbility = g.ability;
    g.originalAbilityDesc = g.abilityDesc; g.originalRarity = g.rarity;
    g.id = 112; g.name = "Doom"; g.maxHp = 7; g.hp = 7;
    g.ability = "Fiendship"; g.abilityDesc = "+2 bonus damage!";
    g.art = "art/originals/doom.jpg"; g.rarity = "legendary"; g.ko = false;
    queueAbility('TRANSFORMATION!', 'var(--legendary)', 'Bigsby sacrifices himself — DOOM rises!', null, team);
    log(`<span class="log-ability">Bigsby</span> — Omen! <span class="log-dmg">DOOM has arrived!</span>`);
    checkRipagooTransform(team);
    renderBattle();
  }

  // Dispatch a custom event so the unified window picks up the completion
  const msPostDelay = magicTouchFired ? 1600 : 1200;
  setTimeout(() => {
    document.dispatchEvent(new CustomEvent('unifiedMsDone', { detail: { team } }));
  }, msPostDelay);
}

// ============================================================
// CROSS-TYPE SPECIALS WINDOW
// One team has Moonstone, the other has Lucky Stone.
// Both tiles highlight simultaneously with a shared 5s countdown.
// If neither acts in 5s → both skip (saves ~5s vs 5s+5s sequential).
// If MS player acts first → LS player gets a fresh 5s after MS resolves.
// If LS player acts first → MS player gets a fresh 5s after LS resolves.
// ============================================================
function startCrossTypeSpecialsWindow(msTeam, lsTeam) {
  // Blue AI: if blue has either moonstone or lucky stone in cross-type window,
  // auto-use it so the player doesn't see blue's interactive prompts
  if (AI_ACTIVE && (msTeam === 'blue' || lsTeam === 'blue')) {
    // Auto-use blue's moonstone
    if (msTeam === 'blue' && B.blue.resources.moonstone > 0) {
      const dice = B.pendingResolve.blueDice || B.blueDice;
      let worstIdx = 0, worstVal = 7;
      dice.forEach((d, i) => { if (d < worstVal) { worstVal = d; worstIdx = i; } });
      dice[worstIdx] = 6;
      dice.sort((a, b) => a - b);
      B.blue.resources.moonstone--;
      applyMoonstoneSickness('blue'); // Moonstone Sickness
      triggerCameronSpecialWatch('blue', true); // Cameron (25) — Unstoppable Force (immediate post-roll die)
      B.blueDice = dice;
      log(`<span class="log-ms">BLUE uses Moonstone!</span> Changed ${worstVal} → 6!`);
      renderDice(B.redDice, B.blueDice);
    }
    // Auto-use blue's lucky stone
    if (lsTeam === 'blue' && B.blue.resources.luckyStone > 0) {
      const dice = B.pendingResolve.blueDice || B.blueDice;
      let worstIdx = 0, worstVal = 7;
      dice.forEach((d, i) => { if (d < worstVal) { worstVal = d; worstIdx = i; } });
      if (worstVal <= 4) {
        dice[worstIdx] = Math.floor(Math.random() * 6) + 1;
        dice.sort((a, b) => a - b);
        B.blue.resources.luckyStone--;
        B.blueDice = dice;
        log(`<span class="log-ms">BLUE uses Lucky Stone!</span> Rerolled ${worstVal}!`);
        renderDice(B.redDice, B.blueDice);
      }
    }
    // If the other team (red/player) still has their special, show only their window
    if (msTeam === 'red' && B.red.resources.moonstone > 0) {
      showMoonstoneChoice('red', B.pendingResolve.redDice || B.redDice);
      return;
    }
    if (lsTeam === 'red' && B.red.resources.luckyStone > 0) {
      startLuckyStoneWindow('red', () => {
        const pr = B.pendingResolve;
        if (pr) { B.pendingResolve = null; doResolve(pr.redDice, pr.blueDice, pr.redRoll, pr.blueRoll); }
      });
      return;
    }
    // Both auto-resolved — proceed to resolve
    setTimeout(() => {
      const pr = B.pendingResolve;
      if (pr) { B.pendingResolve = null; doResolve(pr.redDice, pr.blueDice, pr.redRoll, pr.blueRoll); }
    }, spd(800));
    return;
  }

  B.phase = 'specials-shared';
  const tLabel = t => t.charAt(0).toUpperCase() + t.slice(1);
  narrate(`<b class="${msTeam}-text">${tLabel(msTeam)}</b> has a <b style="color:var(--moonstone)">Moonstone</b> and <b class="${lsTeam}-text">${tLabel(lsTeam)}</b> has a <b class="gold">Lucky Stone!</b> Click yours to use it!`);

  const msDice = B.pendingResolve[msTeam === 'red' ? 'redDice' : 'blueDice'];
  const lsDice = B.pendingResolve[lsTeam === 'red' ? 'redDice' : 'blueDice'];

  const msResEl = document.getElementById(msTeam + '-resources');
  const msTile  = msResEl && msResEl.querySelector('.res-tile.moonstone');
  const lsResEl = document.getElementById(lsTeam + '-resources');
  const lsTile  = lsResEl && lsResEl.querySelector('.res-tile.luckyStone');
  const lsDiceEl = document.getElementById(lsTeam + '-dice');
  const msDiceEl = document.getElementById(msTeam + '-dice');

  const state = { closed: false };

  const closeBoth = () => {
    if (state.closed) return;
    state.closed = true;
    hideSkipBtn();
    clearInterval(lsSharedTimer); lsSharedTimer = null;
    // MS tile cleanup
    if (msTile) {
      msTile.classList.remove('rerollable');
      msTile.onclick = null;
      msTile.style.cursor = '';
      clearMsCountdown(msTile);
    }
    clearInterval(msCountdownTimer);
    // LS tile cleanup
    if (lsTile) {
      lsTile.classList.remove('rerollable');
      lsTile.onclick = null;
      lsTile.style.cursor = '';
    }
    document.querySelectorAll('.ls-shared-cd').forEach(el => el.remove());
    clearLsCountdown();
    clearDiceClickable(lsTeam);
  };
  showSkipBtn(() => closeBoth());

  // Shared countdown badges on both tiles
  const updateBadges = (r) => {
    if (msTile) {
      let cd = msTile.querySelector('.ls-shared-cd');
      if (!cd) {
        cd = document.createElement('div');
        cd.className = 'reroll-countdown ls-shared-cd';
        msTile.style.position = 'relative';
        msTile.appendChild(cd);
      }
      cd.textContent = r;
    }
    if (lsTile) {
      let cd = lsTile.querySelector('.ls-shared-cd');
      if (!cd) {
        cd = document.createElement('div');
        cd.className = 'reroll-countdown ls-shared-cd';
        lsTile.style.position = 'relative';
        lsTile.appendChild(cd);
      }
      cd.textContent = r;
    }
  };

  let remaining = getSpecialsTimerSecs();
  updateBadges(remaining);
  clearInterval(lsSharedTimer); lsSharedTimer = null;
  lsSharedTimer = setInterval(() => {
    remaining--;
    if (remaining <= 0 || state.closed) {
      clearInterval(lsSharedTimer); lsSharedTimer = null;
      if (!state.closed) {
        closeBoth();
        log(`<span style="color:var(--text2)">Both teams passed on their specials.</span>`);
        resolveRound();
      }
    } else {
      updateBadges(remaining);
    }
  }, 1000);

  // ─── MS tile click ───────────────────────────────────────────
  if (msTile) {
    msTile.classList.add('rerollable');
    msTile.style.cursor = 'pointer';
    msTile.onclick = () => {
      if (state.closed) return;
      state.closed = true; // Lock out LS click while MS overlay is up
      clearInterval(lsSharedTimer); lsSharedTimer = null;
      document.querySelectorAll('.ls-shared-cd').forEach(el => el.remove());
      // Remove LS tile highlight (overlay blocks LS interaction anyway)
      if (lsTile) { lsTile.classList.remove('rerollable'); lsTile.onclick = null; lsTile.style.cursor = ''; }
      if (msTile) { clearMsCountdown(msTile); msTile.classList.remove('rerollable'); msTile.onclick = null; msTile.style.cursor = ''; }

      // After MS completes (use or skip), offer LS player their window
      B.afterMoonstoneCallback = () => {
        delete B.afterMoonstoneCallback;
        const lsAvail = B.lsAvailable ? B.lsAvailable[lsTeam] : 0;
        if (lsAvail > 0 && B[lsTeam].resources.luckyStone > 0) {
          startLuckyStoneWindow(lsTeam, () => resolveRound());
        } else {
          resolveRound();
        }
      };

      // Enter die-pick phase directly (skip re-showing the tile countdown)
      B.pendingMoonstone = { team: msTeam, dice: [...msDice], dieIndex: null, phase: 'pick-die' };
      narrate(`<b class="${msTeam}-text">${tLabel(msTeam)}</b> — pick a die to change!`);
      msDiceEl.querySelectorAll('.die').forEach((d, i) => {
        d.classList.add('rerollable');
        d.style.borderColor = 'var(--moonstone)';
        d.onclick = () => pickMsDie(i);
      });
      sync3dDiceClickable(msTeam);
      let pickRemaining = getSpecialsTimerSecs();
      showLsCountdown(msDiceEl, pickRemaining);
      clearInterval(msCountdownTimer);
      msCountdownTimer = setInterval(() => {
        pickRemaining--;
        if (pickRemaining <= 0) {
          clearInterval(msCountdownTimer);
          clearMsCountdown(msDiceEl);
          clearDiceClickable(msTeam);
          skipMoonstone();
        } else {
          showLsCountdown(msDiceEl, pickRemaining);
        }
      }, 1000);
    };
  }

  // ─── LS tile click ───────────────────────────────────────────
  if (lsTile) {
    lsTile.classList.add('rerollable');
    lsTile.style.cursor = 'pointer';
    lsTile.onclick = () => {
      if (state.closed) return;
      state.closed = true; // Lock out MS click while LS is running
      clearInterval(lsSharedTimer); lsSharedTimer = null;
      document.querySelectorAll('.ls-shared-cd').forEach(el => el.remove());
      if (msTile) { clearMsCountdown(msTile); msTile.classList.remove('rerollable'); msTile.onclick = null; msTile.style.cursor = ''; }
      if (lsTile) { lsTile.classList.remove('rerollable'); lsTile.onclick = null; lsTile.style.cursor = ''; }

      // After LS completes, offer MS player their window
      const afterLs = () => {
        const msAvail = B.msAvailable ? B.msAvailable[msTeam] : 0;
        if (msAvail > 0 && B[msTeam].resources.moonstone > 0) {
          showMoonstoneChoice(msTeam, msTeam === 'red' ? B.redDice : B.blueDice);
          B.afterMoonstoneCallback = () => {
            delete B.afterMoonstoneCallback;
            resolveRound();
          };
        } else {
          resolveRound();
        }
      };

      // LS die-pick phase
      narrate(`<b class="${lsTeam}-text">${tLabel(lsTeam)}</b> — pick a die to reroll!`);
      lsDiceEl.querySelectorAll('.die').forEach((d, i) => {
        d.classList.add('rerollable');
        d.onclick = () => doLuckyReroll(lsTeam, i, lsDice, afterLs);
      });
      sync3dDiceClickable(lsTeam);
      let pickRemaining = Math.max(3, getSpecialsTimerSecs() - 2);
      showLsCountdown(lsDiceEl, pickRemaining);
      clearInterval(lsCountdownTimer); lsCountdownTimer = null;
      lsCountdownTimer = setInterval(() => {
        pickRemaining--;
        if (pickRemaining <= 0) {
          clearInterval(lsCountdownTimer); lsCountdownTimer = null;
          clearLsCountdown();
          clearDiceClickable(lsTeam);
          log(`<span style="color:var(--text2)">${lsTeam.toUpperCase()} didn't pick a die in time.</span>`);
          afterLs();
        } else {
          showLsCountdown(lsDiceEl, pickRemaining);
        }
      }, 1000);
    };
  }
}

// ============================================================
// v731: PvP SPECIALS SYNC — Blue broadcasts "done", Red waits
// ============================================================
// Blue calls this after all specials (MS + LS) are finished,
// right before resolveRound(). Red listens for the signal.
function pvpBroadcastSpecialsDone() {
  if (!LIVE_PVP || PVP_SIDE !== 'blue' || !PVP_GAME_REF || !B) return;
  PVP_GAME_REF.child('specialsDone').set({
    blueDice: (B.pendingResolve ? B.pendingResolve.blueDice : B.blueDice || []).slice(),
    ts: Date.now()
  });
}

// Red calls this instead of resolveRound() after its own specials.
// If Blue had any specials available this round, Red waits for Blue's
// "specialsDone" signal (with final dice). Otherwise resolves immediately.
let _pvpSpecialsDoneRef = null; // listener handle for cleanup
function pvpWaitForBlueSpecials() {
  if (!LIVE_PVP || PVP_SIDE !== 'red' || !PVP_GAME_REF || !B) { resolveRound(); return; }

  // Check if Blue had any specials this round
  const blueMsAvail = B.msAvailable ? B.msAvailable.blue : 0;
  const blueLsAvail = B.lsAvailable ? B.lsAvailable.blue : 0;
  const blueHadMS = blueMsAvail > 0 && B.blue.resources.moonstone > 0;
  const blueHadLS = blueLsAvail > 0 && B.blue.resources.luckyStone > 0;

  if (!blueHadMS && !blueHadLS) { resolveRound(); return; }

  // Wait for Blue's specialsDone signal (with timeout safety)
  log(`<span style="color:var(--text2)">Waiting for Blue's specials...</span>`);
  let resolved = false;
  const finish = (blueDice) => {
    if (resolved) return;
    resolved = true;
    if (_pvpSpecialsDoneRef) { PVP_GAME_REF.child('specialsDone').off('value', _pvpSpecialsDoneRef); _pvpSpecialsDoneRef = null; }
    clearTimeout(safetyTimeout);
    PVP_GAME_REF.child('specialsDone').set(null);
    PVP_GAME_REF.child('specialsChoice').remove();
    // Apply Blue's final dice
    if (blueDice && blueDice.length && B.pendingResolve) {
      B.pendingResolve.blueDice = blueDice;
      B.blueDice = blueDice;
      renderDice(B.pendingResolve.redDice, blueDice);
    }
    resolveRound();
  };

  _pvpSpecialsDoneRef = PVP_GAME_REF.child('specialsDone').on('value', snap => {
    const data = snap.val();
    if (!data || !data.blueDice) return;
    finish(data.blueDice);
  });

  // Safety timeout — if Blue disconnects or something breaks, don't deadlock
  const safetyTimeout = setTimeout(() => {
    if (!resolved) {
      log(`<span style="color:var(--text2)">Blue specials timed out — resolving with current dice.</span>`);
      finish(null);
    }
  }, 15000);
}

// ============================================================
// LUCKY STONE — countdown + clickable dice reroll
// ============================================================
let lsCountdownTimer = null;
let lsSharedTimer = null; // separate timer for the simultaneous Lucky Stone window

function checkLuckyStones() {
  // Only offer Lucky Stones that existed BEFORE this round (not gained this turn)
  const redAvail = B.lsAvailable ? B.lsAvailable.red : 0;
  const blueAvail = B.lsAvailable ? B.lsAvailable.blue : 0;
  const redHasLS = redAvail > 0 && B.red.resources.luckyStone > 0;
  const blueHasLS = blueAvail > 0 && B.blue.resources.luckyStone > 0;

  if (!redHasLS && !blueHasLS) { resolveRound(); return; }

  // v728: PvP Blue local resolution — show Blue's own LS picker, skip Red's
  if (LIVE_PVP && PVP_SIDE === 'blue' && pvpBlueResolvedLocally) {
    if (blueHasLS) {
      startLuckyStoneWindow('blue', () => { pvpBroadcastSpecialsDone(); resolveRound(); });
    } else {
      pvpBroadcastSpecialsDone(); // v731: tell Red we're done with specials
      resolveRound();
    }
    return;
  }
  // v728: PvP Red — show Red's own LS picker, skip Blue's
  if (LIVE_PVP && PVP_SIDE === 'red') {
    if (redHasLS) {
      startLuckyStoneWindow('red', () => pvpWaitForBlueSpecials());
    } else {
      pvpWaitForBlueSpecials(); // v731: wait for Blue's LS/MS choices before resolving
    }
    return;
  }

  // Both teams have Lucky Stones — show simultaneously (saves up to 3s vs sequential)
  if (redHasLS && blueHasLS) {
    startSimultaneousLuckyStoneWindows();
    return;
  }

  // Only one team has stones — single sequential window (unchanged)
  if (redHasLS) { startLuckyStoneWindow('red', () => resolveRound()); return; }
  startLuckyStoneWindow('blue', () => resolveRound());
}

// Simultaneous Lucky Stone window: both teams' tiles highlight at the same time.
// Shared 5-second countdown. Either team can act; die-pick phases are serialized
// (one team at a time) to avoid timer conflicts on lsCountdownTimer.
function startSimultaneousLuckyStoneWindows() {
  B.phase = 'luckystone-shared';
  narrate(`Both teams have <b class="gold">Lucky Stones!</b> Click yours to use it!`);

  const state = { redDone: false, blueDone: false, pickingTeam: null, closed: false };

  const closeShared = () => {
    if (state.closed) return;
    state.closed = true;
    hideSkipBtn();
    clearInterval(lsSharedTimer); lsSharedTimer = null;
    clearLsCountdown();
    ['red', 'blue'].forEach(t => {
      clearDiceClickable(t);
      const resEl = document.getElementById(t + '-resources');
      const lsEl = resEl && resEl.querySelector('.res-tile.luckyStone');
      if (lsEl) { lsEl.classList.remove('rerollable'); lsEl.onclick = null; lsEl.style.cursor = ''; }
    });
    document.querySelectorAll('.ls-shared-cd').forEach(el => el.remove());
    resolveRound();
  };
  showSkipBtn(() => closeShared());

  const checkBothDone = () => { if (state.redDone && state.blueDone) closeShared(); };

  // Show/update the shared countdown badge on both active tiles
  const updateSharedBadges = (remaining) => {
    ['red', 'blue'].forEach(t => {
      const done = t === 'red' ? state.redDone : state.blueDone;
      if (done || state.pickingTeam === t) return;
      const resEl = document.getElementById(t + '-resources');
      const lsEl = resEl && resEl.querySelector('.res-tile.luckyStone');
      if (!lsEl || !lsEl.classList.contains('rerollable')) return;
      let cd = lsEl.querySelector('.ls-shared-cd');
      if (!cd) {
        cd = document.createElement('div');
        cd.className = 'reroll-countdown ls-shared-cd';
        lsEl.style.position = 'relative';
        lsEl.appendChild(cd);
      }
      cd.textContent = remaining;
      cd.style.animation = 'none';
      requestAnimationFrame(() => { cd.style.animation = ''; });
    });
  };

  const restartSharedCountdown = (secs) => {
    if (state.closed) return;
    clearInterval(lsSharedTimer); lsSharedTimer = null;
    document.querySelectorAll('.ls-shared-cd').forEach(el => el.remove());
    let remaining = secs;
    updateSharedBadges(remaining);
    lsSharedTimer = setInterval(() => {
      remaining--;
      if (remaining <= 0 || state.closed) {
        clearInterval(lsSharedTimer); lsSharedTimer = null;
        document.querySelectorAll('.ls-shared-cd').forEach(el => el.remove());
        if (!state.closed) {
          log(`<span style="color:var(--text2)">Lucky Stone window expired.</span>`);
          closeShared();
        }
      } else {
        updateSharedBadges(remaining);
      }
    }, 1000);
  };

  // Activate a team's LS tile in shared mode
  const activateTile = (team) => {
    if (state.closed || (team === 'red' ? state.redDone : state.blueDone)) return;
    const dice = team === 'red' ? B.pendingResolve.redDice : B.pendingResolve.blueDice;
    const resEl = document.getElementById(team + '-resources');
    const lsEl = resEl && resEl.querySelector('.res-tile.luckyStone');
    const diceEl = document.getElementById(team + '-dice');
    const teamLabel = team.charAt(0).toUpperCase() + team.slice(1);
    if (!lsEl) { if (team === 'red') state.redDone = true; else state.blueDone = true; return; }

    lsEl.classList.add('rerollable');
    lsEl.style.cursor = 'pointer';
    lsEl.onclick = () => {
      if (state.closed || state.pickingTeam) return; // serialized: wait if other team is picking
      state.pickingTeam = team;
      // Pause shared countdown while this team picks a die
      clearInterval(lsSharedTimer); lsSharedTimer = null;
      document.querySelectorAll('.ls-shared-cd').forEach(el => el.remove());
      lsEl.classList.remove('rerollable'); lsEl.onclick = null; lsEl.style.cursor = '';

      narrate(`<b class="${team}-text">${teamLabel}</b> — pick a die to reroll!`);
      const dieDivs = diceEl.querySelectorAll('.die');
      dieDivs.forEach((d, i) => {
        d.classList.add('rerollable');
        d.onclick = () => {
          clearLsCountdown();
          clearDiceClickable(team);
          // Zero lsAvailable[team] so doLuckyReroll won't spawn a new sequential window;
          // we handle multi-stone re-offering ourselves in the callback.
          const savedAvail = B.lsAvailable ? B.lsAvailable[team] : 0;
          if (B.lsAvailable) B.lsAvailable[team] = 0;

          doLuckyReroll(team, i, dice, () => {
            state.pickingTeam = null;
            if (B.lsAvailable) B.lsAvailable[team] = Math.max(0, savedAvail - 1);
            const tObj = B[team];
            const stillAvail = B.lsAvailable ? B.lsAvailable[team] : 0;
            if (tObj.resources.luckyStone > 0 && stillAvail > 0) {
              // More stones — re-activate tile, resume shared countdown.
              // stillAvail is already correctly set to savedAvail-1 (line above),
              // representing the remaining authorized uses. Do NOT decrement again here —
              // the next click will capture the correct savedAvail from B.lsAvailable[team].
              setTimeout(() => { if (state.closed) return; activateTile(team); restartSharedCountdown(getSpecialsTimerSecs()); }, 600);
            } else {
              if (team === 'red') state.redDone = true; else state.blueDone = true;
              if (!state.closed) {
                const otherDone = team === 'red' ? state.blueDone : state.redDone;
                if (!otherDone) setTimeout(() => restartSharedCountdown(getSpecialsTimerSecs()), 600);
                else checkBothDone();
              }
            }
          });
        };
      });
      sync3dDiceClickable(team);

      // 3s die-pick sub-countdown (safe: serialized by pickingTeam)
      let pickRem = Math.max(3, getSpecialsTimerSecs() - 2);
      showLsCountdown(diceEl, pickRem);
      lsCountdownTimer = setInterval(() => {
        pickRem--;
        if (pickRem <= 0) {
          clearLsCountdown();
          clearDiceClickable(team);
          log(`<span style="color:var(--text2)">${team.toUpperCase()} didn't pick a die in time.</span>`);
          state.pickingTeam = null;
          if (team === 'red') state.redDone = true; else state.blueDone = true;
          if (!state.closed) {
            const otherDone = team === 'red' ? state.blueDone : state.redDone;
            if (!otherDone) setTimeout(() => restartSharedCountdown(Math.max(3, getSpecialsTimerSecs() - 2)), 100);
            else checkBothDone();
          }
        } else { showLsCountdown(diceEl, pickRem); }
      }, 1000);
    };
  };

  // Activate both tiles simultaneously
  activateTile('red');
  activateTile('blue');

  // AI blue: auto-use Lucky Stone (reroll lowest die) instead of waiting for DOM click
  if (AI_ACTIVE && !state.blueDone) {
    const dice = B.pendingResolve ? B.pendingResolve.blueDice : null;
    if (dice && B.blue.resources.luckyStone > 0) {
      let worstIdx = 0, worstVal = 7;
      dice.forEach((d, i) => { if (d < worstVal) { worstVal = d; worstIdx = i; } });
      if (worstVal <= 4) {
        B.blue.resources.luckyStone--;
        B.luckyStoneSpentThisTurn.blue++;
        const newVal = Math.floor(Math.random() * 6) + 1;
        dice[worstIdx] = newVal;
        dice.sort((a, b) => a - b);
        log(`<span class="log-ms">BLUE uses Lucky Stone!</span> Rerolled ${worstVal} → ${newVal}!`);
        narrate(`<b class="blue-text">Blue</b> uses <b class="gold">Lucky Stone!</b> ${worstVal} → ${newVal}!`);
        renderDice(B.redDice, B.blueDice);
        renderBattle();
      } else {
        log(`<span style="color:var(--text2)">BLUE holds Lucky Stone (${worstVal} is good enough).</span>`);
      }
    }
    // Mark blue as done — clear its tile
    state.blueDone = true;
    const blueResEl = document.getElementById('blue-resources');
    const blueLsEl = blueResEl && blueResEl.querySelector('.res-tile.luckyStone');
    if (blueLsEl) { blueLsEl.classList.remove('rerollable'); blueLsEl.onclick = null; blueLsEl.style.cursor = ''; }
  }

  checkBothDone(); // in case neither team had a tile element (or AI already resolved blue)
  if (!state.closed) restartSharedCountdown(getSpecialsTimerSecs());
}

// ============================================================
// FLICK — Charlie (18) physics-based die fling
// Normal roll plays out fully. Lowest die slides below the tray
// into open arena space. Player grabs and flings it upward into
// the lined-up dice. Physics runs in arena-center space — the
// tray has NO walls. All moved dice get new random results.
// ============================================================
function showFlickPicker(team, callback) {
  B.phase = 'flick-' + team;
  const myDice = team === 'red' ? B.pendingResolve.redDice : B.pendingResolve.blueDice;
  const oppTeam = team === 'red' ? 'blue' : 'red';
  const oppDice = team === 'red' ? B.pendingResolve.blueDice : B.pendingResolve.redDice;
  const teamLabel = team.charAt(0).toUpperCase() + team.slice(1);

  // Blue AI: auto-Flick lowest die into opponent's highest
  if (AI_ACTIVE && team === 'blue') {
    const oldVal = myDice[0];
    myDice[0] = Math.floor(Math.random() * 6) + 1;
    myDice.sort((a, b) => a - b);
    log(`<span class="log-ability">Charlie</span> — Rush! Flicked ${oldVal} → <b>${myDice[0]}</b>!`);
    if (oppDice.length > 0) {
      const ti = oppDice.length - 1;
      const tOld = oppDice[ti];
      oppDice[ti] = Math.floor(Math.random() * 6) + 1;
      oppDice.sort((a, b) => a - b);
      log(`<span class="log-ability">Charlie</span> — Contact! ${oppTeam} die ${tOld} → <b>${oppDice[oppDice.length-1]}</b>!`);
    }
    B.redDice = B.pendingResolve.redDice;
    B.blueDice = B.pendingResolve.blueDice;
    renderDice(B.redDice, B.blueDice);
    showAbilityCallout('RUSH!', '#f59e0b', 'Charlie — Flick!', team);
    setTimeout(() => callback(), spd(800));
    return;
  }

  narrate(`<b class="${team}-text">${teamLabel}</b> — <b style="color:#f59e0b">Rush!</b> Grab &amp; fling your lowest die!`);
  log(`<span class="log-ability">Charlie</span> — Rush! Flick activated!`);
  showAbilityCallout('RUSH!', '#f59e0b', 'Charlie — Fling a die!', team);

  // 1. Kill 3D dice, render flat
  ['red','blue'].forEach(t => {
    const ph = _dicePhysics[t];
    if (ph) { cancelAnimationFrame(ph.raf); ph.els.forEach(e => e.remove()); delete _dicePhysics[t]; }
  });
  renderDice(B.redDice, B.blueDice);

  // 2. Use full arena-board as physics space (entire battle screen)
  const board = document.querySelector('.arena-board');
  const center = document.querySelector('.arena-center');
  const centerRect = board.getBoundingClientRect();
  const physW = board.offsetWidth;
  const physH = board.offsetHeight;
  const tray = document.querySelector('.dice-stack');
  const trayRect = tray.getBoundingClientRect();
  const redRow = document.getElementById('red-dice');
  const blueRow = document.getElementById('blue-dice');
  const redDieEls = [...redRow.querySelectorAll('.die')];
  const blueDieEls = [...blueRow.querySelectorAll('.die')];
  const dieSize = redDieEls[0]?.offsetWidth || 56;
  const dieR = dieSize / 2;

  // 3. Record positions, create 3D physics dice
  const bodies = [];
  const allEls = [...redDieEls, ...blueDieEls];
  const flickEls = []; // 3D elements to clean up

  allEls.forEach((el, i) => {
    const r = el.getBoundingClientRect();
    const cx = r.left - centerRect.left + r.width / 2;
    const cy = r.top - centerRect.top + r.height / 2;
    const dTeam = i < redDieEls.length ? 'red' : 'blue';
    const dIdx = i < redDieEls.length ? i : i - redDieEls.length;
    const val = dTeam === 'red' ? B.redDice[dIdx] : B.blueDice[dIdx];

    // Create 3D die (same structure as showRolling)
    const die3d = document.createElement('div');
    die3d.className = 'die-physics';
    die3d.style.width = dieSize + 'px';
    die3d.style.height = dieSize + 'px';
    die3d.style.zIndex = '100';
    die3d.style.setProperty('--dh', dieR + 'px');
    die3d.innerHTML = `<div class="die-cube">${cube3dHTML(dTeam)}</div>`;
    const cube = die3d.querySelector('.die-cube');
    const ft = FACE_TARGET[val] || { rx: 0, ry: 0 };

    bodies.push({
      el: die3d, cube,
      cx, cy, vx: 0, vy: 0,
      rx: ft.rx, ry: ft.ry, rz: 0,
      vrx: 0, vry: 0, vrz: 0,
      origCx: cx, origCy: cy,
      team: dTeam, dieIndex: dIdx,
      isFlicker: dTeam === team && dIdx === 0,
      moved: false
    });
    flickEls.push(die3d);
  });

  // 4. Place 3D dice on arena-board, hide flat dice
  board.style.position = 'relative';
  board.style.overflow = 'hidden';
  redRow.style.visibility = 'hidden';
  blueRow.style.visibility = 'hidden';
  bodies.forEach(b => {
    b.el.style.left = (b.cx - dieR) + 'px';
    b.el.style.top = (b.cy - dieR) + 'px';
    b.cube.style.transform = `rotateX(${b.rx}deg) rotateY(${b.ry}deg)`;
    board.appendChild(b.el);
  });

  // 5. Position flicker die below tray, centered on board
  const flicker = bodies.find(b => b.isFlicker);
  const trayBottom = trayRect.bottom - centerRect.top;
  flicker.cx = physW / 2; // centered on the full board
  flicker.cy = trayBottom + dieSize * 0.8;
  // Clamp so it stays inside arena-center
  flicker.cy = Math.min(flicker.cy, physH - dieR - 8);
  flicker.origCx = flicker.cx;
  flicker.origCy = flicker.cy;
  flicker.el.style.transition = 'left 0.3s ease-out, top 0.3s ease-out';
  flicker.el.style.left = (flicker.cx - dieR) + 'px';
  flicker.el.style.top = (flicker.cy - dieR) + 'px';
  flicker.el.style.filter = 'drop-shadow(0 0 12px rgba(245,158,11,0.9))';
  flicker.el.style.cursor = 'grab';
  setTimeout(() => { flicker.el.style.transition = 'none'; }, 350);

  // -- Restore helper --
  const restoreLayout = () => {
    clearLsCountdown();
    flickEls.forEach(el => el.remove()); // remove 3D physics dice
    redRow.style.visibility = '';
    blueRow.style.visibility = '';
    board.style.overflow = '';
  };

  // 6. Mouse / touch fling
  let isDragging = false;
  let mouseHist = [];
  let launched = false;
  let flickRaf = null;

  const evtXY = (e) => {
    const src = e.touches ? e.touches[0] : e;
    return { x: src.clientX - centerRect.left, y: src.clientY - centerRect.top };
  };

  const onDown = (e) => {
    if (launched) return;
    e.preventDefault();
    const p = evtXY(e);
    const dx = p.x - flicker.cx, dy = p.y - flicker.cy;
    if (Math.sqrt(dx * dx + dy * dy) > dieR * 2.5) return;
    isDragging = true;
    flicker.el.style.cursor = 'grabbing';
    mouseHist = [{ x: p.x, y: p.y, t: performance.now() }];
  };

  const onMove = (e) => {
    if (!isDragging) return;
    e.preventDefault();
    const p = evtXY(e);
    p.x = Math.max(dieR, Math.min(physW - dieR, p.x));
    p.y = Math.max(dieR, Math.min(physH - dieR, p.y));
    mouseHist.push({ x: p.x, y: p.y, t: performance.now() });
    if (mouseHist.length > 12) mouseHist.shift();
    flicker.cx = p.x;
    flicker.cy = p.y;
    flicker.el.style.left = (p.x - dieR) + 'px';
    flicker.el.style.top = (p.y - dieR) + 'px';
  };

  const removeListeners = () => {
    flicker.el.removeEventListener('mousedown', onDown);
    flicker.el.removeEventListener('touchstart', onDown);
    document.removeEventListener('mousemove', onMove);
    document.removeEventListener('mouseup', onUp);
    document.removeEventListener('touchmove', onMove);
    document.removeEventListener('touchend', onUp);
  };

  const onUp = (e) => {
    if (!isDragging) return;
    isDragging = false;
    launched = true;
    flicker.el.style.cursor = '';
    clearLsCountdown();
    removeListeners();

    const now = performance.now();
    const recent = mouseHist.filter(p => now - p.t < 150);
    if (recent.length >= 2) {
      const first = recent[0], last = recent[recent.length - 1];
      const dt = Math.max((last.t - first.t) / 16.67, 0.5);
      flicker.vx = (last.x - first.x) / dt;
      flicker.vy = (last.y - first.y) / dt;
      const sp = Math.sqrt(flicker.vx * flicker.vx + flicker.vy * flicker.vy);
      if (sp > 35) { flicker.vx = (flicker.vx / sp) * 35; flicker.vy = (flicker.vy / sp) * 35; }
      if (sp < 2) { flicker.vx = 0; flicker.vy = 0; }
    }

    playSfx('sfxDiceRoll');
    physStart = performance.now(); // start timer NOW, not when UI appeared
    flickRaf = requestAnimationFrame(physStep);
  };

  flicker.el.addEventListener('mousedown', onDown);
  flicker.el.addEventListener('touchstart', onDown, { passive: false });
  document.addEventListener('mousemove', onMove);
  document.addEventListener('mouseup', onUp);
  document.addEventListener('touchmove', onMove, { passive: false });
  document.addEventListener('touchend', onUp);

  // 7. Physics — full arena-board walls, force-settle after 2.5s
  const BOUNCE_WALL = 0.5;   // walls absorb energy
  const BOUNCE_DIE = 0.85;   // die-die collisions: punchy but energy-losing
  const SETTLE_THRESH = 0.3;
  const PAD = 12;
  let collisionCooldown = 0;
  let physStart = 0; // set when fling launches, not when UI appears
  const FORCE_SETTLE_MS = 2500; // force stop after 2.5 seconds

  const physStep = () => {
    let maxSpd = 0;
    collisionCooldown = Math.max(0, collisionCooldown - 1);

    // Time-based friction ramp: starts normal, ramps hard after 1.5s
    const elapsed = performance.now() - physStart;
    const baseFriction = 0.96;
    const friction = elapsed > 1500
      ? baseFriction * Math.pow(0.97, (elapsed - 1500) / 100) // progressive slowdown
      : baseFriction;

    // Force settle if time exceeded
    if (elapsed > FORCE_SETTLE_MS) {
      cancelAnimationFrame(flickRaf);
      settleFlick();
      return;
    }

    // Sub-step physics to prevent tunneling at high velocity
    // At max fling (35 px/frame) and dieSize ~56, a die can skip past another.
    // 3 sub-steps = max ~12 px/step, well within the 56px collision radius.
    const SUB_STEPS = 3;
    const subFric = Math.pow(friction, 1 / SUB_STEPS);
    for (let ss = 0; ss < SUB_STEPS; ss++) {
      bodies.forEach(b => {
        b.cx += b.vx / SUB_STEPS; b.cy += b.vy / SUB_STEPS;
        b.vx *= subFric; b.vy *= subFric;
      });

      // Elastic collisions
      for (let i = 0; i < bodies.length; i++) {
        for (let j = i + 1; j < bodies.length; j++) {
          const a = bodies[i], c = bodies[j];
          const dx = c.cx - a.cx, dy = c.cy - a.cy;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < dieSize && dist > 0.01) {
            const nx = dx / dist, ny = dy / dist;
            const rvn = (a.vx - c.vx) * nx + (a.vy - c.vy) * ny;
            if (rvn > 0) {
              const imp = rvn * BOUNCE_DIE;
              a.vx -= imp * nx; a.vy -= imp * ny;
              c.vx += imp * nx; c.vy += imp * ny;
              // 3D tumble on impact
              const spinF = Math.min(rvn * 20, 400);
              a.vrx += (Math.random()-0.5) * spinF; a.vry += (Math.random()-0.5) * spinF; a.vrz += (Math.random()-0.5) * spinF * 0.5;
              c.vrx += (Math.random()-0.5) * spinF; c.vry += (Math.random()-0.5) * spinF; c.vrz += (Math.random()-0.5) * spinF * 0.5;
              if (collisionCooldown === 0) { playSfx('sfxDiceRoll', 0.15); collisionCooldown = 10; }
            }
            const ov = (dieSize - dist) / 2 + 0.5;
            a.cx -= ov * nx; a.cy -= ov * ny;
            c.cx += ov * nx; c.cy += ov * ny;
          }
        }
      }

      // Wall bounce
      bodies.forEach(b => {
        if (b.cx - dieR < PAD) { b.cx = PAD + dieR; b.vx = Math.abs(b.vx) * BOUNCE_WALL; b.vrx += (Math.random()-0.5)*120; b.vry += (Math.random()-0.5)*120; }
        if (b.cx + dieR > physW - PAD) { b.cx = physW - PAD - dieR; b.vx = -Math.abs(b.vx) * BOUNCE_WALL; b.vrx += (Math.random()-0.5)*120; b.vry += (Math.random()-0.5)*120; }
        if (b.cy - dieR < PAD) { b.cy = PAD + dieR; b.vy = Math.abs(b.vy) * BOUNCE_WALL; b.vrx += (Math.random()-0.5)*120; b.vry += (Math.random()-0.5)*120; }
        if (b.cy + dieR > physH - PAD) { b.cy = physH - PAD - dieR; b.vy = -Math.abs(b.vy) * BOUNCE_WALL; b.vrx += (Math.random()-0.5)*120; b.vry += (Math.random()-0.5)*120; }
      });
    }

    // Update 3D rotation — [shadow] perf: batch all JS reads before DOM writes to avoid layout thrash
    // Pass 1: all state updates + settle-threshold check (reads only)
    bodies.forEach(b => {
      b.rx += b.vrx; b.ry += b.vry; b.rz += b.vrz;
      b.vrx *= 0.93; b.vry *= 0.93; b.vrz *= 0.93; // angular friction
      const s = Math.sqrt(b.vx * b.vx + b.vy * b.vy);
      const rotSpd = Math.abs(b.vrx) + Math.abs(b.vry) + Math.abs(b.vrz);
      const totalMotion = s + rotSpd * 0.05;
      if (totalMotion > maxSpd) maxSpd = totalMotion;
    });
    // Pass 2: all DOM writes (batched to prevent interleaved forced reflow)
    bodies.forEach(b => {
      b.el.style.left = (b.cx - dieR) + 'px';
      b.el.style.top = (b.cy - dieR) + 'px';
      b.cube.style.transform = `rotateX(${b.rx}deg) rotateY(${b.ry}deg) rotateZ(${b.rz}deg)`;
    });

    if (maxSpd < SETTLE_THRESH) {
      cancelAnimationFrame(flickRaf);
      settleFlick();
    } else {
      flickRaf = requestAnimationFrame(physStep);
    }
  };

  // 8. Settle — read face value from 3D rotation, snap to nearest face
  const settleFlick = () => {
    let changed = 0;
    const flickerBody = bodies.find(b => b.isFlicker);
    bodies.forEach(b => {
      const dx = b.cx - b.origCx, dy = b.cy - b.origCy;
      b.moved = !b.isFlicker && Math.sqrt(dx * dx + dy * dy) > 15;
      if (b.moved) {
        changed++;
        // The 3D rotation determines the new value — not random!
        const nv = getFlickFaceValue(b.rx, b.ry);
        const ft = FACE_TARGET[nv] || { rx: 0, ry: 0 };
        b.cube.style.transition = 'transform 0.35s cubic-bezier(0.25,0.1,0.25,1)';
        b.cube.style.transform = `rotateX(${nearestSnap(b.rx, ft.rx)}deg) rotateY(${nearestSnap(b.ry, ft.ry)}deg) rotateZ(${nearestSnap(b.rz, 0)}deg)`;
        if (b.team === 'red') B.pendingResolve.redDice[b.dieIndex] = nv;
        else B.pendingResolve.blueDice[b.dieIndex] = nv;
      } else {
        // Didn't move or is the flicker die — snap to original/current face
        const val = b.isFlicker
          ? getFlickFaceValue(b.rx, b.ry)
          : (b.team === 'red' ? B.pendingResolve.redDice[b.dieIndex] : B.pendingResolve.blueDice[b.dieIndex]);
        if (b.isFlicker) {
          // Flicker die always changes its own value
          if (b.team === 'red') B.pendingResolve.redDice[b.dieIndex] = val;
          else B.pendingResolve.blueDice[b.dieIndex] = val;
        }
        const ft = FACE_TARGET[val] || { rx: 0, ry: 0 };
        b.cube.style.transition = 'transform 0.35s cubic-bezier(0.25,0.1,0.25,1)';
        b.cube.style.transform = `rotateX(${nearestSnap(b.rx, ft.rx)}deg) rotateY(${nearestSnap(b.ry, ft.ry)}deg) rotateZ(${nearestSnap(b.rz, 0)}deg)`;
      }
    });

    B.pendingResolve.redDice.sort((a, b) => a - b);
    B.pendingResolve.blueDice.sort((a, b) => a - b);
    B.redDice = B.pendingResolve.redDice;
    B.blueDice = B.pendingResolve.blueDice;

    if (changed > 0) {
      log(`<span class="log-ability">Charlie</span> — Flick! <b>${changed}</b> dice changed! → Red [${B.redDice.join(',')}] Blue [${B.blueDice.join(',')}]`);
      narrate(`<b style="color:#f59e0b">Flick!</b> ${changed} dice changed!`);
    } else {
      // MISS! — didn't hit any dice
      log(`<span class="log-ability">Charlie</span> — Flick missed! No contact.`);
      showAbilityCallout('MISS!', '#ef4444', 'Charlie whiffed the Flick!', flickerBody ? flickerBody.team : team);
      narrate(`<b style="color:#ef4444">MISS!</b> Charlie whiffed the Flick!`);
    }

    setTimeout(() => {
      restoreLayout();
      renderDice(B.redDice, B.blueDice);
      renderBattle();
      setTimeout(() => callback(), spd(400));
    }, spd(900));
  };

  // 9. Timeout
  let remaining = getSpecialsTimerSecs() + 3;
  showLsCountdown(center, remaining);
  lsCountdownTimer = setInterval(() => {
    remaining--;
    if (remaining <= 0) {
      clearLsCountdown();
      if (flickRaf) cancelAnimationFrame(flickRaf);
      removeListeners();
      restoreLayout();
      renderDice(B.redDice, B.blueDice);
      log(`<span style="color:var(--text2)">Charlie didn't Flick in time.</span>`);
      B.redDice = B.pendingResolve.redDice;
      B.blueDice = B.pendingResolve.blueDice;
      callback();
    } else if (!launched) {
      showLsCountdown(center, remaining);
    }
  }, 1000);
}

function startLuckyStoneWindow(team, callback) {
  // Blue AI: auto-use lucky stone (reroll lowest die)
  if (AI_ACTIVE && team === 'blue') {
    B.phase = 'luckystone-' + team;
    const dice = team === 'red' ? B.pendingResolve.redDice : B.pendingResolve.blueDice;
    if (dice && B[team].resources.luckyStone > 0) {
      let worstIdx = 0, worstVal = 7;
      dice.forEach((d, i) => { if (d < worstVal) { worstVal = d; worstIdx = i; } });
      if (worstVal <= 4) {
        B[team].resources.luckyStone--;
        B.luckyStoneSpentThisTurn[team]++;
        const newVal = Math.floor(Math.random() * 6) + 1;
        dice[worstIdx] = newVal;
        dice.sort((a, b) => a - b);
        log(`<span class="log-ms">${team.toUpperCase()} uses Lucky Stone!</span> Rerolled ${worstVal} → ${newVal}!`);
        narrate(`<b class="${team}-text">Blue</b> uses <b class="gold">Lucky Stone!</b> ${worstVal} → ${newVal}!`);
        renderDice(B.redDice, B.blueDice);
        renderBattle();
      } else {
        log(`<span style="color:var(--text2)">${team.toUpperCase()} holds Lucky Stone (${worstVal} is good enough).</span>`);
      }
    }
    setTimeout(() => callback(), spd(800));
    return;
  }

  B.phase = 'luckystone-' + team;
  const dice = team === 'red' ? B.pendingResolve.redDice : B.pendingResolve.blueDice;
  const teamLabel = team.charAt(0).toUpperCase() + team.slice(1);
  let _lsSkipped = false;
  const skipLs = () => {
    if (_lsSkipped) return;
    _lsSkipped = true;
    hideSkipBtn();
    clearInterval(lsCountdownTimer);
    clearLsCountdown();
    clearDiceClickable(team);
    const resEl = document.getElementById(team + '-resources');
    const lsEl = resEl && resEl.querySelector('.res-tile.luckyStone');
    if (lsEl) { lsEl.classList.remove('rerollable'); lsEl.onclick = null; lsEl.style.cursor = ''; }
    log(`<span style="color:var(--text2)">${team.toUpperCase()} skipped Lucky Stone.</span>`);
    callback();
  };
  showSkipBtn(skipLs);

  narrate(`<b class="${team}-text">${teamLabel}</b> has a <b class="gold">Lucky Stone!</b>&nbsp;Click it to use!`);

  // Highlight the Lucky Stone resource tile — player clicks IT first
  const resEl = document.getElementById(team + '-resources');
  const lsEl = resEl.querySelector('.res-tile.luckyStone');
  const diceEl = document.getElementById(team + '-dice');
  const countdownTarget = lsEl || diceEl;

  if (lsEl) {
    lsEl.classList.add('rerollable');
    lsEl.style.cursor = 'pointer';
    lsEl.onclick = () => {
      // Player clicked Lucky Stone — stop the old tile countdown, start a fresh one for die picking
      clearInterval(lsCountdownTimer);
      clearLsCountdown(); // remove countdown display from the tile
      lsEl.classList.remove('rerollable');
      lsEl.onclick = null;
      narrate(`<b class="${team}-text">${teamLabel}</b> — pick a die to reroll!`);
      const dieDivs = diceEl.querySelectorAll('.die');
      dieDivs.forEach((d, i) => {
        d.classList.add('rerollable');
        d.onclick = () => doLuckyReroll(team, i, dice, callback);
      });
      sync3dDiceClickable(team);
      // Fresh 3s countdown on the dice row — mirrors Moonstone's pick-die phase
      let pickRemaining = Math.max(3, getSpecialsTimerSecs() - 2);
      showLsCountdown(diceEl, pickRemaining);
      lsCountdownTimer = setInterval(() => {
        pickRemaining--;
        if (pickRemaining <= 0) {
          clearLsCountdown();
          clearDiceClickable(team);
          log(`<span style="color:var(--text2)">${team.toUpperCase()} didn't pick a die in time.</span>`);
          callback();
        } else {
          showLsCountdown(diceEl, pickRemaining);
        }
      }, 1000);
    };
  } else {
    // No resource tile visible — fall back to direct dice click
    const dieDivs = diceEl.querySelectorAll('.die');
    dieDivs.forEach((d, i) => {
      d.classList.add('rerollable');
      d.onclick = () => doLuckyReroll(team, i, dice, callback);
    });
    sync3dDiceClickable(team);
  }

  // Start countdown — auto-skip if not used
  let remaining = getSpecialsTimerSecs();
  showLsCountdown(countdownTarget, remaining);

  lsCountdownTimer = setInterval(() => {
    remaining--;
    if (remaining <= 0) {
      clearLsCountdown();
      clearDiceClickable(team);
      if (lsEl) { lsEl.classList.remove('rerollable'); lsEl.onclick = null; }
      log(`<span style="color:var(--text2)">${team.toUpperCase()} didn't use their Lucky Stone.</span>`);
      callback();
    } else {
      showLsCountdown(countdownTarget, remaining);
    }
  }, 1000);
}

function showLsCountdown(parentEl, num) {
  let cd = parentEl.querySelector('.reroll-countdown');
  if (!cd) {
    cd = document.createElement('div');
    cd.className = 'reroll-countdown';
    parentEl.style.position = 'relative';
    parentEl.appendChild(cd);
  }
  cd.textContent = num;
  cd.style.animation = 'none';
  requestAnimationFrame(() => { cd.style.animation = ''; });
}

function clearLsCountdown() {
  if (lsCountdownTimer) { clearInterval(lsCountdownTimer); lsCountdownTimer = null; }
  document.querySelectorAll('.reroll-countdown').forEach(el => el.remove());
}

function clearDiceClickable(team) {
  const diceEl = document.getElementById(team + '-dice');
  diceEl.querySelectorAll('.die').forEach(d => {
    d.classList.remove('rerollable');
    d.onclick = null;
  });
  // Also clear 3D dice rerollable state
  const physics = _dicePhysics[team];
  if (physics && physics.settled) {
    physics.dice.forEach(d => {
      d.el.classList.remove('rerollable-3d');
      d.el.onclick = null;
      d.el.style.cursor = '';
    });
  }
}

// Sync visual highlights from flat dice to 3D dice (tiered mapping)
function sync3dDiceHighlights(team) {
  const physics = _dicePhysics[team];
  if (!physics || !physics.settled) return;
  const flatDice = [...document.getElementById(team + '-dice').querySelectorAll('.die')];
  const HL_3D = [
    'die-win-singles-3d', 'die-win-doubles-3d', 'die-win-triples-3d', 'die-win-mega-3d',
    'die-win-secondary-3d', 'die-loser-3d', 'triples-glow-3d',
    'highlight-single', 'highlight-double', 'highlight-triple'
  ];
  physics.dice.forEach((d, i) => {
    d.el.classList.remove(...HL_3D);
    const flat = flatDice[i];
    if (!flat) return;
    // Map each flat highlight tier to its 3D equivalent
    if (flat.classList.contains('die-win-mega')) {
      d.el.classList.add('die-win-mega-3d');
    } else if (flat.classList.contains('die-win-triples')) {
      d.el.classList.add('die-win-triples-3d');
    } else if (flat.classList.contains('die-win-doubles')) {
      d.el.classList.add('die-win-doubles-3d');
    } else if (flat.classList.contains('die-win')) {
      d.el.classList.add('die-win-singles-3d');
    } else if (flat.classList.contains('die-win-secondary')) {
      d.el.classList.add('die-win-secondary-3d');
    } else if (flat.classList.contains('die-loser')) {
      d.el.classList.add('die-loser-3d');
    }
    if (flat.classList.contains('triples-glow')) {
      d.el.classList.add('triples-glow-3d');
    }
  });
}

// Proxy click events from 3D dice to flat dice so existing handlers work unchanged
function sync3dDiceClickable(team) {
  const physics = _dicePhysics[team];
  if (!physics || !physics.settled) return;
  const flatDice = [...document.getElementById(team + '-dice').querySelectorAll('.die')];
  physics.dice.forEach((d, i) => {
    d.el.classList.add('rerollable-3d');
    d.el.onclick = () => { if (flatDice[i] && flatDice[i].onclick) flatDice[i].onclick(); };
  });
}

function doLuckyReroll(team, dieIndex, dice, callback) {
  clearLsCountdown();
  clearDiceClickable(team);
  playSfx('sfxSpecial', 0.4);

  const t = B[team];
  const oldVal = dice[dieIndex];

  // Animate the die rolling
  const diceEl = document.getElementById(team + '-dice');
  const dieDivs = diceEl.querySelectorAll('.die');
  const targetDie = dieDivs[dieIndex];
  targetDie.classList.add('rolling');
  targetDie.textContent = '?';
  // Also spin the 3D die if present
  const lrPhysics = _dicePhysics[team];
  if (lrPhysics && lrPhysics.settled && lrPhysics.dice[dieIndex]) {
    lrPhysics.dice[dieIndex].el.classList.add('rolling-3d');
  }
  playSfx('sfxDiceRoll');

  setTimeout(() => {
    // Lucky Stones are 15% luckier — bias toward higher values
    const lsRoll = Math.random();
    const newVal = lsRoll < 0.12 ? 1 : lsRoll < 0.22 ? 2 : lsRoll < 0.34 ? 3 : lsRoll < 0.50 ? 4 : lsRoll < 0.70 ? 5 : 6;
    dice[dieIndex] = newVal;
    dice.sort((a, b) => a - b);
    t.resources.luckyStone--;

    // Cameron (25) — Unstoppable Force: opponent used a special (Lucky Stone — immediate die)
    triggerCameronSpecialWatch(team, true);

    if (team === 'red') B.pendingResolve.redDice = dice;
    else B.pendingResolve.blueDice = dice;
    B.redDice = B.pendingResolve.redDice;
    B.blueDice = B.pendingResolve.blueDice;

    // v731: broadcast Lucky Stone reroll to Red's engine so it resolves with correct dice
    if (LIVE_PVP && PVP_SIDE === 'blue' && PVP_GAME_REF) {
      PVP_GAME_REF.child('specialsChoice').push({
        type: 'luckyStone',
        side: 'blue',
        dieIndex: dieIndex,
        newValue: newVal,
        dice: dice.slice(), // full sorted dice array for easy application
        ts: Date.now()
      });
    }

    // Re-render dice directly (revealDice needs IDs from showRolling which aren't present here)
    targetDie.classList.remove('rolling');
    if (lrPhysics && lrPhysics.settled && lrPhysics.dice[dieIndex]) {
      lrPhysics.dice[dieIndex].el.classList.remove('rolling-3d');
    }
    renderDice(
      team === 'red' ? dice : B.pendingResolve.redDice,
      team === 'blue' ? dice : B.pendingResolve.blueDice
    );

    // Track Lucky Stone usage for Twyla (417) Lucky Dance
    if (B.luckyStoneSpentThisTurn) B.luckyStoneSpentThisTurn[team] = (B.luckyStoneSpentThisTurn[team] || 0) + 1;

    // Twyla (417) — Lucky Dance: each Lucky Stone spent adds +1 bonus die AND +1 Healing Seed LIVE
    const twylaFighter = active(B[team]);
    if (twylaFighter.id === 417 && !twylaFighter.ko) {
      // Add bonus die to the live dice array
      const lsRoll2 = Math.random();
      const bonusDie = lsRoll2 < 0.12 ? 1 : lsRoll2 < 0.22 ? 2 : lsRoll2 < 0.34 ? 3 : lsRoll2 < 0.50 ? 4 : lsRoll2 < 0.70 ? 5 : 6;
      dice.push(bonusDie);
      dice.sort((a, b) => a - b);
      // Sync dice back to battle state
      if (team === 'red') { B.pendingResolve.redDice = dice; B.redDice = dice; }
      else { B.pendingResolve.blueDice = dice; B.blueDice = dice; }
      // Grant Healing Seed
      B[team].resources.healingSeed++;
      log(`<span class="log-ability">${twylaFighter.name}</span> — Lucky Dance! <span class="log-heal">+1 Healing Seed!</span> <span class="log-ice">+1 bonus die (${bonusDie})!</span>`);
      showAbilityCallout('LUCKY DANCE!', 'var(--rare)', `${twylaFighter.name} — +1 die and +1 Healing Seed!`, team);
      // Re-render dice to show the new bonus die
      renderDice(
        team === 'red' ? dice : B.pendingResolve.redDice,
        team === 'blue' ? dice : B.pendingResolve.blueDice
      );
    }

    log(`<span class="log-ms">Lucky Stone!</span> ${team.charAt(0).toUpperCase()+team.slice(1)} rerolled ${oldVal} → <b>${newVal}</b> → [${dice.join(', ')}]`);
    narrate(`<b class="gold">Lucky Stone!</b> Rerolled ${oldVal} → <b>${newVal}</b>!`);
    renderBattle();

    // If player has more Lucky Stones available, go directly to dice-pick mode
    // (skip the tile-click step — keep the flow seamless within the same window)
    const stillAvail = B.lsAvailable ? B.lsAvailable[team] : 0;
    if (t.resources.luckyStone > 0 && stillAvail > 0) {
      B.lsAvailable[team]--;
      setTimeout(() => {
        const teamLabel = team.charAt(0).toUpperCase() + team.slice(1);
        narrate(`<b class="${team}-text">${teamLabel}</b> has <b class="gold">${t.resources.luckyStone} Lucky Stone${t.resources.luckyStone>1?'s':''}!</b> Pick a die to reroll!`);
        const diceElInner = document.getElementById(team + '-dice');
        const liveDice = team === 'red' ? B.pendingResolve.redDice : B.pendingResolve.blueDice;
        diceElInner.querySelectorAll('.die').forEach((d, i) => {
          d.classList.add('rerollable');
          d.onclick = () => doLuckyReroll(team, i, liveDice, callback);
        });
        sync3dDiceClickable(team);
        // Brief 3s countdown for the next die pick
        let pickRem = Math.max(3, getSpecialsTimerSecs() - 2);
        showLsCountdown(diceElInner, pickRem);
        lsCountdownTimer = setInterval(() => {
          pickRem--;
          if (pickRem <= 0) {
            clearLsCountdown();
            clearDiceClickable(team);
            log(`<span style="color:var(--text2)">${team.toUpperCase()} didn't pick a die in time.</span>`);
            callback();
          } else {
            showLsCountdown(diceElInner, pickRem);
          }
        }, 1000);
      }, 600);
    } else {
      setTimeout(callback, 600);
    }
  }, 500);
}

// ============================================================
// DICE HIGHLIGHTING — visually tell the story of why someone won
// ============================================================
function highlightWinnerDice(winTeam, winRoll, loseTeam, tiebreaker) {
  const winEl  = document.getElementById(winTeam  + '-dice');
  const loseEl = document.getElementById(loseTeam + '-dice');
  if (!winEl || !loseEl) return;

  // Clear ALL stale highlight classes from both rows before applying fresh state
  const ALL_HL = ['die-win','die-win-doubles','die-win-triples','die-win-mega','die-win-secondary','die-loser'];
  [winEl, loseEl].forEach(el =>
    el.querySelectorAll('.die').forEach(d => d.classList.remove(...ALL_HL))
  );

  const winDivs  = [...winEl.querySelectorAll('.die')];
  const loseDivs = [...loseEl.querySelectorAll('.die')];

  // Dim every losing die
  loseDivs.forEach(d => d.classList.add('die-loser'));

  // Tiebreaker — same hand type & value, remaining die decided it
  if (tiebreaker) {
    // Secondary glow on the matched (tied) dice so players can see what hand tied
    // Skip for singles — there's only one matched die and it's just a number, not a "hand"
    if (winRoll.type !== 'singles') {
      const matchCount = { doubles:2, triples:3, quads:4, penta:5 }[winRoll.type] || 0;
      let winCount = 0, loseCount = 0;
      winDivs.forEach(d => {
        if (winCount < matchCount && parseInt(d.textContent) === winRoll.value) {
          d.classList.add('die-win-secondary');
          winCount++;
        }
      });
      // Symmetric: loser's matched group also gets dim-gold so both rows tell the story
      loseDivs.forEach(d => {
        if (loseCount < matchCount && parseInt(d.textContent) === winRoll.value) {
          d.classList.add('die-win-secondary'); // overrides die-loser grey via CSS specificity
          loseCount++;
        }
      });
    }
    // Primary gold glow on the decisive tiebreaker die (overrides secondary if same die)
    let done = false;
    [...winDivs].reverse().forEach(d => {
      if (!done && parseInt(d.textContent) === tiebreaker.value) {
        d.classList.remove('die-win-secondary'); // ensure gold fully overrides
        d.classList.add('die-win');
        done = true;
      }
    });
    // Fallback: if Blackout removed the tiebreaker die, highlight the highest remaining
    if (!done && winDivs.length > 0) {
      winDivs[winDivs.length - 1].classList.add('die-win');
    }
    return;
  }

  // Pick the CSS class based on hand tier
  let hlClass = 'die-win'; // singles default
  if (winRoll.type === 'doubles') hlClass = 'die-win-doubles';
  else if (winRoll.type === 'triples') hlClass = 'die-win-triples';
  else if (winRoll.type === 'quads' || winRoll.type === 'penta') hlClass = 'die-win-mega';

  if (winRoll.type === 'singles') {
    // Highlight just the highest die (the decision-maker)
    let done = false;
    [...winDivs].reverse().forEach(d => {
      if (!done && parseInt(d.textContent) === winRoll.value) {
        d.classList.add(hlClass);
        done = true;
      }
    });
  } else if (winRoll.type === 'doubles') {
    // Highlight the matching pair
    let count = 0;
    winDivs.forEach(d => {
      if (count < 2 && parseInt(d.textContent) === winRoll.value) {
        d.classList.add(hlClass);
        count++;
      }
    });
  } else {
    // triples / quads / penta — all matching dice light up
    winDivs.forEach(d => {
      if (parseInt(d.textContent) === winRoll.value) d.classList.add(hlClass);
    });
  }
  // Sync highlights to 3D dice
  sync3dDiceHighlights(winTeam);
  sync3dDiceHighlights(loseTeam);
}

// Bridge for callers that pass dice/roll explicitly after nulling B.pendingResolve
function doResolve(redDice, blueDice, redRoll, blueRoll) {
  B.pendingResolve = { redDice, blueDice, redRoll, blueRoll };
  resolveRound();
}

// v386: Safe wrapper — catches any thrown error in the damage/cinematic pipeline
// and recovers the game to a rollable state. Without this, a ReferenceError or
// TypeError anywhere inside the 2000-line resolveRound body silently kills the
// round and freezes the UI (no damage applied, no callouts, no roll buttons).
// The wrapper surfaces the error to the log/narrator so it can be diagnosed AND
// forces B.phase='ready' + resetRollButtons() so the game keeps running.
function resolveRound() {
  try {
    _resolveRoundImpl();
  } catch (err) {
    console.error('[resolveRound CRASH]', err);
    try { log(`<span class="log-dmg">INTERNAL ERROR</span> in resolveRound: ${err && err.message ? err.message : String(err)} — game recovered, please roll again.`); } catch (_) {}
    try { narrate(`<b class="gold">⚠ Round resolution crashed</b> — <span style="color:var(--text2)">${err && err.message ? err.message : 'unknown error'}</span>`); } catch (_) {}
    // Force the game out of 'resolving' so roll buttons come back alive
    try {
      if (typeof B !== 'undefined' && B) {
        B.phase = 'ready';
        B.preRoll = null;
        B.pendingResolve = null;
        B.sylviaPendingResult = null;
        B.sylviaResuming = false;
        B.bogeyReflectResuming = false;
        B.bogeyReflectChoice = null;
        B.bogeyReflectPending = null;
      }
      abilityQueue = [];
      abilityQueueMode = false;
      if (typeof narrateQueue !== 'undefined') narrateQueue = [];
      if (typeof resetRollButtons === 'function') resetRollButtons();
      if (typeof renderBattle === 'function') renderBattle();
    } catch (_) {}
  }
}
function _resolveRoundImpl() {
  B.phase = 'resolving';
  // v331: resolveRound can be re-entered after the Sylvia player-rolled modal resolves.
  // When resuming, we skip the Blackout pass (already applied) and the header log line
  // (already printed) so nothing double-fires. All downstream logic (winner determination,
  // damage calc, cinematics) is pure w.r.t. dice state and safe to re-run.
  const sylviaResuming = !!B.sylviaResuming;
  B.sylviaResuming = false;
  // Clear any stale roll narrations ("X rolls...", "X rolled [...]") that built up in the
  // narrator queue while both teams were rolling. Without this, up to 4 queued items (each
  // holding 1800ms) delay the damage narration by 5–7 seconds after the HP bar has already
  // visually dropped — the narrator then explains an event the player already watched long ago.
  // We clear only the PENDING queue (not the currently-displaying item), so whatever is
  // mid-display finishes its 1800ms hold, then the damage narration fires immediately after.
  narrateQueue = [];
  const redDice = B.pendingResolve.redDice;
  const blueDice = B.pendingResolve.blueDice;

  // Blackout (403) — remove named number from opponent's dice
  // Only fires if Smudge is active and alive on the team that set the number
  // Callouts are collected here and prepended to the post-roll ability queue below,
  // so BLACKOUT! plays sequentially instead of being stomped by the first queued ability.
  // Use B.blackoutCallouts so the queue survives a Sylvia-resuming re-entry.
  if (!sylviaResuming) B.blackoutCallouts = [];
  const blackoutCallouts = B.blackoutCallouts || [];
  if (!sylviaResuming) {
    ['red', 'blue'].forEach(team => {
      const oppTeam = team === 'red' ? 'blue' : 'red';
      const t = B[team];
      const smudgeActive = active(t).id === 403 && !active(t).ko;
      if (B.blackoutNum && B.blackoutNum[team] && smudgeActive) {
        const num = B.blackoutNum[team];
        const originalDice = team === 'red' ? blueDice : redDice;
        const filtered = [];
        let removed = 0;
        originalDice.forEach(d => {
          if (d === num) { removed++; }
          else { filtered.push(d); }
        });
        if (removed > 0) {
          if (team === 'red') { blueDice.splice(0, blueDice.length, ...filtered); }
          else { redDice.splice(0, redDice.length, ...filtered); }
          blackoutCallouts.push({ name: 'BLACKOUT!', color: 'var(--rare)', desc: `Smudge — ${removed} dice showing ${num} vanished!`, team: team });
          log(`<span class="log-ability">Smudge</span> — Blackout! Named ${num} — <span class="log-dmg">${removed} opponent dice removed!</span>`);
        }
        // No callout if opponent didn't roll the number — silent miss, don't interrupt the flow
      }
    });
    // Reset blackout picks
    B.blackoutNum = {};
  }

  B.redDice = redDice; B.blueDice = blueDice;

  // Kaylee (453) — Slipstream: if any die shows a 2, player chooses which dice to swap
  // Interactive modal pauses resolution — player picks one of their dice and one of opponent's
  // Fires BEFORE winner determination so the swap changes the outcome
  let slipstreamTeam = null;
  if (!sylviaResuming) {
    for (const _slipTeam of ['red', 'blue']) {
      const _slipF = active(B[_slipTeam]);
      if (_slipF && _slipF.id === 453 && !_slipF.ko) {
        const myDice = _slipTeam === 'red' ? redDice : blueDice;
        if (myDice.includes(2)) { slipstreamTeam = _slipTeam; break; }
      }
    }
  }
  if (slipstreamTeam) {
    const myDice = slipstreamTeam === 'red' ? redDice : blueDice;
    const oppDice = slipstreamTeam === 'red' ? blueDice : redDice;
    // Sync dice display so player can see what they rolled
    renderDice(B.redDice, B.blueDice);
    // Show interactive picker — resolution resumes in callback
    B.slipstreamResuming = true;
    showSlipstreamPicker(slipstreamTeam, myDice, oppDice, () => {
      // Resume resolution from the top — slipstreamResuming flag skips re-entry into slipstream
      B.sylviaResuming = true; // reuse this flag to skip header log + blackout re-fire
      _resolveRoundImpl();
    });
    return; // Pause resolution until player picks
  }
  B.slipstreamResuming = false;

  // Sync visual dice display after Blackout/Slipstream may have modified dice arrays.
  renderDice(B.redDice, B.blueDice);

  const rR = classify(redDice), bR = classify(blueDice);
  if (!sylviaResuming) {
    log(`Red [${redDice.join(',')}] <span style="color:var(--text2)">(${rR.type} ${rR.value})</span> vs Blue [${blueDice.join(',')}] <span style="color:var(--text2)">(${bR.type} ${bR.value})</span>`);
  }

  // Captain James (443) — Final Strike: triples or higher → gain 2 Sacred Fires
  // (Fires win or lose, just needs triples+. Placed in post-roll section near Gom Gom Gom/Sable.)

  // Welder (450) — Arc: if any die shows a 4, Welder transforms into Foreman
  ['red', 'blue'].forEach(_wTeam => {
    const _wF = active(B[_wTeam]);
    const _wDice = _wTeam === 'red' ? redDice : blueDice;
    if (_wF.id === 450 && !_wF.ko && _wDice.some(d => d === 4)) {
      welderTransform(_wTeam);
    }
  });

  // Determine winner with cascading tiebreakers
  // Rule: compare best hand type first. If same type AND same value,
  // compare remaining dice highest-to-lowest. Missing dice = 0.
  const typeRank = {penta:5,quads:4,triples:3,doubles:2,singles:1,none:0};
  function getRank(type) {
    if (typeRank[type] !== undefined) return typeRank[type];
    if (type.endsWith('-of-a-kind')) return parseInt(type); // 6-of-a-kind → 6, 7 → 7, etc.
    return 0;
  }
  let winner = null;
  let tiebreaker = null; // {value: N} — the remaining die that broke the tie

  // Hector (96) — Protector: when Hector is active on either team, singles beat doubles.
  // Singles promote to effective rank 2.5 — still lose to triples, quads, penta, etc.
  const _rAct = active(B.red), _bAct = active(B.blue);
  const hectorActive = (_rAct.id === 96 && !_rAct.ko) || (_bAct.id === 96 && !_bAct.ko);
  const rEffRank = (hectorActive && rR.type === 'singles' && bR.type === 'doubles') ? 2.5 : getRank(rR.type);
  const bEffRank = (hectorActive && bR.type === 'singles' && rR.type === 'doubles') ? 2.5 : getRank(bR.type);

  if (rEffRank > bEffRank) winner = 'red';
  else if (bEffRank > rEffRank) winner = 'blue';
  else if (rR.value > bR.value) winner = 'red';
  else if (bR.value > rR.value) winner = 'blue';
  else {
    // Same hand type AND same value — cascading tiebreaker on remaining dice
    // Remove the matched dice, then compare highest-to-lowest
    const rRemain = [...redDice];
    const bRemain = [...blueDice];
    // Remove the matching group (e.g., for doubles of 6, remove two 6s from each)
    const matchCount = {doubles:2, triples:3, quads:4, penta:5, singles:1, none:0}[rR.type] || 0;
    for (let i = 0; i < matchCount; i++) {
      const ri = rRemain.indexOf(rR.value);
      if (ri >= 0) rRemain.splice(ri, 1);
      const bi = bRemain.indexOf(bR.value);
      if (bi >= 0) bRemain.splice(bi, 1);
    }
    // Sort remaining descending and compare
    rRemain.sort((a,b) => b-a);
    bRemain.sort((a,b) => b-a);
    const maxLen = Math.max(rRemain.length, bRemain.length);
    for (let i = 0; i < maxLen; i++) {
      const rv = i < rRemain.length ? rRemain[i] : 0;
      const bv = i < bRemain.length ? bRemain[i] : 0;
      if (rv > bv) { winner = 'red'; tiebreaker = {value: rv}; break; }
      if (bv > rv) { winner = 'blue'; tiebreaker = {value: bv}; break; }
    }
  }

  // Charlie (18) — Flick: upon losing a roll or rolling Doubles, Flick a die
  // Fires BEFORE highlights/Sylvia so new dice change the outcome.
  // Charlie (18) — Rush / Flick: upon LOSING a roll, Flick a die
  // Uses B.flickResuming to skip on re-entry after dice are modified.
  if (!B.flickResuming) {
    let flickTeam = null;
    for (const ft of ['red', 'blue']) {
      const f = active(B[ft]);
      if (f.id === 18 && !f.ko) {
        const lost = winner !== null && winner !== ft;
        if (lost) { flickTeam = ft; break; }
      }
    }
    if (flickTeam) {
      showFlickPicker(flickTeam, () => {
        B.flickResuming = true;
        B.sylviaResuming = true;
        _resolveRoundImpl();
      });
      return;
    }
  }
  B.flickResuming = false;

  // Highlight dice immediately — winner dice glow, losers fade
  if (winner) {
    const loser = winner === 'red' ? 'blue' : 'red';
    const wRoll = winner === 'red' ? rR : bR;
    setTimeout(() => highlightWinnerDice(winner, wRoll, loser, tiebreaker), 80);
  }

  // ========================================
  // SYLVIA (313) — PORPOISE PLAYER-ROLLED DODGE
  // v331: if the losing fighter is Sylvia and no result is pending yet,
  // show the Sylvia modal so the player rolls 1 die themselves. The modal
  // stores B.sylviaPendingResult then re-enters resolveRound with
  // B.sylviaResuming=true to pick up where we left off.
  // Ties (winner === null) don't trigger — Sylvia only cares about losses.
  // ========================================
  if (winner !== null && !sylviaResuming && !B.sylviaPendingResult) {
    const loserTeamName = winner === 'red' ? 'blue' : 'red';
    const loserF = active(B[loserTeamName]);
    // Cameron (25) — Unstoppable Force: skip Sylvia's dodge modal when Cameron is the winner
    const winnerF = active(B[winner]);
    if (loserF && loserF.id === 313 && !loserF.ko && !(winnerF && winnerF.id === 25 && !winnerF.ko)) {
      showSylviaModal(loserTeamName, () => {
        B.sylviaResuming = true;
        resolveRound();
      });
      return;
    }
  }

  if (winner === null) {
    // ========================================
    // TIE — reset dice highlight so previous round's glow doesn't linger
    // ========================================
    let dupyFrolicKO = false;
    ['red','blue'].forEach(team => {
      const el = document.getElementById(team + '-dice');
      if (el) el.querySelectorAll('.die').forEach(d => {
        d.classList.remove('die-win','die-win-doubles','die-win-triples','die-win-mega','die-win-secondary','die-loser');
      });
      // Also clear 3D dice highlights
      const ph = _dicePhysics[team];
      if (ph && ph.settled) {
        ph.dice.forEach(d => d.el.classList.remove('die-win-singles-3d','die-win-doubles-3d','die-win-triples-3d','die-win-mega-3d','die-win-secondary-3d','die-loser-3d','triples-glow-3d','highlight-single','highlight-double','highlight-triple'));
      }
    });

    // Mark both active ghosts as having rolled (so Ambush/Lurk don't fire next round).
    active(B.red)._rolledOnce = true;
    active(B.blue)._rolledOnce = true;
    log(`<span class="log-ability">TIE!</span> No damage dealt.`);
    narrate(`Both roll ${describeRoll(rR)} — <b class="gold">a standoff!</b> No damage dealt.`);
    playSfx('sfxSpecial', 0.3);

    // Queue tie-round ability callouts so they play sequentially
    abilityQueue = [];
    abilityQueueMode = true;

    // Tweak and Twonk (303) — sideline: tie → gain 4 Surge (Roaring Crowd)
    // Sandwiches (33) — Dependable: mirrors the Surge grant to opponent.
    [B.red, B.blue].forEach(team => {
      const tNameTie = team === B.red ? 'red' : 'blue';
      if (hasSideline(team, 303)) {
        const tweakGhost = getSidelineGhost(team, 303);
        const oppTeamTweak = opp(team);
        const sandwichMirrorsTweak = hasOnTeam(oppTeamTweak, 33);
        const surgeTotal = team.resources.surge + 4;
        queueAbility('ROARING CROWD!', 'var(--common)', `Tweak and Twonk — Tie! +4 Surge! (${surgeTotal} total)`, () => {
          team.resources.surge += 4;
          popSidelineCard(team, 303);
          log(`<span class="log-ability">Tweak and Twonk</span> (sideline) — Roaring Crowd! Tie → gained <span class="log-ms">4 Surge</span>!`);
          renderBattle();
        }, tNameTie);
        // Knight reactions must be queued WHILE abilityQueueMode===true (not inside onShow
        // where abilityQueueMode is false and checkKnightEffects fires showAbilityCallout
        // directly, stomping the ROARING CROWD! callout still on screen).
        checkKnightEffects(tNameTie, 'Tweak and Twonk', tweakGhost);
        if (sandwichMirrorsTweak) {
          queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Roaring Crowd! +4 Surge! (${oppTeamTweak.resources.surge + 4} total)`, () => { oppTeamTweak.resources.surge += 4; renderBattle(); }, tNameTie === 'red' ? 'blue' : 'red');
        }
      }
    });

    // Jimmy (352) — Sideline & In Play: tie → gain 3 Lucky Stones + 1 Magic Firefly
    [B.red, B.blue].forEach(team => {
      const f = active(team);
      const tNameJim = team === B.red ? 'red' : 'blue';
      const hasJimmyActive = f.id === 352 && !f.ko;
      const hasJimmySideline = hasSideline(team, 352);
      if (hasJimmyActive || hasJimmySideline) {
        const oppTeamJim = team === B.red ? B.blue : B.red;
        const sandwichMirrorsJim = hasOnTeam(oppTeamJim, 33);
        const lsTotal = team.resources.luckyStone + 3;
        const ffTotal = (team.resources.firefly || 0) + 1;
        const jimmyGhost = hasJimmyActive ? f : team.ghosts.find(g => g.id === 352);
        queueAbility('CHIRP!', 'var(--common)', `${jimmyGhost.name} — Tie! +3 Lucky Stones + 1 Magic Firefly! (${lsTotal} LS, ${ffTotal} FF)`, () => {
          team.resources.luckyStone += 3;
          team.resources.firefly = (team.resources.firefly || 0) + 1;
          log(`<span class="log-ability">${jimmyGhost.name}</span> — Chirp! Tie → gained <span class="log-ms">3 Lucky Stones</span> + <span class="log-ms">1 Magic Firefly</span>!`);
          renderBattle();
        }, tNameJim);
        checkKnightEffects(tNameJim, jimmyGhost.name);
        if (sandwichMirrorsJim) {
          queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Chirp! +3 Lucky Stones + 1 Magic Firefly!`, () => { oppTeamJim.resources.luckyStone += 3; oppTeamJim.resources.firefly = (oppTeamJim.resources.firefly || 0) + 1; renderBattle(); }, tNameJim === 'red' ? 'blue' : 'red');
        }
      }
    });

    // Goobs (444) — Dance Break: Sideline & In Play: on a tie, both players gain 1 of every resource
    // Check BOTH teams; fire once even if both teams have Goobs
    {
      let goobFired = false;
      [B.red, B.blue].forEach(team => {
        if (goobFired) return;
        const f = active(team);
        const tNameGoob = team === B.red ? 'red' : 'blue';
        const hasGoobActive = f.id === 444 && !f.ko;
        const hasGoobSideline = hasSideline(team, 444);
        if (hasGoobActive || hasGoobSideline) {
          goobFired = true;
          const goobGhost = hasGoobActive ? f : team.ghosts.find(g => g.id === 444);
          const goobName = goobGhost ? goobGhost.name : 'Goobs';
          const goobTeam = B[tNameGoob];
          const goobActiveGhost = active(goobTeam);
          queueAbility('DANCE PARTY!', 'var(--uncommon)', `${goobName} — Tie! Both players gain 1 Magic Firefly! ${goobActiveGhost.name} +5 HP!`, () => {
            [B.red, B.blue].forEach(t => {
              if (!t.resources.firefly) t.resources.firefly = 0;
              t.resources.firefly += 1;
            });
            goobActiveGhost.hp += 5;
            log(`<span class="log-ability">${goobName}</span> — Dance Party! Both teams gain <span class="log-ms">+1 Magic Firefly!</span> <span class="log-heal">${goobActiveGhost.name} +5 HP!</span>`);
            renderBattle();
          }, tNameGoob);
          checkKnightEffects(tNameGoob, goobName);
        }
      });
    }

    // Kairan (68) — Let's Dance: doubles (win, lose, or tie) → +1 die next roll
    [B.red, B.blue].forEach(team => {
      const f = active(team);
      const tNameKai = team === B.red ? 'red' : 'blue';
      const kaiRoll = team === B.red ? rR : bR;
      if (f.id === 68 && !f.ko && kaiRoll.type === 'doubles') {
        B.letsDanceBonus[tNameKai] = (B.letsDanceBonus[tNameKai] || 0) + 1;
        queueAbility("LET'S DANCE!", 'var(--rare)', `${f.name} — Doubles on a tie! +1 die next roll!`, null, tNameKai);
        checkKnightEffects(tNameKai, f.name);
        log(`<span class="log-ability">${f.name}</span> — Let's Dance! Doubles tie → +1 die next round.`);
      }
    });

    // Outlaw (43) — Thief: doubles (tie) → steal 1 enemy die next roll
    [B.red, B.blue].forEach(team => {
      const f = active(team);
      const tNameOut = team === B.red ? 'red' : 'blue';
      const outRoll = team === B.red ? rR : bR;
      if (f.id === 43 && !f.ko && outRoll.type === 'doubles') {
        B.outlawStolenDie[tNameOut] = (B.outlawStolenDie[tNameOut] || 0) + 1;
        queueAbility('THIEF!', 'var(--uncommon)', `${f.name} — Doubles tie! Stealing 1 die from enemy next round!`, null, tNameOut);
        log(`<span class="log-ability">${f.name}</span> — Thief! Doubles tie → steal 1 enemy die next round.`);
        checkKnightEffects(tNameOut, f.name);
      }
    });

    // Haywire (78) — Wild Chords: tie — triples or better grants +1 permanent die AND Haywire +2 damage for the rest of the game (once per game)
    [B.red, B.blue].forEach(team => {
      const f = active(team);
      const tNameHW = team === B.red ? 'red' : 'blue';
      const hwRoll = team === B.red ? rR : bR;
      if (f.id === 78 && !f.ko && isTripleOrBetter(hwRoll.type) && B.haywireUsed && !B.haywireUsed[tNameHW]) {
        B.haywireBonus[tNameHW] = (B.haywireBonus[tNameHW] || 0) + 1;
        B.haywireDamageBonus[tNameHW] = 2;
        B.haywireUsed[tNameHW] = true;
        queueAbility('WILD CHORDS!', 'var(--rare)', `${f.name} — Triples or better on a tie! +1 permanent die AND Haywire gains +2 damage for the rest of the game! (Once per game)`, null, tNameHW);
        log(`<span class="log-ability">${f.name}</span> — Wild Chords! Triples or better tie → +1 permanent die + Haywire +2 damage for the rest of the game!`);
        checkKnightEffects(tNameHW, f.name);
      }
    });

    // Scallywags (19) — Frenzy: tie — if Scallywags' own dice are all under 4, gain +1 die next turn
    [B.red, B.blue].forEach(team => {
      const f = active(team);
      const tNameSC = team === B.red ? 'red' : 'blue';
      const scDice = team === B.red ? redDice : blueDice;
      if (f.id === 19 && !f.ko && scDice && scDice.length > 0 && scDice.every(d => d < 4)) {
        B.scallywagsFrenzyBonus[tNameSC] = (B.scallywagsFrenzyBonus[tNameSC] || 0) + 1;
        team.resources.surge = (team.resources.surge || 0) + 1;
        queueAbility('FRENZY!', 'var(--common)', `${f.name} — All dice under 4 on a tie! +1 die next roll + 1 Surge!`, null, tNameSC);
        log(`<span class="log-ability">${f.name}</span> — Frenzy! Tie: all dice under 4 → +1 die next round + <span class="log-ms">+1 Surge</span>.`);
        checkKnightEffects(tNameSC, f.name);
      }
    });

    // Floop (20) — Muck: tie — if opponent rolled doubles, they lose 1 die next round
    [B.red, B.blue].forEach(team => {
      const f = active(team);
      if (f.id === 20 && !f.ko) {
        const enemyTeam = opp(team);
        const enemyTName = enemyTeam === B.red ? 'red' : 'blue';
        const enemyRoll = enemyTeam === B.red ? rR : bR;
        if (enemyRoll.type === 'doubles') {
          B.floopMuck[enemyTName] = (B.floopMuck[enemyTName] || 0) + 1;
          queueAbility('MUCK!', 'var(--common)', `${f.name} — ${active(enemyTeam).name} rolled doubles on a tie! They lose 1 die next round!`, null, team === B.red ? 'red' : 'blue');
          log(`<span class="log-ability">${f.name}</span> — Muck! ${active(enemyTeam).name} rolled doubles → -1 die next round.`);
          checkKnightEffects(team === B.red ? 'red' : 'blue', f.name);
        }
      }
    });

    // Logey (26) — Heinous: tie — count opponent's 5+ dice, lock them out next roll
    [B.red, B.blue].forEach(team => {
      const f = active(team);
      if (f.id === 26 && !f.ko) {
        const enemyTeam = opp(team);
        const enemyTName = enemyTeam === B.red ? 'red' : 'blue';
        const enemyDice = enemyTeam === B.red ? redDice : blueDice;
        const locked = (enemyDice || []).filter(d => d >= 5).length;
        if (locked > 0) {
          B.logeyLockout[enemyTName] = (B.logeyLockout[enemyTName] || 0) + locked;
          queueAbility('HEINOUS!', 'var(--common)', `${f.name} — Tie! ${locked} of ${active(enemyTeam).name}'s dice (5+) locked out next roll!`, null, team === B.red ? 'red' : 'blue');
          log(`<span class="log-ability">${f.name}</span> — Heinous! Tie: locked ${locked} of enemy's 5+ dice.`);
          checkKnightEffects(team === B.red ? 'red' : 'blue', f.name);
        }
      }
    });

    // Sable (413) — Smoldering Soul: all odd dice → +1 Sacred Fire (active or sideline, tie path)
    [B.red, B.blue].forEach(team => {
      const f = active(team);
      const tNameSable = team === B.red ? 'red' : 'blue';
      const sableDice = team === B.red ? redDice : blueDice;
      const hasSableActive = f.id === 413 && !f.ko;
      const hasSableSideline = hasSideline(team, 413);
      if ((hasSableActive || hasSableSideline) && sableDice && sableDice.length > 0 && sableDice.every(d => d % 2 === 1)) {
        team.resources.fire++;
        const sableName = hasSableActive ? f.name : (getSidelineGhost(team, 413) || { name: 'Sable' }).name;
        const sableLoc = hasSableActive ? '' : ' (sideline)';
        queueAbility('SMOLDERING SOUL!', 'var(--uncommon)', `${sableName}${sableLoc} — All dice odd! +1 Sacred Fire!`, null, tNameSable);
        log(`<span class="log-ability">${sableName}</span> — Smoldering Soul! All dice odd → <span class="log-ms">+1 Sacred Fire!</span>`);
        checkKnightEffects(tNameSable, sableName);
      }
    });

    // Pip (418) — Toasted: triples+ → remove 1 enemy die permanently + 2 Sacred Fires (once per game, tie path)
    [B.red, B.blue].forEach(team => {
      const f = active(team);
      const tNamePip = team === B.red ? 'red' : 'blue';
      const pipRoll = team === B.red ? rR : bR;
      if (f.id === 418 && !f.ko && isTripleOrBetter(pipRoll.type) && B.pipToastedUsed && !B.pipToastedUsed[tNamePip]) {
        B.pipToastedUsed[tNamePip] = true;
        const oppName = tNamePip === 'red' ? 'blue' : 'red';
        B.pipDieRemoval[oppName] = (B.pipDieRemoval[oppName] || 0) + 1;
        team.resources.fire += 2;
        queueAbility('TOASTED!', 'var(--rare)', `${f.name} — ${pipRoll.type}! Enemy permanently loses 1 die + 2 Sacred Fires! (Once per game)`, null, tNamePip);
        log(`<span class="log-ability">${f.name}</span> — Toasted! ${pipRoll.type} → enemy -1 die permanently + <span class="log-ms">+2 Sacred Fires!</span>`);
        checkKnightEffects(tNamePip, f.name);
      }
    });

    // Dream Cat (28) — Jinx: tie where BOTH teams rolled doubles → +1 die next round
    // In a tie rR.type === bR.type, so rR.type === 'doubles' means both had doubles.
    if (rR.type === 'doubles') {
      [B.red, B.blue].forEach(team => {
        const f = active(team);
        if (f.id === 28 && !f.ko) {
          const tNameDC = team === B.red ? 'red' : 'blue';
          B.dreamCatBonus[tNameDC] = (B.dreamCatBonus[tNameDC] || 0) + 1;
          queueAbility('JINX!', 'var(--common)', `${f.name} — Both teams rolled doubles on a tie! +1 die next round!`, null, tNameDC);
          log(`<span class="log-ability">${f.name}</span> — Jinx! Both rolled doubles (tie) → +1 die next round.`);
          checkKnightEffects(tNameDC, f.name);
        }
      });
    }

    // Opa (48) — Rest: tie → gain +1 HP (overclocks! Rule #9 — do NOT add Math.min cap)
    // Mr Filbert (59) — Mask Merchant: flips heal to -1 damage when on enemy sideline.
    [B.red, B.blue].forEach(team => {
      const f = active(team);
      const tNameOpaTie = team === B.red ? 'red' : 'blue';
      if (f.id === 48 && !f.ko) {
        const opaEnemy = opp(team);
        if (hasSideline(opaEnemy, 59)) {
          const opaFlippedTie = Math.max(0, f.hp - 1);
          const opaGhostTie = f;
          queueAbility('MASK MERCHANT!', 'var(--uncommon)', `Mr Filbert — Rest cursed! ${f.name} takes 1 damage! (${f.hp}→${opaFlippedTie} HP)`, () => { opaGhostTie.hp = opaFlippedTie; if (opaGhostTie.hp <= 0) { opaGhostTie.hp = 0; opaGhostTie.ko = true; opaGhostTie.killedBy = 59; } renderBattle(); }, tNameOpaTie);
          log(`<span class="log-ability">${f.name}</span> — Rest! Mr Filbert curses → -1 HP (${opaFlippedTie} HP).`);
        } else {
          const opaNewHpTie = f.hp + 1;
          const opaOverTie = opaNewHpTie > f.maxHp;
          queueAbility('REST!', 'var(--uncommon)', `${f.name} — Tie! +1 HP! (${f.hp}→${opaNewHpTie} HP${opaOverTie ? ' · overclocked!' : ''})`, () => { f.hp++; renderBattle(); }, tNameOpaTie);
          log(`<span class="log-ability">${f.name}</span> — Rest! Tie → +1 HP (${opaNewHpTie} HP${opaOverTie ? ' overclocked!' : ''}).`);
        }
        checkKnightEffects(tNameOpaTie, f.name);
      }
    });

    // Ancient One (22) — Friend to All: sideline passive → active ghost gains +3 HP on ties
    // Negated by Cornelius (45) — Antidote: if the enemy team has Cornelius on sideline, Friend to All is blocked.
    // Mr Filbert (59) — Mask Merchant: flips the +3 heal to 3 damage when on enemy sideline (Cornelius takes priority).
    [B.red, B.blue].forEach(team => {
      const f = active(team);
      const tNameAO = team === B.red ? 'red' : 'blue';
      if (!hasSideline(team, 22) || f.ko) return;
      const aoEnemy = opp(team);
      if (hasSideline(aoEnemy, 45)) {
        const cornGhostAO = getSidelineGhost(aoEnemy, 45);
        queueAbility('ANTIDOTE!', 'var(--uncommon)', `${cornGhostAO ? cornGhostAO.name : 'Cornelius'} (sideline) — blocks Ancient One's Friend to All on ${f.name}!`, () => { renderBattle(); }, tNameAO);
        checkKnightEffects(tNameAO, cornGhostAO ? cornGhostAO.name : 'Cornelius');
        log(`<span class="log-ability">Cornelius</span> (sideline) — Antidote! Friend to All blocked for ${f.name}.`);
      } else if (hasSideline(aoEnemy, 59)) {
        const aoFlipped = Math.max(0, f.hp - 3);
        queueAbility('MASK MERCHANT!', 'var(--uncommon)', `Mr Filbert — Friend to All cursed! ${f.name} takes 3 damage! (${f.hp}→${aoFlipped} HP)`, () => { f.hp = Math.max(0, f.hp - 3); if (f.hp <= 0) { f.hp = 0; f.ko = true; f.killedBy = 59; } renderBattle(); }, tNameAO);
        checkKnightEffects(tNameAO, 'Mr Filbert');
        log(`<span class="log-ability">${f.name}</span> — Friend to All! Mr Filbert curses → -3 HP (${aoFlipped} HP).`);
      } else {
        const aoNewHp = f.hp + 3;
        const aoOver = aoNewHp > f.maxHp;
        queueAbility('FRIEND TO ALL!', 'var(--common)', `Ancient One — Tie! ${f.name} gains +3 HP! (${f.hp}→${aoNewHp} HP${aoOver ? ' · overclocked!' : ''})`, () => { f.hp += 3; renderBattle(); }, tNameAO);
        checkKnightEffects(tNameAO, 'Ancient One');
        log(`<span class="log-ability">${f.name}</span> — Friend to All! Tie → +3 HP (${aoNewHp} HP${aoOver ? ' overclocked!' : ''}).`);
      }
    });

    // Maximo (302) — end of round: gain 1 Healing Seed
    // Sandwiches (33) — Dependable: if opponent gains a seed, mirror it.
    [B.red, B.blue].forEach(team => {
      const f = active(team);
      const tNameMax = team === B.red ? 'red' : 'blue';
      if (f.id === 302 && !f.ko) {
        const oppTeamMax    = opp(team);
        const sandwichMirrorsMax = hasOnTeam(oppTeamMax, 33);
        queueAbility('NAP!', 'var(--common)', `${f.name} — +1 Healing Seed and +1 Lucky Stone while napping!`, () => {
          team.resources.healingSeed++;
          team.resources.luckyStone++;
          log(`<span class="log-ability">${f.name}</span> — Nap! Gained <span class="log-ms">1 Healing Seed</span> + <span class="log-ms">1 Lucky Stone</span>.`);
          renderBattle();
        }, tNameMax);
        // Knight reactions must be queued WHILE abilityQueueMode===true (not inside onShow
        // where abilityQueueMode is false and checkKnightEffects fires showAbilityCallout
        // directly, stomping the NAP! callout still on screen).
        checkKnightEffects(tNameMax, f.name);
        if (sandwichMirrorsMax) {
          queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Nap! +1 Healing Seed + 1 Lucky Stone!`, () => { oppTeamMax.resources.healingSeed++; oppTeamMax.resources.luckyStone++; renderBattle(); }, tNameMax === 'red' ? 'blue' : 'red');
        }
      }
    });

    // Dupy (12) — Frolic: tie → instant KO the opposing ghost
    [B.red, B.blue].forEach(team => {
      const f = active(team);
      const ef = active(opp(team));
      const tNameDupy = team === B.red ? 'red' : 'blue';
      if (f.id === 12 && !f.ko && !ef.ko) {
        ef.hp = 0;
        ef.ko = true;
        ef.killedBy = 12;
        dupyFrolicKO = true;
        playDamageSfx();
        queueAbility('FROLIC!', 'var(--common)', `${f.name} — Tie! ${ef.name} instantly KO'd!`, () => { hitDamage(tNameDupy); renderBattle(); }, tNameDupy);
        log(`<span class="log-ability">${f.name}</span> — Frolic! Tie → ${ef.name} <span class="log-ko">instantly KO'd!</span>`);
        checkKnightEffects(tNameDupy, f.name);
      }
    });

    abilityQueueMode = false;

    // Reset committed resources + Blackout picks + per-round ability flags
    B.committed.red = { ice:0, fire:0, surge:0, auntSusan:0, auntSusanHeal:0, harrison:0, zainBlade:0 };
    B.committed.blue = { ice:0, fire:0, surge:0, auntSusan:0, auntSusanHeal:0, harrison:0, zainBlade:0 };
    B.blackoutNum = {};
    B.pressureUsed = { red: false, blue: false };
    if (B.romyPrediction) { B.romyPrediction.red = null; B.romyPrediction.blue = null; }
    if (B.guardianFairyStandby) { B.guardianFairyStandby.red = false; B.guardianFairyStandby.blue = false; }
    if (B.eloiseUsedThisRound) { B.eloiseUsedThisRound.red = false; B.eloiseUsedThisRound.blue = false; }
    // bogeyArmed removed v430 — Bogey reflect is now reactive (no pre-arm state)
    // Duel Phase: tie rounds DON'T clear duelLastLoser — the previous non-tie loser's
    // initiative is sticky, so it carries forward through tie rounds. "Easier to
    // understand: tie round just keeps the last loser as first mover." (Wyatt, v394)
    // galeForceDecided reset removed — Gus is now reactive post-win
    if (B.jacksonUsedThisRound) { B.jacksonUsedThisRound.red = false; B.jacksonUsedThisRound.blue = false; }
    if (B.sonyaUsedThisRound) { B.sonyaUsedThisRound.red = false; B.sonyaUsedThisRound.blue = false; }
    // Dark Wing (76) Precision: NO per-round reset — once-per-GAME flag persists across rounds (v595)
    if (B.mallowDecided) { B.mallowDecided.red = false; B.mallowDecided.blue = false; }
    if (B.fangUndercoverArmed) { B.fangUndercoverArmed.red = false; B.fangUndercoverArmed.blue = false; } // clear — tied, no damage taken
    if (B.tylerDecidedThisRound) { B.tylerDecidedThisRound.red = false; B.tylerDecidedThisRound.blue = false; }
    if (B.booTeamworkDecidedThisRound) { B.booTeamworkDecidedThisRound.red = false; B.booTeamworkDecidedThisRound.blue = false; }
    if (B.luckyStoneSpentThisTurn) { B.luckyStoneSpentThisTurn.red = 0; B.luckyStoneSpentThisTurn.blue = 0; }
    if (B.preRollAbilitiesFiredThisTurn) { B.preRollAbilitiesFiredThisTurn.red = false; B.preRollAbilitiesFiredThisTurn.blue = false; } B.moonstoneSicknessFiredThisTurn = false;
    // Willow (435) — Joy of Painting: tie = nobody lost, clear both flags
    if (B.willowLostLast) { B.willowLostLast.red = false; B.willowLostLast.blue = false; }
    // Reset item swing toggles each round (player must actively choose to swing)
    if (B.flameBladeSwing) { B.flameBladeSwing.red = false; B.flameBladeSwing.blue = false; }
    if (B.iceBladeSwing) { B.iceBladeSwing.red = false; B.iceBladeSwing.blue = false; }
    // Toby — Pure Heart: carry forward scheduled KO, then clear declaration (tie path)
    if (B.pureHeartDeclared) {
      if (B.pureHeartDeclared.red === true && B.pureHeartScheduledKO) B.pureHeartScheduledKO.red = true;
      if (B.pureHeartDeclared.blue === true && B.pureHeartScheduledKO) B.pureHeartScheduledKO.blue = true;
      B.pureHeartDeclared.red = null;
      B.pureHeartDeclared.blue = null;
    }
    B.selenePending = null; // discard any doubles-triggered Selene reward from this tie round — it must not ghost into the next round's post-roll flow
    B.wiseAlPending = null;
    B.gordokPending = null;
    B.sophiaPending = null;

    B.round++;
    B.phase = 'ko-pause'; // brief hold on tie so narration lands
    B.preRoll = null;
    renderDice(redDice, blueDice);
    renderBattle();

    // Drain tie-round ability callouts, then resume.
    // drainAbilityQueue now fires its callback 1500ms after the LAST callout fires —
    // 100ms after the 1400ms splash auto-dismisses — so roll buttons only become live
    // after the last callout is fully cleared.  The old 600ms wrapper (v111) that
    // compensated for the former 900ms early-callback window has been removed.
    // Narrate first, then enable buttons 350ms later — same breathing-room pattern as
    // the no-KO path (v110), KO path (v114), and openKoSwap all-swaps-done (v113).
    // Previously: B.phase='ready' + resetRollButtons() fired BEFORE narrate(), making
    // roll buttons live the instant the callback ran — zero reading time on "Round N".
    drainAbilityQueue(() => {
      // Dupy (12) — Frolic killed on this tie — hand off to KO swap flow
      if (dupyFrolicKO) {
        if (!handleKOs()) renderBattle();
        return;
      }
      narrate(`<b class="gold">Round ${B.round}</b> — <b class="red-text">${active(B.red).name}</b>&nbsp;vs&nbsp;<b class="blue-text">${active(B.blue).name}</b>`);
      renderBattle();
      setTimeout(() => { startNextRound(); }, spd(350));
    });
    return;
  }

  // ========================================
  // PHASE 5: RESOLVE DAMAGE
  // ========================================
  const winTeamName = winner;
  const winTeam = B[winner];
  const loseTeamName = winner === 'red' ? 'blue' : 'red';
  const loseTeam = opp(winTeam);
  // Mr Filbert (59) — Mask Merchant: while on the enemy sideline, any healing the opponent receives
  // is flipped to damage instead. filbertCursesWin = Filbert is on loseTeam's bench → wF heals → damage.
  const filbertCursesWin = hasSideline(loseTeam, 59);
  const filbertCursesLose = hasSideline(winTeam, 59);
  // Sandwiches (33) — Dependable: while on the sideline, if opponent gains a Special, you gain it too.
  // sandwichForLose = Sandwiches on loseTeam bench → mirrors winTeam Special grants to loseTeam.
  // sandwichForWin  = Sandwiches on winTeam bench  → mirrors loseTeam Special grants to winTeam.
  const sandwichForLose = hasOnTeam(loseTeam, 33);
  const sandwichForWin  = hasOnTeam(winTeam, 33);
  const wF = active(winTeam);
  const lF = active(loseTeam);
  // Per-ghost first-roll tracking for Nikon (2) Ambush and Cave Dweller (46) Lurk.
  // B.round === 1 is WRONG for KO-swap replacements — a ghost brought in round 4 has their
  // "first roll" in round 4, not round 1. Solution: tag each ghost object with _rolledOnce
  // (falsy until they've resolved their first roll as either winner or loser). Checked here,
  // BEFORE being set to true, so the first call into resolveRound correctly captures state.
  const nikonIsFirstRoll = (wF.id === 2 && !wF._rolledOnce);
  const caveDwellerIsFirstRoll = (wF.id === 46 && !wF._rolledOnce);
  wF._rolledOnce = true;
  lF._rolledOnce = true;
  const wR = winner==='red' ? rR : bR;
  const lR = winner==='red' ? bR : rR;
  const winDice = winner==='red' ? redDice : blueDice;
  const loseDice = winner==='red' ? blueDice : redDice;

  // Store roll data for raid spectator snapshots
  if (RAID_MODE) {
    window._lastRaidRollData = {
      player: [...redDice],
      boss: [...blueDice],
      winner: winner === 'red' ? 'player' : 'boss',
      damage: wR.damage
    };
    window._lastRaidAbilityCallout = wF.name + ' — ' + wR.type + (wR.type !== 'singles' ? '!' : '');
  }

  let dmg = wR.damage;

  // Antoinette (82) — Grace: +1 damage on doubles
  if (wF.id === 82 && !wF.ko && wR.type === 'doubles') {
    dmg += 1;
    log(`<span class="log-ability">${wF.name}</span> — Grace! Doubles → +1 damage!`);
  }

  // Boo Brothers (17) — Teamwork damage bonus: +1 if they used the ability this round
  let booTeamworkDmgTriggered = false;
  if (wF.id === 17 && !wF.ko && B.booTeamworkDmgBonus && B.booTeamworkDmgBonus[winTeamName] > 0) {
    dmg += 1;
    booTeamworkDmgTriggered = true;
    B.booTeamworkDmgBonus[winTeamName] = 0;
    log(`<span class="log-ability">${wF.name}</span> — Teamwork Bonus! Used ability → +1 damage!`);
  }
  // Clear unused Boo Brothers bonus on loss
  if (lF.id === 17 && B.booTeamworkDmgBonus && B.booTeamworkDmgBonus[loseTeamName] > 0) {
    B.booTeamworkDmgBonus[loseTeamName] = 0;
  }

  // Zippa (423) — Glimmer: +1 damage per Healing Seed held (passive, active or sideline)
  let zippaGlimmerBonus = 0;
  if (wF.id === 423 && !wF.ko) {
    const zippaSeeds = winTeam.resources.healingSeed || 0;
    if (zippaSeeds > 0) {
      zippaGlimmerBonus = zippaSeeds;
      dmg += zippaSeeds;
      log(`<span class="log-ability">${wF.name}</span> — Glimmer! ${zippaSeeds} Healing Seed${zippaSeeds>1?'s':''} → +${zippaSeeds} damage!`);
    }
  }

  // v386: collectKC defined BEFORE any ability block that might call it (was TDZ-declared
  // at line ~8163 but referenced by Skylar Winter Barrage at 8131 and Tyler Heating Up
  // at 8144 — would throw ReferenceError if either fighter was active with ice/fire
  // committed. Same bug class as v305 teamLabel and v377 calloutCount.)
  const resolveKnightCallouts = [];
  const pendingHeavyAirHits = []; // deferred Heavy Air damage — only applied if Knight Terror survives the round
  const collectKC = (t, n, s) => {
    const savedQ = abilityQueue, savedM = abilityQueueMode;
    abilityQueue = []; abilityQueueMode = true;
    // Use deferred mode: Heavy Air damage stored, not applied immediately
    checkKnightEffects(t, n, s, pendingHeavyAirHits);
    resolveKnightCallouts.push(...abilityQueue);
    abilityQueue = savedQ; abilityQueueMode = savedM;
  };

  // Champ (438) — Thrill (A): immune to damage from Specials (committed resources)
  const champImmuneToSpecials = lF.id === 438 && !lF.ko;
  if (champImmuneToSpecials && (B.committed[winTeamName].ice > 0 || B.committed[winTeamName].fire > 0 || B.committed[winTeamName].surge > 0)) {
    log(`<span class="log-ability">${lF.name}</span> — Thrill! Immune to all committed resource damage!`);
  }

  // Committed Ice Shards: +1 per shard (Skylar Winter Barrage: +2 each)
  let skylarTriggered = false;
  if (B.committed[winTeamName].ice > 0 && !champImmuneToSpecials) {
    const skylarActive = wF.id === 104 && !wF.ko;
    const perShard = skylarActive ? 2 : 1;
    const iceDmg = B.committed[winTeamName].ice * perShard;
    dmg += iceDmg;
    if (skylarActive) {
      skylarTriggered = true;
      collectKC(winTeamName, wF.name);
    }
    log(`<span class="log-ms">Ice Shards committed!</span> <span class="log-dmg">+${iceDmg} damage!</span>${skylarActive ? ' (Winter Barrage ×2!)' : ''}`);
  }
  // Committed Sacred Fires: +3 per fire (Tyler 105 Heating Up: ×2 = +6 per fire)
  // Rook (416) — Charcoal: immune to Sacred Fire damage when Rook is the LOSER/target
  let tylerFireTriggered = false;
  if (B.committed[winTeamName].fire > 0 && lF.id !== 416 && !champImmuneToSpecials) {
    const tylerWins = wF.id === 105 && !wF.ko;
    const perFire = tylerWins ? 6 : 3;
    // Lucy's Shadow (439) — Mentor: doubles Sacred Fire damage when Lucy (108) is active winner
    // Cornelius (45) Antidote blocks Lucy's Shadow sideline effect
    const corneliusBlocksLucyShadowDmg = hasSideline(loseTeam, 45);
    const lucyShadowBoost = (wF.id === 108 && hasSideline(winTeam, 439) && !corneliusBlocksLucyShadowDmg) ? 2 : 1;
    const fireDmg = B.committed[winTeamName].fire * perFire * lucyShadowBoost;
    dmg += fireDmg;
    if (tylerWins) {
      tylerFireTriggered = true;
      collectKC(winTeamName, wF.name);
    }
    const lucyShadowTag = lucyShadowBoost === 2 ? ' (Mentor ×2!)' : '';
    log(`<span class="log-ms">Sacred Fires committed!</span> <span class="log-dmg">+${fireDmg} damage!</span>${tylerWins ? ' (Heating Up ×2!)' : ''}${lucyShadowTag}`);

    // Eternal Flame (406) — Sacred Fires not discarded (grant deferred to ETERNAL FLAME! onShow)
  }
  // Rook (416) — Charcoal: Sacred Fire immunity log
  if (B.committed[winTeamName].fire > 0 && lF.id === 416) {
    log(`<span class="log-ability">${lF.name}</span> — Charcoal! Immune to Sacred Fire damage!`);
  }

  // Aunt Susan (309) — +2 damage per seed committed (also blocked by Champ Thrill)
  if (B.auntSusanBonus[winTeamName] > 0 && !champImmuneToSpecials) {
    const susanDmg = B.auntSusanBonus[winTeamName] * 2;
    dmg += susanDmg;
    log(`<span class="log-ability">${wF.name}</span> — Harvest Dance! <span class="log-dmg">+${susanDmg} bonus damage!</span>`);
  }

  // Rook (416) — Charcoal: Win: +1 dmg per Surge committed this round (also blocked by Champ Thrill)
  if (wF.id === 416 && !wF.ko && B.committed[winTeamName].surge > 0 && !champImmuneToSpecials) {
    const rookSurgeDmg = B.committed[winTeamName].surge;
    dmg += rookSurgeDmg;
    collectKC(winTeamName, wF.name);
    log(`<span class="log-ability">${wF.name}</span> — Charcoal! <span class="log-dmg">+${rookSurgeDmg} damage</span> from ${rookSurgeDmg} Surge committed!`);
  }

  // Haywire (78) — Wild Chords permanent +2 damage on any winning roll (after trigger)
  // Added to base before doubles/triples multipliers so the bonus scales with Mountain King etc., same precedent as Pudge 311.
  if (wF.id === 78 && !wF.ko && (B.haywireDamageBonus[winTeamName] || 0) > 0) {
    const hwDmg = B.haywireDamageBonus[winTeamName];
    dmg += hwDmg;
    log(`<span class="log-ability">${wF.name}</span> — Wild Chords damage! <span class="log-dmg">+${hwDmg} damage!</span>`);
  }

  // v386: collectKC + resolveKnightCallouts moved to ~line 8125, before any ability
  // block that might reference them. (Was: `const collectKC = …` here, which created
  // a Temporal Dead Zone for Skylar/Tyler at lines ~8131/~8144.)

  // Little Boo (9) — Mercy: enemy rolled triples count as a 1,2,3 roll instead.
  // Override wR.type to 'singles' BEFORE all damage-multiplier checks so Larry Flying Kick,
  // Haywire Wild Chords, Bubble Boys Pop, and all other triples-gated abilities see 'singles'.
  // Adjust dmg by -2 to swap base from 3 (triples) to 1 (singles); committed resources preserved.
  let mercyTriggered = false;
  if (lF.id === 9 && !lF.ko && wR.type === 'triples') {
    wR.type = 'singles';
    wR.damage = 1;
    dmg -= 2; // triples base 3 → singles base 1; committed ice/fire bonuses untouched
    mercyTriggered = true;
    collectKC(loseTeamName, lF.name);
    log(`<span class="log-ability">${lF.name}</span> — Mercy! Enemy triples converted to [1,2,3]! Base damage reduced 3 → 1!`);
  }

  // Bigsby (424) — Omen: Win: +1 damage
  if (wF.id === 424 && !wF.ko) {
    dmg += 1;
    collectKC(winTeamName, wF.name);
    log(`<span class="log-ability">${wF.name}</span> — Omen! <span class="log-dmg">+1 damage!</span>`);
  }

  // Michael (445) — Torrent: Even doubles → +2 damage
  if (wF.id === 445 && !wF.ko && wR.type === 'doubles' && wR.value % 2 === 0) {
    dmg += 2;
    collectKC(winTeamName, wF.name);
    log(`<span class="log-ability">${wF.name}</span> — Torrent! Even doubles → <span class="log-dmg">+2 damage!</span>`);
  }

  // Twyla (417) — Lucky Dance: MOVED to dice count section (v674 rework: Lucky Stones give dice + Healing Seeds, not damage + HP)

  // Pudge (311) — doubles: +2 damage
  let pudgeSelfDmg = false;
  if (wF.id === 311 && !wF.ko && wR.type === 'doubles') {
    dmg += 2;
    pudgeSelfDmg = true;
    collectKC(winTeamName, wF.name);
  }

  // The Mountain King (110) — Beast Mode: doubles deal 2X damage
  let mountainKingTriggered = false;
  let mountainKingBaseDmg = 0;
  if (wF.id === 110 && !wF.ko && wR.type === 'doubles') {
    mountainKingBaseDmg = dmg;
    dmg *= 2;
    mountainKingTriggered = true;
    collectKC(winTeamName, wF.name);
  }

  // Stone Cold (73) — One-two-one!: winning with double 1s → 3X damage
  // Accept any roll containing two or more 1s (doubles, triples, quads of 1).
  let stoneColdTriggered = false;
  let stoneColdBaseDmg = 0;
  if (wF.id === 73 && !wF.ko && winDice && winDice.filter(d => d === 1).length >= 2) {
    stoneColdBaseDmg = dmg;
    dmg *= 3;
    stoneColdTriggered = true;
    collectKC(winTeamName, wF.name);
    log(`<span class="log-ability">${wF.name}</span> — One-two-one! Double 1s → 3X damage!`);
  }

  // Larry (35) — Flying Kick: triples deal 3X damage
  let larryTriggered = false;
  let larryBaseDmg = 0;
  if (wF.id === 35 && !wF.ko && wR.type === 'triples') {
    larryBaseDmg = dmg;
    dmg *= 3;
    larryTriggered = true;
    collectKC(winTeamName, wF.name);
    log(`<span class="log-ability">${wF.name}</span> — Flying Kick! Triples → 3X damage!`);
  }

  // Buttons (8) — Perfect Plan: triple 6s deal +15 bonus damage.
  // The dream: 1 HP kamikaze — if it lands, it nukes anything. 3+15=18 damage minimum.
  // Accept any roll with at least 3 sixes in the winning dice (triples/quads/penta of 6).
  let buttonsTriggered = false;
  let buttonsBaseDmg = 0;
  if (wF.id === 8 && !wF.ko && winDice && winDice.filter(d => d === 6).length >= 3) {
    buttonsBaseDmg = dmg;
    dmg += 15;
    buttonsTriggered = true;
    collectKC(winTeamName, wF.name);
    log(`<span class="log-ability">${wF.name}</span> — Perfect Plan! Triple 6s! ${buttonsBaseDmg} + 15 = ${dmg} damage!`);
  }

  // Nikon (2) — Ambush: first roll win deals 3X damage
  // nikonIsFirstRoll is captured above (before _rolledOnce is set) — works for starters AND KO-swap replacements.
  let nikonTriggered = false;
  let nikonBaseDmg = 0;
  if (wF.id === 2 && !wF.ko && nikonIsFirstRoll) {
    nikonBaseDmg = dmg;
    dmg *= 3;
    nikonTriggered = true;
    collectKC(winTeamName, wF.name);
    log(`<span class="log-ability">${wF.name}</span> — Ambush! First roll ambush → 3X damage!`);
  }

  // Cave Dweller (46) — Lurk: first roll win deals 3X damage
  // caveDwellerIsFirstRoll captured above — correct for starters AND KO-swap replacements.
  let caveDwellerTriggered = false;
  let caveDwellerBaseDmg = 0;
  if (wF.id === 46 && !wF.ko && caveDwellerIsFirstRoll) {
    caveDwellerBaseDmg = dmg;
    dmg *= 3;
    caveDwellerTriggered = true;
    collectKC(winTeamName, wF.name);
    log(`<span class="log-ability">${wF.name}</span> — Lurk! First roll ambush → 3X damage!`);
  }

  // Doom (112) — Fiendship: every win deals +2 bonus damage
  let doomTriggered = false;
  if (wF.id === 112 && !wF.ko) {
    dmg += 2;
    doomTriggered = true;
    collectKC(winTeamName, wF.name);
  }

  // Lucy (108) — Blue Fire: Win → gain 1 Sacred Fire (REWORKED 2026-04-12, swapped with Humar)
  let lucyTriggered = false;
  let lucyShadowExtraFire = false;
  if (wF.id === 108 && !wF.ko) {
    lucyTriggered = true;
    collectKC(winTeamName, wF.name);
    log(`<span class="log-ability">${wF.name}</span> — Blue Fire! Gain <span class="log-ms">1 Sacred Fire</span>!`);
    // Lucy's Shadow (439) — Mentor: +1 extra Sacred Fire when Lucy wins
    // Cornelius (45) Antidote blocks Lucy's Shadow sideline effect
    const corneliusBlocksLucyShadowFire = hasSideline(loseTeam, 45);
    if (hasSideline(winTeam, 439) && !corneliusBlocksLucyShadowFire) {
      lucyShadowExtraFire = true;
      log(`<span class="log-ability">Lucy's Shadow</span> — Mentor! +1 extra Sacred Fire!`);
    } else if (hasSideline(winTeam, 439) && corneliusBlocksLucyShadowFire) {
      const cornGhostLS = getSidelineGhost(loseTeam, 45);
      log(`<span class="log-ability">Cornelius</span> (sideline) — Antidote! Lucy's Shadow Mentor blocked!`);
    }
  }

  // Gom Gom Gom (440) — Chaos: Win with doubles → gain 1 Sacred Fire (v685: moved from post-roll to win-path only)
  let gomTriggered = false;
  if (wF.id === 440 && !wF.ko && ['doubles','triples','quads','penta'].includes(wR.type)) {
    gomTriggered = true;
    collectKC(winTeamName, wF.name);
    log(`<span class="log-ability">${wF.name}</span> — Chaos! Win with doubles → <span class="log-ms">+1 Sacred Fire</span>!`);
  }

  // Humar (336) — Meteor: Win → opponent takes 2 damage before next roll + gain 1 Burn (was Lucy's old ability, buffed 1→2 dmg)
  let humarTriggered = false;
  if (wF.id === 336 && !wF.ko) {
    B.pendingLucyDmg[loseTeamName] = 2; // reuse pendingLucyDmg but with 2 damage
    if (!winTeam.resources.burn) winTeam.resources.burn = 0;
    winTeam.resources.burn += 1;
    humarTriggered = true;
    collectKC(winTeamName, wF.name);
    log(`<span class="log-ability">${wF.name}</span> — Meteor! <span class="log-dmg">2 delayed damage</span> + <span class="log-dmg">1 Burn</span>!`);
  }

  // Wim (65) — Slash: all winning dice odd → +5 damage
  let wimTriggered = false;
  let wimBaseDmg = 0;
  if (wF.id === 65 && !wF.ko && winDice && winDice.length > 0 && winDice.every(d => d % 2 === 1)) {
    wimBaseDmg = dmg;
    dmg += 5;
    wimTriggered = true;
    collectKC(winTeamName, wF.name);
    log(`<span class="log-ability">${wF.name}</span> — Slash! All dice odd → +5 damage!`);
  }

  // Snorton (67) — Fissure: two or more 6s in winning dice → +5 damage
  let snortonTriggered = false;
  let snortonBaseDmg = 0;
  if (wF.id === 67 && !wF.ko && winDice && winDice.filter(d => d === 6).length >= 2) {
    snortonBaseDmg = dmg;
    dmg += 5;
    snortonTriggered = true;
    collectKC(winTeamName, wF.name);
    log(`<span class="log-ability">${wF.name}</span> — Fissure! Two 6s → +5 damage!`);
  }

  // Pelter (86) — Snowball: doubles win → +2 bonus damage
  let pelterTriggered = false;
  let pelterBaseDmg = 0;
  if (wF.id === 86 && !wF.ko && wR.type === 'doubles') {
    pelterBaseDmg = dmg;
    dmg += 2;
    pelterTriggered = true;
    collectKC(winTeamName, wF.name);
    log(`<span class="log-ability">${wF.name}</span> — Snowball! Doubles win → +2 damage!`);
  }

  // Kaylee (453) — Slipstream: dice stealing handled pre-winner in _resolveRoundImpl
  const slipstreamBonus = 0; // kept for callout compatibility

  // Doc (42) — Savage: doubles win → +5 bonus damage
  let docTriggered = false;
  let docBaseDmg = 0;
  if (wF.id === 42 && !wF.ko && wR.type === 'doubles') {
    docBaseDmg = dmg;
    dmg += 5;
    docTriggered = true;
    collectKC(winTeamName, wF.name);
    log(`<span class="log-ability">${wF.name}</span> — Savage! Doubles win → +5 damage!`);
  }

  // Charlie (18) — Rush is now a Flick ability (triggers on loss in resolveRound)
  // No damage modifier on win — the old "Double 2s = 7 damage" is retired.
  let charlieTriggered = false;
  let charlieBaseDmg = 0;

  // Bill & Bob (36) — Bait n Switch: while below 4 HP, winning rolls deal 2X damage
  let billBobTriggered = false;
  let billBobBaseDmg = 0;
  if (wF.id === 36 && !wF.ko && wF.hp < 4) {
    billBobBaseDmg = dmg;
    dmg *= 2;
    billBobTriggered = true;
    collectKC(winTeamName, wF.name);
    log(`<span class="log-ability">${wF.name}</span> — Bait n Switch! Below 4 HP → 2X damage!`);
  }

  // Alucard (38) — Colony Call: doubles win → +2 damage per alive sideline ghost. Once per game.
  let alucardTriggered = false;
  let alucardBaseDmg = 0;
  let alucardSidelineCount = 0;
  if (wF.id === 38 && !wF.ko && wR.type === 'doubles' && B.alucardUsed && !B.alucardUsed[winTeamName]) {
    alucardSidelineCount = winTeam.ghosts.filter((g, i) => i !== winTeam.activeIdx && !g.ko).length;
    if (alucardSidelineCount > 0) {
      alucardBaseDmg = dmg;
      dmg += alucardSidelineCount * 2;
      alucardTriggered = true;
      B.alucardUsed[winTeamName] = true;
      collectKC(winTeamName, wF.name);
      log(`<span class="log-ability">${wF.name}</span> — Colony Call! ${alucardSidelineCount} sideline ghost${alucardSidelineCount>1?'s':''} × 2 = +${alucardSidelineCount*2} damage!`);
    }
  }

  // Castle Guards (39) — Flamethrower: each 3 in winning dice multiplies damage by 2.
  // e.g. one 3 = 2X, two 3s = 4X, three 3s = 8X. Only fires when at least one 3 is rolled.
  let castleGuardsTriggered = false;
  let castleGuardsBaseDmg = 0;
  let castleGuardsThreeCount = 0;
  if (wF.id === 39 && !wF.ko && winDice && winDice.length > 0) {
    castleGuardsThreeCount = winDice.filter(d => d === 3).length;
    if (castleGuardsThreeCount > 0) {
      castleGuardsBaseDmg = dmg;
      for (let t = 0; t < castleGuardsThreeCount; t++) dmg *= 2;
      castleGuardsTriggered = true;
      collectKC(winTeamName, wF.name);
      log(`<span class="log-ability">${wF.name}</span> — Flamethrower! ${castleGuardsThreeCount} three${castleGuardsThreeCount>1?'s':''} → ${castleGuardsBaseDmg} × ${Math.pow(2,castleGuardsThreeCount)} = ${dmg} damage!`);
    }
  }

  // Team Zippy (40) — Teamwork: singles win deals +2 bonus damage.
  // Ported from boobattles: `if (roll.type === 'singles') damage += 2`.
  let teamZippyTriggered = false;
  let teamZippyBaseDmg = 0;
  if (wF.id === 40 && !wF.ko && wR.type === 'singles') {
    teamZippyBaseDmg = dmg;
    dmg += 2;
    teamZippyTriggered = true;
    collectKC(winTeamName, wF.name);
    log(`<span class="log-ability">${wF.name}</span> — Teamwork! Singles win → +2 damage!`);
  }

  // Ridley (462) — Nimble: singles +1 damage, doubles +2 damage.
  let ridleyTriggered = false;
  let ridleyBaseDmg = 0;
  let ridleyBonus = 0;
  if (wF.id === 462 && !wF.ko) {
    if (wR.type === 'singles') { ridleyBonus = 1; }
    else if (['doubles','triples','quads','penta'].includes(wR.type)) { ridleyBonus = 2; }
    if (ridleyBonus > 0) {
      ridleyBaseDmg = dmg;
      dmg += ridleyBonus;
      ridleyTriggered = true;
      collectKC(winTeamName, wF.name);
      log(`<span class="log-ability">${wF.name}</span> — Nimble! ${wR.type === 'singles' ? 'Singles' : 'Doubles'} → +${ridleyBonus} damage!`);
    }
  }

  // Carpenter (449) — Apprentice: +2 damage on singles (active Carpenter only)
  let carpenterTriggered = false;
  if (wF.id === 449 && !wF.ko && wR.type === 'singles') {
    dmg += 2;
    carpenterTriggered = true;
    collectKC(winTeamName, wF.name);
    log(`<span class="log-ability">${wF.name}</span> — Apprentice! Singles win → +2 damage!`);
  }

  // Carpenter's Hammer (permanent item) — +2 damage on singles for ANY active ghost on the team
  let carpenterHammerTriggered = false;
  if (B.carpenterHammer && B.carpenterHammer[winTeamName] && wR.type === 'singles' && wF.id !== 449) {
    dmg += 2;
    carpenterHammerTriggered = true;
    log(`<span class="log-ability">Carpenter's Hammer</span> — +2 singles damage!`);
  }

  // Greg (49) — Chase: if Greg has more HP than the opposing ghost, rolls deal 2X damage.
  // Faithfully ported from GHOSTS abilityDesc: "If Greg has more health than the opposing ghost, Greg's rolls do x2 damage."
  let gregTriggered = false;
  let gregBaseDmg = 0;
  if (wF.id === 49 && !wF.ko && wF.hp > lF.hp) {
    gregBaseDmg = dmg;
    dmg *= 2;
    gregTriggered = true;
    collectKC(winTeamName, wF.name);
    log(`<span class="log-ability">${wF.name}</span> — Chase! Greg has ${wF.hp} HP vs enemy ${lF.hp} HP → 2X damage!`);
  }

  // Tommy Salami (30) — Regulator: bonus dice from chain-6s were already added in checkTommyRegulator.
  // No win-path damage bonus — the extra dice ARE the benefit (more dice = higher hand type / more damage).
  let tommyTriggered = false;
  let tommyRegulatedCount = (B.tommyRegulatorBonus && B.tommyRegulatorBonus[winTeamName]) || 0;
  if (wF.id === 30 && !wF.ko && tommyRegulatedCount > 0) {
    tommyTriggered = true;
    collectKC(winTeamName, wF.name);
  }

  // Romy (114) — Valley Guardian: if prediction matches any winning die, +3 damage
  // Capture prediction now; clear both teams so neither carries over to next round.
  const romyPredRed = (B.romyPrediction || {}).red;
  const romyPredBlue = (B.romyPrediction || {}).blue;
  if (B.romyPrediction) { B.romyPrediction.red = null; B.romyPrediction.blue = null; }
  const romyWinPred = winTeamName === 'red' ? romyPredRed : romyPredBlue;
  let romyTriggered = false;
  if (wF.id === 114 && !wF.ko && romyWinPred != null && winDice && winDice.includes(romyWinPred)) {
    dmg += 3;
    romyTriggered = true;
    collectKC(winTeamName, wF.name);
  }

  // Hector (96) — Protector: singles win → +1 bonus damage
  let hectorTriggered = false;
  if (wF.id === 96 && !wF.ko && wR.type === 'singles') {
    dmg += 1;
    hectorTriggered = true;
    collectKC(winTeamName, wF.name);
  }

  // Toby (97) — Pure Heart: win with declaration → instant KO enemy (boost dmg to exactly KO)
  let pureHeartKO = false;
  if (wF.id === 97 && !wF.ko && B.pureHeartDeclared && B.pureHeartDeclared[winTeamName] === true) {
    dmg = Math.max(dmg, lF.hp); // guarantee KO via normal damage resolution at Beat 3
    pureHeartKO = true;
    collectKC(winTeamName, wF.name);
    log(`<span class="log-ability">${wF.name}</span> — Pure Heart! Instant KO — ${lF.name} is defeated!`);
  }

  // Zain (206) — Ice Blade: permanent +2 damage on ALL winning rolls once forged AND swinging
  // Fires for ANY ghost on the team, not just Zain.
  let zainIceBladeTriggered = false;
  if (B.iceBladeForgedPermanent && B.iceBladeForgedPermanent[winTeamName] && (B.committed[winTeamName].zainBlade > 0 || (B.iceBladeSwing && B.iceBladeSwing[winTeamName]))) {
    dmg += 2;
    zainIceBladeTriggered = true;
  }

  // Sophia (457) — Mask of Night: +1 damage on win when active
  let maskOfNightDmgTriggered = false;
  if (B.sophiaMask && B.sophiaMask[winTeamName] === 'night' && B.sophiaMaskActive[winTeamName]) {
    dmg += 1;
    maskOfNightDmgTriggered = true;
    log(`<span class="log-ability">Mask of Night</span> — 🌙 +1 damage!`);
  }

  // Flame Blade: +3 Burn on win when swinging
  let flameBladeWinTriggered = false;
  if (B.flameBlade && B.flameBlade[winTeamName] && B.flameBladeSwing && B.flameBladeSwing[winTeamName]) {
    if (!winTeam.resources.burn) winTeam.resources.burn = 0;
    winTeam.resources.burn += 3;
    flameBladeWinTriggered = true;
    log(`<span class="log-ability">Flame Blade</span> — Win while swinging! <span class="log-dmg">+3 Burn!</span>`);
  }

  // Red Hunter (345) — if opponent has any specials (resources, including committed): +3 damage
  let redHunterTriggered = false;
  if (wF.id === 345 && !wF.ko) {
    const eRes = loseTeam.resources;
    const eCom = B.committed[loseTeamName];
    const hasSpecials = (eRes.moonstone + (eCom.moonstone||0)) > 0
      || (eRes.ice + (eCom.ice||0)) > 0
      || (eRes.fire + (eCom.fire||0)) > 0
      || (eRes.surge + (eCom.surge||0)) > 0
      || (eRes.healingSeed + (eCom.healingSeed||0)) > 0
      || (eRes.luckyStone + (eCom.luckyStone||0)) > 0;
    if (hasSpecials) {
      dmg += 3;
      redHunterTriggered = true;
      collectKC(winTeamName, wF.name);
    }
  }

  // Timpleton (312) — Big Target: v640 rework — Win a roll, deal +3 damage if enemy HP > Timpleton's HP.
  // Was an Entry strike (triggerEntry) until v640. Now a Win-path damage multiplier, patterned after Red Hunter.
  let timpletonTriggered = false;
  if (wF.id === 312 && !wF.ko && lF && !lF.ko && lF.hp > wF.hp) {
    dmg += 3;
    timpletonTriggered = true;
    collectKC(winTeamName, wF.name);
  }

  // Cameron (25) — Unstoppable Force: Cameron's damage cannot be negated.
  // Defined early so it guards Sylvia, Guard Thomas, Bogey, Kodako, Patrick, Dealer, Sky, City Cyboo, King Jay, Fang.
  const cameronUnnegatable = (wF.id === 25 && !wF.ko);

  // Sylvia (313) — loser dodge check: roll 1 die, if it's a 6 negate all damage.
  // v331: the die is rolled by the PLAYER via the Sylvia modal (showSylviaModal) before
  // resolveRound's second pass reaches this block. B.sylviaPendingResult = { value, dodged }
  // is set by doSylviaRoll(). If it's missing (defensive fallback), we roll 1 die here.
  // Note: callouts are intentionally NOT queued here — they are queued in the cinematic section
  // (where abilityQueueMode=true) to prevent them firing synchronously and being stomped.
  let sylviaDodged = false;
  let sylviaDodgeRolls = []; // store for callout (array form for back-compat with callout)
  if (lF.id === 313 && !lF.ko && !cameronUnnegatable) {
    let rolledValue;
    if (B.sylviaPendingResult && typeof B.sylviaPendingResult.value === 'number') {
      rolledValue = B.sylviaPendingResult.value;
      sylviaDodged = !!B.sylviaPendingResult.dodged;
      B.sylviaPendingResult = null; // consume
    } else {
      // Defensive fallback — should never hit in normal flow
      rolledValue = Math.floor(Math.random()*6)+1;
      sylviaDodged = (rolledValue >= 5); // 5 or 6 dodge
    }
    sylviaDodgeRolls = [rolledValue];
    if (sylviaDodged) {
      dmg = 0;
      log(`<span class="log-ability">${lF.name}</span> — Porpoise! Rolled [${rolledValue}] — <span class="log-ms">ALL DAMAGE NEGATED!</span>`);
    } else {
      log(`<span class="log-ability">${lF.name}</span> — Porpoise dodge: [${rolledValue}] (needed 5 or 6).`);
    }
    collectKC(loseTeamName, lF.name);
  }

  // Tabitha (95) — Rally: while on the sideline, +2 damage to the active ghost's doubles wins
  // Negated by Cornelius (45) — Antidote: if the LOSING team has Cornelius on sideline, Rally is blocked.
  let tabithaTriggered = false;
  const corneliusBlocksRally = hasSideline(loseTeam, 45);   // win-team's sideline effects blocked (Cornelius on loseTeam)
  const corneliusOnWinTeam = hasSideline(winTeam, 45);       // lose-team's sideline effects blocked (Cornelius on winTeam)
  // Tracks whether Cornelius actually negated a sideline effect this round (for ANTIDOTE! callout)
  let corneliusSidelineBlockedList = [];
  if (hasSideline(winTeam, 95) && wR.type === 'doubles' && !wF.ko) {
    if (corneliusBlocksRally) {
      const cornGhost2 = getSidelineGhost(loseTeam, 45);
      log(`<span class="log-ability">Cornelius</span> (sideline) — Antidote! <span class="log-ability">Tabitha</span> Rally blocked!`);
    } else {
      dmg += 2;
      tabithaTriggered = true;
      const tabithaGhost = getSidelineGhost(winTeam, 95);
      collectKC(winTeamName, 'Tabitha', tabithaGhost);
      log(`<span class="log-ability">Tabitha</span> (sideline) — Rally! Doubles win gets +2 damage!`);
    }
  }

  // Admiral (71) — Comrades: while on the sideline, +2 damage to your even doubles rolls.
  // "Even doubles" = win type is doubles AND the paired value is even (2, 4, or 6).
  // FIX v279: was winDice.every(d => d%2===0) — that required ALL dice to be even, so [4,4,3]
  // (double 4s with an odd third die) wrongly failed. Correct check is wR.value % 2 === 0.
  let admiralTriggered = false;
  let admiralBaseDmg = 0;
  if (hasSideline(winTeam, 71) && !wF.ko && wR.type === 'doubles' && wR.value % 2 === 0) {
    if (!corneliusBlocksRally) {
      admiralBaseDmg = dmg;
      dmg += 2;
      admiralTriggered = true;
      const admiralGhost = getSidelineGhost(winTeam, 71);
      collectKC(winTeamName, 'Admiral', admiralGhost);
      log(`<span class="log-ability">Admiral</span> (sideline) — Comrades! Even doubles → +2 damage!`);
    } else { corneliusSidelineBlockedList.push('Admiral'); log(`<span class="log-ability">Cornelius</span> — Antidote! Admiral Comrades blocked.`); }
  }

  // Explorer Jeff (455) — Treasure Hunter: sideline & in play, +1 damage if 3+ different specials held
  let explorerJeffTriggered = false;
  let explorerJeffBaseDmg = 0;
  const ejOnSidelineDmg = hasSideline(winTeam, 455);
  const ejActiveDmg = wF.id === 455 && !wF.ko;
  if ((ejOnSidelineDmg || ejActiveDmg) && !wF.ko) {
    const ejRes = B[winTeamName].resources;
    const ejTypes = ['moonstone','ice','fire','surge','healingSeed','luckyStone','firefly','burn'].filter(r => (ejRes[r] || 0) > 0).length;
    if (ejTypes >= 3) {
      // Cornelius only blocks sideline, not in-play
      if (ejOnSidelineDmg && !ejActiveDmg && corneliusBlocksRally) {
        corneliusSidelineBlockedList.push('Explorer Jeff'); log(`<span class="log-ability">Cornelius</span> — Antidote! Explorer Jeff Treasure Hunter blocked.`);
      } else {
        explorerJeffBaseDmg = dmg;
        dmg += 1;
        explorerJeffTriggered = true;
        const loc = ejActiveDmg ? 'in play' : 'sideline';
        if (ejOnSidelineDmg && !ejActiveDmg) { const ejGhost = getSidelineGhost(winTeam, 455); collectKC(winTeamName, 'Explorer Jeff', ejGhost); }
        else { collectKC(winTeamName, wF.name); }
        log(`<span class="log-ability">Explorer Jeff</span> (${loc}) — Treasure Hunter! ${ejTypes} specials → +1 damage!`);
      }
    }
  }

  // Dark Jeff (74) — Cackle: while on the sideline, all your rolls deal +1 damage.
  // Passive sideline damage booster — applies to any win when Dark Jeff is benched.
  let darkJeffTriggered = false;
  let darkJeffBaseDmg = 0;
  if (hasSideline(winTeam, 74) && !wF.ko) {
    if (!corneliusBlocksRally) {
      darkJeffBaseDmg = dmg;
      dmg += 1;
      darkJeffTriggered = true;
      const djGhost = getSidelineGhost(winTeam, 74);
      collectKC(winTeamName, 'Dark Jeff', djGhost);
      log(`<span class="log-ability">Dark Jeff</span> (sideline) — Cackle! +1 damage to all rolls!`);
    } else { corneliusSidelineBlockedList.push('Dark Jeff'); log(`<span class="log-ability">Cornelius</span> — Antidote! Dark Jeff Cackle blocked.`); }
  }

  // Bilbo (80) — Little Buddy: while on the sideline, your ghost in play gains +2 damage on singles wins.
  // Dark Castle sideline singles booster — pairs naturally with Team Zippy Teamwork (+2 singles) and Hector Protector (+1 singles).
  let bilboTriggered = false;
  let bilboBaseDmg = 0;
  if (hasSideline(winTeam, 80) && !wF.ko && wR.type === 'singles') {
    if (!corneliusBlocksRally) {
      bilboBaseDmg = dmg;
      dmg += 2;
      bilboTriggered = true;
      const bilboGhost = getSidelineGhost(winTeam, 80);
      collectKC(winTeamName, 'Bilbo', bilboGhost);
      log(`<span class="log-ability">Bilbo</span> (sideline) — Little Buddy! Singles win → +2 damage!`);
    } else { corneliusSidelineBlockedList.push('Bilbo'); log(`<span class="log-ability">Cornelius</span> — Antidote! Bilbo Little Buddy blocked.`); }
  }

  // Pale Nimbus (88) — Hidden Storm: while on the sideline, +2 damage if winning dice sum < 7.
  // Frost Valley sideline damage booster — rewards low-total rolls (1+2+3=6, 1+1+4=6, etc.) from the bench.
  let paleNimbusTriggered = false;
  let paleNimbusBaseDmg = 0;
  if (hasSideline(winTeam, 88) && !wF.ko && winDice && winDice.reduce((s, d) => s + d, 0) < 7) {
    if (!corneliusBlocksRally) {
      paleNimbusBaseDmg = dmg;
      dmg += 2;
      paleNimbusTriggered = true;
      const pnGhost = getSidelineGhost(winTeam, 88);
      collectKC(winTeamName, 'Pale Nimbus', pnGhost);
      log(`<span class="log-ability">Pale Nimbus</span> (sideline) — Hidden Storm! Roll sum ${winDice.reduce((s,d)=>s+d,0)} < 7 → +2 damage!`);
    } else { corneliusSidelineBlockedList.push('Pale Nimbus'); log(`<span class="log-ability">Cornelius</span> — Antidote! Pale Nimbus Hidden Storm blocked.`); }
  }

  // Laura (79) — Catchy Tune: Sideline & In Play: roll a straight to unlock permanently.
  // Check WINNER's dice for straight activation (both teams checked separately below).
  let catchyJustUnlockedWin = false, catchyJustUnlockedLose = false;
  if (!B.catchyTuneUnlocked[winTeamName] && hasAlive(winTeam, 79) && winDice && isStraight(winDice)) {
    if (!corneliusBlocksRally || wF.id === 79) {
      B.catchyTuneUnlocked[winTeamName] = true;
      catchyJustUnlockedWin = true;
      const lauraG = wF.id === 79 ? wF : (getSidelineGhost(winTeam, 79) || { name: 'Laura' });
      const lauraLoc = wF.id === 79 ? '' : ' (sideline)';
      collectKC(winTeamName, lauraG.name);
      log(`<span class="log-ability">${lauraG.name}${lauraLoc}</span> — Catchy Tune unlocked! Straight [${[...winDice].sort((a,b)=>a-b).join('-')}]! Choose a die to lock after each roll!`);
      popSidelineCard(winTeam, 79);
    } else { corneliusSidelineBlockedList.push('Laura'); }
  }
  // Check LOSER's dice for straight activation too (Laura is Sideline & In Play — triggers on any roll)
  if (!B.catchyTuneUnlocked[loseTeamName] && hasAlive(loseTeam, 79) && loseDice && isStraight(loseDice)) {
    const enemyCornelius = hasSideline(winTeam, 45);
    if (!enemyCornelius || lF.id === 79) {
      B.catchyTuneUnlocked[loseTeamName] = true;
      catchyJustUnlockedLose = true;
      const lauraGL = lF.id === 79 ? lF : (getSidelineGhost(loseTeam, 79) || { name: 'Laura' });
      const lauraLocL = lF.id === 79 ? '' : ' (sideline)';
      collectKC(loseTeamName, lauraGL.name);
      log(`<span class="log-ability">${lauraGL.name}${lauraLocL}</span> — Catchy Tune unlocked! Straight [${[...loseDice].sort((a,b)=>a-b).join('-')}]! Choose a die to lock after each roll!`);
      popSidelineCard(loseTeam, 79);
    }
  }

  // Gary (92) — Lucky Novice: gain +1 Ice Shard for each 1 rolled by your active ghost.
  // v598 BUFF (Wyatt 2026-04-11): Gary now fires whether he is on the sideline OR in play.
  // When Gary is active, the dice he's counting are his own.
  // Cornelius (45) Antidote still blocks sideline Gary — but an ACTIVE Gary is not a
  // sideline ability and is unaffected by Cornelius.
  const winGaryActive = wF.id === 92 && !wF.ko;
  const winGarySide = hasSideline(winTeam, 92);
  const loseGaryActive = lF.id === 92 && !lF.ko;
  const loseGarySide = hasSideline(loseTeam, 92);
  const garyOnesWin = ((winGaryActive || (winGarySide && !corneliusBlocksRally)) && winDice) ? winDice.filter(d => d === 1).length : 0;
  const garyOnesLose = ((loseGaryActive || (loseGarySide && !corneliusOnWinTeam)) && loseDice) ? loseDice.filter(d => d === 1).length : 0;
  // v599 BALANCE BUFF (Wyatt 2026-04-11): Lucky Novice grants +2 Ice Shards per 1 rolled, not +1.
  const garyIceWin = garyOnesWin * 2;
  const garyIceLose = garyOnesLose * 2;
  if (garyOnesWin > 0) {
    const garyWinGhost = winGaryActive ? wF : getSidelineGhost(winTeam, 92);
    collectKC(winTeamName, 'Gary', garyWinGhost);
    const winLoc = winGaryActive ? 'active' : 'sideline';
    log(`<span class="log-ability">Gary</span> (${winLoc}) — Lucky Novice! ${garyOnesWin} rolled 1${garyOnesWin > 1 ? 's' : ''} → +${garyIceWin} Ice Shards!`);
  }
  if (garyOnesLose > 0) {
    const garyLoseGhost = loseGaryActive ? lF : getSidelineGhost(loseTeam, 92);
    collectKC(loseTeamName, 'Gary', garyLoseGhost);
    const loseLoc = loseGaryActive ? 'active' : 'sideline';
    log(`<span class="log-ability">Gary</span> (${loseLoc}) — Lucky Novice! ${garyOnesLose} rolled 1${garyOnesLose > 1 ? 's' : ''} → +${garyIceLose} Ice Shards!`);
  }

  // Bandit Pete (93) — Bandit: while on the sideline, if either player rolls only 2 dice, active ghost gains +3 damage.
  // Frost Valley sideline booster — punishes die-drain builds (Piper, Hugo, Outlaw) by turning a 2-die roll into a damage trigger.
  let banditPeteTriggered = false;
  let banditPeteBaseDmg = 0;
  if (hasSideline(winTeam, 93) && !wF.ko && winDice && loseDice && (winDice.length === 2 || loseDice.length === 2)) {
    if (!corneliusBlocksRally) {
      banditPeteBaseDmg = dmg;
      dmg += 3;
      banditPeteTriggered = true;
      const bpGhost = getSidelineGhost(winTeam, 93);
      collectKC(winTeamName, 'Bandit Pete', bpGhost);
      const bpWho = winDice.length === 2 ? 'Your ghost rolled only 2 dice' : 'Opponent rolled only 2 dice';
      log(`<span class="log-ability">Bandit Pete</span> (sideline) — Bandit! ${bpWho} → +3 damage!`);
    } else { corneliusSidelineBlockedList.push('Bandit Pete'); log(`<span class="log-ability">Cornelius</span> — Antidote! Bandit Pete Bandit blocked.`); }
  }

  // Zach (87) — Craftsman: while on the sideline, Guard Thomas gains +3 damage on Doubles.
  // Frost Valley sideline synergy — specific Guard Thomas / Zach pairing: doubles win + GT active + Zach benched → +3 bonus.
  let zachCraftsmanTriggered = false;
  let zachCraftsmanBaseDmg = 0;
  if (hasSideline(winTeam, 87) && wF.id === 41 && !wF.ko && wR.type === 'doubles') {
    if (!corneliusBlocksRally) {
      zachCraftsmanBaseDmg = dmg;
      dmg += 3;
      zachCraftsmanTriggered = true;
      const zachGhost = getSidelineGhost(winTeam, 87);
      collectKC(winTeamName, 'Zach', zachGhost);
      log(`<span class="log-ability">Zach</span> (sideline) — Craftsman! Guard Thomas doubles → +3 damage!`);
    } else { corneliusSidelineBlockedList.push('Zach'); log(`<span class="log-ability">Cornelius</span> — Antidote! Zach Craftsman blocked.`); }
  }

  // Lou (32) — Bros: while on the sideline, Grawr (id=34) gains +1 Damage and +1 Health on Winning Rolls.
  // Frost Valley common — dedicated Grawr support. Damage bonus computed here; HP grant deferred to onShow in cinematic queue.
  let louBrosTriggered = false;
  let louBrosBaseDmg = 0;
  if (hasSideline(winTeam, 32) && wF.id === 34 && !wF.ko) {
    if (!corneliusBlocksRally) {
      louBrosBaseDmg = dmg;
      dmg += 1;
      louBrosTriggered = true;
      log(`<span class="log-ability">Lou</span> (sideline) — Bros! Grawr wins → +1 damage!`);
    } else { corneliusSidelineBlockedList.push('Lou'); log(`<span class="log-ability">Cornelius</span> — Antidote! Lou Bros blocked.`); }
  }

  // Chip (16) — Acrobatic Dive: even rolled doubles add +3 damage if you deal damage.
  // "Even doubles" = win type is doubles AND the paired value is even (2, 4, or 6) AND dmg > 0.
  // FIX v279: was winDice.every(d => d%2===0) — required ALL dice to be even, so [4,4,3]
  // (double 4s with an odd third die) wrongly failed. Correct check is wR.value % 2 === 0.
  let chipTriggered = false;
  let chipBaseDmg = 0;
  if (wF.id === 16 && !wF.ko && wR.type === 'doubles' && dmg > 0 && wR.value % 2 === 0) {
    chipBaseDmg = dmg;
    dmg += 3;
    chipTriggered = true;
    collectKC(winTeamName, wF.name);
    log(`<span class="log-ability">${wF.name}</span> — Acrobatic Dive! Even doubles → +3 damage! (${chipBaseDmg} + 3 = ${dmg})`);
  }

  // Yawn Eater (464) — Feast: odd doubles deal +1 damage
  let yawnEaterOddTriggered = false;
  if (wF.id === 464 && !wF.ko && wR.type === 'doubles' && wR.value % 2 === 1 && dmg > 0) {
    const yeBaseDmg = dmg;
    dmg += 1;
    yawnEaterOddTriggered = true;
    collectKC(winTeamName, wF.name);
    log(`<span class="log-ability">${wF.name}</span> — Feast! Odd doubles → +1 damage! (${yeBaseDmg} + 1 = ${dmg})`);
  }

  // Dealer (37) — House Rules WIN: straight → +3 damage.
  let dealerWinTriggered = false;
  if (wF.id === 37 && !wF.ko && dmg > 0 && winDice && isStraight(winDice)) {
    const dealerWinBase = dmg;
    dmg += 3;
    dealerWinTriggered = true;
    collectKC(winTeamName, wF.name);
    log(`<span class="log-ability">${wF.name}</span> — House Rules! Straight [${[...winDice].sort((a,b)=>a-b).join(', ')}] → +3 damage! (${dealerWinBase} + 3 = ${dmg})`);
  }

  // Dark Fang (202) — Pressure: Win: +1 damage per KO'd ghost this game (both teams)
  let deathHowlTriggered = false;
  let deathHowlKOs = 0;
  if (wF.id === 202 && !wF.ko && dmg > 0) {
    deathHowlKOs = [...B.red.ghosts, ...B.blue.ghosts].filter(g => g.ko && !g.isPadded).length;
    if (deathHowlKOs > 0) {
      const dhBaseDmg = dmg;
      dmg += deathHowlKOs;
      deathHowlTriggered = true;
      collectKC(winTeamName, wF.name);
      log(`<span class="log-ability">${wF.name}</span> — Pressure! ${deathHowlKOs} KO'd ghost${deathHowlKOs > 1 ? 's' : ''} → +${deathHowlKOs} damage! (${dhBaseDmg} + ${deathHowlKOs} = ${dmg})`);
    }
  }

  // Wanderer (4) — Curiosity: roll a straight (consecutive, no repeats) → +2 damage.
  let wandererTriggered = false;
  if (wF.id === 4 && !wF.ko && dmg > 0 && winDice && isStraight(winDice)) {
    const wandererBaseDmg = dmg;
    dmg += 2;
    wandererTriggered = true;
    collectKC(winTeamName, wF.name);
    log(`<span class="log-ability">${wF.name}</span> — Curiosity! Straight [${[...winDice].sort((a,b)=>a-b).join(', ')}] → +2 damage! (${wandererBaseDmg} + 2 = ${dmg})`);
  }

  // Ancient Librarian (3) — Knowledge: for each 2 rolled by BOTH players combined, add +1 damage (only if winning ghost deals damage).
  // Set 1 common — both teams' dice count, so high-die-count opponents ironically fuel the bonus. Pure damage engine.
  let librarianTriggered = false;
  let librarianBaseDmg = 0;
  let librarianTwos = 0;
  if (wF.id === 3 && !wF.ko && dmg > 0 && winDice && loseDice) {
    librarianTwos = [...winDice, ...loseDice].filter(d => d === 2).length;
    if (librarianTwos > 0) {
      librarianBaseDmg = dmg;
      dmg += librarianTwos;
      librarianTriggered = true;
      collectKC(winTeamName, wF.name);
      log(`<span class="log-ability">${wF.name}</span> — Knowledge! ${librarianTwos} two${librarianTwos > 1 ? 's' : ''} rolled (both teams) → +${librarianTwos} damage!`);
    }
  }

  // Sparky (64) — Tinder: each rolled 1 adds +3 damage, but only if Sparky wins and damage > 0 (the 1s "ignite").
  // Set 1 rare damage multiplier — rewards low-die faces (1s are usually the worst roll, now lethal).
  let sparkyTriggered = false;
  let sparkyBaseDmg = 0;
  let sparkyOneCount = 0;
  if (wF.id === 64 && !wF.ko && dmg > 0 && winDice) {
    sparkyOneCount = winDice.filter(d => d === 1).length;
    if (sparkyOneCount > 0) {
      sparkyBaseDmg = dmg;
      dmg += sparkyOneCount * 3;
      sparkyTriggered = true;
      collectKC(winTeamName, wF.name);
      log(`<span class="log-ability">${wF.name}</span> — Tinder! ${sparkyOneCount} rolled 1${sparkyOneCount > 1 ? 's' : ''} × 3 = +${sparkyOneCount * 3} damage!`);
    }
  }

  // Splinter (101) — Toxic Fumes: first win activates fumes; 1 pre-roll chip damage every subsequent round
  let splinterJustActivated = false;
  if (wF.id === 101 && !wF.ko && B.splinterActivated && !B.splinterActivated[winTeamName]) {
    B.splinterActivated[winTeamName] = true;
    splinterJustActivated = true;
    log(`<span class="log-ability">${wF.name}</span> — Toxic Fumes! Activated — 1 pre-roll damage every round from here on.`);
  }

  // Kodako (1) — Swift WIN case: rolling 1-2-3 (all three values present) while winning → deal exactly 4 damage (overrides all modifiers)
  let kodakoSwiftWin = false;
  if (wF.id === 1 && !wF.ko && winDice && [1,2,3].every(v => winDice.includes(v))) {
    dmg = 4;
    kodakoSwiftWin = true;
    collectKC(winTeamName, wF.name);
    log(`<span class="log-ability">${wF.name}</span> — Swift! 1-2-3 combo → exactly 4 damage!`);
  }

  // Guard Thomas (41) — Stoic: while Guard Thomas has less than 6 HP, singles rolls deal 0 damage to him.
  // Defensive immunity — no stat change needed, just zero out dmg and flag it.
  let guardThomasStoic = false;
  if (lF.id === 41 && !lF.ko && lF.hp < 6 && wR.type === 'singles' && dmg > 0 && !cameronUnnegatable) {
    guardThomasStoic = true;
    dmg = 0;
    log(`<span class="log-ability">${lF.name}</span> — Stoic! Below 6 HP — immune to singles! ${wF.name}'s singles roll blocked!`);
  }

  // Bogey (53) — Bogus: REACTIVE reflect — player sees incoming damage and chooses whether to bounce it.
  // v430: Sylvia re-entry pattern. First pass: open modal with live damage preview, return early.
  // Second pass (bogeyReflectResuming): read choice and either zero dmg + mark used, or fall through.
  // Fires after guardThomasStoic — Stoic may have zeroed dmg, Bogus only triggers on real damage.
  let bogeyReflected = false;
  let bogeyReflectDmg = 0;
  let bogeyHpAfter = 0;
  const bogeyReflectResuming = !!B.bogeyReflectResuming;
  B.bogeyReflectResuming = false;
  if (lF.id === 53 && !lF.ko && B.bogeyUsed && !B.bogeyUsed[loseTeamName] && dmg > 0 && !cameronUnnegatable) {
    if (!bogeyReflectResuming && !B.bogeyReflectChoice) {
      // First pass — pause resolveRound, open modal with live damage preview
      B.bogeyReflectPending = { loseTeamName, dmg };
      const subEl = document.getElementById('bogeyReflectSub');
      if (subEl) subEl.innerHTML =
        `<b>${wF.name}</b> hits <b>${lF.name}</b> for <b>${dmg}</b> damage. Reflect it back?` +
        `<br><i>(Once per game — save it for a bigger hit?)</i>`;
      document.getElementById('bogeyOverlay').classList.add('active');
      return; // pause — doBogeyReflectChoice() will re-enter resolveRound
    }
    // Second pass — read choice and clear pending state
    const bogeyChoice = B.bogeyReflectChoice;
    B.bogeyReflectChoice = null;
    B.bogeyReflectPending = null;
    if (bogeyChoice === 'yes') {
      bogeyReflectDmg = dmg;
      dmg = 0; // Bogey takes nothing — all damage bounces back
      bogeyReflected = true;
      B.bogeyUsed[loseTeamName] = true;   // once per game — never offered again
      collectKC(loseTeamName, lF.name, lF);
      log(`<span class="log-ability">${lF.name}</span> — Bogus! ${bogeyReflectDmg} damage reflected back to ${wF.name}!`);
    }
    // bogeyChoice === 'no': dmg falls through unchanged, bogeyUsed stays false (reflect preserved)
  }

  // Kodako (1) — Swift LOSE case: rolling 1-2-3 while losing → negate all incoming damage, deal 4 back to winner
  let kodakoSwiftLose = false;
  if (lF.id === 1 && !lF.ko && loseDice && [1,2,3].every(v => loseDice.includes(v)) && dmg > 0 && !cameronUnnegatable) {
    dmg = 0; // Kodako takes nothing — Swift counters the hit
    kodakoSwiftLose = true;
    collectKC(loseTeamName, lF.name);
    log(`<span class="log-ability">${lF.name}</span> — Swift! 1-2-3 while losing → negate damage, deal 4 back to ${wF.name}!`);
  }

  // Patrick (10) — Stone Form: losing to a singles roll negates all incoming damage and deals 3 counter-damage back to the winner.
  // Fires after Kodako Swift Lose — if Swift already zeroed dmg, Patrick won't double-trigger on the same hit.
  let patrickStoneForm = false;
  const patrickStoneDmg = 3;
  let stoneFormHpAfter = 0;
  if (lF.id === 10 && !lF.ko && wR.type === 'singles' && dmg > 0 && !cameronUnnegatable) {
    dmg = 0; // Patrick takes nothing — Stone Form counters singles
    patrickStoneForm = true;
    collectKC(loseTeamName, lF.name);
    log(`<span class="log-ability">${lF.name}</span> — Stone Form! Singles roll negated — dealing 3 back to ${wF.name}!`);
  }

  // Dealer (37) — House Rules LOSE: straight (consecutive, no repeats) → negate all incoming damage.
  let dealerHouseRules = false;
  if (lF.id === 37 && !lF.ko && dmg > 0 && loseDice && loseDice.length >= 2 && !cameronUnnegatable && isStraight(loseDice)) {
    dmg = 0;
    dealerHouseRules = true;
    collectKC(loseTeamName, lF.name);
    log(`<span class="log-ability">${lF.name}</span> — House Rules! Straight [${[...loseDice].sort((a,b)=>a-b).join(', ')}] — ${wF.name}'s attack negated!`);
  }

  // Sky (72) — Elusive: if incoming damage is greater than 2, negate it and deal counter die damage.
  // Counter die is pre-computed; KO flag set synchronously; HP mutation deferred to modal.
  let skyElusive = false;
  let skyElusiveBlockedDmg = 0;
  if (lF.id === 72 && !lF.ko && dmg > 2 && !cameronUnnegatable) {
    skyElusiveBlockedDmg = dmg;
    dmg = 0;
    skyElusive = true;
    const skyCounterDie = Math.floor(Math.random() * 6) + 1;
    const skyCounterHp = Math.max(0, wF.hp - skyCounterDie);
    if (skyCounterHp <= 0) { wF.ko = true; wF.killedBy = 72; }
    B.skyElusivePending = {
      counterDie: skyCounterDie,
      wFName: wF.name,
      lFName: lF.name,
      winTeamName: winTeamName
    };
    collectKC(loseTeamName, lF.name);
    log(`<span class="log-ability">${lF.name}</span> — Elusive! ${skyElusiveBlockedDmg} incoming damage > 2 — ${wF.name}'s hit negated! Counter die pending.`);
  }

  // City Cyboo (77) — Barrier: takes no damage from enemy doubles.
  // A 1 HP doubles-immune defender — the win roll type must be 'doubles' for Barrier to trigger.
  let cityCybooBarrier = false;
  let cityCybooBlockedDmg = 0;
  if (lF.id === 77 && !lF.ko && wR.type === 'doubles' && dmg > 0 && !cameronUnnegatable) {
    cityCybooBlockedDmg = dmg;
    dmg = 0;
    cityCybooBarrier = true;
    collectKC(loseTeamName, lF.name);
    log(`<span class="log-ability">${lF.name}</span> — Barrier! Enemy doubles blocked! ${cityCybooBlockedDmg} damage negated!`);
  }

  // Puff (5) — Cute: enemy doubles and triples deal -1 damage (minimum 0).
  // Partial reduction, NOT full negation — Cute is not a negation (Cameron Unstoppable Force doesn't interact with it).
  let puffCute = false;
  let puffCuteOriginalDmg = 0;
  if (lF.id === 5 && !lF.ko && (wR.type === 'doubles' || wR.type === 'triples') && dmg > 0) {
    puffCuteOriginalDmg = dmg;
    dmg = Math.max(0, dmg - 1);
    puffCute = true;
    collectKC(loseTeamName, lF.name);
    log(`<span class="log-ability">${lF.name}</span> — Cute! ${wR.type} roll softened — ${puffCuteOriginalDmg} → ${dmg} damage!`);
  }

  // King Jay (106) — Reflection: lose the roll & loser's dice total = 7 → reflect all damage back to winner
  // Fires after Sylvia (both can't be active at the same time, but ordering is: Sylvia negates first, then Jay reflects what's left)
  let kingJayReflected = false;
  let kingJayReflectDmg = 0;
  let kingJayHpAfter = 0;
  if (lF.id === 106 && !lF.ko && dmg > 0 && loseDice && loseDice.reduce((a, b) => a + b, 0) === 7 && !cameronUnnegatable) {
    kingJayReflectDmg = dmg;
    dmg = 0; // loser takes nothing — all damage goes back
    kingJayReflected = true;
    collectKC(loseTeamName, lF.name);
    log(`<span class="log-ability">${lF.name}</span> — Reflection! Dice total = 7! ${kingJayReflectDmg} damage reflected back to ${wF.name}!`);
  }

  // Gus (31) — Gale Force: reactive post-win timed button.
  // Defers damage — player decides in drain chain whether to force swap or deal damage.
  // Detects BEFORE Guardian Fairy so winner gets first choice.
  let galeForceSwap = false;
  let galeForceSLIdx = -1;
  let galeForceDmg = 0;
  let gusGaleReactiveTriggered = false;
  if (wF.id === 31 && !wF.ko && dmg > 0) {
    galeForceSLIdx = loseTeam.ghosts.findIndex((g, i) => i !== loseTeam.activeIdx && !g.ko);
    if (galeForceSLIdx >= 0) {
      gusGaleReactiveTriggered = true;
      galeForceDmg = dmg; // stash original damage for swap picker or decline
      dmg = 0; // defer ALL damage — reactive handler will apply or swap
      // Set up reactive pending (resume set later in drain chain)
      B.gusGaleReactivePending = {
        winTeamName, loseTeamName, dmg: galeForceDmg, wF, lF,
        resume: null // set in drain chain
      };
    }
  }

  // Guardian Fairy (99) — Wish: REACTIVE — if losing team has GF on sideline and damage > 0,
  // defer damage application and show a modal letting the player choose to swap GF in.
  // GF intercepts BEFORE damage is applied to lF. (Gus Gale Force takes priority if both trigger.)
  let guardianFairyAbsorbed = false;
  let guardianFairyAbsorbedDmg = 0;
  let guardianFairyKOd = false;
  let gfSacrifice = null;
  let gfHpAfter = 0;
  let guardianFairyReactiveTriggered = false;
  if (!kingJayReflected && dmg > 0) {
    const gfG = getSidelineGhost(loseTeam, 99);
    if (gfG && !gfG.ko) {
      // Store pending state — damage deferred to modal handler
      guardianFairyReactiveTriggered = true;
      gfSacrifice = gfG;
      guardianFairyAbsorbedDmg = dmg;
      B.guardianFairyReactivePending = {
        loseTeamName, gfGhost: gfG, dmg, lF, wFName: wF.name, wFId: (wF.originalId || wF.id),
        resume: null // set later during drain
      };
      dmg = 0; // defer ALL damage — modal handler will apply it
      guardianFairyAbsorbed = true; // flag so "0 damage" log doesn't fire
    }
  }

  // Fang Undercover (7) — Skilled Coward: armed → negate all incoming damage, trigger post-round swap
  // Fires after Guardian Fairy (GF takes priority if both are in play; Fang Undercover fires only if GF didn't absorb)
  let fangUndercoverActivated = false;
  if (!kingJayReflected && !guardianFairyAbsorbed && !cameronUnnegatable &&
      lF.id === 7 && !lF.ko && B.fangUndercoverArmed && B.fangUndercoverArmed[loseTeamName] && dmg > 0) {
    B.fangUndercoverArmed[loseTeamName] = false; // consume the arm
    fangUndercoverActivated = true;
    B.fangUndercoverSwapPending = loseTeamName; // signal drain callback to show ghost-picker
    dmg = 0; // Fang takes no damage — dodge activated
    collectKC(loseTeamName, lF.name);
    log(`<span class="log-ability">${lF.name}</span> — Skilled Coward! Dodge activated! Fang will swap to the sideline!`);
  }
  if (B.fangUndercoverArmed) { B.fangUndercoverArmed[loseTeamName] = false; B.fangUndercoverArmed[winTeamName] = false; } // clear any unused arm

  // --- Mirror Matt (410) — Seven Years: doubles ONLY damage reflected to winner ---
  let mirrorMattReflected = false;
  let mirrorMattReflectDmg = 0;
  if (lF.id === 410 && !lF.ko && dmg > 0 && wR.type === 'doubles') {
    mirrorMattReflectDmg = dmg;
    wF.hp = Math.max(0, wF.hp - dmg);
    if (wF.hp <= 0) { wF.ko = true; wF.killedBy = 410; }
    dmg = 0; // Mirror Matt takes nothing
    mirrorMattReflected = true;
    collectKC(loseTeamName, lF.name);
    log(`<span class="log-ability">${lF.name}</span> — SEVEN YEARS! ${wR.type} reflected! <span class="log-dmg">${mirrorMattReflectDmg} damage bounced to ${wF.name}!</span> ${wF.ko?'<span class="log-ko">KO!</span>':wF.hp+' HP left'}`);
  }

  // Garrick (427) — Watchfire: Lose: -1 damage (damage reduction)
  if (lF.id === 427 && !lF.ko && dmg > 0) {
    dmg = Math.max(0, dmg - 1);
    log(`<span class="log-ability">${lF.name}</span> — Watchfire! Absorbs 1 damage. (${dmg > 0 ? dmg + ' damage remaining' : 'All damage absorbed!'})`);
  }

  // Gordok (430) — River Terror: Win: you MAY steal 2 resources instead of dealing damage (player choice)
  let gordokStole = false;
  if (wF.id === 430 && !wF.ko && dmg > 0) {
    const gordokOppRes = loseTeam.resources;
    const gordokResTypes = ['ice', 'fire', 'surge', 'luckyStone', 'moonstone', 'healingSeed'];
    const gordokTotalRes = gordokResTypes.reduce((sum, r) => sum + (gordokOppRes[r] || 0), 0);
    if (gordokTotalRes > 0) {
      if (autoPlayRunning) {
        // AI auto-picks: always steal
        let gordokStolen = 0;
        const gordokStolenList = [];
        for (let i = 0; i < 2 && gordokStolen < 2; i++) {
          const avail = gordokResTypes.filter(r => (gordokOppRes[r] || 0) > 0);
          if (avail.length === 0) break;
          const pick = avail[Math.floor(Math.random() * avail.length)];
          gordokOppRes[pick]--;
          winTeam.resources[pick] = (winTeam.resources[pick] || 0) + 1;
          gordokStolenList.push(pick);
          gordokStolen++;
        }
        dmg = 0;
        gordokStole = true;
        if (!B.gordokDieBonus) B.gordokDieBonus = { red: 0, blue: 0 };
        B.gordokDieBonus[winTeamName] = 1;
        winTeam.resources.moonstone++;
        collectKC(winTeamName, wF.name);
        log(`<span class="log-ability">${wF.name}</span> — River Terror! Stole ${gordokStolenList.join(', ')} instead of dealing damage! <span class="log-ice">+1 die next roll!</span> <span class="log-ms">+1 Moonstone!</span>`);
      } else {
        // Human player: defer to modal choice
        B.gordokPending = { winTeam, winTeamName, loseTeam, lF, wF, dmg, resume: null };
        dmg = 0; // defer damage — modal handler will apply
        gordokStole = true; // flag so "0 damage" log doesn't fire
      }
    }
  }

  // Pal Al (431) — Squall: Win: you MAY gain 4 Ice Shards instead of dealing damage (player choice)
  let wiseAlSqualled = false;
  if (wF.id === 431 && !wF.ko && dmg > 0) {
    if (autoPlayRunning) {
      // AI auto-picks: take ice if < 6
      const wiseAlIce = winTeam.resources.ice || 0;
      if (wiseAlIce < 6) {
        winTeam.resources.ice = (winTeam.resources.ice || 0) + 4;
        dmg = 0;
        wiseAlSqualled = true;
        collectKC(winTeamName, wF.name);
        log(`<span class="log-ability">${wF.name}</span> — Squall! <span class="log-ice">+4 Ice Shards</span> instead of dealing damage!`);
      }
    } else {
      // Human player: defer to modal choice
      B.wiseAlPending = { winTeam, winTeamName, loseTeam, lF, wF, dmg, resume: null };
      dmg = 0; // defer damage — modal handler will apply
      wiseAlSqualled = true; // flag so "0 damage" log doesn't fire
    }
  }

  // Sophia (457) — Masquerade: Win: you MAY gain Mask of Day or Mask of Night instead of dealing damage (once per game)
  let sophiaMasqueraded = false;
  if (wF.id === 457 && !wF.ko && dmg > 0 && !B.sophiaMask[winTeamName]) {
    if (autoPlayRunning) {
      // AI auto-picks: take Mask of Night (anti-dice is stronger for AI)
      B.sophiaMask[winTeamName] = 'night';
      B.sophiaMaskActive[winTeamName] = true;
      dmg = 0;
      sophiaMasqueraded = true;
      collectKC(winTeamName, wF.name);
      log(`<span class="log-ability">${wF.name}</span> — Masquerade! Gained <b>🌙 Mask of Night</b> instead of dealing damage! (Roll the same number of dice as the enemy ghost, +1 damage)`);
    } else {
      // Human player: defer to modal choice
      B.sophiaPending = { winTeam, winTeamName, loseTeam, lF, wF, dmg, resume: null };
      dmg = 0;
      sophiaMasqueraded = true;
    }
  }

  // --- APPLY DAMAGE (game state updates immediately) ---
  const winColor = winTeamName === 'red' ? 'red-text' : 'blue-text';
  const loseColor = winTeamName === 'red' ? 'blue-text' : 'red-text';
  if (dmg > 0) {
    lF.hp = Math.max(0, lF.hp - dmg);
    if (lF.hp <= 0) { lF.ko = true; lF.killedBy = (wF.originalId || wF.id); }
    log(`<span class="log-dmg">${wF.name} deals ${dmg} to ${lF.name}!</span> ${lF.ko?'<span class="log-ko">KO!</span>':lF.hp+' HP left'}`);

  // Resolve deferred Heavy Air hits — only if Knight Terror survived this round's damage
  if (pendingHeavyAirHits.length > 0) {
    // lF is the loser; check if Knight Terror (401) is on the losing side and got KO'd
    const knightSurvived = !lF.ko || lF.id !== 401;
    // Also check if Knight Terror is on the winning side (he could be the winner's opponent's active)
    const oppKnight = active(B[loseTeamName]);
    const knightOnLosingTeamKOd = oppKnight && oppKnight.id === 401 && oppKnight.ko;
    if (!knightOnLosingTeamKOd) {
      // Knight Terror survived — apply all deferred Heavy Air damage
      for (const hit of pendingHeavyAirHits) {
        if (!hit.target.ko) {
          hit.target.hp = Math.max(0, hit.target.hp - 2);
          if (hit.target.hp <= 0) { hit.target.ko = true; hit.target.killedBy = 401; }
          log(`<span class="log-ability">Knight Terror</span> — Heavy Air! <span class="log-dmg">${hit.targetName} loses 2 HP!</span> ${hit.target.ko ? '<span class="log-ko">KO!</span>' : hit.target.hp + ' HP left'}`);
        }
      }
    } else {
      // Knight Terror was KO'd — discard all Heavy Air hits and callouts
      const heavyAirCalloutCount = pendingHeavyAirHits.length;
      // Remove the queued HEAVY AIR! callouts from resolveKnightCallouts
      for (let i = resolveKnightCallouts.length - 1; i >= 0; i--) {
        if (resolveKnightCallouts[i].name === 'HEAVY AIR!') resolveKnightCallouts.splice(i, 1);
      }
    }
    pendingHeavyAirHits.length = 0;
  }
  } else if (!mirrorMattReflected && !gordokStole && !wiseAlSqualled && !kingJayReflected && !guardianFairyAbsorbed && !bogeyReflected && !kodakoSwiftLose && !patrickStoneForm && !dealerHouseRules && !skyElusive && !cityCybooBarrier && !puffCute && !fangUndercoverActivated) {
    log(`${wF.name} wins but deals 0 damage.`);
  }

  // Jasper (428) — Flame Dive: Win: interactive bonus die reveal (Balatron-style)
  // HP visual deferred to showJasperModal → finishJasperRoll.
  // KO flag set synchronously so downstream checks (Balatron Party Time, Cameron, etc.)
  // see the correct alive/dead state immediately.
  let jasperTriggered = false;
  let jasperBonusDie = 0;
  if (wF.id === 428 && !wF.ko) {
    jasperBonusDie = Math.floor(Math.random() * 6) + 1;
    jasperTriggered = true;
    collectKC(winTeamName, wF.name);
    // Synchronous KO check — Flame Dive bonus damage to loser
    const jasperLFHpAfter = Math.max(0, lF.hp - jasperBonusDie);
    if (jasperLFHpAfter <= 0 && !lF.ko) { lF.ko = true; lF.killedBy = 428; }
    // Synchronous self-damage check — Jasper takes 1 recoil
    const jasperSelfHpAfter = Math.max(0, wF.hp - 1);
    if (jasperSelfHpAfter <= 0) { wF.ko = true; wF.killedBy = -1; }
    // Stash for modal — HP visual mutations deferred to finishJasperRoll
    B.jasperPending = {
      bonusDie: jasperBonusDie,
      wFName: wF.name,
      lFName: lF.name,
      winTeamName: winTeamName
    };
  }

  // Mirror Matt (410) — Seven Years reflected damage callout (deferred to cinematic)
  // HP already applied synchronously above, callout queued later in ability queue section.

  // King Jay reflected damage — applies to the winner
  // wF.hp deferred to onShow so HP bar updates when REFLECTION! callout fires, not silently during beat 4.
  // wF.ko is set synchronously here so Cameron (25) Force of Nature check immediately below sees the correct KO state.
  if (kingJayReflected && kingJayReflectDmg > 0) {
    kingJayHpAfter = Math.max(0, wF.hp - kingJayReflectDmg);
    if (kingJayHpAfter <= 0) { wF.ko = true; wF.killedBy = lF.id; }
    log(`<span class="log-dmg">${lF.name} reflects ${kingJayReflectDmg} back! ${wF.name} takes the hit!</span> ${wF.ko?'<span class="log-ko">KO!</span>':kingJayHpAfter+' HP left'}`);
  }

  // Bogey reflected damage — applies to the winner (lF takes 0; wF eats the full hit)
  // wF.hp deferred to onShow so HP bar updates when BOGUS! callout fires, not silently during beat 4.
  // wF.ko is set synchronously so Cameron (25) Force of Nature check immediately below sees the correct KO state.
  if (bogeyReflected && bogeyReflectDmg > 0) {
    bogeyHpAfter = Math.max(0, wF.hp - bogeyReflectDmg);
    if (bogeyHpAfter <= 0) { wF.ko = true; wF.killedBy = lF.id; }
    log(`<span class="log-dmg">${lF.name} — BOGUS! ${bogeyReflectDmg} damage bounced back to ${wF.name}!</span> ${wF.ko?'<span class="log-ko">KO!</span>':bogeyHpAfter+' HP left'}`);
  }

  // Kodako (1) — Swift lose counter: 4 damage dealt back to the winner
  // wF.hp deferred to onShow so HP bar updates when SWIFT! callout fires, not silently during beat 4.
  // wF.ko is set synchronously here so Cameron (25) Force of Nature check immediately below sees the correct KO state.
  let swiftLoseHpAfter = 0;
  if (kodakoSwiftLose) {
    swiftLoseHpAfter = Math.max(0, wF.hp - 4);
    if (swiftLoseHpAfter <= 0) { wF.ko = true; wF.killedBy = lF.id; }
    log(`<span class="log-dmg">${lF.name} — Swift counter! 4 damage to ${wF.name}!</span> ${wF.ko?'<span class="log-ko">KO!</span>':swiftLoseHpAfter+' HP left'}`);
  }

  // Patrick (10) — Stone Form counter: 3 damage dealt back to the winner for throwing a singles roll
  // wF.hp deferred to onShow so HP bar updates when STONE FORM! callout fires, not silently during beat 4.
  // wF.ko is set synchronously here so Cameron (25) Force of Nature check at line ~8814 sees the correct KO state.
  if (patrickStoneForm) {
    stoneFormHpAfter = Math.max(0, wF.hp - patrickStoneDmg);
    if (stoneFormHpAfter <= 0) { wF.ko = true; wF.killedBy = lF.id; }
    log(`<span class="log-dmg">${lF.name} — Stone Form counter! ${patrickStoneDmg} damage to ${wF.name}!</span> ${wF.ko?'<span class="log-ko">KO!</span>':stoneFormHpAfter+' HP left'}`);
  }

  // Cameron (25) — Unstoppable Force: damage cannot be negated (cameronUnnegatable flag set above,
  // all negation checks already guarded). Log a callout if Cameron wins and dealt damage.
  let cameronUnstoppableLogged = false;
  if (cameronUnnegatable && !wF.ko && dmg > 0) {
    cameronUnstoppableLogged = true;
    collectKC(winTeamName, wF.name);
    log(`<span class="log-ability">${wF.name}</span> — Unstoppable Force! Damage cannot be negated!`);
  }

  // Pudge self-damage (game state — HP mutation deferred to BELLY FLOP! onShow)
  // pudgeSelfDmgApplied tracks that damage landed so the visual fires even on a fatal hit —
  // without it, wF.ko=true from the fatal self-hit causes the animation to be silently skipped.
  let pudgeSelfDmgApplied = false;
  let pudgeHpAfter = 0;
  if (pudgeSelfDmg && !wF.ko) {
    pudgeHpAfter = Math.max(0, wF.hp - 1); // compute only — HP bar deferred to onShow
    if (pudgeHpAfter <= 0) { wF.ko = true; wF.killedBy = -1; } // ko flag synchronous (Cameron check); killedBy=-1 = self-inflicted (Belly Flop), so no kill credit goes to the loser
    pudgeSelfDmgApplied = true;
    log(`<span class="log-dmg">${wF.name} takes 1 self-damage from Belly Flop!</span> ${wF.ko?'<span class="log-ko">KO!</span>':pudgeHpAfter+' HP left'}`);
  }

  // Prince Balatron (113) — Party Time: lose & survive → player rolls 1 counter die
  // Counter fires even if wF is not KO'd by the main roll — Balatron always fights back when alive.
  // The counter die is pre-computed here (so wF.ko/Cameron cascade stays accurate) but the
  // reveal + HP mutation + log are deferred to showBalatronModal → finishBalatronRoll so the
  // player gets the dramatic click-to-roll moment. See function block near showSylviaModal.
  let balatronCounterDie = 0;
  let balatronHpAfter = 0;
  let balatronTriggered = false;
  if (lF.id === 113 && !lF.ko && !wF.ko) {
    balatronCounterDie = Math.floor(Math.random() * 6) + 1;
    balatronHpAfter = Math.max(0, wF.hp - balatronCounterDie); // compute only — HP bar deferred to modal
    const willKo = balatronHpAfter <= 0;
    if (willKo) { wF.ko = true; wF.killedBy = lF.id; } // ko flag synchronous (Cameron check)
    balatronTriggered = true;
    collectKC(loseTeamName, lF.name);
    // Stash everything the modal will need. Log is deferred to finishBalatronRoll so the
    // combat log doesn't spoil the reveal before the player clicks the roll button.
    B.balatronPending = {
      counterDie: balatronCounterDie,
      hpAfter: balatronHpAfter,
      wasKo: willKo,
      lFName: lF.name,
      wFName: wF.name,
      loseTeamName: loseTeamName
    };
  }

  // Bubble Boys (44) — Pop: if the opposing ghost rolled triples, Bubble Boys are instantly defeated.
  // Two cases: (1) BB lost and enemy winner rolled triples; (2) BB won but losing roll was also triples.
  let bubbleBoysPopped = false;
  let bubbleBoysName = '';
  let bubbleBoysEnemyName = '';
  // Case 1: Bubble Boys lost, enemy winner rolled triples
  if (lF.id === 44 && !lF.ko && wR.type === 'triples') {
    lF.hp = 0;
    lF.ko = true;
    lF.killedBy = (wF.originalId || wF.id);
    bubbleBoysPopped = true;
    bubbleBoysName = lF.name;
    bubbleBoysEnemyName = wF.name;
    collectKC(loseTeamName, lF.name);
    log(`<span class="log-ability">${lF.name}</span> — Pop! ${wF.name} rolled triples — Bubble Boys burst!`);
  }
  // Case 2: Bubble Boys won, but the losing roll was also triples (enemy still activated Pop)
  if (wF.id === 44 && !wF.ko && lR.type === 'triples') {
    wF.hp = 0;
    wF.ko = true;
    wF.killedBy = lF.id;
    bubbleBoysPopped = true;
    bubbleBoysName = wF.name;
    bubbleBoysEnemyName = lF.name;
    collectKC(winTeamName, wF.name);
    log(`<span class="log-ability">${wF.name}</span> — Pop! ${lF.name} rolled triples — Bubble Boys burst even in victory!`);
  }

  // Night Master (103) — Bullseye: win with doubles → destroy an enemy sideline ghost that has < 4 HP
  // Snipes the first eligible target (lowest index). KO applied now; callout fires via queue.
  let bullseyeTarget = null;
  if (wF.id === 103 && !wF.ko && wR.type === 'doubles') {
    const loseActiveIdx = loseTeam.activeIdx;
    const bsCandidate = loseTeam.ghosts.find((g, i) => i !== loseActiveIdx && !g.ko && g.hp < 4);
    if (bsCandidate) {
      bullseyeTarget = { ghost: bsCandidate, priorHp: bsCandidate.hp };
      bsCandidate.hp = 0;
      bsCandidate.ko = true;
      bsCandidate.killedBy = 103;
      collectKC(winTeamName, wF.name);
      log(`<span class="log-ability">${wF.name}</span> — Bullseye! ${bsCandidate.name} (${bullseyeTarget.priorHp} HP) sniped from the enemy sideline!`);
    }
  }

  // Slicer (460) — Parting Gift: Sideline & In Play — win with quads+ → destroy any enemy sideline ghost
  // Auto-picks highest-HP target (most impactful). No HP restriction unlike Night Master.
  let slicerTarget = null;
  const slicerActive = wF.id === 460 && !wF.ko;
  const slicerSideline = hasSideline(winTeam, 460);
  if ((slicerActive || slicerSideline) && (wR.type === 'quads' || wR.type === 'penta' || wR.type.endsWith('-of-a-kind'))) {
    const loseActiveIdx = loseTeam.activeIdx;
    const slicerCandidates = loseTeam.ghosts.filter((g, i) => i !== loseActiveIdx && !g.ko);
    if (slicerCandidates.length > 0) {
      const best = slicerCandidates.reduce((a, b) => b.hp > a.hp ? b : a);
      slicerTarget = { ghost: best, priorHp: best.hp };
      best.hp = 0;
      best.ko = true;
      best.killedBy = 460;
      const slicerGhost = slicerActive ? wF : getSidelineGhost(winTeam, 460);
      const slicerLabel = slicerSideline && !slicerActive ? `${slicerGhost.name} (sideline)` : slicerGhost.name;
      collectKC(winTeamName, slicerLabel);
      log(`<span class="log-ability">${slicerLabel}</span> — Parting Gift! ${best.name} (${slicerTarget.priorHp} HP) destroyed from the enemy sideline!`);
    }
  }

  // Flora (75) — Restore: rolling doubles (win OR lose) heals +2 HP. Fires after damage is applied.
  // Win case: Flora won with doubles — heal her after lF took damage.
  // Lose case: Flora lost but rolled doubles and survived — heal even in defeat.
  // Mr Filbert (59) — Mask Merchant: if Filbert is on the enemy sideline, the +2 heal flips to -2 damage.
  // HP mutation deferred to onShow so the bar jumps exactly when RESTORE!/MASK MERCHANT! flashes.
  let floraRestored = false;
  let floraRestoredName = '';
  let floraRestoredHp = 0;
  let floraFlipped = false;
  let floraFlippedName = '';
  let floraFlippedFrom = 0;
  let floraFlippedTo = 0;
  let floraGhost = null; // captured reference for onShow callback
  if (wF.id === 75 && !wF.ko && wR.type === 'doubles') {
    const flBefore = wF.hp;
    floraGhost = wF;
    if (filbertCursesWin) {
      floraFlippedTo = Math.max(0, wF.hp - 2); // compute only — defer mutation to onShow
      if (floraFlippedTo <= 0) { wF.ko = true; wF.killedBy = 59; } // KO flag synchronous (Cameron check)
      floraFlipped = true; floraFlippedName = wF.name; floraFlippedFrom = flBefore;
      collectKC(winTeamName, wF.name);
      log(`<span class="log-ability">${wF.name}</span> — Restore! Mr Filbert curses it → -2 HP! (${flBefore} → ${floraFlippedTo})`);
    } else {
      floraRestoredHp = wF.hp + 2; // compute only — defer mutation to onShow
      floraRestoredName = wF.name; floraRestored = true;
      collectKC(winTeamName, wF.name);
      log(`<span class="log-ability">${wF.name}</span> — Restore! Doubles win → +2 HP! (${flBefore} → ${floraRestoredHp}/${wF.maxHp}${floraRestoredHp > wF.maxHp ? ' overclocked!' : ''})`);
    }
  }
  if (lF.id === 75 && !lF.ko && lR.type === 'doubles') {
    const flBefore = lF.hp;
    floraGhost = lF;
    if (filbertCursesLose) {
      floraFlippedTo = Math.max(0, lF.hp - 2); // compute only — defer mutation to onShow
      if (floraFlippedTo <= 0) { lF.ko = true; lF.killedBy = 59; } // KO flag synchronous
      floraFlipped = true; floraFlippedName = lF.name; floraFlippedFrom = flBefore;
      collectKC(loseTeamName, lF.name);
      log(`<span class="log-ability">${lF.name}</span> — Restore! Mr Filbert curses it → -2 HP! (${flBefore} → ${floraFlippedTo})`);
    } else {
      floraRestoredHp = lF.hp + 2; // compute only — defer mutation to onShow
      floraRestoredName = lF.name; floraRestored = true;
      collectKC(loseTeamName, lF.name);
      log(`<span class="log-ability">${lF.name}</span> — Restore! Rolled doubles → +2 HP even in defeat! (${flBefore} → ${floraRestoredHp}/${lF.maxHp}${floraRestoredHp > lF.maxHp ? ' overclocked!' : ''})`);
    }
  }

  // Simon (24) — Brew Time: REMOVED from post-roll damage. Only triggers on before-the-roll effects
  // (Swarm, Haunt, Toxic Fumes, Blue Fire/Meteor, Princess Shade Bounty, Shade's Shadow).
  // Pre-roll triggers live in doPreRollSetup(). No post-roll Sacred Fire generation.
  let simonBrewTriggered = false;

  // Sad Sal (29) — Tough Job: losing ANY roll grants +1 Ice Shard (no dmg guard — triggers even on 0 damage)
  // Boobattles ref: "loser.ability === 'Tough Job' → iceShards += 1" — loss condition only, no HP threshold.
  let sadSalTriggered = false;
  if (lF.id === 29) {
    sadSalTriggered = true;
    collectKC(loseTeamName, lF.name);
    log(`<span class="log-ability">${lF.name}</span> — Tough Job! Lost the roll → +1 Ice Shard!`);
  }

  // Hugo (52) — Wreckage: when Hugo takes real roll damage, the attacker loses 1 die next roll
  // Fires even if Hugo is KO'd — attacking Hugo costs you regardless. Flag stored on the WIN team.
  let hugoWreckageTriggered = false;
  if (lF.id === 52 && dmg > 0) {
    B.hugoWreckage[winTeamName] = (B.hugoWreckage[winTeamName] || 0) + 1;
    hugoWreckageTriggered = true;
    collectKC(loseTeamName, lF.name);
    log(`<span class="log-ability">${lF.name}</span> — Wreckage! Took ${dmg} damage → ${wF.name} loses 1 die next roll!`);
  }

  // Marcus (57) — Glacial Pounding: if Marcus (loser) took 3+ real damage, the PLAYER gains +4 bonus dice next roll
  // Fires even if Marcus dies from the hit — the bonus carries to whoever comes in next
  // Must fire AFTER all defensive mods (Stoic, Bogus, King Jay, GF) so dmg reflects what actually landed on lF
  let marcusGlacialTriggered = false;
  if (lF.id === 57 && dmg >= 3) {
    B.marcusGlacialBonus[loseTeamName] = (B.marcusGlacialBonus[loseTeamName] || 0) + 4;
    marcusGlacialTriggered = true;
    collectKC(loseTeamName, lF.name);
    log(`<span class="log-ability">${lF.name}</span> — Glacial Pounding! Took ${dmg} damage → +4 bonus dice next roll!`);
  }

  // Troubling Haters (83) — Growing Mob: win with 4+ damage → +2 HP (overclocks per v294)
  // Mr Filbert (59) — Mask Merchant: flips the +2 heal to -2 damage when on enemy sideline.
  // HP mutation deferred to onShow so HP bar jumps WITH the callout, not before it (same as Opa/Villager/Jeffery pattern).
  let growingMobTriggered = false;
  let growingMobHpAfter = 0;
  let growingMobFlipped = false;
  if (wF.id === 83 && !wF.ko && dmg >= 4) {
    const gmBefore = wF.hp;
    if (filbertCursesWin) {
      growingMobHpAfter = Math.max(0, wF.hp - 2); growingMobFlipped = true; growingMobTriggered = true;
      collectKC(winTeamName, wF.name);
      log(`<span class="log-ability">${wF.name}</span> — Growing Mob! Mr Filbert curses it → -2 HP! (${gmBefore} → ${growingMobHpAfter})`);
    } else {
      growingMobHpAfter = wF.hp + 2; growingMobTriggered = true;
      collectKC(winTeamName, wF.name);
      log(`<span class="log-ability">${wF.name}</span> — Growing Mob! Dealt ${dmg} damage → +2 HP! (${gmBefore} → ${growingMobHpAfter}/${wF.maxHp}${growingMobHpAfter > wF.maxHp ? ' overclocked!' : ''})`);
    }
  }

  // Munch (66) — Scraps: upon defeating a ghost, gain 4 health (overclocks per v294)
  // Mr Filbert (59) — Mask Merchant: flips the +4 heal to -4 damage when on enemy sideline.
  // HP mutation deferred to onShow so HP bar jumps WITH the callout, not before it (same as Opa/Villager/Jeffery pattern).
  let munchScrapTriggered = false;
  let munchHpBefore = 0;
  let munchHpAfter = 0;
  let munchFlipped = false;
  if (wF.id === 66 && !wF.ko && lF.ko) {
    munchHpBefore = wF.hp;
    if (filbertCursesWin) {
      munchHpAfter = Math.max(0, wF.hp - 4); munchFlipped = true; munchScrapTriggered = true;
      collectKC(winTeamName, wF.name);
      log(`<span class="log-ability">${wF.name}</span> — Scraps! Mr Filbert curses it → -4 HP! (${munchHpBefore} → ${munchHpAfter})`);
    } else {
      munchHpAfter = wF.hp + 4; munchScrapTriggered = true;
      collectKC(winTeamName, wF.name);
      log(`<span class="log-ability">${wF.name}</span> — Scraps! ${lF.name} defeated → +4 HP! (${munchHpBefore} → ${munchHpAfter}/${wF.maxHp}${munchHpAfter > wF.maxHp ? ' overclocked!' : ''})`);
    }
  }

  // On-win resource gains — deferred to callout onShow so tiles update WITH the splash, not 800ms before it.
  // Beat 4 renderBattle() fires at t=1900ms; the ability queue starts at t=2700ms — without this deferral,
  // the player sees "+2 Surge" appear during the HP bar drop, then sees PLUNDER! announce it 800ms later.
  if (wF.id === 209 && !wF.ko) { collectKC(winTeamName, wF.name); }
  if (wF.id === 307 && !wF.ko) { collectKC(winTeamName, wF.name); }
  if (wF.id === 342 && !wF.ko) { collectKC(winTeamName, wF.name); }
  if (wF.id === 336 && !wF.ko) { collectKC(winTeamName, wF.name); }
  if (wF.id === 309 && !wF.ko) { collectKC(winTeamName, wF.name); }
  if (wF.id === 81 && !wF.ko) { collectKC(winTeamName, wF.name); }   // Spockles Valley Magic
  if (wF.id === 58 && !wF.ko) { collectKC(winTeamName, wF.name); }   // Ashley Burning Soul
  if (wF.id === 206 && !wF.ko) { collectKC(winTeamName, wF.name); }  // Zain Ice Blade — win grants +1 Ice Shard
  // Dylan (301) Stained Glass — Sideline & In Play: winning rolls gain +1 Burn
  const hasDylanWin = (wF.id === 301 && !wF.ko) || hasSideline(winTeam, 301);
  if (hasDylanWin) { collectKC(winTeamName, wF.id === 301 ? wF.name : 'Dylan'); }
  // Farmer Jeff (314) — Harvest: active OR sideline fires on any 6 rolled, win OR lose (v636 buff).
  // Cornelius (45) Antidote blocks Farmer Jeff's sideline effect (not active).
  const fjWinIsActive = wF.id === 314 && !wF.ko;
  const fjWinIsSideline = hasSideline(winTeam, 314);
  const corneliusBlocksFJWin = fjWinIsSideline && !fjWinIsActive && hasSideline(loseTeam, 45);
  const hasFJWin = (fjWinIsActive || fjWinIsSideline) && !corneliusBlocksFJWin;
  if (hasFJWin) {
    const sixes = countVal(winDice, 6);
    if (sixes > 0) { const jeffGhost = getSidelineGhost(winTeam, 314) || wF; collectKC(winTeamName, 'Farmer Jeff', jeffGhost); }
  }
  const fjLoseIsActive = lF.id === 314 && !lF.ko;
  const fjLoseIsSideline = hasSideline(loseTeam, 314);
  const corneliusBlocksFJLose = fjLoseIsSideline && !fjLoseIsActive && hasSideline(winTeam, 45);
  const hasFJLose = (fjLoseIsActive || fjLoseIsSideline) && !corneliusBlocksFJLose;
  if (hasFJLose) {
    const sixesLose = countVal(loseDice, 6);
    if (sixesLose > 0) { const jeffGhostLose = getSidelineGhost(loseTeam, 314) || lF; collectKC(loseTeamName, 'Farmer Jeff', jeffGhostLose); }
  }

  // Aunt Susan heal bonus (game state — preview only; actual HP mutation deferred to HARVEST DANCE! onShow)
  // Also checks for Mr. Filbert (59) curse: heal → damage (same pattern as Shoo/Boris/Katrina/Opa).
  B.auntSusanHealResult = {};
  ['red', 'blue'].forEach(tn => {
    if (B.auntSusanHealBonus[tn] > 0) {
      const f = active(B[tn]);
      if (!f.ko) {
        const healAmt = B.auntSusanHealBonus[tn] * 2;
        const enemyT = tn === 'red' ? B.blue : B.red;
        const filbertFlips = hasSideline(enemyT, 59);
        const hpBefore = f.hp;
        if (filbertFlips) {
          const hpAfter = Math.max(0, hpBefore - healAmt);
          B.auntSusanHealResult[tn] = { f, healAmt, before: hpBefore, after: hpAfter, filbertFlipped: true };
          log(`<span class="log-ability">Mr Filbert</span> — Harvest Dance cursed! ${f.name} takes ${healAmt} damage! (${hpBefore}→${hpAfter} HP)`);
        } else {
          const hpAfter = hpBefore + healAmt;
          const susanOver = hpAfter > f.maxHp;
          B.auntSusanHealResult[tn] = { f, healAmt, before: hpBefore, after: hpAfter, overclocked: susanOver };
          log(`<span class="log-heal">${f.name}</span> — Harvest Dance! Healed +${healAmt} HP (${hpBefore}→${hpAfter}/${f.maxHp})${susanOver ? ' · overclocked!' : ''}!`);
        }
      }
    }
  });

  // On-lose resource gains — deferred to BITTER END! onShow (same Beat-4 race as on-win grants)
  if (lF.id === 404 && !lF.ko) { collectKC(loseTeamName, lF.name); }
  // NOTE: Sad Sal (29) collectKC already called at line ~10004 (no-ko-guard block) — do NOT add a second one here

  // On-KO triggers (game state) — resource grants deferred to BEDTIME STORY!/BITTER END! onShow
  let powderFinalGiftTriggered = false;
  // Cornelius (45) Antidote blocks Granny's sideline Bedtime Story (hoisted for render section access)
  const corneliusBlocksGrannyLose = hasSideline(winTeam, 45);
  const corneliusBlocksGrannyWin = hasSideline(loseTeam, 45);
  if (lF.ko) {
    if (hasSideline(loseTeam, 310) && !corneliusBlocksGrannyLose) {
      const grannyGhost = getSidelineGhost(loseTeam, 310);
      collectKC(loseTeamName, 'Granny', grannyGhost);
    }
    // Powder (23) — Final Gift: KO'd → team gains 3 Ice Shards for the next ghost
    if (lF.id === 23) {
      powderFinalGiftTriggered = true;
      collectKC(loseTeamName, lF.name); // Knight reactions fire on FINAL GIFT! (same pattern as Granny/Chagrin KO paths)
      log(`<span class="log-ability">${lF.name}</span> — Final Gift! KO'd... leaving 3 Ice Shards for the next ghost.`);
    }
    if (lF.id === 404) { collectKC(loseTeamName, lF.name); } // Chagrin on-KO surge → BITTER END! onShow below
  }

  // Granny Bedtime Story fires for the WINNER's team too when the winner self-KOs (Pudge Belly Flop)
  if (wF.ko && hasSideline(winTeam, 310) && !corneliusBlocksGrannyWin) {
    const grannyGhost = getSidelineGhost(winTeam, 310);
    collectKC(winTeamName, 'Granny', grannyGhost);
  }

  // Bo (109) — Miracle: upon defeating a Ghost, revive a previously KO'd ally to sideline at 1 HP.
  // Detection in game-state section; actual revive deferred to MIRACLE! onShow so the resurrection
  // is visually synchronized with the callout splash (same Beat-4 deferral pattern as Granny/Dart).
  let boMiracleTarget = null;
  if (wF.id === 109 && !wF.ko && lF.ko) {
    const revived = winTeam.ghosts.find((g, i) => i !== winTeam.activeIdx && g.ko);
    if (revived) {
      boMiracleTarget = revived;
      collectKC(winTeamName, wF.name);
    }
  }

  // End-of-round (game state) — Maximo seed deferred to NAP! onShow
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const tNameMax2 = team === B.red ? 'red' : 'blue';
    if (f.id === 302 && !f.ko) { collectKC(tNameMax2, f.name); }
  });

  // (Eternal Flame game state already handled at line ~2657)

  // ========================================
  // CINEMATIC ABILITY QUEUE — visuals play sequentially
  // ========================================
  abilityQueue = [];
  abilityQueueMode = true;

  // BLACKOUT! fires before winner calc, so its callouts lead the queue
  blackoutCallouts.forEach(b => queueAbility(b.name, b.color, b.desc, null, b.team));

  // Damage modifier callouts
  if (B.auntSusanBonus[winTeamName] > 0) {
    const cnt = B.auntSusanBonus[winTeamName];
    queueAbility('HARVEST DANCE!', 'var(--rare)', `${wF.name} — ${cnt} seed${cnt>1?'s':''} → +${cnt*2} damage!`, null, winTeamName);
  }
  // Aunt Susan heal callouts (both teams) — actual HP mutation happens inside onShow so the bar
  // jumps exactly when HARVEST DANCE! (or MASK MERCHANT!) fires, not before.
  ['red', 'blue'].forEach(tn => {
    if (B.auntSusanHealBonus[tn] > 0) {
      const cnt = B.auntSusanHealBonus[tn];
      const res = (B.auntSusanHealResult || {})[tn];
      if (res) {
        const { f, healAmt, before, after, overclocked, filbertFlipped } = res;
        if (filbertFlipped) {
          queueAbility('MASK MERCHANT!', 'var(--uncommon)',
            `Mr Filbert — Harvest Dance cursed! ${f.name} takes ${healAmt} damage! (${before}→${after} HP)`,
            () => { f.hp = Math.max(0, f.hp - healAmt); if (f.hp <= 0) { f.hp = 0; f.ko = true; f.killedBy = 59; } renderBattle(); }, tn);
        } else {
          const hpDelta = `${before}→${after} HP${overclocked ? ' · overclocked!' : ''}`;
          queueAbility('HARVEST DANCE!', 'var(--rare)',
            `${f.name} — ${cnt} seed${cnt>1?'s':''} → +${cnt*2} HP! ${hpDelta}`,
            () => { f.hp += healAmt; renderBattle(); }, tn);
        }
      }
    }
  });
  if (pudgeSelfDmg || (wF.id === 311 && wR.type === 'doubles')) {
    queueAbility('BELLY FLOP!', 'var(--common)', `${wF.name} — Doubles! +2 damage, 1 self-damage! (${pudgeHpAfter} HP left)`, pudgeSelfDmgApplied ? () => { wF.hp = pudgeHpAfter; renderBattle(); } : null, winTeamName);
  }
  if (mountainKingTriggered) {
    queueAbility('BEAST MODE!', 'var(--legendary)', `${wF.name} — Doubles! ${mountainKingBaseDmg} × 2 = ${dmg} damage!`, null, winTeamName);
  }
  if (stoneColdTriggered) {
    queueAbility('ONE-TWO-ONE!', 'var(--rare)', `${wF.name} — Double 1s! ${stoneColdBaseDmg} × 3 = ${dmg} damage!`, null, winTeamName);
  }
  if (larryTriggered) {
    queueAbility('FLYING KICK!', 'var(--uncommon)', `${wF.name} — Triples! ${larryBaseDmg} × 3 = ${dmg} damage!`, null, winTeamName);
  }
  if (buttonsTriggered) {
    queueAbility('PERFECT PLAN!', 'var(--common)', `${wF.name} — TRIPLE 6s!!! ${buttonsBaseDmg} + 15 = ${dmg} damage!!`, null, winTeamName);
  }
  if (nikonTriggered) {
    queueAbility('AMBUSH!', 'var(--common)', `${wF.name} — First roll! ${nikonBaseDmg} × 3 = ${dmg} damage!`, null, winTeamName);
  }
  if (caveDwellerTriggered) {
    queueAbility('LURK!', 'var(--uncommon)', `${wF.name} — First roll ambush! ${caveDwellerBaseDmg} × 3 = ${dmg} damage!`, null, winTeamName);
  }
  if (doomTriggered) {
    queueAbility('FIENDSHIP!', 'var(--legendary)', `${wF.name} — Win! +2 bonus damage dealt!`, null, winTeamName);
  }
  if (lucyTriggered) {
    queueAbility('BLUE FIRE!', 'var(--legendary)', `${wF.name} — Win! +1 Sacred Fire!`, () => { winTeam.resources.fire++; renderBattle(); }, winTeamName);
  }
  if (lucyShadowExtraFire) {
    queueAbility('MENTOR!', 'var(--rare)', `Lucy's Shadow — Mentor! +1 extra Sacred Fire!`, () => { winTeam.resources.fire++; renderBattle(); }, winTeamName);
  }
  if (gomTriggered) {
    queueAbility('CHAOS!', 'var(--common)', `${wF.name} — Win with doubles! +1 Sacred Fire!`, () => { winTeam.resources.fire++; renderBattle(); }, winTeamName);
  }
  if (wimTriggered) {
    queueAbility('SLASH!', 'var(--rare)', `${wF.name} — All dice odd! ${wimBaseDmg} + 5 = ${dmg} damage!`, null, winTeamName);
  }
  if (snortonTriggered) {
    queueAbility('FISSURE!', 'var(--rare)', `${wF.name} — Two 6s! ${snortonBaseDmg} + 5 = ${dmg} damage!`, null, winTeamName);
  }
  if (floraRestored) {
    queueAbility('RESTORE!', 'var(--rare)', `${floraRestoredName} — Doubles! +2 HP! Now at ${floraRestoredHp} HP!`, () => { floraGhost.hp = floraRestoredHp; renderBattle(); }, floraGhost === wF ? winTeamName : loseTeamName);
  }
  if (floraFlipped) {
    queueAbility('MASK MERCHANT!', 'var(--uncommon)', `Mr Filbert — Restore cursed! ${floraFlippedName} takes 2 damage instead! (${floraFlippedFrom} → ${floraFlippedTo} HP)`, () => { floraGhost.hp = floraFlippedTo; renderBattle(); }, floraGhost === wF ? winTeamName : loseTeamName);
  }
  if (pelterTriggered) {
    queueAbility('SNOWBALL!', 'var(--rare)', `${wF.name} — Doubles! ${pelterBaseDmg} + 2 = ${dmg} damage!`, null, winTeamName);
  }
  // Kaylee (453) — Slipstream callout now handled in pre-winner section via blackoutCallouts queue
  if (docTriggered) {
    queueAbility('SAVAGE!', 'var(--uncommon)', `${wF.name} — Doubles! ${docBaseDmg} + 5 = ${dmg} damage!`, null, winTeamName);
  }
  if (charlieTriggered) {
    queueAbility('RUSH!', 'var(--common)', `${wF.name} — Double 2s! Override → exactly 7 damage!`, null, winTeamName);
  }
  if (billBobTriggered) {
    queueAbility('BAIT N SWITCH!', 'var(--uncommon)', `${wF.name} — Below 4 HP! ${billBobBaseDmg} × 2 = ${dmg} damage!`, null, winTeamName);
  }
  if (alucardTriggered) {
    queueAbility('COLONY CALL!', 'var(--uncommon)', `${wF.name} — Doubles! ${alucardSidelineCount} sideline ghost${alucardSidelineCount>1?'s':''} × 2 = ${alucardBaseDmg} + ${alucardSidelineCount*2} = ${dmg} damage! (Once per game used)`, null, winTeamName);
  }
  if (castleGuardsTriggered) {
    queueAbility('FLAMETHROWER!', 'var(--uncommon)', `${wF.name} — ${castleGuardsThreeCount} three${castleGuardsThreeCount>1?'s':''} rolled! ${castleGuardsBaseDmg} × ${Math.pow(2,castleGuardsThreeCount)} = ${dmg} damage!`, null, winTeamName);
  }
  if (teamZippyTriggered) {
    queueAbility('TEAMWORK!', 'var(--uncommon)', `${wF.name} — Singles win! ${teamZippyBaseDmg} + 2 = ${dmg} damage!`, null, winTeamName);
  }
  if (ridleyTriggered) {
    queueAbility('NIMBLE!', 'var(--uncommon)', `${wF.name} — ${wR.type === 'singles' ? 'Singles' : 'Doubles'}! ${ridleyBaseDmg} + ${ridleyBonus} = ${ridleyBaseDmg + ridleyBonus} damage!`, null, winTeamName);
  }
  if (gregTriggered) {
    queueAbility('CHASE!', 'var(--uncommon)', `${wF.name} — More HP than ${lF.name}! (${wF.hp} vs ${lF.hp}) ${gregBaseDmg} × 2 = ${dmg} damage!`, null, winTeamName);
  }
  if (tommyTriggered) {
    queueAbility('REGULATOR!', 'var(--common)', `${wF.name} — Rolled 6s! +${tommyRegulatedCount} bonus dice added!`, null, winTeamName);
  }
  if (growingMobTriggered) {
    const growingMobGhost = wF; // safe closure reference
    if (growingMobFlipped) {
      queueAbility('MASK MERCHANT!', 'var(--uncommon)', `Mr Filbert — Growing Mob cursed! ${growingMobGhost.name} takes 2 damage instead! (→ ${growingMobHpAfter} HP)`, () => { growingMobGhost.hp = growingMobHpAfter; if (growingMobGhost.hp <= 0) { growingMobGhost.hp = 0; growingMobGhost.ko = true; growingMobGhost.killedBy = 59; } renderBattle(); }, winTeamName);
    } else {
      queueAbility('GROWING MOB!', 'var(--rare)', `${growingMobGhost.name} — ${dmg} damage dealt! +2 HP! Now at ${growingMobHpAfter} HP!`, () => { growingMobGhost.hp = growingMobHpAfter; renderBattle(); }, winTeamName);
    }
  }
  if (munchScrapTriggered) {
    const munchGhost = wF; // safe closure reference
    if (munchFlipped) {
      queueAbility('MASK MERCHANT!', 'var(--uncommon)', `Mr Filbert — Scraps cursed! ${munchGhost.name} takes 4 damage instead! (${munchHpBefore} → ${munchHpAfter} HP)`, () => { munchGhost.hp = munchHpAfter; if (munchGhost.hp <= 0) { munchGhost.hp = 0; munchGhost.ko = true; munchGhost.killedBy = 59; } renderBattle(); }, winTeamName);
    } else {
      queueAbility('SCRAPS!', 'var(--rare)', `${munchGhost.name} — ${lF.name} defeated! +4 HP! (${munchHpBefore} → ${munchHpAfter}/${munchGhost.maxHp})`, () => { munchGhost.hp = munchHpAfter; renderBattle(); }, winTeamName);
    }
  }
  if (romyTriggered) {
    queueAbility('VALLEY GUARDIAN!', 'var(--legendary)', `${wF.name} — Predicted ${romyWinPred}... HIT! +3 damage!`, null, winTeamName);
  }
  if (hectorTriggered) {
    queueAbility('PROTECTOR!', 'var(--ghost-rare)', `${wF.name} — Singles win! +1 bonus damage!`, null, winTeamName);
  }
  if (tabithaTriggered) {
    queueAbility('RALLY!', 'var(--ghost-rare)', `Tabitha cheers from the sideline — Doubles! +2 damage!`, null, winTeamName);
  }
  if (darkJeffTriggered) {
    queueAbility('CACKLE!', 'var(--rare)', `Dark Jeff (sideline) — ${darkJeffBaseDmg} + 1 = ${dmg} damage!`, null, winTeamName);
  }
  if (explorerJeffTriggered) {
    queueAbility('TREASURE HUNTER!', 'var(--uncommon)', `Explorer Jeff (sideline) — ${explorerJeffBaseDmg} + 1 = ${dmg} damage!`, null, winTeamName);
  }
  if (admiralTriggered) {
    queueAbility('COMRADES!', 'var(--rare)', `Admiral (sideline) — Even doubles! ${admiralBaseDmg} + 2 = ${dmg} damage!`, null, winTeamName);
  }
  if (bilboTriggered) {
    queueAbility('LITTLE BUDDY!', 'var(--rare)', `Bilbo (sideline) — Singles win! ${bilboBaseDmg} + 2 = ${dmg} damage!`, null, winTeamName);
  }
  if (paleNimbusTriggered) {
    const pnSum = winDice ? winDice.reduce((s, d) => s + d, 0) : '?';
    queueAbility('HIDDEN STORM!', 'var(--rare)', `Pale Nimbus (sideline) — Roll sum ${pnSum} < 7! ${paleNimbusBaseDmg} + 2 = ${dmg} damage!`, null, winTeamName);
  }
  // Laura (79) — Catchy Tune unlock callouts (only on first activation)
  if (catchyJustUnlockedWin) {
    const _lSeq = [...winDice].sort((a, b) => a - b).join('-');
    queueAbility('CATCHY TUNE!', 'var(--rare)', `Laura — Straight [${_lSeq}]! Catchy Tune unlocked permanently!`, () => { renderBattle(); }, winTeamName);
  }
  if (catchyJustUnlockedLose) {
    const _lSeqL = [...loseDice].sort((a, b) => a - b).join('-');
    queueAbility('CATCHY TUNE!', 'var(--rare)', `Laura — Straight [${_lSeqL}]! Catchy Tune unlocked permanently!`, () => { renderBattle(); }, loseTeamName);
  }
  // Gary (92) — Lucky Novice: win-team Gary — 1s in winning dice grant ice shards (active OR sideline, v598)
  if (garyOnesWin > 0) {
    const garyWinIceTotal = winTeam.resources.ice + garyIceWin;
    const _garyWinId = winGaryActive ? 92 : (getSidelineGhost(winTeam, 92) || { id: 92 }).id;
    const _garyWinLoc = winGaryActive ? 'active' : 'sideline';
    queueAbility('LUCKY NOVICE!', 'var(--rare)', `Gary (${_garyWinLoc}) — ${garyOnesWin} rolled 1${garyOnesWin > 1 ? 's' : ''}! +${garyIceWin} Ice Shards! (${garyWinIceTotal} total)`, () => { winTeam.resources.ice += garyIceWin; creditGhost(winTeamName, _garyWinId, 'ice', garyIceWin); renderBattle(); }, winTeamName);
    if (sandwichForLose) queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Lucky Novice! +${garyIceWin} Ice Shards! (${loseTeam.resources.ice + garyIceWin} total)`, () => { loseTeam.resources.ice += garyIceWin; creditGhost(loseTeamName, 33, 'ice', garyIceWin); renderBattle(); }, loseTeamName);
    // Knight reactions already collected via collectKC at game-state section (line ~9526) — do NOT double-fire here
  }
  if (banditPeteTriggered) {
    const bpWhoQ = winDice && winDice.length === 2 ? 'Your ghost rolled only 2 dice!' : 'Opponent rolled only 2 dice!';
    queueAbility('BANDIT!', 'var(--rare)', `Bandit Pete (sideline) — ${bpWhoQ} ${banditPeteBaseDmg} + 3 = ${dmg} damage!`, null, winTeamName);
  }
  // Bandit Pete knight reactions already collected via collectKC at game-state section (~line 9545) — do NOT double-fire here
  if (zachCraftsmanTriggered) {
    queueAbility('CRAFTSMAN!', 'var(--rare)', `Zach (sideline) — Guard Thomas doubles! ${zachCraftsmanBaseDmg} + 3 = ${dmg} damage!`, null, winTeamName);
  }
  if (booTeamworkDmgTriggered) {
    queueAbility('TEAMWORK!', 'var(--common)', `${wF.name} — Used Teamwork! +1 bonus damage!`, null, winTeamName);
  }
  if (zippaGlimmerBonus > 0) {
    queueAbility('GLIMMER!', 'var(--uncommon)', `${wF.name} — ${zippaGlimmerBonus} Healing Seed${zippaGlimmerBonus>1?'s':''} = +${zippaGlimmerBonus} damage!`, null, winTeamName);
  }
  // Zach knight reactions already collected via collectKC at game-state section (~line 9561) — do NOT double-fire here
  if (louBrosTriggered) {
    // HP heal deferred so the tile updates exactly as the BROS! splash fires — same pattern as Opa Rest / Calvin Overclock
    const louHpBefore = wF.hp;
    const louHpAfter = wF.hp + 1;
    const louOver = louHpAfter > wF.maxHp;
    if (filbertCursesWin) {
      const louFlipped = Math.max(0, wF.hp - 1);
      const louGhost = wF;
      queueAbility('MASK MERCHANT!', 'var(--uncommon)', `Mr Filbert — Bros heal cursed! ${wF.name} takes 1 damage instead! (${wF.hp}→${louFlipped} HP)`, () => { louGhost.hp = louFlipped; if (louGhost.hp <= 0) { louGhost.hp = 0; louGhost.ko = true; louGhost.killedBy = 59; } renderBattle(); }, winTeamName);
      log(`<span class="log-ability">Lou</span> (sideline) — Bros heal cursed by Mr Filbert! ${wF.name} loses 1 HP.`);
    } else {
      queueAbility('BROS!', 'var(--common)', `Lou (sideline) — ${wF.name} wins! ${louBrosBaseDmg} + 1 = ${dmg} damage! +1 HP! (${louHpBefore}→${louHpAfter} HP${louOver ? ' · overclocked!' : ''})`, () => { wF.hp++; renderBattle(); }, winTeamName);
      log(`<span class="log-ability">Lou</span> (sideline) — Bros! Grawr wins → +1 HP (${louHpBefore}→${louHpAfter}${louOver ? ' overclocked!' : ''}).`);
    }
  }
  // Lou knight reactions already collected via collectKC at game-state section (~line 9577) — do NOT double-fire here
  if (chipTriggered) {
    queueAbility('ACROBATIC DIVE!', 'var(--common)', `${wF.name} — Even doubles! +3 damage! (${chipBaseDmg} + 3 = ${dmg})`, null, winTeamName);
  }
  // Chip knight reactions already collected via collectKC at game-state section (~line 9589) — do NOT double-fire here
  if (yawnEaterOddTriggered) {
    queueAbility('FEAST!', 'var(--uncommon)', `${wF.name} — Odd doubles! +1 damage!`, null, winTeamName);
  }
  if (librarianTriggered) {
    queueAbility('KNOWLEDGE!', 'var(--common)', `Ancient Librarian — ${librarianTwos} 2${librarianTwos > 1 ? 's' : ''} rolled by both teams! ${librarianBaseDmg} + ${librarianTwos} = ${dmg} damage!`, null, winTeamName);
  }
  // Ancient Librarian knight reactions already collected via collectKC at game-state section (~line 9604) — do NOT double-fire here
  if (wandererTriggered) {
    const _wandererSorted = [...winDice].sort((a, b) => a - b);
    queueAbility('CURIOSITY!', 'var(--common)', `${wF.name} — Straight [${_wandererSorted.join('-')}]! +2 damage!`, null, winTeamName);
  }
  if (sparkyTriggered) {
    queueAbility('TINDER!', 'var(--rare)', `${wF.name} — ${sparkyOneCount} rolled 1${sparkyOneCount > 1 ? 's' : ''} × 3 = +${sparkyOneCount * 3} damage! (${sparkyBaseDmg} + ${sparkyOneCount * 3} = ${dmg})`, null, winTeamName);
  }
  // Sparky knight reactions already collected via collectKC at game-state section (~line 9620) — do NOT double-fire here
  if (!tabithaTriggered && corneliusBlocksRally && hasSideline(winTeam, 95) && wR.type === 'doubles' && !wF.ko) {
    // Cornelius (45) — Antidote: blocked Tabitha Rally — show the negation callout
    const cornGhost3 = getSidelineGhost(loseTeam, 45);
    const blockerName = cornGhost3 ? cornGhost3.name : 'Cornelius';
    queueAbility('ANTIDOTE!', 'var(--uncommon)', `${blockerName} neutralizes Tabitha's Rally — +0 damage!`, null, loseTeamName);
  }
  // Cornelius (45) — Antidote: blocked any other sideline damage boosters (Admiral/Dark Jeff/Bilbo/Pale Nimbus/Laura/Bandit Pete/Zach/Lou)
  if (corneliusSidelineBlockedList.length > 0) {
    const cornGhost4 = getSidelineGhost(loseTeam, 45);
    const antidoteName = cornGhost4 ? cornGhost4.name : 'Cornelius';
    const blockedStr = corneliusSidelineBlockedList.join(', ');
    queueAbility('ANTIDOTE!', 'var(--uncommon)', `${antidoteName} neutralizes: ${blockedStr} — sideline buffs blocked!`, null, loseTeamName);
  }
  if (kodakoSwiftWin) {
    queueAbility('SWIFT!', 'var(--common)', `${wF.name} — 1-2-3! Combo locked in → exactly 4 damage!`, null, winTeamName);
  }
  // Kodako knight reactions already collected via collectKC at game-state section (~line 9638) — do NOT double-fire here
  if (pureHeartKO) {
    queueAbility('PURE HEART!', 'var(--ghost-rare)', `${wF.name} — All-in! ${lF.name} instantly defeated!`, null, winTeamName);
  }
  // Pure Heart/Toby knight reactions already collected via collectKC at game-state section (~line 9356) — do NOT double-fire here
  if (skylarTriggered) {
    const shardsUsed = B.committed[winTeamName].ice;
    queueAbility('WINTER BARRAGE!', 'var(--ghost-rare)', `${wF.name} — ${shardsUsed} Ice Shard${shardsUsed>1?'s':''} × 2 = +${shardsUsed*2} damage!`, null, winTeamName);
  }
  // Skylar knight reactions already collected via collectKC at game-state section (~line 9052) — do NOT double-fire here
  if (tylerFireTriggered) {
    const firesUsed = B.committed[winTeamName].fire;
    queueAbility('HEATING UP!', 'var(--ghost-rare)', `${wF.name} — ${firesUsed} Sacred Fire${firesUsed>1?'s':''} × 2 = +${firesUsed*6} damage!`, null, winTeamName);
  }
  // Tyler knight reactions already collected via collectKC at game-state section (~line 9065) — do NOT double-fire here
  if (zainIceBladeTriggered) {
    queueAbility('ICE BLADE!', 'var(--ghost-rare)', `${wF.name} — Ice Blade strikes! +2 damage!`, null, winTeamName);
  }
  if (zainIceBladeTriggered) checkKnightEffects(winTeamName, wF.name); // Knight Terror/Light react to ICE BLADE! (committed blade)
  // Flame Blade: +3 Burn on win callout
  if (flameBladeWinTriggered) {
    queueAbility('FLAME BLADE!', 'var(--rare)', `Flame Blade strikes! +3 Burn!`, null, winTeamName);
  }
  if (redHunterTriggered) {
    queueAbility('RUMBLE!', 'var(--ghost-rare)', `${wF.name} — Enemy has resources! +3 damage!`, null, winTeamName);
  }
  // Red Hunter knight reactions already collected via collectKC at game-state section (line ~9384) — do NOT double-fire here
  if (timpletonTriggered) {
    queueAbility('BIG TARGET!', 'var(--rare)', `${wF.name} — ${lF.name}'s HP higher than Timpleton! +3 damage!`, null, winTeamName);
  }
  // Timpleton knight reactions already collected via collectKC in the game-state Big Target block above — do NOT double-fire here
  // Sylvia dodge callouts (queued here — abilityQueueMode=true — not in the game-state section)
  if (lF.id === 313 && !lF.ko && sylviaDodgeRolls.length > 0) {
    if (sylviaDodged) queueAbility('PORPOISE!', 'var(--rare)', `${lF.name} rolls [${sylviaDodgeRolls.join(', ')}] — DODGED!`, null, loseTeamName);
    else queueAbility('PORPOISE — MISS', 'var(--border)', `${lF.name} rolls [${sylviaDodgeRolls.join(', ')}] — odd! No dodge.`, null, loseTeamName);
  }
  // Sylvia knight reactions already collected via collectKC at game-state section — do NOT double-fire here

  // Eternal Flame callout — grant fires in onShow so counter updates when the splash fires, not before
  if (B.committed[winTeamName].fire > 0 && winTeam.ghosts.some(g => g.id === 406 && !g.ko)) {
    const _etFlameTeam = winTeam;
    const _etFlameCount = B.committed[winTeamName].fire;
    queueAbility('ETERNAL FLAME!', 'var(--uncommon)', `Fed and Hayden — ${_etFlameCount} Sacred Fire${_etFlameCount > 1 ? 's' : ''} preserved!`, () => {
      _etFlameTeam.resources.fire += _etFlameCount;
      log(`<span class="log-ability">Fed and Hayden</span> — Eternal Flame! ${_etFlameCount} Sacred Fire${_etFlameCount > 1 ? 's' : ''} not discarded! (${_etFlameTeam.resources.fire} total)`);
      renderBattle();
    }, winTeamName);
    checkKnightEffects(winTeamName, 'Fed and Hayden'); // Knight Terror/Light react to ETERNAL FLAME!
    if (sandwichForLose) queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Eternal Flame! +${_etFlameCount} Sacred Fire${_etFlameCount > 1 ? 's' : ''}! (${loseTeam.resources.fire + _etFlameCount} total)`, () => { loseTeam.resources.fire += _etFlameCount; renderBattle(); }, loseTeamName);
  }

  // Prince Balatron (113) — Party Time: NO auto-callout here. B.balatronPending was set in
  // the compute block above; the interactive reveal modal fires at the START of the
  // drainAbilityQueue post-callback (see showBalatronModal injection below), giving the
  // player a click-to-roll moment instead of a flat combat-log line.

  // Night Master (103) — Bullseye: sideline snipe callout — onShow updates sideline display
  if (bullseyeTarget) {
    queueAbility('BULLSEYE!', 'var(--ghost-rare)', `${wF.name} — Doubles! ${bullseyeTarget.ghost.name} (${bullseyeTarget.priorHp} HP) sniped from the enemy sideline!`, () => { renderBattle(); }, winTeamName);
  }

  // Slicer (460) — Parting Gift: sideline snipe callout — onShow updates sideline display
  if (slicerTarget) {
    const slicerGhostQ = (wF.id === 460 && !wF.ko) ? wF : getSidelineGhost(winTeam, 460);
    const slicerLabelQ = (slicerSideline && !slicerActive) ? `${slicerGhostQ ? slicerGhostQ.name : 'Slicer'} (sideline)` : (slicerGhostQ ? slicerGhostQ.name : 'Slicer');
    queueAbility('PARTING GIFT!', 'var(--uncommon)', `${slicerLabelQ} — Quads! ${slicerTarget.ghost.name} (${slicerTarget.priorHp} HP) destroyed from the enemy sideline!`, () => {
      if (slicerSideline && !slicerActive) popSidelineCard(winTeam, 460);
      renderBattle();
    }, winTeamName);
  }

  // Bubble Boys (44) — Pop: callout fires after Bullseye, onShow re-renders so KO greys out BB
  if (bubbleBoysPopped) {
    queueAbility('POP!', 'var(--uncommon)', `${bubbleBoysName} — ${bubbleBoysEnemyName} rolled triples! Bubble Boys burst!`, () => { renderBattle(); }, loseTeamName);
  }

  // King Jay (106) — Reflection: lost + dice total 7 → damage reflected to winner
  // onShow defers wF.hp mutation so the HP bar drops exactly when REFLECTION! fires, not silently during beat 4.
  if (kingJayReflected) {
    const reflectKoSuffix = wF.ko ? ' — KO!' : ` — ${kingJayHpAfter} HP left`;
    queueAbility('REFLECTION!', 'var(--ghost-rare)', `${lF.name} — Lucky 7! ${kingJayReflectDmg} damage reflected back!${reflectKoSuffix}`, () => { wF.hp = kingJayHpAfter; renderBattle(); }, loseTeamName);
  }
  // King Jay knight reactions already collected via collectKC at game-state section (line ~9746) — do NOT double-fire here

  // Guardian Fairy (99) — Wish: absorbed damage callout (onShow re-renders sideline to grey out GF if KO'd)
  if (guardianFairyAbsorbed && gfSacrifice) {
    const gfKoSuffix = guardianFairyKOd ? ' — GUARDIAN FAIRY FALLS!' : ` — ${gfHpAfter} HP remaining.`;
    queueAbility('WISH!', 'var(--ghost-rare)', `${gfSacrifice.name} — Takes ${guardianFairyAbsorbedDmg} damage for ${lF.name}!${gfKoSuffix}`, () => { gfSacrifice.hp = gfHpAfter; renderBattle(); }, loseTeamName);
  }
  // Guardian Fairy knight reactions already collected via collectKC at game-state section (line ~9767) — do NOT double-fire here

  // Guard Thomas (41) — Stoic: immunity callout fires after Wish so defenses resolve in order
  if (guardThomasStoic) {
    queueAbility('STOIC!', 'var(--uncommon)', `${lF.name} — Below 6 HP! Singles roll negated — taking no damage!`, null, loseTeamName);
  }
  if (guardThomasStoic) checkKnightEffects(loseTeamName, lF.name); // Knight Terror/Light react to STOIC!

  // Bogey (53) — Bogus: reflect callout fires after Stoic — shows the reflected amount and winner's remaining HP
  // HP bar updates in onShow callback so it drops exactly when BOGUS! flashes, not silently at beat 4.
  if (bogeyReflected) {
    const bogeyKoSuffix = wF.ko ? ' — KO!' : ` — ${bogeyHpAfter} HP left`;
    queueAbility('BOGUS!', 'var(--uncommon)', `${lF.name} — REFLECT! ${bogeyReflectDmg} damage bounced back to ${wF.name}!${bogeyKoSuffix}`,
      () => { wF.hp = bogeyHpAfter; renderBattle(); }, loseTeamName);
  }
  // Bogey knight reactions already collected via collectKC at game-state section (line ~9662) — do NOT double-fire here

  // Mirror Matt (410) — Seven Years: reflected damage callout
  if (mirrorMattReflected) {
    const mmKoSuffix = wF.ko ? ' — KO!' : ` — ${wF.hp} HP left`;
    queueAbility('SEVEN YEARS!', 'var(--uncommon)', `${lF.name} — REFLECT! ${wR.type} → ${mirrorMattReflectDmg} damage bounced to ${wF.name}!${mmKoSuffix}`, null, loseTeamName);
  }

  // Jasper (428) — Flame Dive: NO auto-callout here. B.jasperPending was set in the
  // resolver; the interactive modal (showJasperModal) fires in the post-drain callback.

  // Twyla (417) — Lucky Dance: v674 rework moved to dice count section (dice + Healing Seeds pre-roll)

  // Garrick (427) — Watchfire: damage reduction callout (on loss)
  if (lF.id === 427 && !lF.ko) {
    // callout only if Garrick was hit — logged inline above
  }

  if (kodakoSwiftLose) {
    const swiftLoseKoSuffix = wF.ko ? ' — KO!' : ` — ${swiftLoseHpAfter} HP left`;
    queueAbility('SWIFT!', 'var(--common)', `${lF.name} — 1-2-3! Negate damage, deal 4 back to ${wF.name}!${swiftLoseKoSuffix}`,
      () => { wF.hp = swiftLoseHpAfter; renderBattle(); }, loseTeamName);
  }
  // Kodako SWIFT! lose-path knight reactions already collected via collectKC at game-state section (line ~9671) — do NOT double-fire here

  // Patrick (10) — Stone Form: singles negated + 3 counter-damage callout
  // onShow defers wF.hp mutation so the HP bar drops at the same moment the callout fires.
  if (patrickStoneForm) {
    const stoneFormKoSuffix = wF.ko ? ' — KO!' : ` — ${stoneFormHpAfter} HP left`;
    queueAbility('STONE FORM!', 'var(--common)', `${lF.name} — Singles blocked! ${patrickStoneDmg} damage to ${wF.name}!${stoneFormKoSuffix}`,
      () => { wF.hp = stoneFormHpAfter; renderBattle(); }, loseTeamName);
  }
  // Patrick knight reactions already collected via collectKC at game-state section (line ~9683) — do NOT double-fire here

  // Dealer (37) — House Rules: straight on loss → damage negated callout
  if (dealerHouseRules) {
    const _dealerSorted = [...loseDice].sort((a, b) => a - b);
    queueAbility('HOUSE RULES!', 'var(--uncommon)', `${lF.name} — Straight [${_dealerSorted.join('-')}]! ${wF.name}'s attack is nullified!`, null, loseTeamName);
  }
  // Dealer (37) — House Rules: straight on win → +3 damage callout
  if (dealerWinTriggered) {
    const _dealerWinSorted = [...winDice].sort((a, b) => a - b);
    queueAbility('HOUSE RULES!', 'var(--uncommon)', `${wF.name} — Straight [${_dealerWinSorted.join('-')}]! +3 damage!`, null, winTeamName);
  }
  if (deathHowlTriggered) {
    queueAbility('PRESSURE!', 'var(--rare)', `${wF.name} — ${deathHowlKOs} KO${deathHowlKOs > 1 ? 's' : ''} on the field! +${deathHowlKOs} damage!`, null, winTeamName);
  }

  // Sky (72) — Elusive: incoming big damage (>2) negated + counter die pending
  if (skyElusive) {
    queueAbility('ELUSIVE!', 'var(--rare)', `${lF.name} — ${skyElusiveBlockedDmg} damage? Too much! Negated + counter die incoming!`, null, loseTeamName);
  }
  // Sky knight reactions already collected via collectKC at game-state section (line ~9709) — do NOT double-fire here

  // City Cyboo (77) — Barrier: enemy doubles negated callout
  if (cityCybooBarrier) {
    queueAbility('BARRIER!', 'var(--rare)', `${lF.name} — Enemy doubles BLOCKED! ${cityCybooBlockedDmg} damage negated!`, null, loseTeamName);
  }
  // City Cyboo knight reactions already collected via collectKC at game-state section (line ~9721) — do NOT double-fire here

  // Puff (5) — Cute: doubles/triples softened by 1 callout
  if (puffCute) {
    const puffSuffix = dmg === 0 ? ` — 0 damage! Fully absorbed!` : ` — ${wF.name} deals ${dmg} instead!`;
    queueAbility('CUTE!', 'var(--common)', `${lF.name} — ${wR.type}! -1 damage (${puffCuteOriginalDmg} → ${dmg})${puffSuffix}`, null, loseTeamName);
  }
  // Puff knight reactions already collected via collectKC at game-state section (line ~9733) — do NOT double-fire here

  // Little Boo (9) — Mercy: enemy triples converted to [1,2,3] singles callout
  if (mercyTriggered) {
    queueAbility('MERCY!', 'var(--common)', `${lF.name} — Enemy triples count as [1,2,3]! Base damage: 3 → 1. ${wF.name}'s big roll softened!`, null, loseTeamName);
  }
  // Little Boo knight reactions already collected via collectKC at game-state section (line ~9093) — do NOT double-fire here

  // Fang Undercover (7) — Skilled Coward: dodge activated → negate hit, ghost-picker fires after queue drains
  if (fangUndercoverActivated) {
    queueAbility('SKILLED COWARD!', 'var(--common)', `${lF.name} — Dodge! ${wF.name}'s attack negated! Fang slips to the sideline...`, null, loseTeamName);
  }
  // Fang Undercover knight reactions already collected via collectKC at game-state section (line ~9784) — do NOT double-fire here

  // Cameron (25) — Unstoppable Force: damage pierced negation callout (queued after defense callouts)
  if (cameronUnstoppableLogged) {
    queueAbility('UNSTOPPABLE!', 'var(--common)', `${wF.name} — Damage cannot be negated! ${dmg} damage goes through!`, null, winTeamName);
  }
  // Cameron knight reactions already collected via collectKC at game-state section — do NOT double-fire here

  // Gus (31) — Gale Force: callout now handled in doGusGaleReactive() when player accepts
  // Gus knight reactions already collected via collectKC at game-state section (line ~9798) — do NOT double-fire here

  // Hugo (52) — Wreckage: took real damage → attacker loses 1 die next roll
  if (hugoWreckageTriggered) {
    queueAbility('WRECKAGE!', 'var(--uncommon)', `${lF.name} — Took ${dmg} damage! ${wF.name} loses 1 die next roll!`, null, loseTeamName);
  }
  // Hugo knight reactions already collected via collectKC at game-state section (line ~10019) — do NOT double-fire here

  // Marcus (57) — Glacial Pounding: taking 3+ damage charges up +4 bonus dice for the PLAYER's next roll
  if (marcusGlacialTriggered) {
    queueAbility('GLACIAL POUNDING!', 'var(--uncommon)', `${lF.name} — Took ${dmg} damage! +4 bonus dice next roll${lF.ko ? ' for the next fighter!' : '!'}`, null, loseTeamName);
  }
  // Marcus knight reactions already collected via collectKC at game-state section (line ~10029) — do NOT double-fire here

  // On-win callouts — onShow grants the resource the moment the splash appears (not 800ms earlier at Beat 4)
  if (wF.id === 209 && !wF.ko) { queueAbility('PLUNDER!', 'var(--common)', `${wF.name} — Win! +2 Surge!`, () => { winTeam.resources.surge += 2; renderBattle(); }, winTeamName); }
  // Dart knight reactions already collected via collectKC at game-state section (line ~10075) — do NOT double-fire here
  if (wF.id === 209 && !wF.ko && sandwichForLose) queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Plunder! +2 Surge! (${loseTeam.resources.surge + 2} total)`, () => { loseTeam.resources.surge += 2; renderBattle(); }, loseTeamName);
  if (wF.id === 307 && !wF.ko) { queueAbility('DAUGHTER OF THE STREAM!', 'var(--rare)', `${wF.name} — Win! +3 Ice Shards!`, () => { winTeam.resources.ice += 3; renderBattle(); }, winTeamName); }
  // Artemis knight reactions already collected via collectKC at game-state section (line ~10076) — do NOT double-fire here
  if (wF.id === 307 && !wF.ko && sandwichForLose) queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Daughter of the Stream! +3 Ice Shards!`, () => { loseTeam.resources.ice += 3; creditGhost(loseTeamName, 33, 'ice', 3); renderBattle(); }, loseTeamName);
  if (wF.id === 81 && !wF.ko) { queueAbility('VALLEY MAGIC!', 'var(--rare)', `${wF.name} — Win! +2 Ice Shards! (${winTeam.resources.ice + 2} total)`, () => { winTeam.resources.ice += 2; renderBattle(); }, winTeamName); }
  // Spockles knight reactions already collected via collectKC at game-state section (line ~10080) — do NOT double-fire here
  if (wF.id === 81 && !wF.ko && sandwichForLose) queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Valley Magic! +2 Ice Shards! (${loseTeam.resources.ice + 2} total)`, () => { loseTeam.resources.ice += 2; creditGhost(loseTeamName, 33, 'ice', 2); renderBattle(); }, loseTeamName);
  // Zain (206) — Ice Blade: win any roll → gain 1 Ice Shard (fires every win, regardless of blade swing)
  if (wF.id === 206 && !wF.ko) { queueAbility('ICE SHARD!', 'var(--ghost-rare)', `${wF.name} — Win! +1 Ice Shard! (${winTeam.resources.ice + 1} total)`, () => { winTeam.resources.ice++; creditGhost(winTeamName, 206, 'ice', 1); renderBattle(); }, winTeamName); }
  // Zain ICE SHARD knight reactions already collected via collectKC at game-state section (line ~10082) — do NOT double-fire here
  if (wF.id === 206 && !wF.ko && sandwichForLose) queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Ice Shard! +1 Ice Shard! (${loseTeam.resources.ice + 1} total)`, () => { loseTeam.resources.ice++; creditGhost(loseTeamName, 33, 'ice', 1); renderBattle(); }, loseTeamName);
  // Dylan (301) — Stained Glass: Sideline & In Play, winning rolls gain +1 Burn
  if (hasDylanWin) {
    if (!winTeam.resources.burn) winTeam.resources.burn = 0;
    const dylanName = (wF.id === 301) ? wF.name : (getSidelineGhost(winTeam, 301) || {}).name || 'Dylan';
    const dylanLabel = (wF.id === 301) ? '' : ' (sideline)';
    queueAbility('STRAW GUARDIAN!', 'var(--common)', `${dylanName}${dylanLabel} — Win! +1 Burn!`, () => { winTeam.resources.burn += 1; renderBattle(); }, winTeamName);
    log(`<span class="log-ability">${dylanName}${dylanLabel}</span> — Straw Guardian! Gain <span class="log-dmg">1 Burn</span>!`);
  }
  // Foreman (451) — Blueprint: win → +1 die next turn
  if (wF.id === 451 && !wF.ko) {
    if (!B.foremanDieBonus) B.foremanDieBonus = { red: 0, blue: 0 };
    B.foremanDieBonus[winTeamName] = (B.foremanDieBonus[winTeamName] || 0) + 1;
    collectKC(winTeamName, wF.name);
    queueAbility('BLUEPRINT!', 'var(--rare)', `${wF.name} — Win! +1 die next turn!`, null, winTeamName);
    log(`<span class="log-ability">${wF.name}</span> — Blueprint! <span class="log-ms">+1 die next turn!</span>`);
  }
  // Welder (450) — Arc: wins give 1 Burn (active Welder only, not duplicated by Torch)
  if (wF.id === 450 && !wF.ko) {
    if (!winTeam.resources.burn) winTeam.resources.burn = 0;
    queueAbility('ARC!', 'var(--uncommon)', `${wF.name} — Win! +1 Burn!`, () => { winTeam.resources.burn += 1; renderBattle(); }, winTeamName);
    log(`<span class="log-ability">${wF.name}</span> — Arc! Gain <span class="log-dmg">1 Burn</span>!`);
  }
  // Welder's Torch (permanent item) — wins give 1 Burn for ANY active ghost on the team
  if (B.welderTorch && B.welderTorch[winTeamName] && wF.id !== 450) {
    if (!winTeam.resources.burn) winTeam.resources.burn = 0;
    queueAbility("WELDER'S TORCH!", 'var(--rare)', `Welder's Torch — Win! +1 Burn!`, () => { winTeam.resources.burn += 1; renderBattle(); }, winTeamName);
    log(`<span class="log-ability">Welder's Torch</span> — Win! <span class="log-dmg">+1 Burn!</span>`);
  }
  // Roger (54) — Tempest: win with 4+ dice containing 2 different pairs → +3 Sacred Fires
  if (wF.id === 54 && !wF.ko && winDice && winDice.length >= 4) {
    const _dieCounts = {};
    winDice.forEach(d => _dieCounts[d] = (_dieCounts[d]||0)+1);
    const _pairCount = Object.values(_dieCounts).filter(c => c >= 2).length;
    if (_pairCount >= 2) {
      collectKC(winTeamName, wF.name);  // Roger Tempest — Knight Terror/Light react when ability fires
      const _newFires = winTeam.resources.fire + 3;
      queueAbility('TEMPEST!', 'var(--uncommon)', `${wF.name} — 2 pairs! Boom shaka laka! +3 Sacred Fires! (${_newFires} total)`, () => { winTeam.resources.fire += 3; renderBattle(); }, winTeamName);
      if (sandwichForLose) queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Tempest! +3 Sacred Fires! (${loseTeam.resources.fire + 3} total)`, () => { loseTeam.resources.fire += 3; renderBattle(); }, loseTeamName);
    }
  }
  // Ashley (58) — Burning Soul: win a roll → gain +1 Sacred Fire
  if (wF.id === 58 && !wF.ko) { queueAbility('BURNING SOUL!', 'var(--uncommon)', `${wF.name} — Win! +1 Sacred Fire! (${winTeam.resources.fire + 1} total)`, () => { winTeam.resources.fire++; renderBattle(); }, winTeamName); }
  // Ashley knight reactions already collected via collectKC at game-state section (line ~10081) — do NOT double-fire here
  if (wF.id === 58 && !wF.ko && sandwichForLose) queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Burning Soul! +1 Sacred Fire! (${loseTeam.resources.fire + 1} total)`, () => { loseTeam.resources.fire++; renderBattle(); }, loseTeamName);
  // Piper (107) — Slick Coat: win with singles → gain 1 Sacred Fire
  if (wF.id === 107 && !wF.ko && wR.type === 'singles') {
    queueAbility('SLICK COAT!', 'var(--ghost-rare)', `${wF.name} — Singles win! +1 Sacred Fire! (${winTeam.resources.fire + 1} total)`, () => { winTeam.resources.fire++; renderBattle(); }, winTeamName);
    log(`<span class="log-ability">${wF.name}</span> — Slick Coat! Singles win → <span class="log-ms">+1 Sacred Fire!</span>`);
    collectKC(winTeamName, wF.name);
  }
  // Opa (48) — Rest: win → gain +1 HP (overclocks! Rule #9 — do NOT add Math.min cap)
  // Mr Filbert (59) — Mask Merchant: flips the +1 heal to -1 damage when on enemy sideline.
  if (wF.id === 48 && !wF.ko) {
    if (filbertCursesWin) {
      const opaFlipped = Math.max(0, wF.hp - 1);
      const opaGhost = wF;
      queueAbility('MASK MERCHANT!', 'var(--uncommon)', `Mr Filbert — Rest cursed! ${wF.name} takes 1 damage! (${wF.hp}→${opaFlipped} HP)`, () => { opaGhost.hp = opaFlipped; if (opaGhost.hp <= 0) { opaGhost.hp = 0; opaGhost.ko = true; opaGhost.killedBy = 59; } renderBattle(); }, winTeamName);
      log(`<span class="log-ability">${wF.name}</span> — Rest! Mr Filbert curses → -1 HP (${opaFlipped} HP).`);
    } else {
      const opaNewHp = wF.hp + 1;
      const opaOver = opaNewHp > wF.maxHp;
      queueAbility('REST!', 'var(--uncommon)', `${wF.name} — Won! +1 HP! (${wF.hp}→${opaNewHp} HP${opaOver ? ' · overclocked!' : ''})`, () => { wF.hp++; renderBattle(); }, winTeamName);
      log(`<span class="log-ability">${wF.name}</span> — Rest! Win → +1 HP (${opaNewHp} HP${opaOver ? ' overclocked!' : ''}).`);
    }
  }
  if (wF.id === 48 && !wF.ko) checkKnightEffects(winTeamName, wF.name); // Knight Terror/Light react to REST! (both heal and Filbert-curse branches)
  // Villager (11) — Hospitality: sideline passive — active ghost gains +1 HP every winning roll (Filbert-aware, Cornelius-aware).
  if (hasSideline(winTeam, 11) && !wF.ko) {
    if (corneliusBlocksRally) {
      const cornVillager = getSidelineGhost(loseTeam, 45);
      const antidoteNameV = cornVillager ? cornVillager.name : 'Cornelius';
      queueAbility('ANTIDOTE!', 'var(--uncommon)', `${antidoteNameV} neutralizes Villager's Hospitality — heal blocked!`, null, winTeamName);
      log(`<span class="log-ability">Cornelius</span> — Antidote! Villager Hospitality blocked.`);
    } else if (filbertCursesWin) {
      const villagerFlipped = Math.max(0, wF.hp - 1);
      const villagerGhost = wF;
      queueAbility('MASK MERCHANT!', 'var(--uncommon)', `Mr Filbert — Hospitality cursed! ${wF.name} takes 1 damage! (${wF.hp}→${villagerFlipped} HP)`, () => { villagerGhost.hp = villagerFlipped; if (villagerGhost.hp <= 0) { villagerGhost.hp = 0; villagerGhost.ko = true; villagerGhost.killedBy = 59; } renderBattle(); }, winTeamName);
      log(`<span class="log-ability">${wF.name}</span> — Hospitality! Filbert curses → -1 HP (${villagerFlipped} HP).`);
    } else {
      const villagerNewHp = wF.hp + 1;
      const vilOver = villagerNewHp > wF.maxHp;
      queueAbility('HOSPITALITY!', 'var(--common)', `Villager — ${wF.name} wins! +1 HP from the sideline! (${wF.hp}→${villagerNewHp} HP${vilOver ? ' · overclocked!' : ''})`, () => { guardedHeal(wF, 1, winTeamName); renderBattle(); }, winTeamName);
      log(`<span class="log-ability">${wF.name}</span> — Hospitality! Villager sideline → +1 HP (${villagerNewHp} HP${vilOver ? ' overclocked!' : ''}).`);
    }
  }
  if (hasSideline(winTeam, 11) && !wF.ko) checkKnightEffects(winTeamName, wF.name); // Knight Terror/Light react to HOSPITALITY! (all branches)
  // Jeffery (14) — Chuckle: sideline passive — active ghost gains +3 HP when the winning roll DEFEATS the enemy ghost (lF.ko).
  // "Wins a battle" = KO an enemy ghost, NOT merely winning a roll. Filbert-aware, Cornelius-aware.
  // Phase 3 debug breadcrumb — helps Wyatt verify the Chuckle path fires correctly
  if (DEBUG) console.log('[CHUCKLE DEBUG]', {
    hasSideline: hasSideline(winTeam, 14),
    wFko: wF.ko,
    lFko: lF.ko,
    cornelius: corneliusBlocksRally,
    filbert: filbertCursesWin
  });
  if (hasSideline(winTeam, 14) && !wF.ko && lF.ko) {
    if (corneliusBlocksRally) {
      const cornJeffery = getSidelineGhost(loseTeam, 45);
      const antidoteNameJ = cornJeffery ? cornJeffery.name : 'Cornelius';
      queueAbility('ANTIDOTE!', 'var(--uncommon)', `${antidoteNameJ} neutralizes Jeffery's Chuckle — heal blocked!`, null, winTeamName);
      log(`<span class="log-ability">Cornelius</span> — Antidote! Jeffery Chuckle blocked.`);
    } else if (filbertCursesWin) {
      const jeffFlipped = Math.max(0, wF.hp - 3);
      const jeffGhost = wF;
      queueAbility('MASK MERCHANT!', 'var(--uncommon)', `Mr Filbert — Chuckle cursed! ${wF.name} takes 3 damage! (${wF.hp}→${jeffFlipped} HP)`, () => { jeffGhost.hp = jeffFlipped; if (jeffGhost.hp <= 0) { jeffGhost.hp = 0; jeffGhost.ko = true; jeffGhost.killedBy = 59; } renderBattle(); }, winTeamName);
      log(`<span class="log-ability">${wF.name}</span> — Chuckle! Filbert curses → -3 HP (${jeffFlipped} HP).`);
    } else {
      const jeffNewHp = wF.hp + 3;
      const jeffOver = jeffNewHp > wF.maxHp;
      queueAbility('CHUCKLE!', 'var(--common)', `Jeffery — ${wF.name} wins! +3 HP from the sideline! (${wF.hp}→${jeffNewHp} HP${jeffOver ? ' · overclocked!' : ''})`, () => { wF.hp += 3; renderBattle(); }, winTeamName);
      log(`<span class="log-ability">${wF.name}</span> — Chuckle! Jeffery sideline → +3 HP (${jeffNewHp} HP${jeffOver ? ' overclocked!' : ''}).`);
    }
  }
  if (hasSideline(winTeam, 14) && !wF.ko && lF.ko) checkKnightEffects(winTeamName, wF.name); // Knight Terror/Light react to CHUCKLE! (all branches, KO-gated)
  // Calvin (342) — Overclock: win heals 1 HP + gains 1 Healing Seed. Mr Filbert flips the heal to damage.
  if (wF.id === 342 && !wF.ko) {
    if (filbertCursesWin) {
      const calFlipped = Math.max(0, wF.hp - 1);
      queueAbility('MASK MERCHANT!', 'var(--uncommon)', `Mr Filbert — Overclock cursed! ${wF.name} takes 1 damage! (${wF.hp}→${calFlipped} HP)`, () => { wF.hp = calFlipped; if (wF.hp <= 0) { wF.hp = 0; wF.ko = true; wF.killedBy = 59; } renderBattle(); }, winTeamName);
      log(`<span class="log-ability">Mr Filbert</span> — Mask Merchant! Calvin Overclock flipped to damage. ${wF.name} ${wF.hp} → ${calFlipped} HP.`);
    } else {
      queueAbility('OVERCLOCK!', 'var(--uncommon)', `${wF.name} — Win heals 1 HP + 1 Healing Seed! ${wF.hp}→${wF.hp + 1} HP${wF.hp + 1 > wF.maxHp ? ' · overclocked!' : ''}`, () => { guardedHeal(wF, 1, winTeamName); winTeam.resources.healingSeed++; renderBattle(); }, winTeamName);
      log(`<span class="log-ability">${wF.name}</span> — Overclock! +1 HP (${wF.hp + 1} HP${wF.hp + 1 > wF.maxHp ? ' overclocked!' : ''}) + <span class="log-heal">+1 Healing Seed!</span>`);
    }
  }
  // Calvin knight reactions already collected via collectKC at game-state section (line ~10077) — do NOT double-fire here
  if (humarTriggered) { queueAbility('METEOR!', 'var(--legendary)', `${wF.name} — Win! 2 delayed damage + 1 Burn gained!`, () => { renderBattle(); }, winTeamName); }
  // Humar knight reactions already collected via collectKC at game-state section (line ~10078) — do NOT double-fire here
  // Humar Sandwiches mirror removed — Meteor deals delayed damage + burn, not mirrorable resources
  if (wF.id === 309 && !wF.ko) { queueAbility('HARVEST DANCE!', 'var(--rare)', `${wF.name} — Win → +2 Healing Seeds!`, () => { winTeam.resources.healingSeed += 2; renderBattle(); }, winTeamName); }
  // Aunt Susan knight reactions already collected via collectKC at game-state section (line ~10079) — do NOT double-fire here
  if (wF.id === 309 && !wF.ko && sandwichForLose) queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Harvest Dance! +1 Healing Seed! (${loseTeam.resources.healingSeed + 1} total)`, () => { loseTeam.resources.healingSeed++; renderBattle(); }, loseTeamName);
  // Splinter (101) — Toxic Fumes: first win triggers activation callout
  if (splinterJustActivated) {
    queueAbility('TOXIC FUMES!', 'var(--ghost-rare)', `${wF.name} — First Win! Toxic Fumes activated — 1 chip damage before every roll from now on!`, null, winTeamName);
  }
  // Farmer Jeff (314) — Harvest: active OR sideline fires on any 6 rolled, win OR lose (v636 buff).
  // Cornelius (45) Antidote — show block callout if Jeff's sideline Harvest was negated
  if (corneliusBlocksFJWin && countVal(winDice, 6) > 0) {
    const cornGhostFJW = getSidelineGhost(loseTeam, 45);
    queueAbility('ANTIDOTE!', 'var(--uncommon)', `${cornGhostFJW ? cornGhostFJW.name : 'Cornelius'} blocks Farmer Jeff's Harvest!`, null, loseTeamName);
    log(`<span class="log-ability">Cornelius</span> (sideline) — Antidote! Farmer Jeff Harvest blocked!`);
  }
  if (corneliusBlocksFJLose && countVal(loseDice, 6) > 0) {
    const cornGhostFJL = getSidelineGhost(winTeam, 45);
    queueAbility('ANTIDOTE!', 'var(--uncommon)', `${cornGhostFJL ? cornGhostFJL.name : 'Cornelius'} blocks Farmer Jeff's Harvest!`, null, winTeamName);
    log(`<span class="log-ability">Cornelius</span> (sideline) — Antidote! Farmer Jeff Harvest blocked!`);
  }
  if (hasFJWin && countVal(winDice, 6) > 0) {
    const sx = countVal(winDice, 6);
    const fjIsActive = wF.id === 314 && !wF.ko;
    const _jeffId = fjIsActive ? 314 : (getSidelineGhost(winTeam, 314) || { id: 314 }).id;
    const fjLabel = fjIsActive ? 'Farmer Jeff' : 'Farmer Jeff (sideline)';
    queueAbility('HARVEST!', 'var(--ghost-rare)', `${fjLabel} — ${sx} six${sx>1?'es':''} = ${sx} Healing Seed${sx>1?'s':''}!`, () => { winTeam.resources.healingSeed += sx; creditGhost(winTeamName, _jeffId, 'seed', sx); if (!fjIsActive) popSidelineCard(winTeam, 314); renderBattle(); }, winTeamName);
    // Farmer Jeff knight reactions already collected via collectKC at game-state section — do NOT double-fire here
    if (sandwichForLose) queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Harvest! +${sx} Healing Seed${sx>1?'s':''}! (${loseTeam.resources.healingSeed + sx} total)`, () => { loseTeam.resources.healingSeed += sx; creditGhost(loseTeamName, 33, 'seed', sx); renderBattle(); }, loseTeamName);
  }
  if (hasFJLose && countVal(loseDice, 6) > 0) {
    const sxL = countVal(loseDice, 6);
    const fjIsActiveLose = lF.id === 314 && !lF.ko;
    const _jeffIdLose = fjIsActiveLose ? 314 : (getSidelineGhost(loseTeam, 314) || { id: 314 }).id;
    const fjLabelLose = fjIsActiveLose ? 'Farmer Jeff' : 'Farmer Jeff (sideline)';
    queueAbility('HARVEST!', 'var(--ghost-rare)', `${fjLabelLose} — ${sxL} six${sxL>1?'es':''} = ${sxL} Healing Seed${sxL>1?'s':''}!`, () => { loseTeam.resources.healingSeed += sxL; creditGhost(loseTeamName, _jeffIdLose, 'seed', sxL); if (!fjIsActiveLose) popSidelineCard(loseTeam, 314); renderBattle(); }, loseTeamName);
    // Farmer Jeff lose-path knight reactions already collected via collectKC at game-state section — do NOT double-fire here
    if (sandwichForWin) queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Harvest! +${sxL} Healing Seed${sxL>1?'s':''}! (${winTeam.resources.healingSeed + sxL} total)`, () => { winTeam.resources.healingSeed += sxL; creditGhost(winTeamName, 33, 'seed', sxL); renderBattle(); }, winTeamName);
  }

  // Simon (24) — Brew Time: post-roll trigger REMOVED. Only fires on pre-roll chip damage now.
  // simonBrewTriggered is always false — kept for code structure compatibility.

  // Sad Sal (29) — Tough Job: lost → +1 Ice Shard (onShow deferred so ice tile updates WITH the splash)
  if (sadSalTriggered) {
    const sadSalIceTotal = loseTeam.resources.ice + 1;
    queueAbility('TOUGH JOB!', 'var(--common)', `${lF.name} — Lost the roll... but gained 1 Ice Shard! (${sadSalIceTotal} total)`, () => { loseTeam.resources.ice++; renderBattle(); }, loseTeamName);
    // Sad Sal knight reactions already collected via collectKC at game-state section (line ~10009) — do NOT double-fire here
    if (sandwichForWin) queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Tough Job! +1 Ice Shard! (${winTeam.resources.ice + 1} total)`, () => { winTeam.resources.ice++; creditGhost(winTeamName, 33, 'ice', 1); renderBattle(); }, winTeamName);
  }

  // Gary (92) — Lucky Novice: lose-team Gary — 1s in losing dice still grant ice shards (active OR sideline, v598)
  if (garyOnesLose > 0) {
    const garyLoseIceTotal = loseTeam.resources.ice + garyIceLose;
    const _garyLoseId = loseGaryActive ? 92 : (getSidelineGhost(loseTeam, 92) || { id: 92 }).id;
    const _garyLoseLoc = loseGaryActive ? 'active' : 'sideline';
    queueAbility('LUCKY NOVICE!', 'var(--rare)', `Gary (${_garyLoseLoc}) — ${garyOnesLose} rolled 1${garyOnesLose > 1 ? 's' : ''}! +${garyIceLose} Ice Shards! (${garyLoseIceTotal} total)`, () => { loseTeam.resources.ice += garyIceLose; creditGhost(loseTeamName, _garyLoseId, 'ice', garyIceLose); renderBattle(); }, loseTeamName);
    if (sandwichForWin) queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Lucky Novice! +${garyIceLose} Ice Shards! (${winTeam.resources.ice + garyIceLose} total)`, () => { winTeam.resources.ice += garyIceLose; creditGhost(winTeamName, 33, 'ice', garyIceLose); renderBattle(); }, winTeamName);
    // Gary lose-path knight reactions already collected via collectKC at game-state section (line ~9531) — do NOT double-fire here
  }

  // On-lose callouts — onShow applies the surge grant with the splash
  if (lF.id === 404 && !lF.ko) { queueAbility('BITTER END!', 'var(--rare)', `${lF.name} — Lost but gained 1 Surge!`, () => { loseTeam.resources.surge++; renderBattle(); }, loseTeamName); }
  // Chagrin knight reactions already collected via collectKC at game-state section (line ~10109) — do NOT double-fire here
  if (lF.id === 404 && !lF.ko && sandwichForWin) queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Bitter End! +1 Surge! (${winTeam.resources.surge + 1} total)`, () => { winTeam.resources.surge++; renderBattle(); }, winTeamName);
  // On-KO callouts — onShow applies the Granny resource grant with the splash
  if (lF.ko) {
    if (hasSideline(loseTeam, 310) && !corneliusBlocksGrannyLose) {
      if (wR.type === 'singles') {
        queueAbility('BEDTIME STORY!', 'var(--uncommon)', `Granny consoles — singles KO → 3 Lucky Stones!`, () => { loseTeam.resources.luckyStone += 3; creditGhost(loseTeamName, 310, 'ls', 3); popSidelineCard(loseTeam, 310); renderBattle(); }, loseTeamName);
        if (sandwichForWin) queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Bedtime Story! +3 Lucky Stones! (${winTeam.resources.luckyStone + 3} total)`, () => { winTeam.resources.luckyStone += 3; renderBattle(); }, winTeamName);
      } else if (wR.type === 'doubles') {
        queueAbility('BEDTIME STORY!', 'var(--uncommon)', `Granny consoles — doubles KO → Moonstone!`, () => { loseTeam.resources.moonstone++; creditGhost(loseTeamName, 310, 'ms', 1); popSidelineCard(loseTeam, 310); renderBattle(); }, loseTeamName);
        if (sandwichForWin) queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Bedtime Story! +1 Moonstone! (${winTeam.resources.moonstone + 1} total)`, () => { winTeam.resources.moonstone++; renderBattle(); }, winTeamName);
      } else if (isTripleOrBetter(wR.type)) {
        queueAbility('BEDTIME STORY!', 'var(--uncommon)', `Granny consoles — ${wR.type} KO → 3 Sacred Fires!`, () => { loseTeam.resources.fire += 3; creditGhost(loseTeamName, 310, 'fire', 3); popSidelineCard(loseTeam, 310); renderBattle(); }, loseTeamName);
        if (sandwichForWin) queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Bedtime Story! +3 Sacred Fires! (${winTeam.resources.fire + 3} total)`, () => { winTeam.resources.fire += 3; renderBattle(); }, winTeamName);
      }
    } else if (hasSideline(loseTeam, 310) && corneliusBlocksGrannyLose) {
      const cornGhostGrL = getSidelineGhost(winTeam, 45);
      queueAbility('ANTIDOTE!', 'var(--uncommon)', `${cornGhostGrL ? cornGhostGrL.name : 'Cornelius'} blocks Granny's Bedtime Story!`, null, winTeamName);
      log(`<span class="log-ability">Cornelius</span> (sideline) — Antidote! Granny Bedtime Story blocked!`);
    }
    if (lF.id === 404) { queueAbility('BITTER END!', 'var(--rare)', `${lF.name} — KO'd but still gains 1 Surge!`, () => { loseTeam.resources.surge++; renderBattle(); }, loseTeamName); }
    if (lF.id === 404 && sandwichForWin) queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Bitter End (KO)! +1 Surge! (${winTeam.resources.surge + 1} total)`, () => { winTeam.resources.surge++; renderBattle(); }, winTeamName);
  }
  // Granny callout when winner self-KOs (Pudge Belly Flop doubles = always surge for Granny on winner's team)
  if (wF.ko && hasSideline(winTeam, 310) && !corneliusBlocksGrannyWin) {
    if (wR.type === 'singles') {
      queueAbility('BEDTIME STORY!', 'var(--uncommon)', `Granny consoles — singles KO → 3 Lucky Stones!`, () => { winTeam.resources.luckyStone += 3; creditGhost(winTeamName, 310, 'ls', 3); popSidelineCard(winTeam, 310); renderBattle(); }, winTeamName);
      if (sandwichForLose) queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Bedtime Story! +3 Lucky Stones! (${loseTeam.resources.luckyStone + 3} total)`, () => { loseTeam.resources.luckyStone += 3; renderBattle(); }, loseTeamName);
    } else if (wR.type === 'doubles') {
      queueAbility('BEDTIME STORY!', 'var(--uncommon)', `Granny consoles — doubles KO → Moonstone!`, () => { winTeam.resources.moonstone++; creditGhost(winTeamName, 310, 'ms', 1); popSidelineCard(winTeam, 310); renderBattle(); }, winTeamName);
      if (sandwichForLose) queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Bedtime Story! +1 Moonstone! (${loseTeam.resources.moonstone + 1} total)`, () => { loseTeam.resources.moonstone++; renderBattle(); }, loseTeamName);
    } else if (isTripleOrBetter(wR.type)) {
      queueAbility('BEDTIME STORY!', 'var(--uncommon)', `Granny consoles — ${wR.type} KO → 3 Sacred Fires!`, () => { winTeam.resources.fire += 3; creditGhost(winTeamName, 310, 'fire', 3); popSidelineCard(winTeam, 310); renderBattle(); }, winTeamName);
      if (sandwichForLose) queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Bedtime Story! +3 Sacred Fires! (${loseTeam.resources.fire + 3} total)`, () => { loseTeam.resources.fire += 3; renderBattle(); }, loseTeamName);
    }
  } else if (wF.ko && hasSideline(winTeam, 310) && corneliusBlocksGrannyWin) {
    const cornGhostGrW = getSidelineGhost(loseTeam, 45);
    queueAbility('ANTIDOTE!', 'var(--uncommon)', `${cornGhostGrW ? cornGhostGrW.name : 'Cornelius'} blocks Granny's Bedtime Story!`, null, loseTeamName);
    log(`<span class="log-ability">Cornelius</span> (sideline) — Antidote! Granny Bedtime Story blocked!`);
  }

  // Powder (23) — Final Gift: KO'd → loseTeam gains 3 Ice Shards (onShow deferred for visual sync)
  if (powderFinalGiftTriggered) {
    const powderIceTotal = loseTeam.resources.ice + 3;
    queueAbility('FINAL GIFT!', 'var(--common)', `${lF.name} — Defeated... but leaves 3 Ice Shards behind! (${powderIceTotal} total)`, () => { loseTeam.resources.ice += 3; creditGhost(loseTeamName, 23, 'ice', 3); renderBattle(); }, loseTeamName);
    if (sandwichForWin) queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Final Gift! +3 Ice Shards! (${winTeam.resources.ice + 3} total)`, () => { winTeam.resources.ice += 3; creditGhost(winTeamName, 33, 'ice', 3); renderBattle(); }, winTeamName);
  }

  // Chester (426) — Well Read: Win: +1 Healing Seed always. Doubles+: also +2 Burn.
  if (wF.id === 426 && !wF.ko) {
    const chesterIsDoubles = ['doubles','triples','quads','penta'].includes(wR.type);
    if (chesterIsDoubles) {
      // Doubles+: +1 Healing Seed AND +2 Burn (granted as resource, player places via burn picker)
      queueAbility('WELL READ!', 'var(--uncommon)', `${wF.name} — Doubles+ Win! +1 Healing Seed + 2 Burn!`, () => {
        winTeam.resources.healingSeed++;
        if (!winTeam.resources.burn) winTeam.resources.burn = 0;
        winTeam.resources.burn += 2;
        renderBattle();
      }, winTeamName);
      log(`<span class="log-ability">${wF.name}</span> — Well Read! +1 Healing Seed + 2 Burn!`);
    } else {
      queueAbility('WELL READ!', 'var(--uncommon)', `${wF.name} — Win! +1 Healing Seed!`, () => { winTeam.resources.healingSeed++; renderBattle(); }, winTeamName);
      log(`<span class="log-ability">${wF.name}</span> — Well Read! +1 Healing Seed!`);
    }
    checkKnightEffects(winTeamName, wF.name);
  }

  // Nick & Knack (409) — Knick Knack: steal is pre-roll now (win trigger removed)

  // Zippa (423) — Glimmer: reworked — +1 damage per Healing Seed held

  // Mable Stadango (446) — Hex: Win → +1 Burn
  if (wF.id === 446 && !wF.ko) {
    queueAbility('HEX!', 'var(--uncommon)', `${wF.name} — Win! +1 Burn!`, () => {
      if (!winTeam.resources.burn) winTeam.resources.burn = 0;
      winTeam.resources.burn += 1;
      renderBattle();
    }, winTeamName);
    log(`<span class="log-ability">${wF.name}</span> — Hex! Win → +1 Burn!`);
    checkKnightEffects(winTeamName, wF.name);
  }
  // Mable Stadango (446) — Hex: in play only, no sideline win trigger

  // Starling (441) — Moonbeam: Win with doubles+ → +1 Moonstone + 1 Magic Firefly
  if (wF.id === 441 && !wF.ko && ['doubles','triples','quads','penta'].includes(wR.type)) {
    const _starWTeam = winTeam;
    const _starSandOpp = opp(winTeam);
    queueAbility('MOONBEAM!', 'var(--rare)', `${wF.name} — Doubles+ Win! +1 Magic Firefly!`, () => {
      _starWTeam.resources.firefly = (_starWTeam.resources.firefly || 0) + 1;
      log(`<span class="log-ability">${wF.name}</span> — Moonbeam! +1 Magic Firefly!`);
      renderBattle();
    }, winTeamName);
    checkKnightEffects(winTeamName, wF.name);
  }

  // Harvey (448) — Harvest Moon: Win: +1 damage per 5 rolled, gain 1 Moonstone if any 5s (v799 — added damage)
  if (wF.id === 448 && !wF.ko) {
    const fives = winDice.filter(d => d === 5).length;
    if (fives > 0) {
      const harveyDmg = fives;
      queueAbility('HARVEST MOON!', 'var(--ghost-rare)', `${wF.name} — Win with ${fives} five${fives > 1 ? 's' : ''}! +${harveyDmg} damage + 1 Moonstone!`, () => {
        const lF = active(loseTeam);
        if (lF && !lF.ko) {
          lF.hp = Math.max(0, lF.hp - harveyDmg);
          log(`<span class="log-ability">${wF.name}</span> — Harvest Moon! ${fives} five${fives > 1 ? 's' : ''} → <span class="log-dmg">${harveyDmg} bonus damage</span> + <span class="log-ms">1 Moonstone</span>!`);
          if (lF.hp <= 0) { lF.ko = true; }
        }
        winTeam.resources.moonstone = Math.min((winTeam.resources.moonstone || 0) + 1, 1);
        renderBattle();
      }, winTeamName);
      checkKnightEffects(winTeamName, wF.name);
      if (sandwichForLose) {
        queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Harvest Moon! +1 Moonstone!`, () => { loseTeam.resources.moonstone = Math.min((loseTeam.resources.moonstone || 0) + 1, 1); renderBattle(); }, loseTeamName);
      }
    }
  }

  // Gordok (430) — River Terror: callout for steal (logic applied pre-damage) — only for autoPlay (human uses modal)
  if (gordokStole && !B.gordokPending) {
    queueAbility('RIVER TERROR!', 'var(--rare)', `${wF.name} — stole resources instead of dealing damage! +1 Moonstone!`, null, winTeamName);
  }

  // Pal Al (431) — Squall: callout for ice gain (logic applied pre-damage) — only for autoPlay (human uses modal)
  if (wiseAlSqualled && !B.wiseAlPending) {
    queueAbility('SQUALL!', 'var(--rare)', `${wF.name} — +4 Ice Shards instead of dealing damage!`, null, winTeamName);
  }

  // Garrick (427) — Watchfire: Win + KO → +1 Sacred Fire
  if (wF.id === 427 && !wF.ko && lF.ko) {
    queueAbility('WATCHFIRE!', 'var(--uncommon)', `${wF.name} — KO! +1 Sacred Fire!`, () => { winTeam.resources.fire++; renderBattle(); }, winTeamName);
    log(`<span class="log-ability">${wF.name}</span> — Watchfire! KO → <span class="log-ms">+1 Sacred Fire!</span>`);
    checkKnightEffects(winTeamName, wF.name);
  }

  // Nyx & Bessie (415) — Moo! Caw!: sideline KO → 3 Healing Seeds
  // Cornelius (45) Antidote blocks Nyx & Bessie's sideline effect
  const corneliusBlocksNyx = hasSideline(loseTeam, 45);
  if (hasSideline(winTeam, 415) && !wF.ko && lF.ko && !corneliusBlocksNyx) {
    const nyxG = getSidelineGhost(winTeam, 415);
    const nyxName = nyxG ? nyxG.name : 'Nyx & Bessie';
    queueAbility('MOO! CAW!', 'var(--uncommon)', `${nyxName} (sideline) — KO! +4 Healing Seeds!`, () => { winTeam.resources.healingSeed += 4; renderBattle(); }, winTeamName);
    log(`<span class="log-ability">${nyxName}</span> — Moo! Caw! KO → <span class="log-heal">+4 Healing Seeds!</span>`);
    checkKnightEffects(winTeamName, wF.name);
  } else if (hasSideline(winTeam, 415) && !wF.ko && lF.ko && corneliusBlocksNyx) {
    const cornGhostNyx = getSidelineGhost(loseTeam, 45);
    queueAbility('ANTIDOTE!', 'var(--uncommon)', `${cornGhostNyx ? cornGhostNyx.name : 'Cornelius'} blocks Nyx & Bessie's Moo! Caw!!`, null, loseTeamName);
    log(`<span class="log-ability">Cornelius</span> (sideline) — Antidote! Nyx & Bessie Moo! Caw! blocked!`);
  }

  // Valkin the Grand (432) — Grand Spoils: active Valkin KO → full resource suite
  if (wF.id === 432 && !wF.ko && lF.ko) {
    queueAbility('GRAND SPOILS!', 'var(--legendary)', `${wF.name} — KO! Grand Spoils: +1 Fire, +2 Ice, +1 Lucky, +1 Moon, +2 Seed!`, () => {
      winTeam.resources.fire += 1;
      winTeam.resources.ice += 2;
      winTeam.resources.luckyStone += 1;
      winTeam.resources.moonstone += 1;
      winTeam.resources.healingSeed += 2;
      renderBattle();
    }, winTeamName);
    log(`<span class="log-ability">${wF.name}</span> — Grand Spoils! KO → <span class="log-ms">+1🔥 +2❄️ +1🍀 +1🌙 +2🌱!</span>`);
    checkKnightEffects(winTeamName, wF.name);
  }

  // Bo (109) — Miracle callout: fires after enemy KO effects; onShow applies the revive so the
  // resurrection is visually synchronized with the legendary splash rather than jumping the HP bar.
  // Vigil (433) sideline — Kindling: +6 Sacred Fires on any resurrection.
  // Both triggers also fire for any future resurrection sources (e.g. Shepherd's Flock 360 when implemented).
  if (boMiracleTarget) {
    const bt = boMiracleTarget; // capture for closure
    // If resurrecting a transformed ghost (Bigsby→Doom), restore original identity
    if (bt.originalId) {
      bt.id = bt.originalId; bt.name = bt.originalName; bt.art = bt.originalArt;
      bt.maxHp = bt.originalMaxHp; bt.ability = bt.originalAbility;
      bt.abilityDesc = bt.originalAbilityDesc; bt.rarity = bt.originalRarity;
      delete bt.originalId; delete bt.originalName; delete bt.originalArt;
      delete bt.originalMaxHp; delete bt.originalAbility; delete bt.originalAbilityDesc; delete bt.originalRarity;
    }
    const lucasActive = hasSideline(winTeam, 433);
    const calloutText = `${wF.name} — KO! ${bt.name} resurrected to sideline at 1 HP + 1 Magic Firefly!`;
    queueAbility('MIRACLE!', 'var(--legendary)', calloutText, () => {
      bt.ko = false;
      bt.hp = 1;
      winTeam.resources.firefly = Math.min((winTeam.resources.firefly || 0) + 1, 1); // v736: was 3
      log(`<span class="log-ability">Bo</span> — Miracle! <span class="log-heal">${bt.name} revived at 1 HP!</span> <span class="log-ms">+1 Magic Firefly!</span>`);
      if (lucasActive) {
        // Lucas (433) — Kindling: revived ghost enters play at 4 HP, Bo to sideline, +1 die next roll
        bt.hp += 3; // 1 + 3 = 4 HP total
        const revivedIdx = winTeam.ghosts.indexOf(bt);
        if (revivedIdx !== -1) winTeam.activeIdx = revivedIdx; // swap revived ghost to active
        if (!B.lucasKindlingBonus) B.lucasKindlingBonus = { red: 0, blue: 0 };
        B.lucasKindlingBonus[winTeamName] = 1; // +1 die next roll
        log(`<span class="log-ability">Lucas</span> — Kindling! <span class="log-heal">${bt.name} charges into play at ${bt.hp} HP! +1 die next roll!</span>`);
        queueAbility('KINDLING!', 'var(--rare)', `Lucas — ${bt.name} charges into play at ${bt.hp} HP! +3 HP, +1 die next roll!`, null, winTeamName);
      }
      renderBattle();
    }, winTeamName);
  }

  // Kairan (68) — Let's Dance: rolling doubles (win or lose) → +1 die next roll
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const tNameKai = team === B.red ? 'red' : 'blue';
    const kaiRoll = team === B.red ? rR : bR;
    if (f.id === 68 && !f.ko && kaiRoll.type === 'doubles') {
      B.letsDanceBonus[tNameKai] = (B.letsDanceBonus[tNameKai] || 0) + 1;
      const ctx = f === wF ? 'Winner doubles' : 'Loser doubles still counts';
      queueAbility("LET'S DANCE!", 'var(--rare)', `${f.name} — ${ctx}! +1 die next roll!`, null, tNameKai);
      checkKnightEffects(tNameKai, f.name); // Knight Terror / Knight Light react to LET'S DANCE!
      log(`<span class="log-ability">${f.name}</span> — Let's Dance! Doubles → +1 die next round.`);
    }
  });

  // Outlaw (43) — Thief: doubles → remove 1 enemy die next roll.
  // Farewell pattern (Wyatt 2026-04-11): a dying Outlaw still plants the die
  // penalty on the enemy for next round. Uses wF/lF so a KO'd Outlaw still fires.
  // Indexing note: B.outlawStolenDie[myTName] keys by Outlaw's OWN team — the
  // consumption block at line ~7199 reads it that way and subtracts from the enemy.
  [[wF, wR, winTeamName], [lF, lR, loseTeamName]].forEach(([f, roll, myTName]) => {
    if (f.id !== 43) return;
    if (roll.type !== 'doubles') return;
    B.outlawStolenDie[myTName] = (B.outlawStolenDie[myTName] || 0) + 1;
    const ctx = f === wF ? 'Winner doubles' : (f.ko ? 'Final doubles' : 'Loser doubles');
    queueAbility('THIEF!', 'var(--uncommon)', `${f.name} — ${ctx}! Stealing 1 die from enemy next round!`, null, myTName);
    checkKnightEffects(myTName, f.name);
    log(`<span class="log-ability">${f.name}</span> — Thief! ${ctx} → steal 1 enemy die next round.`);
  });

  // Suspicious Jeff (61) — Snicker: sideline passive — when your ghost DEFEATS an enemy ghost (lF.ko), steal 1 enemy die next roll.
  // "Wins a battle" = KO the enemy, NOT merely winning a roll. Same family correction as Jeffery Chuckle.
  if (hasSideline(winTeam, 61) && !wF.ko && lF.ko) {
    const jeffSideF = getSidelineGhost(winTeam, 61);
    const jeffName = jeffSideF ? jeffSideF.name : 'Suspicious Jeff';
    B.jeffSnicker[winTeamName] = (B.jeffSnicker[winTeamName] || 0) + 1;
    queueAbility('SNICKER!', 'var(--uncommon)', `${jeffName} (sideline) — Your ghost won! Stealing 1 die from ${lF.name} next round!`, null, winTeamName);
    log(`<span class="log-ability">${jeffName}</span> — Snicker! Win → steal 1 enemy die next round.`);
  }

  // Haywire (78) — Wild Chords: rolling triples or better grants +1 permanent die AND Haywire +2 damage for the rest of the game (once per game, win or lose)
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const tNameHW = team === B.red ? 'red' : 'blue';
    const hwRoll = team === B.red ? rR : bR;
    if (f.id === 78 && !f.ko && isTripleOrBetter(hwRoll.type) && B.haywireUsed && !B.haywireUsed[tNameHW]) {
      B.haywireBonus[tNameHW] = (B.haywireBonus[tNameHW] || 0) + 1;
      B.haywireDamageBonus[tNameHW] = 2;
      B.haywireUsed[tNameHW] = true;
      queueAbility('WILD CHORDS!', 'var(--rare)', `${f.name} — Triples or better! +1 permanent die AND Haywire gains +2 damage for the rest of the game! (Once per game)`, null, tNameHW);
      log(`<span class="log-ability">${f.name}</span> — Wild Chords! Triples or better → +1 permanent die + Haywire +2 damage for the rest of the game!`);
      checkKnightEffects(tNameHW, f.name);
    }
  });

  // Sable (413) — Smoldering Soul: all odd dice → +1 Sacred Fire (active or sideline, win/loss path)
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const tNameSable = team === B.red ? 'red' : 'blue';
    const sableDice = team === B.red ? redDice : blueDice;
    const hasSableActive = f.id === 413 && !f.ko;
    const hasSableSideline = hasSideline(team, 413);
    if ((hasSableActive || hasSableSideline) && sableDice && sableDice.length > 0 && sableDice.every(d => d % 2 === 1)) {
      team.resources.fire++;
      const sableName = hasSableActive ? f.name : (getSidelineGhost(team, 413) || { name: 'Sable' }).name;
      const sableLoc = hasSableActive ? '' : ' (sideline)';
      queueAbility('SMOLDERING SOUL!', 'var(--uncommon)', `${sableName}${sableLoc} — All dice odd! +1 Sacred Fire!`, null, tNameSable);
      log(`<span class="log-ability">${sableName}</span> — Smoldering Soul! All dice odd → <span class="log-ms">+1 Sacred Fire!</span>`);
      checkKnightEffects(tNameSable, sableName);
    }
  });

  // Pip (418) — Toasted: triples+ → remove 1 enemy die permanently + 2 Sacred Fires (once per game, win/loss path)
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    const tNamePip = team === B.red ? 'red' : 'blue';
    const pipRoll = team === B.red ? rR : bR;
    if (f.id === 418 && !f.ko && isTripleOrBetter(pipRoll.type) && B.pipToastedUsed && !B.pipToastedUsed[tNamePip]) {
      B.pipToastedUsed[tNamePip] = true;
      const oppName = tNamePip === 'red' ? 'blue' : 'red';
      B.pipDieRemoval[oppName] = (B.pipDieRemoval[oppName] || 0) + 1;
      team.resources.fire += 2;
      queueAbility('TOASTED!', 'var(--rare)', `${f.name} — ${pipRoll.type}! Enemy permanently loses 1 die + 2 Sacred Fires! (Once per game)`, null, tNamePip);
      log(`<span class="log-ability">${f.name}</span> — Toasted! ${pipRoll.type} → enemy -1 die permanently + <span class="log-ms">+2 Sacred Fires!</span>`);
      checkKnightEffects(tNamePip, f.name);
    }
  });

  // Dream Cat (28) — Jinx: if BOTH teams rolled doubles, Dream Cat gains +2 dice next round
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    if (f.id === 28 && !f.ko) {
      const tNameDC = team === B.red ? 'red' : 'blue';
      const ownRoll = team === B.red ? rR : bR;
      const foeRoll = team === B.red ? bR : rR;
      if (ownRoll.type === 'doubles' && foeRoll.type === 'doubles') {
        B.dreamCatBonus[tNameDC] = (B.dreamCatBonus[tNameDC] || 0) + 2;
        queueAbility('JINX!', 'var(--common)', `${f.name} — Both teams rolled doubles! +2 dice next round!`, null, tNameDC);
        log(`<span class="log-ability">${f.name}</span> — Jinx! Both rolled doubles → +2 dice next round.`);
        checkKnightEffects(tNameDC, f.name);
      }
    }
  });

  // Scallywags (19) — Frenzy: if Scallywags' own dice are all under 4, gain +1 die next round.
  // Farewell pattern (Wyatt 2026-04-11): fires even if Scallywags is KO'd by this roll
  // — the +1 die is granted to the team (his replacement) as his parting gift.
  // Uses wF/lF (captured pre-damage) and winDice/loseDice so Scallywags's death
  // mid-round does not drop the ability.
  [[wF, winDice, winTeamName], [lF, loseDice, loseTeamName]].forEach(([f, dice, myTName]) => {
    if (f.id !== 19) return;
    if (!dice || dice.length === 0 || !dice.every(d => d < 4)) return;
    B.scallywagsFrenzyBonus[myTName] = (B.scallywagsFrenzyBonus[myTName] || 0) + 1;
    const _scTeam = B[myTName];
    _scTeam.resources.surge = (_scTeam.resources.surge || 0) + 1;
    const ctx = f === wF ? 'Win' : (f.ko ? 'Down' : 'Loss');
    queueAbility('FRENZY!', 'var(--common)', `${f.name} — ${ctx}! All dice under 4! +1 die next roll + 1 Surge!`, null, myTName);
    log(`<span class="log-ability">${f.name}</span> — Frenzy! ${ctx}: all dice under 4 → +1 die next round + <span class="log-ms">+1 Surge</span>.`);
    checkKnightEffects(myTName, f.name);
  });

  // Floop (20) — Muck: if opponent rolled doubles, they lose 1 die next round.
  // Fires whenever Floop was the ACTIVE fighter at roll time — win, lose, OR killed.
  // Uses wF/lF (captured pre-damage at line ~9025) instead of active(team) so a
  // dying Floop still triggers Muck, and skips the !f.ko gate entirely.
  // Wyatt spec 2026-04-11: "No ifs, ands, or buts."
  [[wF, winTeamName, lR, loseTeamName], [lF, loseTeamName, wR, winTeamName]].forEach(([f, myTName, enemyRoll, enemyTName]) => {
    if (f.id !== 20) return;
    if (enemyRoll.type !== 'doubles') return;
    B.floopMuck[enemyTName] = (B.floopMuck[enemyTName] || 0) + 1;
    const ctx = f === wF ? 'Win' : (f.ko ? 'Down' : 'Loss');
    const enemyName = f === wF ? lF.name : wF.name;
    queueAbility('MUCK!', 'var(--common)', `${f.name} — ${ctx}! ${enemyName} rolled doubles → they lose 1 die next round!`, null, myTName);
    log(`<span class="log-ability">${f.name}</span> — Muck! ${enemyName} rolled doubles → -1 die next round.`);
    checkKnightEffects(myTName, f.name);
  });

  // Logey (26) — Heinous: win/lose — count opponent's 5+ dice, lock them out next roll
  // Farewell pattern (Wyatt 2026-04-11): dying Logey still locks out enemy 5+ dice.
  if (wF.id === 26) {
    const locked = (loseDice || []).filter(d => d >= 5).length;
    if (locked > 0) {
      B.logeyLockout[loseTeamName] = (B.logeyLockout[loseTeamName] || 0) + locked;
      const wCtx = wF.ko ? 'Down' : 'Win';
      queueAbility('HEINOUS!', 'var(--common)', `${wF.name} — ${wCtx}! ${locked} of ${lF.name}'s 5+ dice locked out next roll!`, null, winTeamName);
      log(`<span class="log-ability">${wF.name}</span> — Heinous! ${wCtx}: locked ${locked} of ${lF.name}'s 5+ dice.`);
    }
  }
  if (lF.id === 26) {
    const locked = (winDice || []).filter(d => d >= 5).length;
    if (locked > 0) {
      B.logeyLockout[winTeamName] = (B.logeyLockout[winTeamName] || 0) + locked;
      const lCtx = lF.ko ? 'Down' : 'Loss';
      queueAbility('HEINOUS!', 'var(--common)', `${lF.name} — ${lCtx}! ${locked} of ${wF.name}'s 5+ dice locked out next roll!`, null, loseTeamName);
      log(`<span class="log-ability">${lF.name}</span> — Heinous! ${lCtx}: locked ${locked} of ${wF.name}'s 5+ dice.`);
    }
  }

  // End-of-round callouts — Maximo seed granted with NAP! splash via onShow
  // Sandwiches (33) — Dependable: if opponent gains a seed, you mirror it.
  [B.red, B.blue].forEach(team => {
    const f = active(team);
    if (f.id === 302 && !f.ko) {
      const isWinSide = team === winTeam;
      const sandwichMirrors = isWinSide ? sandwichForLose : sandwichForWin;
      const oppTeam         = isWinSide ? loseTeam : winTeam;
      queueAbility('NAP!', 'var(--common)', `${f.name} — round ends, +1 Healing Seed and +1 Lucky Stone!`, () => { team.resources.healingSeed++; team.resources.luckyStone++; renderBattle(); }, team === B.red ? 'red' : 'blue');
      // Maximo knight reactions already collected via collectKC at game-state section (line ~10155) — do NOT double-fire here
      if (sandwichMirrors) queueAbility('DEPENDABLE!', 'var(--common)', `Sandwiches — mirrors Nap! +1 Healing Seed + 1 Lucky Stone!`, () => { oppTeam.resources.healingSeed++; oppTeam.resources.luckyStone++; renderBattle(); }, isWinSide ? loseTeamName : winTeamName);
    }
  });

  // Knight reactions (HEAVY AIR!/RETRIBUTION!) collected from all pre-cinematic ability triggers.
  // These play last in the queue — after all ability callouts — so each Knight reaction follows
  // the full round's events rather than firing synchronously and being stomped.
  resolveKnightCallouts.forEach(kc => queueAbility(kc.name, kc.color, kc.desc, kc.onShow, kc.team));

  abilityQueueMode = false;

  // ========================================
  // CINEMATIC PLAYBACK — damage hits first, then abilities sequence
  // ========================================
  // ========================================
  // CINEMATIC BEATS — pauses let each moment land
  // ========================================
  // Beat 1: Announce the winner (pause to let dice highlight register)
  let beatTimer = 0;
  const BEAT_ANNOUNCE = 600;  // pause after dice highlight, before narration
  const BEAT_DAMAGE  = 800;   // pause after narration, before damage hit
  const BEAT_HP      = 500;   // pause after hit animation, before HP bar drops
  const BEAT_POST    = 800;   // pause after HP update, before ability queue

  setTimeout(() => {
    // Beat 2: Narration
    if (dmg > 0) {
      let dmgNarr = '';
      if (wR.type === 'penta') {
        dmgNarr = `IMPOSSIBLE! FIVE ${wR.value}'s! <b class="${winColor}">${wF.name}</b> unleashes <b class="gold">${dmg} damage</b>!`;
      } else if (wR.type === 'quads') {
        dmgNarr = `DEVASTATING! <b class="${winColor}">${wF.name}</b> slams FOUR ${wR.value}'s! <b class="gold">${dmg} damage</b>!`;
      } else if (wR.type === 'triples') {
        dmgNarr = `<b class="${winColor}">${wF.name}</b> CRUSHES with triple ${wR.value}'s! <b class="gold">${dmg} damage</b> rocks <b class="${loseColor}">${lF.name}</b>!`;
      } else if (wR.type === 'doubles') {
        dmgNarr = `<b class="${winColor}">${wF.name}</b> lands a solid hit with double ${wR.value}'s — <b class="gold">${dmg} damage</b> to <b class="${loseColor}">${lF.name}</b>!`;
      } else {
        dmgNarr = `<b class="${winColor}">${wF.name}</b> edges out <b class="${loseColor}">${lF.name}</b> — <b class="gold">${dmg} damage</b>!`;
      }
      narrate(dmgNarr);

      // Beat 3: Damage hit (after narration sinks in)
      setTimeout(() => {
        playDamageSfx(dmg);
        const hitEl = document.getElementById(loseTeamName + '-fighter');
        hitEl.classList.add('hit');
        setTimeout(() => hitEl.classList.remove('hit'), 500);

        // Beat 4: HP bar drops (after hit animation)
        setTimeout(() => {
          updateHpBar(loseTeamName, lF.hp, lF.maxHp);
          if (lF.ko) {
            playSfx('sfxShatter', 0.7);
            narrate(`<b class="ko-text">${lF.name} goes down!</b>&nbsp;<b class="${winColor}">${wF.name}</b> stands victorious!`);
          } else {
            narrate(`<b class="${loseColor}">${lF.name}</b> holds on — <b class="gold">${lF.hp} HP</b> remaining.`);
          }
          renderBattle();
        }, BEAT_HP);
      }, BEAT_DAMAGE);
    } else {
      if (gusGaleReactiveTriggered) {
        narrate(`<b class="${winColor}">${wF.name}</b> wins! <b class="gold">💨 GALE FORCE?</b> — choose to force a swap!`);
      } else {
        narrate(`<b class="${winColor}">${wF.name}</b> wins the roll but deals 0 damage!`);
      }
    }
  }, BEAT_ANNOUNCE);

  // Pudge self-damage visual (after all damage beats)
  const pudgeDelay = BEAT_ANNOUNCE + BEAT_DAMAGE + BEAT_HP + 400;
  if (pudgeSelfDmgApplied) {
    setTimeout(() => {
      playDamageSfx(1);
      hitDamage(winTeamName);
    }, pudgeDelay);
  }

  // Ability queue drains after all damage beats finish.
  // dmg=0 path: the "deals 0 damage" narration fires at BEAT_ANNOUNCE (600ms) and holds
  // its drainNarrate lock for 1800ms (until t=2400ms).  With the old value of
  // BEAT_ANNOUNCE+200=800ms the drain callback fired at t=800ms — well inside the
  // narration window.  The no-KO path then called narrate("Round N") at t=1550ms, but
  // that message queued behind the still-active 0-damage lock and didn't display until
  // t=2400ms, while roll buttons went live at t=1900ms — a 500ms window where buttons
  // were clickable but zero round-context was visible.
  // Fix: wait BEAT_ANNOUNCE + 1800 + 200 = 2600ms so the callback fires 200ms after the
  // 0-damage narration releases, giving "Round N — X vs Y" a clear slot to display
  // immediately before roll buttons activate.  For non-empty queues the ability callouts
  // also now fire after the 0-damage line clears (more cinematically correct).
  const totalDmgBeats = dmg > 0 ? (BEAT_ANNOUNCE + BEAT_DAMAGE + BEAT_HP + BEAT_POST) : (BEAT_ANNOUNCE + 1800 + 200);
  const dmgDelay = totalDmgBeats;
  setTimeout(() => {
    drainAbilityQueue(() => {
      // Prince Balatron (113) — Party Time: if the loser is Balatron, fire the
      // interactive counter-die modal FIRST (before any round state is reset)
      // so the reveal lands on top of the current scene. Once the player clicks
      // and the shuffle finishes, finishBalatronRoll() calls runPostDrain() to
      // continue with the normal reset + modal chain.
      const runPostDrain = () => {
      // Reset committed resources + per-round ability flags
      B.committed.red = { ice:0, fire:0, surge:0, auntSusan:0, auntSusanHeal:0, harrison:0, zainBlade:0 };
      B.committed.blue = { ice:0, fire:0, surge:0, auntSusan:0, auntSusanHeal:0, harrison:0, zainBlade:0 };
      B.pressureUsed = { red: false, blue: false };
      if (B.romyPrediction) { B.romyPrediction.red = null; B.romyPrediction.blue = null; }
      if (B.guardianFairyStandby) { B.guardianFairyStandby.red = false; B.guardianFairyStandby.blue = false; }
      if (B.eloiseUsedThisRound) { B.eloiseUsedThisRound.red = false; B.eloiseUsedThisRound.blue = false; }
      // bogeyArmed removed v430 — Bogey reflect is now reactive (no pre-arm state)
      // galeForceDecided reset removed — Gus is now reactive post-win
      if (B.jacksonUsedThisRound) { B.jacksonUsedThisRound.red = false; B.jacksonUsedThisRound.blue = false; }
      if (B.sonyaUsedThisRound) { B.sonyaUsedThisRound.red = false; B.sonyaUsedThisRound.blue = false; }
      // Dark Wing (76) Precision: NO per-round reset — once-per-GAME flag persists across rounds (v595)
      if (B.mallowDecided) { B.mallowDecided.red = false; B.mallowDecided.blue = false; }
      // fangUndercoverSwapPending already consumed above; clear arm flag for safety
      if (B.fangUndercoverArmed) { B.fangUndercoverArmed.red = false; B.fangUndercoverArmed.blue = false; }
      if (B.tylerDecidedThisRound) { B.tylerDecidedThisRound.red = false; B.tylerDecidedThisRound.blue = false; }
      if (B.booTeamworkDecidedThisRound) { B.booTeamworkDecidedThisRound.red = false; B.booTeamworkDecidedThisRound.blue = false; }
      if (B.luckyStoneSpentThisTurn) { B.luckyStoneSpentThisTurn.red = 0; B.luckyStoneSpentThisTurn.blue = 0; }
    if (B.preRollAbilitiesFiredThisTurn) { B.preRollAbilitiesFiredThisTurn.red = false; B.preRollAbilitiesFiredThisTurn.blue = false; } B.moonstoneSicknessFiredThisTurn = false;
      // Willow (435) — Joy of Painting: winner didn't lose, loser did
      if (B.willowLostLast) { B.willowLostLast[winTeamName] = false; B.willowLostLast[loseTeamName] = true; }
      // Reset item swing toggles each round (player must actively choose to swing)
      if (B.flameBladeSwing) { B.flameBladeSwing.red = false; B.flameBladeSwing.blue = false; }
      if (B.iceBladeSwing) { B.iceBladeSwing.red = false; B.iceBladeSwing.blue = false; }
      // Toby — Pure Heart: carry forward the scheduled KO flag, then clear declaration
      if (B.pureHeartDeclared) {
        if (B.pureHeartDeclared.red === true && B.pureHeartScheduledKO) B.pureHeartScheduledKO.red = true;
        if (B.pureHeartDeclared.blue === true && B.pureHeartScheduledKO) B.pureHeartScheduledKO.blue = true;
        B.pureHeartDeclared.red = null;
        B.pureHeartDeclared.blue = null;
      }

      // MVP round credit: diff team resources + ghost HPs against the pre-roll snapshot
      try { creditRoundDelta(winTeamName); } catch (e) { console.warn('[MVP] credit failed:', e); }

      // Duel Phase: record this round's loser so they get first move next round
      B.duelLastLoser = loseTeamName;

      B.round++;
      B.preRoll = null;
      // Re-render dice then re-apply highlights SYNCHRONOUSLY in the same tick.
      // The previous code used setTimeout(10) which allowed the browser to paint
      // one neutral frame between innerHTML wipe and highlight re-apply — visible
      // as a ~6-frame flash where winners shrank to scale(1.0) and losers grew
      // from scale(0.94) to scale(1.0), making it look like the losing dice briefly
      // became the winners. Calling highlight synchronously coalesces both DOM
      // changes into one paint.
      renderDice(redDice, blueDice);
      highlightWinnerDice(winTeamName, wR, loseTeamName, tiebreaker);

      // Calvin & Anna (91) — Toboggan: when C&A scores a KO, offer to swap with sideline ghost
      const tobogganAlive = (wF.id === 91 && !wF.ko && lF.ko)
        ? winTeam.ghosts.filter((g, i) => i !== winTeam.activeIdx && !g.ko)
        : [];

      // Fang Outside (6) — Skillful Coward: after any win, offer to swap Fang to sideline
      const fangOutsideAlive = (wF.id === 6 && !wF.ko)
        ? winTeam.ghosts.filter((g, i) => i !== winTeam.activeIdx && !g.ko)
        : [];

      // Winston (15) — Scheme: any win → offer to force-swap opponent's active ghost + gain 2 dice next roll
      const winstonSchemeSideline = (wF.id === 15 && !wF.ko)
        ? loseTeam.ghosts.filter((g, i) => i !== loseTeam.activeIdx && !g.ko)
        : [];

      const proceedToKoHandling = () => {
        // Live PvP: broadcast state after damage so Blue sees HP changes in near-real-time
        pvpBroadcastState({ event: 'damageResolved' });
        if (lF.ko) {
          B.phase = 'ko-pause';
          renderBattle();
          setTimeout(() => {
            if (!handleKOs()) {
              narrate(`<b class="gold">Round ${B.round}</b> — <b class="red-text">${active(B.red).name}</b>&nbsp;vs&nbsp;<b class="blue-text">${active(B.blue).name}</b>`);
              renderBattle();
              setTimeout(() => { startNextRound(); }, spd(350));
            }
          }, spd(900)); // v729: was 1800ms — tightened so swap picker appears faster
        } else {
          B.phase = 'ko-pause';
          renderBattle();
          setTimeout(() => {
            if (!handleKOs()) {
              // Narrate the new matchup first, then enable roll buttons 350ms later —
              // gives the player a beat to read "Round N — X vs Y" before the game unblocks.
              narrate(`<b class="gold">Round ${B.round}</b> — <b class="red-text">${active(B.red).name}</b>&nbsp;vs&nbsp;<b class="blue-text">${active(B.blue).name}</b>`);
              renderBattle();
              setTimeout(() => { startNextRound(); }, spd(350));
            }
          }, spd(750));
        }
      };

      // Fang Undercover (7) — Skilled Coward: if dodge was activated this round, show ghost-picker for lose team
      const fuSwapTeam = B.fangUndercoverSwapPending;
      B.fangUndercoverSwapPending = null;

      // Tyson (365) — Hop: win → choose enemy sideline ghost to disable
      const checkTysonHop = () => {
        if (wF.id === 365 && !wF.ko) {
          const tysonTargets = loseTeam.ghosts.filter((g, i) => i !== loseTeam.activeIdx && !g.ko && !B.tysonDisabled[loseTeamName].includes(i));
          if (tysonTargets.length > 0) {
            showTysonHopPicker(winTeamName, loseTeamName, tysonTargets, proceedToKoHandling);
            return;
          }
        }
        proceedToKoHandling();
      };

      // Winston (15) — Scheme: fires after Toboggan/FangOutside, before Tyson
      const checkWinstonScheme = () => {
        // Barnaby (326) — Stubborn: immune to opponent forced swaps
        const _barnabyWin = active(loseTeam);
        if (_barnabyWin && _barnabyWin.id === 326 && !_barnabyWin.ko && winstonSchemeSideline.length > 0) {
          queueAbility('STUBBORN!', 'var(--uncommon)', `${_barnabyWin.name} — Stubborn! Winston's Scheme is blocked!`, null, loseTeamName);
          log(`<span class="log-ability">Barnaby</span> — Stubborn! Winston Scheme blocked — ${_barnabyWin.name} cannot be forced out.`);
          checkTysonHop();
          return;
        }
        if (winstonSchemeSideline.length > 0) {
          showWinstonSchemeModal(winTeamName, loseTeamName, winstonSchemeSideline, checkTysonHop);
        } else {
          checkTysonHop();
        }
      };

      const afterFangUndercover = () => {
        if (tobogganAlive.length > 0) {
          showTobogganModal(winTeamName, tobogganAlive, checkWinstonScheme);
        } else if (fangOutsideAlive.length > 0) {
          showFangOutsideModal(winTeamName, fangOutsideAlive, checkWinstonScheme);
        } else {
          checkWinstonScheme();
        }
      };

      // Gus (31) — Gale Force: win → force swap, new ghost takes the damage.
      const checkGaleForcePicker = () => {
        if (galeForceSwap && !wF.ko) {
          // Barnaby (326) — Stubborn: immune to opponent forced swaps; takes galeForceDmg directly
          const _barnabyGF = active(loseTeam);
          if (_barnabyGF && _barnabyGF.id === 326 && !_barnabyGF.ko) {
            queueAbility('STUBBORN!', 'var(--uncommon)', `${_barnabyGF.name} — Stubborn! Gus's Gale Force is blocked!`, () => {
              log(`<span class="log-ability">Barnaby</span> — Stubborn! Gale Force blocked — ${_barnabyGF.name} takes ${galeForceDmg} damage directly.`);
              _barnabyGF.hp = Math.max(0, _barnabyGF.hp - galeForceDmg);
              if (_barnabyGF.hp <= 0) { _barnabyGF.ko = true; _barnabyGF.killedBy = 31; }
              renderBattle();
              afterFangUndercover();
            }, loseTeamName);
            return;
          }
          B._galeForceDmg = galeForceDmg; // stash for picker
          const gfAlive = loseTeam.ghosts.filter((g, i) => i !== loseTeam.activeIdx && !g.ko);
          if (gfAlive.length > 1) {
            showGaleForcePickerModal(winTeamName, loseTeamName, gfAlive, afterFangUndercover);
            return;
          } else if (gfAlive.length === 1) {
            // Only 1 option — auto-swap + apply damage
            const autoTarget = gfAlive[0];
            loseTeam.activeIdx = loseTeam.ghosts.indexOf(autoTarget);
            if (galeForceDmg > 0) {
              autoTarget.hp = Math.max(0, autoTarget.hp - galeForceDmg);
              if (autoTarget.hp <= 0) { autoTarget.hp = 0; autoTarget.ko = true; autoTarget.killedBy = 31; }
            }
            renderBattle();
            log(`<span class="log-ability">Gus</span> — Gale Force! ${autoTarget.name} was the only option — enters and takes <span class="log-dmg">${galeForceDmg} damage!</span>${autoTarget.ko ? ' <span class="log-ko">KO!</span>' : ' ' + autoTarget.hp + ' HP left'}`);
            const entryCount = triggerEntry(loseTeam, false);
            afterEntryWithJenkins(entryCount, afterFangUndercover);
            return;
          }
        }
        afterFangUndercover();
      };

      if (fuSwapTeam) {
        const fuTeam = B[fuSwapTeam];
        const fuSidelineGhosts = fuTeam.ghosts.filter((g, i) => i !== fuTeam.activeIdx && !g.ko);
        if (fuSidelineGhosts.length > 0) {
          showFangUndercoverSwapModal(fuSwapTeam, fuSidelineGhosts, checkGaleForcePicker);
        } else {
          // No sideline ghosts (all KO'd since the arm was set) — just proceed
          checkGaleForcePicker();
        }
      } else {
        checkGaleForcePicker();
      }
      }; // end runPostDrain

      // Sky Elusive modal: show after Jasper if pending
      const afterSkyElusive = () => {
        runPostDrain();
      };
      // Jasper Flame Dive modal: show after Balatron if pending
      const afterJasper = () => {
        if (B.skyElusivePending) {
          showSkyElusiveModal(afterSkyElusive);
        } else {
          afterSkyElusive();
        }
      };
      const afterBalatron = () => {
        if (B.jasperPending) {
          showJasperModal(afterJasper);
        } else {
          afterJasper();
        }
      };

      // Guardian Fairy reactive modal: show before Balatron/postDrain if GF pending
      const afterGfReactive = () => {
        // Balatron modal injection: if the pending flag is set, play the interactive
        // counter-die reveal first, then runPostDrain() continues the normal flow.
        if (B.balatronPending) {
          showBalatronModal(afterBalatron);
        } else {
          afterBalatron();
        }
      };

      // Gus (31) — Gale Force reactive: winner decides before Guardian Fairy (loser's defense)
      const afterGusGaleChoice = () => {
        if (B._gusGaleAccepted) {
          // Player accepted Gale Force — damage zeroed, swap picker needed
          B._gusGaleAccepted = false;
          galeForceSwap = true;
          galeForceDmg = B._gusGaleDmg || galeForceDmg;
          dmg = 0; // zero damage to current opponent
          // Skip Guardian Fairy — no damage to absorb
          afterGfReactive();
        } else {
          // Player declined (or wasn't offered) — damage flows normally, GF may absorb
          if (B.guardianFairyReactivePending) {
            const gfp = B.guardianFairyReactivePending;
            gfp.resume = afterGfReactive;
            // v783: timed button instead of full-screen modal
            showGfWishButton();
          } else {
            afterGfReactive();
          }
        }
      };

      // Pal Al / Gordok choice modals: fire before Gus Gale Force (winner decides first)
      const afterWiseAlGordok = () => {
        if (B.gusGaleReactivePending) {
          const gp = B.gusGaleReactivePending;
          gp.resume = afterGusGaleChoice;
          // Auto-accept for AI/autoPlay
          if (autoPlayRunning) {
            doGusGaleReactive('yes');
          } else {
            showGusGaleButton();
          }
        } else {
          afterGusGaleChoice();
        }
      };

      const afterGordokChoice = () => {
        if (B.wiseAlPending) {
          showWiseAlModal(afterWiseAlGordok);
        } else {
          afterWiseAlGordok();
        }
      };

      const afterSophiaChoice = () => {
        if (B.gordokPending) {
          showGordokModal(afterGordokChoice);
        } else {
          afterGordokChoice();
        }
      };

      if (B.sophiaPending) {
        showSophiaModal(afterSophiaChoice);
      } else {
        afterSophiaChoice();
      }
    });
  }, dmgDelay);
}

function handleKOs() {
  // Mark any ghost with hp <= 0 as KO (safety net for edge cases)
  ['red','blue'].forEach(team => {
    B[team].ghosts.forEach(g => { if (g.hp <= 0 && !g.ko) g.ko = true; });
  });

  // Fire post-resolve hooks (event-driven spectator snapshot)
  for (const fn of _postResolveHooks) { try { fn(B); } catch(e) {} }

  // Check for game-over first
  const redAllDown = B.red.ghosts.every(g => g.ko);
  const blueAllDown = B.blue.ghosts.every(g => g.ko);
  if (redAllDown && blueAllDown) { showGameOver('draw'); renderBattle(); return true; }
  if (redAllDown) { showGameOver('blue'); renderBattle(); return true; }
  if (blueAllDown) { showGameOver('red'); renderBattle(); return true; }

  // Check if any active ghost is KO'd and needs a replacement pick
  const teamsNeedingSwap = [];
  for (const team of ['red','blue']) {
    const t = B[team];
    const f = active(t);
    if (f.ko) {
      // Mode G: clear moonstone sickness on KO
      const msModeKO = document.getElementById('moonstoneModeSelect')?.value || 'D';
      if (msModeKO === 'G' && t.moonstoneSickness > 0) {
        log(`<span style="color:var(--moonstone)">Moonstone Sickness cleared!</span> ${team.toUpperCase()}'s sickness lifts with ${f.name}'s defeat.`);
        t.moonstoneSickness = 0;
      }
      const alive = t.ghosts.filter((g,i) => i !== t.activeIdx && !g.ko);
      if (alive.length > 0) {
        teamsNeedingSwap.push(team);
      } else {
        const winner = team === 'red' ? 'blue' : 'red';
        showGameOver(winner); renderBattle(); return true;
      }
    }
  }

  if (teamsNeedingSwap.length > 0) {
    // Queue the KO swap picks — caller must NOT resume to 'ready'
    B.koSwapQueue = teamsNeedingSwap.slice();
    B.phase = 'ko-swap';
    renderBattle();
    openKoSwap();
    return true; // signal: don't resume, swap in progress
  }

  renderBattle();
  return false;
}

function openKoSwap() {
  if (!B.koSwapQueue || B.koSwapQueue.length === 0) {
    // All swaps done — announce the new matchup first, then enable roll buttons
    // 350ms later. Same breathing-room pattern as the v110 no-KO path: narrate()
    // fires before B.phase='ready' so roll buttons don't become live while the
    // entry narration (still draining in drainNarrate) or round announcement is
    // still on screen. Previously B.phase='ready' + resetRollButtons() fired
    // BEFORE narrate(), making buttons clickable before the round line appeared.
    B.koSwapQueue = null;
    renderBattle();
    narrate(`<b class="gold">Round ${B.round}</b> — <b class="red-text">${active(B.red).name}</b>&nbsp;vs&nbsp;<b class="blue-text">${active(B.blue).name}</b>`);
    setTimeout(() => { startNextRound(); }, spd(350));
    return;
  }
  const team = B.koSwapQueue[0];
  const t = B[team];
  const fallen = active(t);
  const alive = t.ghosts.filter((g,i) => i !== t.activeIdx && !g.ko);

  // v728: Blue's local engine auto-picks only for RED's KO swaps (can't make Red's choice).
  // Blue's OWN KO swaps show the real picker so the player can choose.
  if (LIVE_PVP && PVP_SIDE === 'blue' && pvpBlueResolvedLocally && team !== 'blue') {
    const autoIdx = t.ghosts.indexOf(alive[0]);
    const teamLabel = team.charAt(0).toUpperCase() + team.slice(1);
    narrate(`<b class="ko-text">${fallen.name} is down!</b>&nbsp;<b class="${team}-text">${teamLabel}:</b>&nbsp;<b>${alive[0].name}</b> steps up!`);
    setTimeout(() => doKoSwap(team, autoIdx), 400); // v729: was 800ms
    return;
  }

  if (LIVE_PVP && PVP_SIDE === 'red' && team === 'blue') {
    pvpBroadcastState({ event: 'koSwapNeeded', swapTeam: 'blue' });
    const aliveIdxes = alive.map(g => t.ghosts.indexOf(g));
    PVP_GAME_REF.child('koSwapRequest').set({
      side: 'blue',
      fallenName: fallen.name,
      aliveIdxes: aliveIdxes,
      aliveNames: alive.map(g => g.name),
      ts: Date.now()
    });
    // Red waits for Blue's koSwap response via existing listener
    const banner = document.getElementById('pvp-wait-banner');
    if (banner) { banner.textContent = "Waiting for opponent's swap pick..."; banner.style.display = 'block'; }
    return;
  }

  // If only one option, auto-pick (no real choice)
  if (alive.length === 1) {
    const teamLabel = team.charAt(0).toUpperCase() + team.slice(1);
    narrate(`<b class="ko-text">${fallen.name} is down!</b>&nbsp;<b class="${team}-text">${teamLabel}:</b>&nbsp;<b>${alive[0].name}</b> steps up!`);
    setTimeout(() => doKoSwap(team, t.ghosts.indexOf(alive[0])), 400); // v729: was 800ms
    return;
  }

  const teamLabel = team.charAt(0).toUpperCase() + team.slice(1);
  narrate(`<b class="ko-text">${fallen.name} is down!</b>&nbsp;<b class="${team}-text">${teamLabel}</b> — who answers the call?`);
  // Brief delay so narrator text appears before picker lights up
  setTimeout(() => renderBattle(), 150); // v729: was 300ms — tightened for snappier feel
}

function doKoSwap(team, idx) {
  // v728: if Blue picks a KO swap during local resolution, broadcast to Red immediately
  if (LIVE_PVP && PVP_SIDE === 'blue' && pvpBlueResolvedLocally && team === 'blue') {
    PVP_GAME_REF.child('koSwap').push({ side: 'blue', idx: idx, timestamp: firebase.database.ServerValue.TIMESTAMP });
    B._blueKoSwapPick = idx; // stash so koSwapRequest listener can use it
  }
  const t = B[team];
  const fallen = active(t);
  // doKoSwap fires only when a ghost is KO'd by damage — entry effects always fire.
  // Tyson's Hop (skipEntry=true) is handled exclusively via useTysonHop → doSwap.
  const skipEntry = false;
  t.activeIdx = idx;
  const f = active(t);
  // Returning from sideline = full HP
  f.hp = f.maxHp;

  log(`<span class="log-ko">${fallen.name} is down!</span> <span class="log-ability">${f.name} enters at full HP!</span>`);
  const entryCalloutCount = triggerEntry(t, skipEntry);

  renderBattle();

  // Fire post-resolve hooks (spectator snapshot after KO swap)
  for (const fn of _postResolveHooks) { try { fn(B); } catch(e) {} }

  // Remove this team from the queue
  B.koSwapQueue.shift();

  // After entry callouts + Jenkins modal resolve, check for KOs and continue
  afterEntryWithJenkins(entryCalloutCount > 0 ? entryCalloutCount : 0, () => {
    // Check if entry effects caused new KOs (e.g. Nerina's Leviathan, Jenkins Greeting)
    const redAllDown = B.red.ghosts.every(g => g.ko);
    const blueAllDown = B.blue.ghosts.every(g => g.ko);
    if (redAllDown && blueAllDown) { showGameOver('draw'); return; }
    if (redAllDown) { showGameOver('blue'); return; }
    if (blueAllDown) { showGameOver('red'); return; }

    // Check if entry damage KO'd someone new — add to queue
    ['red','blue'].forEach(tm => {
      const tt = B[tm];
      if (active(tt).ko && !B.koSwapQueue.includes(tm)) {
        const alive = tt.ghosts.filter((g,i) => i !== tt.activeIdx && !g.ko);
        if (alive.length > 0) B.koSwapQueue.push(tm);
      }
    });

    openKoSwap();
  });
}

function showGameOver(winner) {
  B.phase = 'over';
  // Fire registered hooks BEFORE the default game-over logic.
  // If a hook returns true, it consumed the event — skip default UI.
  let consumed = false;
  for (const fn of _gameOverHooks) {
    try { if (fn(winner)) consumed = true; } catch(e) { console.error('[showGameOver hook error]', e); }
  }
  if (consumed) return;
  // Live PvP: broadcast game over so both clients show it
  if (LIVE_PVP && PVP_GAME_REF && PVP_SIDE === 'red') {
    const stateSnap = pvpSerializeState();
    PVP_GAME_REF.child('stateSync').set(stateSnap);
    PVP_GAME_REF.child('gameOver').set({ winner, ts: Date.now() });
    PVP_GAME_REF.child('roundResult').push({
      state: stateSnap,
      redDice: B.redDice || null,
      blueDice: B.blueDice || null,
      gameOver: winner,
      ts: Date.now()
    });
  }
  fadeOutMusic();
  // Victory fanfare (delayed to let music fade a bit)
  setTimeout(() => playSfx('sfxVictory', 0.6), 600);
  // Clean up any active overlays/animations
  document.getElementById('abilitySplash').classList.remove('active');
  clearLsCountdown();
  disableRollButtons();

  // Record standings
  let matchMvp = null;
  let redMvpId = null;
  let blueMvpId = null;
  if (winner === 'red' || winner === 'blue') {
    const winTeam = B[winner];
    const loseTeamName = winner === 'red' ? 'blue' : 'red';
    const loseTeamObj = B[loseTeamName];
    winTeam.ghosts.forEach(g => recordWin(g.originalId || g.id));
    loseTeamObj.ghosts.forEach(g => recordLoss(g.originalId || g.id));
    // Record KO'D (times defeated) and Kills (KOs scored) from killedBy tags
    const allGhosts = [...winTeam.ghosts, ...loseTeamObj.ghosts];
    allGhosts.forEach(g => {
      if (g.ko) {
        recordKO(g.originalId || g.id); // this ghost was defeated
        if (g.killedBy && g.killedBy > 0) recordKill(g.killedBy); // credit the killer
      }
    });
    // MVP: pick the winning team's top scorer and record in standings
    try {
      matchMvp = pickMatchMvp(winner);
      if (matchMvp) recordMvp(matchMvp.originalId || matchMvp.id);
      // Compute stats-based MVPs for BOTH teams for the end-of-match display.
      // The losing team gets an MVP too — even if every ghost was KO'd — based
      // on who actually contributed most (KOs scored, damage, rolls won,
      // resources generated). This is display-only; standings still only count
      // the winning team's MVP via recordMvp() above.
      const redPick = pickMatchMvp('red');
      const bluePick = pickMatchMvp('blue');
      redMvpId = redPick ? redPick.id : null;
      blueMvpId = bluePick ? bluePick.id : null;
    } catch (e) { console.warn('[MVP] pick failed:', e); }
  }

  const el = document.getElementById('gameOver');
  el.classList.add('active');
  const title = document.getElementById('goTitle');
  const rounds = B.round - 1;
  if (winner === 'draw') { title.textContent = 'DRAW!'; title.className = ''; }
  else {
    const winnerName = MP_MODE ? MP_PLAYER_NAMES[winner] : `Team ${winner.charAt(0).toUpperCase() + winner.slice(1)}`;
    title.textContent = `${winnerName} WINS!`;
    title.className = `${winner}-win`;
  }

  // Round count
  document.getElementById('goRounds').textContent = `${rounds} round${rounds !== 1 ? 's' : ''} played`;

  // Battle summary with ghost statuses
  function buildTeamCol(teamObj, teamLabel, teamColor, mvpId) {
    const gd = id => ghostData(id);

    const rows = teamObj.ghosts.map((g, i) => {
      const displayId = g.originalId || g.id;
      const displayName = g.originalName || g.name;
      const displayArt = g.originalArt || g.art;
      const data = gd(displayId);
      // MVP badge follows the stats-based pick from pickMatchMvp() — awarded
      // even if the MVP ghost was KO'd (wiped-team case).
      const isMvp = (mvpId != null && (g.id === mvpId || g.originalId === mvpId));
      const artSrc = displayArt || (data && data.art);
      const artHtml = artSrc
        ? `<img class="go-ghost-art" src="${artSrc}" alt="${displayName}" loading="lazy" onerror="this.outerHTML='<div class=\\'go-ghost-art-placeholder\\'>👻</div>'">`
        : `<div class="go-ghost-art-placeholder">&#128123;</div>`;
      const statusText = g.ko
        ? "KO'd"
        : `${g.hp}/${g.maxHp} HP`;
      const statusClass = g.ko ? 'ko' : 'survived';
      const mvpBadge = isMvp ? '<span class="go-mvp-badge">MVP</span>' : '';
      return `<div class="go-ghost-row${isMvp ? ' mvp' : ''}">
        ${artHtml}
        <div class="go-ghost-info">
          <div class="go-ghost-name">${displayName}</div>
          <div class="go-ghost-status ${statusClass}">${statusText}</div>
        </div>
        ${mvpBadge}
      </div>`;
    }).join('');

    const displayLabel = MP_MODE ? MP_PLAYER_NAMES[teamColor] : `Team ${teamLabel}`;
    return `<div class="go-team-col">
      <h3 class="${teamColor}-label">${displayLabel}</h3>
      ${rows}
    </div>`;
  }

  const summaryHtml = buildTeamCol(B.red, 'Red', 'red', redMvpId) + buildTeamCol(B.blue, 'Blue', 'blue', blueMvpId);
  document.getElementById('goSummary').innerHTML = summaryHtml;

  // MULTIPLAYER MODE: replace buttons with "Return to Arena" redirect
  if (MP_MODE) {
    // In live PvP, result is relative to YOUR side
    const result = LIVE_PVP
      ? (winner === PVP_SIDE ? 'win' : (winner === 'draw' ? 'draw' : 'loss'))
      : (winner === 'red' ? 'win' : (winner === 'blue' ? 'loss' : 'draw'));

    // Clean up live PvP game
    if (LIVE_PVP && PVP_GAME_REF) {
      PVP_GAME_REF.child('status').set('finished');
      PVP_GAME_REF.child('winner').set(winner);
    }

    const goButtons = el.querySelector('.go-buttons');

    // RAID MODE: show boss dialogue and redirect with raid results
    if (RAID_MODE && RAID_PARAMS) {
      const bossLine = winner === 'red'
        ? `${RAID_PARAMS.bossName} has been defeated!`
        : `${RAID_PARAMS.bossName} stands triumphant.`;
      const dialogueEl = document.createElement('div');
      dialogueEl.style.cssText = 'text-align:center;color:var(--text2);font-style:italic;font-size:1.1rem;margin:12px 0;';
      dialogueEl.textContent = bossLine;
      const goTitle = document.getElementById('goTitle');
      if (goTitle) goTitle.after(dialogueEl);
      // Calculate total damage dealt to blue team (boss) — exclude padded ghosts
      let totalDamage = 0;
      if (B && B.blue) {
        const realCount = RAID_PARAMS.realBossGhostCount || B.blue.ghosts.length;
        for (let i = 0; i < realCount; i++) {
          const g = B.blue.ghosts[i];
          if (g) totalDamage += Math.max(0, g.maxHp - (g.ko ? 0 : g.hp));
        }
      }
      const ghostsLost = B ? B.red.ghosts.filter(g => g.ko).length : 0;
      // Calculate damage taken by player's team
      let damageTaken = 0;
      if (B && B.red) {
        B.red.ghosts.forEach(g => {
          damageTaken += Math.max(0, g.maxHp - (g.ko ? 0 : g.hp));
        });
      }

      if (goButtons) {
        const returnUrl = `../multiplayer/?raidResult=done`
          + `&instanceId=${encodeURIComponent(RAID_PARAMS.instanceId)}`
          + `&raidId=${encodeURIComponent(RAID_PARAMS.raidId)}`
          + `&damage=${totalDamage}`
          + `&damageTaken=${damageTaken}`
          + `&ghostsLost=${ghostsLost}`
          + `&slot=${RAID_PARAMS.slot}`
          + `&result=${result}`;
        goButtons.innerHTML = `
          <button class="go-btn-rematch" onclick="try{sessionStorage.setItem('raidJustCompleted','1')}catch(e){};window.location.href='${returnUrl}'">
            Return to Raid
          </button>
        `;
        // Mark raid as completed in sessionStorage (survives page navigation)
        try { sessionStorage.setItem('raidJustCompleted', '1'); } catch(e) {}
        // Auto-redirect after 5 seconds
        setTimeout(() => { window.location.href = returnUrl; }, 5000);
      }
    } else if (goButtons) {
      // Daily mode uses dailyResult param; regular MP uses result param
      const returnUrl = MP_DAILY
        ? `../multiplayer/?dailyResult=${result}`
        : `../multiplayer/?result=${result}`;
      goButtons.innerHTML = `
        <button class="go-btn-rematch" onclick="window.location.href='${returnUrl}'">
          Return to Arena
        </button>
      `;
    }
  }
}

// ============================================================
// SWAP
// ============================================================
function openSwap(team) {
  if (!B || B.phase!=='ready') return;
  const t = B[team];
  const opts = t.ghosts.filter((g,i) => i!==t.activeIdx);
  document.getElementById('swapTitle').textContent = `Swap ${team.toUpperCase()} Active Ghost`;
  document.getElementById('swapOptions').innerHTML = opts.map(g => {
    const realIdx = t.ghosts.indexOf(g);
    const gd = ghostData(g.id);
    const hpRatio = g.hp / g.maxHp;
    const hpColor = hpRatio > 0.6 ? 'var(--hp-green)' : hpRatio > 0.3 ? 'var(--hp-yellow)' : 'var(--hp-red)';
    return `<div class="swap-option ${g.ko?'ko':''}" onclick="doSwap('${team}',${realIdx})" style="display:flex; gap:10px; align-items:center;">
      ${gd.art ? `<img src="${gd.art}" style="width:50px; height:50px; border-radius:6px; object-fit:cover; border:1px solid var(--${gd.rarity});">` : ''}
      <div>
        <div class="so-name">${g.name}</div>
        <div class="so-info"><span style="color:${hpColor}; font-weight:700;">&hearts; ${g.hp}/${g.maxHp}</span> ${g.ko?'<span style="color:var(--accent); font-weight:800;">(KO)</span>':''} &middot; <span style="color:var(--moonstone);">${gd.ability}</span></div>
      </div>
    </div>`;
  }).join('');
  document.getElementById('swapOverlay').classList.add('active');
}

function doSwap(team, idx) {
  const t = B[team];
  if (t.ghosts[idx].ko) return;
  const oldGhost = active(t);
  const oldName = oldGhost.name;
  const skipEntry = (oldGhost.id === 365); // Tyson — Hop: no entry effects
  t.activeIdx = idx;
  const f = active(t);
  // Returning from sideline = full HP
  f.hp = f.maxHp;

  log(`<span class="log-ability">${oldName} swaps out — ${f.name} enters at full HP!</span>`);
  if (skipEntry) {
    log(`<span class="log-ability">Tyson</span> — Hop! No entry effects triggered.`);
  }
  const entryCount = triggerEntry(t, skipEntry);

  document.getElementById('swapOverlay').classList.remove('active');
  if (B.jenkinsPending) {
    afterEntryWithJenkins(entryCount, () => {
      if (!handleKOs()) renderBattle();
    });
  } else {
    if (!handleKOs()) renderBattle();
  }
}

// ============================================================
// ABILITY CALLOUT
// ============================================================
// Narration queue — prevents rapid narrations from overwriting each other
let narrateQueue = [];
let narrateActive = false;
function narrate(html) {
  const el = document.getElementById('narrator');
  if (!el) return;
  if (!html) { el.innerHTML = ''; narrateQueue = []; narrateActive = false; return; }
  narrateQueue.push(html);
  if (!narrateActive) drainNarrate();
}
function drainNarrate() {
  const el = document.getElementById('narrator');
  if (!el || narrateQueue.length === 0) { narrateActive = false; return; }
  narrateActive = true;
  const html = narrateQueue.shift();
  el.style.opacity = '0';
  setTimeout(() => {
    el.innerHTML = '<span>' + html + '</span>';
    el.style.opacity = '1';
    // Always hold 1800ms — even as the last item in the queue.
    // Without this, `narrateActive` drops to false immediately after display,
    // so any narrate() called within ~800–1500ms (e.g. "Y enters the arena!"
    // after "X is down!") bypasses the queue and stomps the current line.
    // After the 1800ms hold, drain the next queued item if one arrived,
    // otherwise release the lock so future calls fire immediately.
    setTimeout(() => {
      if (narrateQueue.length > 0) drainNarrate();
      else narrateActive = false;
    }, 1800);
  }, 150);
}

// ============================================================
// AUDIO
// ============================================================
function playSfx(id, vol) {
  const el = document.getElementById(id);
  if (!el || typeof el.play !== 'function') return;
  el.currentTime = 0;
  el.volume = Math.min(vol || 0.8, 1.0);
  el.play().catch(() => {});
}

function playDamageSfx(dmg) {
  if (dmg >= 3) playSfx('sfx3Damage');
  else if (dmg === 2) playSfx('sfx2Damage');
  else playSfx('sfx1Damage');
}

// ============================================================
// MUSIC SYSTEM — v740 rewrite (fixes stale listeners, fade reset, mute state)
// ============================================================
let _musicStarted = false;
let _musicRetryHandler = null; // track the single retry listener so we can remove it

function startMusic() {
  if (_musicStarted) return;
  if (_muted) { _musicStarted = true; return; }
  const music = document.getElementById('bgMusic');
  music.currentTime = 0;
  music.volume = 0.2;
  // Remove any stale retry handler from a previous battle cycle
  if (_musicRetryHandler) {
    document.removeEventListener('click', _musicRetryHandler);
    _musicRetryHandler = null;
  }
  const p = music.play();
  if (p) {
    p.then(() => { _musicStarted = true; }).catch(() => {
      // Autoplay blocked — attach a single retry on next click
      _musicRetryHandler = () => {
        if (_musicStarted) return;
        _musicStarted = true;
        _musicRetryHandler = null;
        music.volume = 0.2;
        music.play().catch(() => {});
      };
      document.addEventListener('click', _musicRetryHandler, { once: true });
    });
  } else {
    _musicStarted = true;
  }
}

function fadeOutMusic() {
  const music = document.getElementById('bgMusic');
  clearInterval(music._fadeInt);
  music._fadeInt = setInterval(() => {
    if (music.volume > 0.03) { music.volume -= 0.03; }
    else {
      clearInterval(music._fadeInt);
      music.pause();
      music.volume = 0.2;
      _musicStarted = false; // reset so music can restart on next battle
    }
  }, 60);
}

// v734: mute toggle — persists via localStorage
let _muted = localStorage.getItem('tr_muted') === '1';
function toggleMute() {
  _muted = !_muted;
  localStorage.setItem('tr_muted', _muted ? '1' : '0');
  const music = document.getElementById('bgMusic');
  const btn = document.getElementById('muteToggle');
  if (_muted) {
    music.pause();
    // Don't reset _musicStarted — muting is temporary, not a stop
    btn.textContent = '\u{1F507}';
    btn.title = 'Music off — click to unmute';
  } else {
    music.volume = 0.2;
    _musicStarted = false; // allow startMusic path to re-engage
    const p = music.play();
    if (p) {
      p.then(() => { _musicStarted = true; }).catch(() => {
        // Autoplay blocked on unmute — retry on next click
        if (_musicRetryHandler) document.removeEventListener('click', _musicRetryHandler);
        _musicRetryHandler = () => {
          if (_musicStarted) return;
          _musicStarted = true;
          _musicRetryHandler = null;
          music.volume = 0.2;
          music.play().catch(() => {});
        };
        document.addEventListener('click', _musicRetryHandler, { once: true });
      });
    } else {
      _musicStarted = true;
    }
    btn.textContent = '\u{1F50A}';
    btn.title = 'Music on — click to mute';
  }
}
// Apply saved mute state on load
document.addEventListener('DOMContentLoaded', () => {
  const btn = document.getElementById('muteToggle');
  if (btn && _muted) {
    btn.textContent = '\u{1F507}';
    btn.title = 'Music off — click to unmute';
  }
});

function stopMusicHard() {
  const music = document.getElementById('bgMusic');
  clearInterval(music._fadeInt);
  music.pause();
  music.currentTime = 0;
  music.volume = 0.2;
  _musicStarted = false;
  // Clean up any pending retry handler
  if (_musicRetryHandler) {
    document.removeEventListener('click', _musicRetryHandler);
    _musicRetryHandler = null;
  }
}

// Unlock audio on first user interaction (browsers block autoplay)
// v726: skip bgMusic entirely — startMusic() has its own retry-on-click handler.
// unlockAudio's play().then(pause) pattern races with startMusic's retry and kills music.
(function unlockAudio() {
  const unlock = () => {
    document.querySelectorAll('audio').forEach(a => {
      if (a.id === 'bgMusic') return; // handled by startMusic's own retry
      if (!a.paused) return;
      a.play().then(() => a.pause()).catch(() => {});
    });
    document.removeEventListener('click', unlock);
    document.removeEventListener('touchstart', unlock);
  };
  document.addEventListener('click', unlock, { once: true });
  document.addEventListener('touchstart', unlock, { once: true });
})();

function showTriplesEffect(side, rollType) {
  const banner = document.getElementById('triplesBanner');
  const flash = document.getElementById('triplesFlash');
  const bannerText = { penta:'PENTA!!', quads:'QUADS!', triples:'TRIPLES!' };
  banner.textContent = bannerText[rollType] || (rollType.endsWith('-of-a-kind') ? rollType.toUpperCase() + '!!!' : 'TRIPLES!');

  if (rollType === 'triples') playSfx('triplesSfx', 1.0);

  // Glow on dice
  const diceEl = document.getElementById(side + '-dice');
  if (diceEl) {
    diceEl.querySelectorAll('.die').forEach(d => d.classList.add('triples-glow'));
  }
  // Also glow 3D dice
  const tripPh = _dicePhysics[side];
  if (tripPh && tripPh.settled) {
    tripPh.dice.forEach(d => d.el.classList.add('triples-glow-3d'));
  }

  // Flash
  flash.className = 'triples-flash ' + side + '-flash';
  flash.style.transition = 'none';
  flash.style.opacity = '0.6';
  requestAnimationFrame(() => { flash.style.transition = 'opacity 0.8s ease-out'; flash.style.opacity = '0'; });

  // Screen shake
  document.body.classList.add('screen-shake');
  setTimeout(() => document.body.classList.remove('screen-shake'), spd(500));

  // Banner pop
  banner.className = 'triples-banner ' + side + '-triples';
  requestAnimationFrame(() => {
    banner.classList.add('show');
    setTimeout(() => {
      banner.classList.remove('show');
      banner.classList.add('fade');
      setTimeout(() => { banner.className = 'triples-banner'; }, spd(500));
    }, spd(1200));
  });
}

// Ability splash themes mapped from color vars
const SPLASH_THEMES = {
  'var(--magma)':      'theme-fire',
  'var(--moonstone)':  'theme-blue',
  'var(--rare)':       'theme-blue',
  'var(--ghost-rare)': 'theme-purple',
  'var(--uncommon)':   'theme-green',
  'var(--legendary)':  'theme-gold',
  'var(--accent)':     'theme-red',
  '#22c55e':           'theme-green',
  '#fbbf24':           'theme-gold',
  '#a855f7':           'theme-purple',
};

// ============================================================
// ABILITY QUEUE — cinematic sequential playback
// ============================================================
let abilityQueue = [];
let abilityQueueMode = false;

function queueAbility(name, color, desc, onShow, team) {
  if (abilityQueueMode) {
    abilityQueue.push({ name, color, desc, onShow, team });
  } else {
    showAbilityCallout(name, color, desc, team);
    if (onShow) onShow();
  }
}

function drainAbilityQueue(callback) {
  abilityQueueMode = false;
  if (abilityQueue.length === 0) {
    try { callback(); } catch (e) { console.error('[drainAbilityQueue empty-callback CRASH]', e); try { log(`<span class="log-dmg">ERROR in post-drain callback:</span> ${e && e.message ? e.message : String(e)}`); } catch (_) {} try { B.phase = 'ready'; resetRollButtons(); renderBattle(); } catch (_) {} }
    return;
  }
  let i = 0;
  function next() {
    if (i >= abilityQueue.length) {
      abilityQueue = [];
      // 1500ms: each splash displays for 1400ms, so firing the callback at 900ms
      // (the old value) meant the last splash still had 500ms left on screen when
      // the callback ran — causing roll buttons, modals, and narration to appear
      // while the callout was still visible.  1500ms gives 100ms of clearance after
      // the last splash auto-dismisses, eliminating the race across ALL drain paths.
      // v386: wrap callback in try/catch so a broken post-drain handler never freezes the game
      setTimeout(() => {
        try { callback(); } catch (e) {
          console.error('[drainAbilityQueue callback CRASH]', e);
          try { log(`<span class="log-dmg">ERROR in post-drain callback:</span> ${e && e.message ? e.message : String(e)}`); } catch (_) {}
          try { B.phase = 'ready'; resetRollButtons(); renderBattle(); } catch (_) {}
        }
      }, spd(1500));
      return;
    }
    const a = abilityQueue[i++];
    // v386: wrap each ability's onShow in try/catch — a single broken closure must not
    // kill the whole cinematic queue and freeze the game.
    try { showAbilityCallout(a.name, a.color, a.desc, a.team); } catch (e) { console.error('[showAbilityCallout CRASH]', a, e); }
    if (a.onShow) {
      try { a.onShow(); } catch (e) { console.error('[ability onShow CRASH]', a.name, e); try { log(`<span class="log-dmg">ERROR in ${a.name} onShow:</span> ${e && e.message ? e.message : String(e)}`); } catch (_) {} }
    }
    setTimeout(next, spd(1300));
  }
  next();
}

// showAbilityCallout — v407: no more full-screen proscenium splash.
// Instead: the firing fighter's card glows with a themed spotlight pulse,
// and the narrator strip shows the ability name + desc for the callout beat.
// #abilitySplash DOM element kept (display:none) so .active toggling still works
// for any external code that reads it (3 callsites) — safe no-op.
function showAbilityCallout(name, color, desc, team) {
  // v721: capture ability events for PvP Blue sync (hooked here to catch ALL callouts)
  if (LIVE_PVP && PVP_SIDE === 'red') {
    pvpAbilityEvents.push({ name: name || '', color: color || '', desc: desc || '', team: team || '' });
  }
  // Maintain splash .active compatibility (visual no-op — CSS sets display:none)
  const el = document.getElementById('abilitySplash');
  const theme = SPLASH_THEMES[color] || '';
  el.className = 'ability-splash ' + theme;
  el.classList.add('active');
  clearTimeout(el._timer);
  el._timer = setTimeout(() => { el.classList.remove('active'); }, spd(1400));

  // Play the ability SFX — audio cue is good, keep it
  playSfx('sfxSpecial', 0.85);

  // Card spotlight glow — pulse the firing fighter's slot
  if (team) {
    const slotId = team === 'red' ? 'red-fighter' : 'blue-fighter';
    const slot = document.getElementById(slotId);
    if (slot) {
      const fireTheme = theme.replace('theme-', '') || 'default';
      clearTimeout(slot._abilityFireTimer);
      slot.classList.remove(
        'ability-fire', 'ability-fire-fire', 'ability-fire-blue',
        'ability-fire-purple', 'ability-fire-green', 'ability-fire-gold',
        'ability-fire-red', 'ability-fire-default'
      );
      void slot.offsetWidth; // force reflow so re-trigger restarts the animation
      slot.classList.add('ability-fire', 'ability-fire-' + fireTheme);
      slot._abilityFireTimer = setTimeout(() => {
        slot.classList.remove(
          'ability-fire', 'ability-fire-fire', 'ability-fire-blue',
          'ability-fire-purple', 'ability-fire-green', 'ability-fire-gold',
          'ability-fire-red', 'ability-fire-default'
        );
      }, spd(1200));
    }
  }

  // Narrator strip — ability name (colored) + desc for the duration of the beat
  const narrator = document.getElementById('narrator');
  if (narrator) {
    clearTimeout(narrator._abilityTimer);
    narrator.classList.add('ability-active');
    narrator.innerHTML = '<b style="color:' + (color || 'var(--moonstone)') + '">' + name + '</b>' +
      (desc ? ' <span style="opacity:0.72;font-size:12px;font-weight:500">\u2014 ' + desc + '</span>' : '');
    narrator._abilityTimer = setTimeout(() => { narrator.classList.remove('ability-active'); }, spd(1300));
  }

  // Small hype-pop callout strip — unobtrusive, keep it
  const small = document.getElementById('abilityCallout');
  if (small) {
    small.style.visibility = '';
    small.textContent = name;
    small.style.color = color || 'var(--moonstone)';
    small.classList.remove('hype-pop');
    void small.offsetWidth;
    small.classList.add('hype-pop');
    clearTimeout(small._timer);
    small._timer = setTimeout(() => { small.textContent = ''; small.classList.remove('hype-pop'); }, spd(2200));
  }
}

// ============================================================
// RENDERING
// ============================================================
function renderCardSlot(ghost, isFighter) {
  const g = ghostData(ghost.id);
  const rarityLabel = g.rarity.replace('-',' ');
  const artHtml = g.art
    ? `<img class="card-img" src="${g.art}" alt="${ghost.name}" loading="lazy" onerror="this.outerHTML='<div class=\\'card-img-placeholder\\'>👻</div>'">`
    : `<div class="card-img-placeholder">👻</div>`;
  let statusHtml = '';
  if (isFighter) {
    if (ghost.hankFirstRoll) statusHtml += `<span class="status-tag pressure">Lazy (1-2-3)</span>`;
    if (ghost.maximoFirstRoll) statusHtml += `<span class="status-tag streak">Napping (1 die)</span>`;
    // Check if opponent has Timber (210) — Howl debuff indicator
    if (B) {
      const thisTeam = B.red.ghosts.includes(ghost) ? B.red : B.blue;
      const thisTeamName = thisTeam === B.red ? 'red' : 'blue';
      const oppTeam = thisTeam === B.red ? B.blue : B.red;
      const oppActive = active(oppTeam);
      if (oppActive && oppActive.id === 210 && !oppActive.ko) {
        statusHtml += `<span class="status-tag pressure" style="background:var(--surface3);">⚠️ Timber · Choose Each Roll</span>`;
      }
      // Retribution indicator — Knight Light (402) has pending bonus dice stored up
      if (ghost.id === 402 && !ghost.ko && B.retributionDice) {
        const stored = B.retributionDice[thisTeamName] || 0;
        if (stored > 0) {
          statusHtml += `<span class="status-tag" style="background:rgba(52,152,219,0.15);color:var(--rare);">+${stored} ⚡ Retribution</span>`;
        }
      }
      // Zain (206) — Ice Blade: persistent forged status
      if (ghost.id === 206 && !ghost.ko && ghost.iceBladeForged) {
        statusHtml += `<span class="status-tag" style="background:rgba(103,232,249,0.18);color:#67e8f9;border:1px solid rgba(103,232,249,0.45);" title="Ice Blade forged — swing for +1 die and +2 damage on win">🗡️ Ice Blade</span>`;
      }
            // Finn (204) Forge indicator:
      // • Finn on sideline → show Forge state on the active fighter's card
      // • Finn IS the active fighter → show "dormant" on his own card so players
      //   know they need to bench him for Forge to activate
      if (ghost.id === 204) {
        statusHtml += `<span class="status-tag" style="background:rgba(100,116,139,0.18);color:#94a3b8;" title="Finn can forge the Flame Blade (sideline or active)">🔥 Flame Blade: ${B.flameBlade && B.flameBlade[thisTeamName] ? 'FORGED' : 'ready to forge'}</span>`;
      } else if (hasSideline(thisTeam, 204)) {
        const canForge = (thisTeam.resources.ice >= 2) || (thisTeam.resources.fire >= 2);
        if (canForge) {
          statusHtml += `<span class="status-tag" style="background:rgba(251,191,36,0.16);color:#fbbf24;border:1px solid rgba(251,191,36,0.35);">🔨 Forge: ready</span>`;
        } else {
          statusHtml += `<span class="status-tag" style="background:rgba(100,116,139,0.18);color:#94a3b8;">🔨 Forge: idle</span>`;
        }
      }
    }
    // Overclock indicator — moonstone cyan pulse, matching HP bar + HP text colors when hp > maxHp
    if (ghost.hp > ghost.maxHp) {
      const overAmt = ghost.hp - ghost.maxHp;
      statusHtml += `<span class="status-tag overclock">💧 +${overAmt} Overheal</span>`;
    }
  }
  // HP color
  const hpRatio = ghost.hp / ghost.maxHp;
  const hpColor = hpRatio > 1 ? 'var(--moonstone)' : hpRatio > 0.6 ? 'var(--hp-green)' : hpRatio > 0.3 ? 'var(--hp-yellow)' : 'var(--hp-red)';
  return `
    <div class="card-name-banner rarity-${g.rarity}">${ghost.name}</div>
    <div class="card-rarity-badge rarity-${g.rarity}">${rarityLabel}</div>
    <div class="card-hp-badge" style="color:${hpColor}">${ghost.hp}/${ghost.maxHp}</div>
    ${artHtml}
    <div class="ability-banner">${g.ability}</div>
    <div class="card-info">
      <div class="ci-desc" title="${g.abilityDesc}">${g.abilityDesc}</div>
    </div>
    ${statusHtml ? `<div class="fighter-status">${statusHtml}</div>` : ''}`;
}

function updateHpBar(team, hp, maxHp) {
  const pct = Math.max(0, hp / maxHp * 100);
  const bar = document.getElementById(`${team}-hpBar`);
  bar.style.width = Math.min(pct, 100) + '%';
  const isOverclock = hp > maxHp;
  bar.classList.toggle('hp-low', !isOverclock && pct <= 50 && pct > 25);
  bar.classList.toggle('hp-critical', !isOverclock && pct <= 25);
  bar.classList.toggle('hp-overclock', isOverclock);
  const hpText = document.getElementById(`${team}-hpText`);
  hpText.textContent = `${Math.max(0, hp)} / ${maxHp}`;
  if (isOverclock) hpText.style.color = 'var(--moonstone)';
  else hpText.style.color = '';
}

// Visual hit — shake the card + drain the HP bar for a team
function hitDamage(teamName) {
  const t = B[teamName];
  const f = active(t);
  const el = document.getElementById(teamName + '-fighter');
  el.classList.add('hit');
  setTimeout(() => el.classList.remove('hit'), 500);
  updateHpBar(teamName, f.hp, f.maxHp);
}

function renderBattle() {
  if (!B) return;

  // v736: enforce Moonstone cap (1) and Firefly cap (1) globally
  ['red','blue'].forEach(s => {
    if (B[s].resources.moonstone > 1) B[s].resources.moonstone = 1;
    if ((B[s].resources.firefly || 0) > 1) B[s].resources.firefly = 1;
  });

  ['red','blue'].forEach(team => {
    const t = B[team];
    const f = active(t);
    const sl = t.ghosts.filter((_,i) => i !== t.activeIdx);

    // Fighter
    const fighterEl = document.getElementById(`${team}-fighter`);
    const fData = ghostData(f.id);
    fighterEl.className = `arena-card fighter-slot team-${team} rarity-${fData.rarity} ${f.ko?'ko':''}`;
    fighterEl.innerHTML = renderCardSlot(f, true);

    // HP Bar
    updateHpBar(team, f.hp, f.maxHp);

    // Sideline
    const slLeft = document.getElementById(`${team}-sl-left`);
    const slRight = document.getElementById(`${team}-sl-right`);
    const isKoPickTeam = B.phase === 'ko-swap' && B.koSwapQueue && B.koSwapQueue[0] === team;
    [slLeft, slRight].forEach((el, i) => {
      if (sl[i] && !sl[i].isPadded) {
        el.style.visibility = 'visible';
        const slData = ghostData(sl[i].id);
        const isPick = isKoPickTeam && !sl[i].ko;
        const realIdx = t.ghosts.indexOf(sl[i]);
        el.className = `arena-card sideline-slot rarity-${slData.rarity} ${sl[i].ko?'ko':''} ${isPick?'ko-swap-pick':''}`;
        let slCardHtml = renderCardSlot(sl[i], false);
        // Burn badge: show how much burn is stacked on this sideline ghost
        if (B.burn && B.burn[team] && B.burn[team][realIdx]) {
          const bc = B.burn[team][realIdx];
          slCardHtml += `<div class="burn-badge">🔥${bc}</div>`;
        }
        el.innerHTML = slCardHtml;
        el.onclick = isPick ? () => doKoSwap(team, realIdx) : null;
      } else {
        el.style.visibility = 'hidden';
        el.onclick = null;
      }
    });

    // Resources — single tile per resource (boobattles style)
    const r = t.resources;
    const c = B.committed[team];
    // Pre-roll controls are available during 'ready' OR during the Duel Phase
    // when it's this team's turn — matches the isPreRollActive() handler gate.
    const isReady = isPreRollActive(team);
    // Sylvia (313): ice is free (not consumed on commit), so r.ice already includes committed ice
    const isSylviaActive = f && f.id === 313 && !f.ko;
    const totalIce = isSylviaActive ? r.ice : (r.ice + c.ice);
    const totalFire = r.fire + c.fire;
    const totalSurge = r.surge + c.surge;
    let rh = '';

    if (r.moonstone > 0) {
      rh += `<div class="res-tile moonstone" title="Moonstone: after rolling, click it — then pick any die and set it to any value you choose"><span class="res-main">💎</span><span class="res-count">${r.moonstone}</span><span class="res-label">MS</span></div>`;
    }
    if (totalIce > 0) {
      const committed = c.ice > 0;
      const click = isReady ? `onclick="cycleCommit('${team}','ice')"` : '';
      const label = committed ? `${c.ice}/${totalIce}⚔` : totalIce;
      const tileLabel = committed ? `+${c.ice} DMG` : 'ICE';
      const iceTitle = committed
        ? `${c.ice} of ${totalIce} Ice Shard${totalIce>1?'s':''} committed — +${c.ice} damage if you win${c.ice < totalIce ? ' (click to commit more)' : ''}`
        : `Ice Shards: ${totalIce} available — click to commit (+1 dmg each)`;
      rh += `<div class="res-tile ice ${committed?'committed':''} ${isReady?'clickable':''}" ${click} title="${iceTitle}"><span class="res-main"><img src="../boobattles/iceshard.png"></span><span class="res-count">${label}</span><span class="res-label ${committed?'res-label-bonus':''}">${tileLabel}</span></div>`;
    }
    if (totalFire > 0) {
      const committed = c.fire > 0;
      const click = isReady ? `onclick="cycleCommit('${team}','fire')"` : '';
      const label = committed ? `${c.fire}/${totalFire}⚔` : totalFire;
      const tileLabel = committed ? `+${c.fire*3} DMG` : 'FIRE';
      const fireTitle = committed
        ? `${c.fire} of ${totalFire} Sacred Fire committed — +${c.fire*3} damage if you win${c.fire < totalFire ? ' (click to commit more)' : ''}`
        : `Sacred Fire: ${totalFire} available — click to commit (+3 dmg each)`;
      rh += `<div class="res-tile fire ${committed?'committed':''} ${isReady?'clickable':''}" ${click} title="${fireTitle}"><span class="res-main"><img src="../boobattles/sacredfire.png"></span><span class="res-count">${label}</span><span class="res-label ${committed?'res-label-bonus':''}">${tileLabel}</span></div>`;
    }
    if (totalSurge > 0) {
      const committed = c.surge > 0;
      const click = isReady ? `onclick="cycleCommit('${team}','surge')"` : '';
      const label = committed ? `${c.surge}/${totalSurge}⚔` : totalSurge;
      const tileLabel = committed ? `+${c.surge} ${c.surge>1?'DICE':'DIE'}` : 'SURGE';
      const surgeTitle = committed
        ? `${c.surge} of ${totalSurge} Surge committed — +${c.surge} extra ${c.surge>1?'dice':'die'} this roll${c.surge < totalSurge ? ' (click to commit more)' : ''}`
        : `Surge: ${totalSurge} available — click to commit (+1 extra die each)`;
      rh += `<div class="res-tile surge ${committed?'committed':''} ${isReady?'clickable':''}" ${click} title="${surgeTitle}"><span class="res-main">⚡</span><span class="res-count">${label}</span><span class="res-label ${committed?'res-label-bonus':''}">${tileLabel}</span></div>`;
    }
    if (r.healingSeed > 0) {
      const canHeal = isReady && f.hp < f.maxHp;
      const click = canHeal ? `onclick="spendHealingSeed('${team}')"` : '';
      const seedTitle = canHeal
        ? `Healing Seed: click to heal 1 HP (${f.hp}/${f.maxHp})`
        : f.hp > f.maxHp
          ? `Healing Seed: HP is overclocked (${f.hp}/${f.maxHp}) — Seeds cannot heal above max HP`
          : f.hp === f.maxHp
            ? `Healing Seed: HP is already full (${f.hp}/${f.maxHp}) — can't use now`
            : `Healing Seed: heal 1 HP — only usable during your turn`;
      rh += `<div class="res-tile healingSeed ${canHeal?'clickable':''}" ${click} title="${seedTitle}"><span class="res-main">🌱</span><span class="res-count">${r.healingSeed}</span><span class="res-label">SEED</span></div>`;
    }
    if (r.luckyStone > 0) {
      rh += `<div class="res-tile luckyStone" title="Lucky Stone: use after rolling to reroll any one of your dice"><span class="res-main">🍀</span><span class="res-count">${r.luckyStone}</span><span class="res-label">LUCK</span></div>`;
    }
    // Magic Fireflies — clickable wildcard resource (pre-roll only)
    if (r.firefly > 0) {
      const ffClick = isReady ? `onclick="showFireflyPicker('${team}')"` : '';
      rh += `<div class="res-tile firefly ${isReady?'clickable':''}" ${ffClick} title="Magic Fireflies: ${r.firefly} available — click to convert to any resource"><span class="res-main">✨</span><span class="res-count">${r.firefly}</span><span class="res-label">FIREFLY</span></div>`;
    }
    // Burn resource pool — clickable to place on enemy sideline ghosts (pre-roll only)
    if (r.burn > 0) {
      const burnClick = isReady ? `onclick="showBurnPicker('${team}')"` : '';
      rh += `<div class="res-tile fire ${isReady?'clickable':''}" ${burnClick} title="Burn: ${r.burn} available — click to place on an enemy sideline ghost (deals damage on entry)"><span class="res-main">🔥</span><span class="res-count">${r.burn}</span><span class="res-label">BURN</span></div>`;
    }
    // Burn placed indicator removed — burn disappears when spent, no need to track visually
    // Happy Crystal (208) — sacrifice tile
    if (isReady && f.id === 208 && !f.ko) {
      rh += `<div class="res-tile moonstone clickable" onclick="sacrificeHappyCrystal('${team}')" title="Sacrifice for 1 Moonstone"><span class="res-main">💀</span><span class="res-label">Sac</span></div>`;
    }
    // Aunt Susan (309) — commit healing seeds for damage (click=add, right-click=remove)
    if (isReady && f.id === 309 && (r.healingSeed > 0 || c.auntSusan > 0)) {
      rh += `<div class="res-tile healingSeed clickable ${c.auntSusan>0?'committed':''}" onclick="toggleAuntSusan('${team}')" oncontextmenu="event.preventDefault();uncommitAuntSusan('${team}')" title="Click: +2 dmg per seed. Right-click: remove"><span class="res-main">🌱</span><span class="res-label">${c.auntSusan>0?'+'+c.auntSusan*2+'dmg':'+2dmg'}</span></div>`;
    }
    // Moonstone Sickness indicator
    {
      const msMode = document.getElementById('moonstoneModeSelect')?.value || 'D';
      const stacks = t.moonstoneSickness || 0;
      const pending = t.moonstoneSicknessPending || 0;
      if ((msMode === 'A' || msMode === 'D' || msMode === 'G') && stacks > 0) {
        const dmgPerTurn = msMode === 'A' ? stacks * 2 : stacks;
        rh += `<div class="res-tile" style="border-color:rgba(168,85,247,0.5);box-shadow:0 0 8px rgba(168,85,247,0.3);" title="Moonstone Sickness: ${dmgPerTurn} damage before every roll (${stacks} stack${stacks>1?'s':''})"><span class="res-main" style="font-size:16px;">🌑</span><span class="res-count" style="color:#a855f7;">${dmgPerTurn}</span><span class="res-label" style="color:#a855f7;">SICK×${stacks}</span></div>`;
      } else if ((msMode === 'B' || msMode === 'C') && pending > 0) {
        rh += `<div class="res-tile" style="border-color:rgba(168,85,247,0.5);box-shadow:0 0 8px rgba(168,85,247,0.3);" title="Moonstone Sickness: ${pending} damage before next roll"><span class="res-main" style="font-size:16px;">🌑</span><span class="res-count" style="color:#a855f7;">${pending}</span><span class="res-label" style="color:#a855f7;">NEXT</span></div>`;
      }
    }
    // Snapshot current resources for flash detection
    const newSnap = { moonstone:r.moonstone, ice:totalIce, fire:totalFire, surge:r.surge+c.surge, healingSeed:r.healingSeed, luckyStone:r.luckyStone, firefly:r.firefly||0 };
    const prev = prevResources[team] || {};
    document.getElementById(`${team}-resources`).innerHTML = rh;
    // Flash any resource tile that increased
    const resEl = document.getElementById(`${team}-resources`);
    ['moonstone','ice','fire','surge','healingSeed','luckyStone','firefly'].forEach(key => {
      if ((newSnap[key]||0) > (prev[key]||0)) {
        const tile = resEl.querySelector(`.res-tile.${key}`);
        if (tile) { tile.classList.remove('res-gained'); void tile.offsetWidth; tile.classList.add('res-gained'); }
      }
    });
    prevResources[team] = newSnap;

    // Persistent permanent effect badges
    const opp_team = team === 'red' ? 'blue' : 'red';
    let permHtml = '';
    if (B.haywireBonus && B.haywireBonus[team] > 0) permHtml += `<div class="permanent-buff">\u{1F3B5} +${B.haywireBonus[team]} Die (Wild Chords)</div>`;
    if (B.haywireDamageBonus && B.haywireDamageBonus[team] > 0) permHtml += `<div class="permanent-buff">\u{1F3B5} +${B.haywireDamageBonus[team]} Dmg (Wild Chords)</div>`;
    if (B.pipDieRemoval && B.pipDieRemoval[team] > 0) permHtml += `<div class="permanent-debuff">🍞 -${B.pipDieRemoval[team]} Die (Toasted)</div>`;
    if (B.carpenterHammer && B.carpenterHammer[team]) permHtml += `<div class="permanent-buff">🔨 Hammer: Singles hit +2 harder</div>`;
    if (B.welderTorch && B.welderTorch[team]) permHtml += `<div class="permanent-buff">💥 Torch: Wins give +1 Burn</div>`;
    if (permHtml) {
      const permRow = document.createElement('div');
      permRow.className = 'permanent-effects-row';
      permRow.innerHTML = permHtml;
      resEl.appendChild(permRow);
    }
  });

  document.getElementById('turnIndicator').textContent = '';
  const logWrap = document.getElementById('battleLog').parentElement;
  document.getElementById('battleLog').innerHTML = B.log.map(l=>`<div class="log-entry">${l}</div>`).join('');
  logWrap.scrollTop = 0;

  // Ability buttons (pre-roll actions)
  ['red','blue'].forEach(team => {
    const el = document.getElementById(`${team}-ability-buttons`);
    // Boss mode: skip blue ability buttons — boss doesn't get interactive buttons
    if (window.BOSS_MODE && team === 'blue') { el.innerHTML = ''; return; }
    const f = active(B[team]);
    const enemy = opp(B[team]);
    let html = '';
    if (isPreRollActive(team)) {
      // Dark Fang (202) — Pressure button (once per round)
      if (f.id === 202 && !f.ko && !dylanNegates(enemy) && !(B.pressureUsed && B.pressureUsed[team])) {
        const enemySideline = enemy.ghosts.filter((g,i) => i !== enemy.activeIdx && !g.ko);
        if (enemySideline.length > 0) {
          html += `<button class="ability-btn pressure" onclick="usePressure('${team}')">🔥 Pressure</button>`;
        }
      }
      // Tyson (365) — Hop: swap self to bench before rolling (no entry effects)
      if (f.id === 365 && !f.ko) {
        const aliveSl = B[team].ghosts.filter((g,i) => i !== B[team].activeIdx && !g.ko);
        if (aliveSl.length > 0) {
          const blocked = dylanNegates(enemy);
          html += `<button class="ability-btn ${blocked?'':'pressure'}" onclick="useTysonHop('${team}')" ${blocked?'disabled title="Blocked by Dylan"':''}>${blocked?'🚫':'🐰'} Hop${blocked?' (Blocked)':''}</button>`;
        }
      }
      // Harrison (315) — Ascend: spend seeds for extra dice (click=add, right-click=remove)
      if (f.id === 315 && !f.ko && (B[team].resources.healingSeed > 0 || B.committed[team].harrison > 0)) {
        const cnt = B.committed[team].harrison;
        html += `<button class="ability-btn ${cnt>0?'committed':'pressure'}" onclick="toggleHarrison('${team}')" oncontextmenu="event.preventDefault();uncommitHarrison('${team}')" style="${cnt>0?'border-color:#22c55e;box-shadow:0 0 8px rgba(34,197,113,0.4);':''}">🌱 Ascend${cnt>0?' (+'+cnt+' dice)':''}</button>`;
      }
      // Mable Stadango (446) — Hex: now passive (triggers in doBurnPlace), no button needed
      // Finn (204) — Flame Blade: forge button (2 Healing Seeds + 1 Sacred Fire) OR swing toggle if forged
      if (B[team].ghosts.some(g => g.id === 204 && !g.ko)) {
        if (!B.flameBlade || !B.flameBlade[team]) {
          const r = B[team].resources;
          const canForge = (r.healingSeed || 0) >= 1 && (r.fire || 0) >= 1;
          if (canForge) {
            html += `<button class="ability-btn pressure" onclick="useFinnFlameBlade('${team}')" title="Finn — forge the Flame Blade (2 Healing Seeds + 1 Sacred Fire)" style="border-color:#fb923c;color:#fb923c;">🔥 Forge Flame Blade (1🌱 + 1🔥)</button>`;
          } else {
            html += `<button class="ability-btn" disabled title="Need 2 Healing Seeds + 1 Sacred Fire" style="opacity:0.4;border-color:#fb923c;color:#fb923c;">🔥 Forge Flame Blade (1🌱 + 1🔥)</button>`;
          }
        }
      }
      // Flame Blade toggle (if forged — shown for any active ghost on the team)
      if (B.flameBlade && B.flameBlade[team]) {
        const fbSwung = B.flameBladeSwing && B.flameBladeSwing[team];
        html += `<button class="ability-btn ${fbSwung?'committed':'pressure'}" onclick="toggleFlameBlade('${team}')" title="${fbSwung?'Sheathing — click to stop swinging':'Swing the Flame Blade — +1 die to your roll AND +3 Burn if you win'}" style="border-color:#fb923c;color:${fbSwung?'#fff':'#fb923c'};${fbSwung?'background:linear-gradient(135deg,#b45309,#fb923c);':''}">🔥 ${fbSwung?'Flame Blade SWINGING (+1 die, +3 Burn on win)':'Swing Flame Blade'}</button>`;
      }
      // Zain (206) — Ice Blade: forge button (Sideline & In Play) OR swing toggle (any active ghost, if forged)
      const hasZainForForge = (f.id === 206 && !f.ko) || B[team].ghosts.some(g => g.id === 206 && !g.ko && B[team].ghosts.indexOf(g) !== B[team].activeIdx);
      if (hasZainForForge && !B.iceBladeForgedPermanent[team]) {
        const r = B[team].resources;
        const canForge = r.ice >= 1 && r.moonstone >= 1;
        if (canForge) {
          html += `<button class="ability-btn pressure" onclick="useZainForge('${team}')" title="Forge the Ice Blade — spend 1 Ice Shard + 1 Moonstone" style="border-color:#67e8f9;color:#67e8f9;">🗡️ Forge Ice Blade (1❄️ + 1💎)</button>`;
        } else {
          html += `<button class="ability-btn" disabled title="Need 1 Ice Shard + 1 Moonstone to forge" style="opacity:0.4;border-color:#67e8f9;color:#67e8f9;">🗡️ Forge Ice Blade (1❄️ + 1💎)</button>`;
        }
      }
      // Ice Blade toggle (if forged — shown for any active ghost on the team)
      if (B.iceBladeForgedPermanent && B.iceBladeForgedPermanent[team]) {
        const ibSwung = (B.iceBladeSwing && B.iceBladeSwing[team]) || (B.committed[team].zainBlade > 0);
        html += `<button class="ability-btn ${ibSwung?'committed':'pressure'}" onclick="toggleIceBlade('${team}')" title="${ibSwung?'Sheathing — click to stop swinging':'Swing the Ice Blade — +1 die to your roll AND +2 damage if you win'}" style="border-color:#67e8f9;color:${ibSwung?'#fff':'#67e8f9'};${ibSwung?'background:linear-gradient(135deg,#0e7490,#67e8f9);':''}">🗡️ ${ibSwung?'Ice Blade SWINGING (+1 die, +2 dmg on win)':'Swing Ice Blade'}</button>`;
      }
      // Sophia (457) — Mask toggle (shown for any active ghost on the team, if mask is owned)
      if (B.sophiaMask && B.sophiaMask[team]) {
        const maskType = B.sophiaMask[team];
        const maskOn = B.sophiaMaskActive[team];
        const maskIcon = maskType === 'day' ? '☀️' : '🌙';
        const maskName = maskType === 'day' ? 'Mask of Day' : 'Mask of Night';
        const maskEffect = maskType === 'day' ? 'Gain 1 Burn per 1 or 2 rolled' : 'Mirror enemy dice count, +1 dmg';
        const maskColor = maskType === 'day' ? '#ffd700' : '#6b7aff';
        const maskBg = maskType === 'day' ? 'background:linear-gradient(135deg,#b8860b,#ffd700);' : 'background:linear-gradient(135deg,#2a2a5a,#6b7aff);';
        html += `<button class="ability-btn ${maskOn?'committed':'pressure'}" onclick="toggleSophiaMask('${team}')" title="${maskOn?'Remove mask':'Wear mask — '+maskEffect}" style="border-color:${maskColor};color:${maskOn?'#fff':maskColor};${maskOn?maskBg:''}">${maskIcon} ${maskOn?maskName+' ON ('+maskEffect+')':'Wear '+maskName}</button>`;
      }
      // Carpenter (449) — no button needed; transforms when Surge is committed via cycleCommit
      // Smudge (403) — Blackout: name a number
      if (f.id === 403 && !f.ko) {
        html += `<div class="blackout-picker">
          <span class="blackout-label">Blackout:</span>
          ${[1,2,3,4,5,6].map(n =>
            `<button class="blackout-num ${B.blackoutNum && B.blackoutNum[team] === n ? 'active' : ''}" onclick="setBlackout('${team}', ${n})">${n}</button>`
          ).join('')}
        </div>`;
      }
      // Zork (463) — Stoke: pre-roll button to discard Burn for dice
      if (f.id === 463 && !f.ko && B.zorkDecided && !B.zorkDecided[team] &&
          B[team].resources && B[team].resources.burn >= 1) {
        html += `<button class="ability-btn pressure" onclick="useZorkStoke('${team}')" style="border-color:#f59e0b;color:#f59e0b;font-weight:bold;">🔥 SMOLDER! (${B[team].resources.burn} Burn → +${B[team].resources.burn} dice)</button>`;
      }
      // Miyoshi (454) — Bonzai!: pre-roll button to sacrifice HP for dice
      if (f.id === 454 && !f.ko && f.hp > 4 && B.bonzaiDecided && !B.bonzaiDecided[team]) {
        html += `<button class="ability-btn pressure" onclick="useBonzaiButton('${team}')" style="border-color:#dc2626;color:#dc2626;font-weight:bold;">⚡ BONZAI! (−4 HP, +5 dice)</button>`;
      }
      // Toby (97) — Pure Heart: pre-roll button to declare all-in
      if (f.id === 97 && !f.ko &&
          B.pureHeartDeclared && B.pureHeartDeclared[team] === null &&
          !(B.pureHeartScheduledKO && B.pureHeartScheduledKO[team])) {
        html += `<button class="ability-btn pressure" onclick="useTobyButton('${team}')" style="border-color:#7f1d1d;color:#7f1d1d;font-weight:bold;">💀 PURE HEART! (Final Roll)</button>`;
      }
      // Castle Gardener (442) — Cultivate: pre-roll button to trade seeds for fire
      if (f.id === 442 && !f.ko && B[team].resources && B[team].resources.healingSeed >= 1) {
        html += `<button class="ability-btn pressure" onclick="useCultivate('${team}')" style="border-color:#40916c;color:#40916c;font-weight:bold;">🌱 CULTIVATE! (1 Seed → 2 Sacred Fire)</button>`;
      }
      // No voluntary swap — swapping only happens via abilities (Tyson Hop, Pressure) or KO
    }
    el.innerHTML = html;
  });

  // Raid boss HP bar: track cumulative damage to blue team (exclude padded ghosts)
  if (RAID_MODE && RAID_PARAMS && B.blue) {
    let totalBlueDamage = 0;
    const realCount = RAID_PARAMS.realBossGhostCount || B.blue.ghosts.length;
    for (let i = 0; i < realCount; i++) {
      const g = B.blue.ghosts[i];
      if (g) totalBlueDamage += g.maxHp - Math.max(0, g.ko ? 0 : g.hp);
    }
    RAID_PARAMS.bossHp = Math.max(0, RAID_PARAMS.bossMaxHp - totalBlueDamage);
    updateRaidBossBar();

    // Write battle snapshot to Firebase for spectators (throttled to every 2s)
    if (RAID_PARAMS.instanceId && db) {
      const now = Date.now();
      if (!window._lastRaidSnapshot || now - window._lastRaidSnapshot > 2000) {
        window._lastRaidSnapshot = now;
        const redActive = active(B.red);
        const blueActive = active(B.blue);
        const snapshot = {
          playerName: MP_PLAYER_NAMES.red || 'Raider',
          playerGhost: { name: redActive.name, hp: redActive.hp, maxHp: redActive.maxHp, art: redActive.art || '' },
          bossGhost: { name: blueActive.name, hp: blueActive.hp, maxHp: blueActive.maxHp, art: blueActive.art || '', isBoss: true },
          playerSideline: B.red.ghosts.filter((_, i) => i !== B.red.activeIdx).map(g => ({ name: g.name, hp: g.hp, maxHp: g.maxHp, ko: g.ko })),
          bossSideline: B.blue.ghosts.filter((_, i) => i !== B.blue.activeIdx).slice(0, realCount - 1).map(g => ({ name: g.name, hp: g.hp, maxHp: g.maxHp, ko: g.ko })),
          bossPoolHp: RAID_PARAMS.bossHp,
          bossMaxHp: RAID_PARAMS.bossMaxHp,
          round: B.round || 1,
          phase: B.phase || 'roll',
          lastRoll: window._lastRaidRollData || null,
          abilityCallout: window._lastRaidAbilityCallout || null,
          updatedAt: firebase.database.ServerValue.TIMESTAMP
        };
        db.ref(`mp/raids/instances/${RAID_PARAMS.instanceId}/battleState`).set(snapshot);
      }
    }
  }
}

/* ═══════ 3D Dice Physics Helpers ═══════ */
const PIP_LAYOUTS = {
  1: ['c'],
  2: ['tr','bl'],
  3: ['tr','c','bl'],
  4: ['tl','tr','bl','br'],
  5: ['tl','tr','c','bl','br'],
  6: ['tl','ml','bl','tr','mr','br']
};
const PIP_STYLES = {
  tl:'top:18%;left:18%', tr:'top:18%;right:18%',
  ml:'top:50%;left:18%;transform:translateY(-50%)',
  c:'top:50%;left:50%;transform:translate(-50%,-50%)',
  mr:'top:50%;right:18%;transform:translateY(-50%)',
  bl:'bottom:18%;left:18%', br:'bottom:18%;right:18%'
};
function pip3dHTML(val) {
  return (PIP_LAYOUTS[val]||PIP_LAYOUTS[1]).map(p=>`<span class="pip3d" style="${PIP_STYLES[p]}"></span>`).join('');
}
function cube3dHTML(team) {
  const c='face-'+team;
  // front=1, right=2, top=3, bottom=4, left=5, back=6
  return [
    ['front',1],['back',6],['right',2],['left',5],['top',3],['bottom',4]
  ].map(([f,v])=>`<div class="die-face ${c} face-${f}">${pip3dHTML(v)}</div>`).join('');
}
const FACE_TARGET = {
  1:{rx:0,ry:0}, 2:{rx:0,ry:-90}, 3:{rx:90,ry:0},
  4:{rx:-90,ry:0}, 5:{rx:0,ry:90}, 6:{rx:0,ry:180}
};
function nearestSnap(cur,tgt){const n=Math.round((cur-tgt)/360);return tgt+n*360;}
let _dicePhysics = {};

/* ═══════ Throw Profiles — choreographed dice paths ═══════ */
// Each profile generates per-die {vx, vy} based on die index and count.
// Red throws right+up from bottom-left; Blue throws left+up from bottom-right.
const THROW_PROFILES = [
  // THE BLOOM — dice unfurl like petals: steep arc, wide sweep, low curl
  (i, n) => {
    const t = n > 1 ? i / (n - 1) : 0.5;
    return { vx: 13 + t * 15, vy: -(25 - t * 20) };
  },
  // THE BANK SHOT — all hit the top wall, spread horizontally
  (i, n) => {
    const t = n > 1 ? i / (n - 1) : 0.5;
    return { vx: 10 + t * 14, vy: -(20 + t * 4) };
  },
  // THE CROSS-TABLE — full send to the far wall
  (i, n) => {
    const t = n > 1 ? i / (n - 1) : 0.5;
    return { vx: 24 + t * 6, vy: -(8 + t * 10) };
  },
  // THE SPIRAL — widest orbit to tightest drop
  (i, n) => {
    const t = n > 1 ? i / (n - 1) : 0.5;
    return { vx: 28 - t * 18, vy: -(10 + t * 12) };
  },
  // THE SCATTER — each die at a very different angle
  (i, n) => {
    const angles = [0.15, 0.55, 0.85, 0.35, 0.7]; // spread across quadrants
    const a = angles[i % angles.length];
    return { vx: 14 + a * 14, vy: -(6 + (1 - a) * 20) };
  },
  // THE GENTLE TOSS — short lob, barely leaves the hand
  (i, n) => {
    const t = n > 1 ? i / (n - 1) : 0.5;
    return { vx: 7 + t * 5, vy: -(9 + t * 3) };
  },
];

function pickThrowProfile(count) {
  const profile = THROW_PROFILES[Math.floor(Math.random() * THROW_PROFILES.length)];
  const noise = () => 1 + (Math.random() - 0.5) * 0.25; // ±12.5% variation
  return Array.from({ length: count }, (_, i) => {
    const v = profile(i, count);
    // 15% velocity boost for more energetic throws
    return { vx: v.vx * noise() * 1.15, vy: v.vy * noise() * 1.15 };
  });
}

function update3dDice(team, values) {
  const physics = _dicePhysics[team];
  if (!physics || !physics.dice) return;
  physics.values = values;
  values.forEach((v, i) => {
    const d = physics.dice[i];
    if (!d || d.value === v) return; // no change
    d.value = v;
    // Clear any highlight classes
    d.el.classList.remove('highlight-single', 'highlight-double', 'highlight-triple',
      'die-win-singles-3d', 'die-win-doubles-3d', 'die-win-triples-3d', 'die-win-mega-3d',
      'die-win-secondary-3d', 'die-loser-3d', 'triples-glow-3d');
    // Smoothly rotate to new face
    const tgt = FACE_TARGET[v];
    d.rx = nearestSnap(d.rx, tgt.rx);
    d.ry = nearestSnap(d.ry, tgt.ry);
    d.el.classList.add('value-update');
    d.cube.style.transform = `rotateX(${d.rx}deg) rotateY(${d.ry}deg) rotateZ(${d.rz}deg)`;
    setTimeout(() => d.el.classList.remove('value-update'), 450);
  });
}

// Flat die HTML with pip dots (used when no 3D dice exist)
function flatDieHTML(val, team) {
  const face = team === 'red' ? 'face-red' : 'face-blue';
  if (val === '?' || val === 0 || !val) return `<div class="die die-${team}">?</div>`;
  return `<div class="die die-${team}"><div style="position:relative;width:100%;height:100%;" class="${face}">${pip3dHTML(val)}</div></div>`;
}

function renderDice(rd, bd) {
  const redEl = document.getElementById('red-dice');
  const blueEl = document.getElementById('blue-dice');
  if (!rd && !bd) {
    // Reset — also clean up any lingering 3D dice
    ['red', 'blue'].forEach(t => {
      if (_dicePhysics[t]) {
        cancelAnimationFrame(_dicePhysics[t].raf);
        _dicePhysics[t].els.forEach(e => e.remove());
        delete _dicePhysics[t];
      }
    });
    redEl.innerHTML = [0,0,0].map(()=>`<div class="die die-red">?</div>`).join('');
    blueEl.innerHTML = [0,0,0].map(()=>`<div class="die die-blue">?</div>`).join('');
  } else {
    if (rd) {
      const rdPh = _dicePhysics['red'];
      if (rdPh && rd.length === rdPh.dice.length) {
        // 3D dice exist with matching count — update them (works during settling too)
        if (rdPh.settled) update3dDice('red', rd);
        const flatRed = redEl.querySelectorAll('.die');
        rd.forEach((v, i) => { if (flatRed[i]) flatRed[i].innerHTML = `<div style="position:relative;width:100%;height:100%;" class="face-red">${pip3dHTML(v)}</div>`; });
      } else if (rdPh && rd.length !== rdPh.dice.length) {
        cancelAnimationFrame(rdPh.raf); rdPh.els.forEach(e => e.remove()); delete _dicePhysics['red'];
        redEl.innerHTML = rd.map(d => flatDieHTML(d, 'red')).join('');
      } else {
        redEl.innerHTML = rd.map(d => flatDieHTML(d, 'red')).join('');
      }
    }
    if (bd) {
      const bdPh = _dicePhysics['blue'];
      if (bdPh && bd.length === bdPh.dice.length) {
        if (bdPh.settled) update3dDice('blue', bd);
        const flatBlue = blueEl.querySelectorAll('.die');
        bd.forEach((v, i) => { if (flatBlue[i]) flatBlue[i].innerHTML = `<div style="position:relative;width:100%;height:100%;" class="face-blue">${pip3dHTML(v)}</div>`; });
      } else if (bdPh && bd.length !== bdPh.dice.length) {
        cancelAnimationFrame(bdPh.raf); bdPh.els.forEach(e => e.remove()); delete _dicePhysics['blue'];
        blueEl.innerHTML = bd.map(d => flatDieHTML(d, 'blue')).join('');
      } else {
        blueEl.innerHTML = bd.map(d => flatDieHTML(d, 'blue')).join('');
      }
    }
  }
}

// Show rolling animation — 3D physics dice bouncing across the arena
function showRolling(team, count) {
  const el = document.getElementById(team + '-dice');
  const cls = 'die-' + team;
  // Hidden placeholder dice for layout (keeps tray height stable)
  el.innerHTML = Array(count).fill(0).map((_, i) =>
    `<div class="die ${cls}" id="${team}-die-${i}" style="visibility:hidden">?</div>`
  ).join('');
  if (count === 0) return;

  // Roll dice across the full arena board
  const board = document.querySelector('.arena-board');
  const boardRect = board.getBoundingClientRect();
  const W = boardRect.width;
  const H = boardRect.height;
  const dieSize = window.innerWidth <= 600 ? 42 : 56;
  const half = dieSize / 2;
  const pad = 16; // board padding
  const minX = pad, maxX = W - pad - dieSize;
  const minY = pad, maxY = H - pad - dieSize;

  // Clean up previous physics for this team
  if (_dicePhysics[team]) {
    cancelAnimationFrame(_dicePhysics[team].raf);
    _dicePhysics[team].els.forEach(e => e.remove());
  }

  const dice = [];
  const els = [];
  const isRed = team === 'red';
  const handX = isRed ? minX + 10 : maxX - 10;
  const handY = maxY - 5;
  const throwVecs = pickThrowProfile(count);

  for (let i = 0; i < count; i++) {
    const die = document.createElement('div');
    die.className = 'die-physics';
    die.style.width = dieSize + 'px';
    die.style.height = dieSize + 'px';
    die.style.zIndex = '100'; // above cards during rolling
    die.style.setProperty('--dh', half + 'px');
    die.innerHTML = `<div class="die-cube">${cube3dHTML(team)}</div>`;
    board.appendChild(die);
    els.push(die);

    // Beautiful choreographed throw from team's corner
    const tv = throwVecs[i];
    dice.push({
      el: die, cube: die.querySelector('.die-cube'),
      x: handX + (Math.random() - 0.5) * 6, y: handY + (Math.random() - 0.5) * 6,
      vx: (isRed ? 1 : -1) * tv.vx,
      vy: tv.vy,
      rx: Math.random() * 720, ry: Math.random() * 720, rz: Math.random() * 360,
      vrx: (Math.random() - 0.5) * 55,   // cranked tumble
      vry: (Math.random() - 0.5) * 55,
      vrz: (Math.random() - 0.5) * 40,
      bounceCount: 0  // tracks wall hits for decaying bounce coefficient
    });
  }

  // Per-die decaying bounce: starts at 0.65, each hit multiplies by 0.8, floor at 0.3
  function getBounceCoeff(d) {
    return Math.max(0.3, 0.65 * Math.pow(0.8, d.bounceCount));
  }
  // Speed-dependent surface friction — fast dice slide, slow dice stick
  function getSurfaceFriction(speed) {
    if (speed > 8) return 0.982;   // fast: ice-smooth
    if (speed > 3) return 0.965;   // medium: felt drag
    return 0.935;                   // slow: table grip, dice stop decisively
  }
  // Speed-dependent rotation friction
  function getRotFriction(speed) {
    if (speed > 8) return 0.972;
    if (speed > 3) return 0.950;
    return 0.920;                   // slow: rotation dies fast
  }

  function step() {
    // Dice-to-dice repulsion (prevents stacking)
    for (let a = 0; a < dice.length; a++) {
      for (let b = a + 1; b < dice.length; b++) {
        const da = dice[a], db = dice[b];
        const dx = da.x - db.x, dy = da.y - db.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < dieSize && dist > 0.1) {
          const push = (dieSize - dist) * 0.15;
          const nx = dx / dist, ny = dy / dist;
          da.vx += nx * push; da.vy += ny * push;
          db.vx -= nx * push; db.vy -= ny * push;
        }
      }
    }
    dice.forEach(d => {
      d.x += d.vx; d.y += d.vy;
      d.rx += d.vrx; d.ry += d.vry; d.rz += d.vrz;
      const speed = Math.abs(d.vx) + Math.abs(d.vy);

      // Wall bounces — decaying coefficient + rotation spike on impact
      const bc = getBounceCoeff(d);
      if (d.x < minX) {
        d.x = minX; d.vx = Math.abs(d.vx) * bc;
        d.vry *= 1.4; d.vrz *= 1.3; // wall clatter — spin spikes on impact
        d.bounceCount++;
      }
      if (d.x > maxX) {
        d.x = maxX; d.vx = -Math.abs(d.vx) * bc;
        d.vry *= 1.4; d.vrz *= 1.3;
        d.bounceCount++;
      }
      if (d.y < minY) {
        d.y = minY; d.vy = Math.abs(d.vy) * bc;
        d.vrx *= 1.4; d.vrz *= 1.3;
        d.bounceCount++;
      }
      if (d.y > maxY) {
        d.y = maxY; d.vy = -Math.abs(d.vy) * bc;
        d.vrx *= 1.4; d.vrz *= 1.3;
        d.bounceCount++;
      }

      // Speed-dependent surface friction
      const fric = getSurfaceFriction(speed);
      const rFric = getRotFriction(speed);
      d.vx *= fric; d.vy *= fric;
      d.vrx *= rFric; d.vry *= rFric; d.vrz *= rFric;

      // Rotation homing — as dice slow down, settle onto nearest face (like gravity)
      if (speed < 6) {
        const strength = 0.08 * (1 - speed / 6);
        d.rx += (Math.round(d.rx / 90) * 90 - d.rx) * strength;
        d.ry += (Math.round(d.ry / 90) * 90 - d.ry) * strength;
        d.rz += (Math.round(d.rz / 90) * 90 - d.rz) * strength;
      }
      // Render
      d.el.style.left = d.x + 'px';
      d.el.style.top = d.y + 'px';
      d.cube.style.transform = `rotateX(${d.rx}deg) rotateY(${d.ry}deg) rotateZ(${d.rz}deg)`;
    });
    _dicePhysics[team].raf = requestAnimationFrame(step);
  }

  _dicePhysics[team] = { raf: requestAnimationFrame(step), dice, els };
}

// Reveal dice values — settle 3D dice to final positions, then swap to flat dice
function revealDice(team, values) {
  const physics = _dicePhysics[team];

  if (!physics || !physics.dice.length) {
    // Fallback for 0 dice or missing physics
    const cls = 'die-' + team;
    values.forEach((v, i) => {
      setTimeout(() => {
        const d = document.getElementById(team + '-die-' + i);
        if (d) { d.classList.remove('rolling'); d.textContent = v; d.style.visibility = 'visible'; }
      }, i * spd(300));
    });
    setTimeout(() => highlightRollPreview(team, values), values.length * spd(300) + 50);
    return;
  }

  // Stop physics loop
  cancelAnimationFrame(physics.raf);

  // Calculate tray position within the arena board
  const board = document.querySelector('.arena-board');
  const boardRect = board.getBoundingClientRect();
  const stack = document.querySelector('.dice-stack');
  const stackRect = stack.getBoundingClientRect();
  const offsetX = stackRect.left - boardRect.left;
  const offsetY = stackRect.top - boardRect.top;
  const stackW = stackRect.width;
  const dieSize = window.innerWidth <= 600 ? 42 : 56;
  const gap = window.innerWidth <= 600 ? 10 : 20;
  const rowGap = window.innerWidth <= 600 ? 8 : 18;

  // Center dice in the tray with proper spacing
  const totalDiceW = values.length * dieSize + (values.length - 1) * gap;
  const trayStartX = offsetX + (stackW - totalDiceW) / 2;
  const trayMidY = offsetY + stackRect.height / 2;

  // Settle: rotation snaps to correct face (0.35s) while position flies to tray (0.7s).
  values.forEach((v, i) => {
    const d = physics.dice[i];
    if (!d) return;

    // Target position — centered in tray, red on top row, blue on bottom
    const tx = trayStartX + i * (dieSize + gap);
    const ty = team === 'red'
      ? trayMidY - dieSize - rowGap / 2
      : trayMidY + rowGap / 2;

    // Target rotation for the correct face value
    const tgt = FACE_TARGET[v];
    const frx = nearestSnap(d.rx, tgt.rx);
    const fry = nearestSnap(d.ry, tgt.ry);
    const frz = nearestSnap(d.rz, 0);
    d.rx = frx; d.ry = fry; d.rz = frz;
    d.value = v;

    // Stagger each die slightly for a natural feel
    setTimeout(() => {
      d.el.classList.add('settling');
      d.el.style.left = tx + 'px';
      d.el.style.top = ty + 'px';
      d.cube.style.transform = `rotateX(${frx}deg) rotateY(${fry}deg) rotateZ(${frz}deg)`;
    }, i * spd(80));
  });

  // After all dice reach the tray
  const settleDelay = values.length * spd(80) + spd(750);
  setTimeout(() => {
    physics.settled = true;
    physics.values = values;
    physics.els.forEach(e => e.style.zIndex = '10');
    values.forEach((v, i) => {
      const d = document.getElementById(team + '-die-' + i);
      if (d) d.textContent = v;
    });
    highlightRollPreview(team, values);
  }, settleDelay);
}

function highlightRollPreview(team, dice) {
  const roll = classify(dice);
  if (roll.type === 'none') return;

  const physics = _dicePhysics[team];
  if (physics && physics.settled) {
    // Highlight 3D dice
    const diceObjs = physics.dice;
    if (roll.type === 'singles') {
      let done = false;
      [...diceObjs].reverse().forEach(d => {
        if (!done && d.value === roll.value) {
          d.el.classList.add('highlight-single');
          done = true;
        }
      });
    } else if (roll.type === 'doubles') {
      let count = 0;
      diceObjs.forEach(d => {
        if (count < 2 && d.value === roll.value) {
          d.el.classList.add('highlight-double');
          count++;
        }
      });
    } else {
      diceObjs.forEach(d => {
        if (d.value === roll.value) {
          d.el.classList.add('highlight-triple');
        }
      });
    }
  } else {
    // Fallback: highlight flat dice
    const diceEl = document.getElementById(team + '-dice');
    if (!diceEl) return;
    const dieDivs = [...diceEl.querySelectorAll('.die')];
    if (roll.type === 'singles') {
      let done = false;
      [...dieDivs].reverse().forEach(d => {
        if (!done && parseInt(d.textContent) === roll.value) {
          d.style.transform = 'scale(1.12)';
          d.style.transition = 'transform 0.3s';
          done = true;
        }
      });
    } else if (roll.type === 'doubles') {
      let count = 0;
      dieDivs.forEach(d => {
        if (count < 2 && parseInt(d.textContent) === roll.value) {
          d.style.transform = 'scale(1.15)';
          d.style.boxShadow = '0 0 14px rgba(251,191,36,0.5)';
          d.style.borderColor = '#fbbf24';
          d.style.transition = 'all 0.3s';
          count++;
        }
      });
    } else {
      dieDivs.forEach(d => {
        if (parseInt(d.textContent) === roll.value) {
          d.style.transform = 'scale(1.2)';
          d.style.boxShadow = '0 0 20px rgba(251,191,36,0.7)';
          d.style.borderColor = '#fbbf24';
          d.style.transition = 'all 0.3s';
        }
      });
    }
  }
}

function clearAllOverlays() {
  document.getElementById('gameOver').classList.remove('active');
  document.getElementById('swapOverlay').classList.remove('active');
  document.getElementById('msPicker').classList.remove('active');
  clearLsCountdown();
  document.getElementById('stealOverlay').classList.remove('active');
  document.getElementById('pressureOverlay').classList.remove('active');
  document.getElementById('seleneOverlay').classList.remove('active');
  document.getElementById('timberOverlay').classList.remove('active');
  document.getElementById('romyOverlay').classList.remove('active');
  document.getElementById('tobyOverlay').classList.remove('active');
  document.getElementById('gfWishBtn').style.display = 'none';
  if (gfWishTimer) { clearInterval(gfWishTimer); gfWishTimer = null; }
  document.getElementById('tylerOverlay').classList.remove('active');
  document.getElementById('eloiseOverlay').classList.remove('active');
  document.getElementById('booOverlay').classList.remove('active');
  document.getElementById('bogeyOverlay').classList.remove('active');
  document.getElementById('gusGaleBtn').style.display = 'none';
  if (gusGaleTimer) { clearInterval(gusGaleTimer); gusGaleTimer = null; }
  document.getElementById('mallowOverlay').classList.remove('active');
  document.getElementById('jacksonOverlay').classList.remove('active');
  document.getElementById('jeanieOverlay').classList.remove('active');
  document.getElementById('sonyaOverlay').classList.remove('active');
  document.getElementById('darkWingOverlay').classList.remove('active');
  document.getElementById('raditzHuntOverlay').classList.remove('active');
  document.getElementById('dougCautionOverlay').classList.remove('active');
  document.getElementById('tobogganOverlay').classList.remove('active');
  document.getElementById('fangOutsideOverlay').classList.remove('active');
  document.getElementById('fangUndercoverArmOverlay').classList.remove('active');
  document.getElementById('fangUndercoverSwapOverlay').classList.remove('active');
  document.getElementById('winstonSchemeOverlay').classList.remove('active');
  document.getElementById('catchyTuneOverlay').classList.remove('active');
  document.getElementById('tysonHopOverlay').classList.remove('active');
  document.getElementById('galeForcePickerOverlay').classList.remove('active');
  document.getElementById('wiseAlOverlay').classList.remove('active');
  document.getElementById('gordokOverlay').classList.remove('active');
  document.getElementById('standingsOverlay').classList.remove('active');
  document.getElementById('cultivateOverlay').classList.remove('active');
  document.getElementById('chowOverlay').classList.remove('active');
  document.getElementById('hexOverlay').classList.remove('active');
  document.getElementById('nickKnackOverlay').classList.remove('active');
  document.getElementById('jasperOverlay').classList.remove('active');
  document.getElementById('jenkinsOverlay').classList.remove('active');
  document.getElementById('balatronOverlay').classList.remove('active');
  document.getElementById('tommyOverlay').classList.remove('active');
  document.getElementById('sylviaOverlay').classList.remove('active');
  document.getElementById('burnOverlay').classList.remove('active');
  document.getElementById('fireflyOverlay').classList.remove('active');
  document.getElementById('abilitySplash').classList.remove('active');
  const vsSplash = document.getElementById('vsSplash');
  if (vsSplash) vsSplash.classList.remove('active');
  clearTimeout(afkTimer);
}

function resetBattle() {
  stopMusicHard();
  const skipBtn = document.getElementById('skipSpecialsBtn');
  if (skipBtn) skipBtn.style.display = 'none';
  B = null; S.battle = null;
  S.redPicks = []; S.bluePicks = [];
  abilityQueue = [];
  abilityQueueMode = false;
  clearAllOverlays();
  document.getElementById('battle-view').style.display = 'none';
  document.getElementById('team-select').style.display = 'block';
  document.querySelector('.app').classList.remove('battle-active');
  resetRollButtons();
  narrate('');
  renderDice(null, null);
  renderPicks();
}

function rematchBattle() {
  stopMusicHard();
  const redIds = S.redPicks.slice();
  const blueIds = S.bluePicks.slice();
  B = null; S.battle = null;
  abilityQueue = [];
  abilityQueueMode = false;
  clearAllOverlays();
  resetRollButtons();
  narrate('');
  renderDice(null, null);
  // Restore picks and start fresh battle
  S.redPicks = redIds;
  S.bluePicks = blueIds;
  startBattle();
}

// ============================================================
// KEYBOARD SHORTCUTS
// ============================================================
document.addEventListener('keydown', e => {
  // Enter or Space on game-over screen → rematch (or redirect in MP mode)
  if ((e.key === 'Enter' || e.key === ' ') && document.getElementById('gameOver').classList.contains('active')) {
    e.preventDefault();
    if (MP_MODE) {
      // Determine result and redirect
      const winner = B && B.phase === 'over' ? (document.getElementById('goTitle').className.includes('red') ? 'red' : document.getElementById('goTitle').className.includes('blue') ? 'blue' : 'draw') : 'draw';
      const result = winner === 'red' ? 'win' : (winner === 'blue' ? 'loss' : 'draw');
      const returnUrl = MP_DAILY
        ? '../multiplayer/?dailyResult=' + result
        : '../multiplayer/?result=' + result;
      window.location.href = returnUrl;
    } else {
      rematchBattle();
    }
    return;
  }
  // Escape closes any open overlay/modal.
  // pressureOverlay is intentionally excluded — the Pressure pick is a FORCED choice
  // for the opponent; allowing Escape to dismiss it would bypass pressureUsed and let
  // Dark Fang spam Pressure every round. The modal only closes via doPressureSwap().
  if (e.key === 'Escape') {
    // In MP mode, don't allow Escape to close gameOver (must use Return to Arena button)
    const overlays = ['swapOverlay','msPicker','stealOverlay','standingsOverlay'];
    if (!MP_MODE) overlays.push('gameOver');
    overlays.forEach(id => document.getElementById(id)?.classList.remove('active'));
  }
});

// ============================================================
// MULTIPLAYER MODE — URL param handler
// ============================================================
// When loaded with ?red=ID,ID,ID&mode=mp, auto-set teams and start battle.
// Player controls both sides. On game end, redirect back to multiplayer page.
// MP_MODE declared earlier (near TESTROOM_VERSION) so keyboard shortcuts can reference it.

(function checkMultiplayerParams() {
  const params = new URLSearchParams(window.location.search);
  const mode = params.get('mode');
  if (mode !== 'mp' && mode !== 'daily' && mode !== 'champion') return;
  if (mode === 'daily') MP_DAILY = true;

  const redParam = params.get('red');
  if (!redParam) return;

  const redIds = redParam.split(',').map(Number).filter(id => ghostData(id));
  if (redIds.length !== 3) return;

  MP_MODE = true;

  // Force standard settings for all MP/daily games
  const speedEl = document.getElementById('speedSlider');
  if (speedEl) speedEl.value = 0; // 1x speed
  const hlCheck = document.getElementById('handLimitCheckbox');
  if (hlCheck) hlCheck.checked = true; // hand limit ON
  const hlSlider = document.getElementById('handLimitSlider');
  if (hlSlider) hlSlider.value = 4; // limit of 4
  const stSlider = document.getElementById('specialsTimerSlider');
  if (stSlider) stSlider.value = 8; // v731: 8 second timer (was 5 — too rushed)

  // Set red team from URL params (player's team)
  S.redPicks = redIds;

  // For daily mode, use blue team from URL; for mp mode, pick curated team
  const blueParam = params.get('blue');
  if (blueParam) {
    const blueIds = blueParam.split(',').map(Number).filter(id => ghostData(id));
    if (blueIds.length === 3) {
      S.bluePicks = blueIds;
    } else {
      S.bluePicks = getCuratedTeam(redIds);
    }
  } else {
    S.bluePicks = getCuratedTeam(redIds);
  }

  // Show opponent name/elo if provided (async PvP)
  const oppName = params.get('oppName');
  const oppElo = params.get('oppElo');
  MP_PLAYER_NAMES.red = 'You';
  if (oppName) {
    MP_PLAYER_NAMES.blue = decodeURIComponent(oppName);
    const blueTitle = document.querySelector('.roster-title.blue');
    if (blueTitle) {
      blueTitle.innerHTML = `<span class="roster-dot"></span> ${MP_PLAYER_NAMES.blue} <span style="font-size:0.7em;color:var(--text2)">(${oppElo || '?'} Elo)</span>`;
    }
  }

  // Switch to arena tab and auto-start battle
  setTimeout(() => {
    switchTab('battle');
    renderPicks();
    startBattle();
    // Start blue AI for async/daily modes (not live PvP — that's a real player)
    if (!LIVE_PVP) startBlueAI();
  }, 300);
})();

// ============================================================
// RAID MODE — Boss fights with cinematic testroom experience
// URL: ?mode=raid&red=id,id,id&blue=bossId,minionId,minionId
//      &raidId=...&instanceId=...&slot=...&bossHp=...&bossMaxHp=...&bossName=...&personality=...
// ============================================================
(function checkRaidParams() {
  // Check URL first, then sessionStorage (survives cache-bust reload)
  let params = new URLSearchParams(window.location.search);
  if (params.get('mode') !== 'raid') {
    const saved = sessionStorage.getItem('_raidParams');
    if (saved) {
      params = new URLSearchParams(saved);
      sessionStorage.removeItem('_raidParams');
    }
  }
  if (params.get('mode') !== 'raid') return;
  if (window._raidParamsProcessed) return;
  window._raidParamsProcessed = true;

  // Clean URL & session immediately so refresh doesn't re-trigger
  window.history.replaceState({}, '', window.location.pathname);
  sessionStorage.removeItem('_raidParams');

  const redParam = params.get('red');
  const blueParam = params.get('blue');
  if (!redParam || !blueParam) return;

  // Parse red team (player's ghosts — must be valid)
  const redIds = redParam.split(',').map(Number).filter(id => ghostData(id));
  if (redIds.length !== 3) return;

  // Parse blue team (boss + minions — may not be in GHOSTS array)
  const blueIds = blueParam.split(',').map(Number);

  // Register boss ghosts in the GHOSTS lookup so the battle engine can find them
  // Boss ghost data is passed via URL as a JSON blob in the 'bossData' param
  const bossDataParam = params.get('bossData');
  if (bossDataParam) {
    try {
      const bossGhosts = JSON.parse(decodeURIComponent(bossDataParam));
      bossGhosts.forEach(bg => {
        const existingIdx = GHOSTS.findIndex(g => g.id === bg.id);
        if (existingIdx >= 0) {
          // Override maxHp for boss version of existing ghost (keeps all ability handlers)
          GHOSTS[existingIdx] = { ...GHOSTS[existingIdx], maxHp: bg.maxHp };
        } else {
          GHOSTS.push({
            id: bg.id, name: bg.name, maxHp: bg.maxHp, art: bg.art || '',
            ability: bg.ability || 'Boss', abilityDesc: bg.abilityDesc || '',
            rarity: bg.rarity || 'legendary', set: 'Raid Boss'
          });
        }
      });
    } catch (e) { console.warn('[RAID] Failed to parse bossData:', e); }
  }

  // Verify all blue IDs are now findable
  const validBlue = blueIds.filter(id => ghostData(id));
  if (validBlue.length === 0) { console.error('[RAID] No valid blue team ghosts'); return; }
  // Track how many real boss ghosts there are (before padding)
  const realBossGhostCount = validBlue.length;
  // Pad to 3 for engine compatibility — padded ghosts will be auto-KO'd after battle starts
  while (validBlue.length < 3) validBlue.push(validBlue[0]);

  // Set raid state
  RAID_MODE = true;
  MP_MODE = true; // reuse MP infrastructure (hide team select, auto-start, etc.)

  RAID_PARAMS = {
    raidId: params.get('raidId') || '',
    instanceId: params.get('instanceId') || '',
    slot: parseInt(params.get('slot') || '0'),
    bossHp: parseInt(params.get('bossHp') || '50'),
    bossMaxHp: parseInt(params.get('bossMaxHp') || '50'),
    bossName: decodeURIComponent(params.get('bossName') || 'Boss'),
    personality: params.get('personality') || 'tyrant',
    totalDamageDealt: 0,
    realBossGhostCount: realBossGhostCount
  };

  // Set teams
  S.redPicks = redIds;
  S.bluePicks = validBlue;

  // Force standard settings
  const speedEl = document.getElementById('speedSlider');
  if (speedEl) speedEl.value = 2; // Faster pace for raids
  const hlCheck = document.getElementById('handLimitCheckbox');
  if (hlCheck) hlCheck.checked = true;
  const hlSlider = document.getElementById('handLimitSlider');
  if (hlSlider) hlSlider.value = 4;
  const stSlider = document.getElementById('specialsTimerSlider');
  if (stSlider) stSlider.value = 8;

  // Set player names
  MP_PLAYER_NAMES.red = 'You';
  MP_PLAYER_NAMES.blue = RAID_PARAMS.bossName;

  // Show boss HP bar
  const bossBar = document.getElementById('raid-boss-bar');
  if (bossBar) {
    bossBar.style.display = 'block';
    document.getElementById('raid-boss-bar-name').textContent = RAID_PARAMS.bossName;
    document.getElementById('raid-boss-bar-text').textContent = `${RAID_PARAMS.bossHp} / ${RAID_PARAMS.bossMaxHp}`;
    document.getElementById('raid-boss-bar-fill').style.width = '100%';
    updateRaidBossBar();
    // Push the arena down to make room for the bar
    document.querySelector('.app').style.paddingTop = '56px';
  }

  // Switch to arena tab and auto-start
  setTimeout(() => {
    switchTab('battle');
    renderPicks();
    startBattle();
    // Mark padded ghost slots as empty placeholders — not real KOs
    if (B && B.blue && realBossGhostCount < 3) {
      for (let i = realBossGhostCount; i < B.blue.ghosts.length; i++) {
        B.blue.ghosts[i].hp = 0;
        B.blue.ghosts[i].ko = true;
        B.blue.ghosts[i].isPadded = true; // flag: not a real ghost, exclude from KO counts
      }
      renderBattle();
    }
    startBlueAI();
  }, 300);
})();

// Raid boss bar update — called after each damage event
function updateRaidBossBar() {
  if (!RAID_MODE || !RAID_PARAMS) return;
  const pct = Math.max(0, RAID_PARAMS.bossHp / RAID_PARAMS.bossMaxHp * 100);
  const fill = document.getElementById('raid-boss-bar-fill');
  const text = document.getElementById('raid-boss-bar-text');
  const phase = document.getElementById('raid-boss-bar-phase');
  if (fill) {
    fill.style.width = pct + '%';
    fill.style.background = pct > 75 ? '#2ecc71' : pct > 50 ? '#f39c12' : pct > 25 ? '#e74c3c' : '#8e44ad';
  }
  if (text) text.textContent = `${RAID_PARAMS.bossHp} / ${RAID_PARAMS.bossMaxHp}`;
  if (phase) {
    const phaseNum = pct > 75 ? 1 : pct > 50 ? 2 : pct > 25 ? 3 : 4;
    phase.textContent = 'PHASE ' + phaseNum;
    phase.style.color = pct > 75 ? '#2ecc71' : pct > 50 ? '#f39c12' : pct > 25 ? '#e74c3c' : '#8e44ad';
  }
}

// ============================================================
// BLUE AI AUTO-PLAY — for MP/daily modes (not live PvP)
// ============================================================
// Watches for blue's roll button to become enabled, then auto-plays:
// - Commits specials before rolling (ice shards, sacred fire, surge)
// - Auto-rolls after a brief delay (feels natural, not instant)
// - Auto-picks KO replacement (save best ghost for last)
// - Auto-handles ability modals on blue's side
let AI_ACTIVE = false;
let aiCheckInterval = null;

function startBlueAI() {
  if (AI_ACTIVE || LIVE_PVP) return;
  AI_ACTIVE = true;

  // Poll for opportunities to act
  aiCheckInterval = setInterval(() => {
    if (!B || B.phase === 'over') { stopBlueAI(); return; }
    aiTick();
  }, 600);
}

function stopBlueAI() {
  AI_ACTIVE = false;
  if (aiCheckInterval) { clearInterval(aiCheckInterval); aiCheckInterval = null; }
}

function aiTick() {
  if (!B || !AI_ACTIVE) return;

  // --- Auto-roll blue when button is ready ---
  if (B.phase === 'ready' || B.phase === 'rolling') {
    const blueBtn = document.getElementById('rollBlueBtn');
    if (blueBtn && !blueBtn.disabled && !blueBtn.classList.contains('locked')) {
      // v733: wait for Red to click READY before AI rolls Blue
      if (!pvpRedClickedRoll) return;
      // Commit specials before rolling
      aiCommitSpecials('blue');
      // v733: Red already committed — short delay for feel, then roll
      pvpRedClickedRoll = false;
      setTimeout(() => {
        if (B && (B.phase === 'ready' || B.phase === 'rolling')) {
          rollReady('blue');
        }
      }, 800 + Math.random() * 400);
      return;
    }
  }

  // --- Auto-pick KO replacement ---
  if (B.phase === 'ko-swap' && B.koSwapQueue && B.koSwapQueue[0] === 'blue') {
    const t = B.blue;
    const alive = t.ghosts.filter((g, i) => i !== t.activeIdx && !g.ko);
    if (alive.length > 0) {
      // Save the best ghost for last: pick the WEAKER one now
      // "Best" = highest rarity, then highest HP
      const rarityRank = { common: 0, uncommon: 1, rare: 2, 'ghost-rare': 3, legendary: 4 };
      // Bo (109) + Lucas (433) combo: keep Lucas on sideline for Kindling triggers
      const boOnTeam = t.ghosts.some(g => g.id === 109 && !g.ko);
      alive.sort((a, b) => {
        if (boOnTeam) {
          const aIsLucas = a.id === 433 ? 1 : 0;
          const bIsLucas = b.id === 433 ? 1 : 0;
          if (aIsLucas !== bIsLucas) return aIsLucas - bIsLucas;
        }
        // Lou (32) must stay on sideline to buff Grawr (34) — always send Grawr in first
        const grawrOnTeam = t.ghosts.some(g => g.id === 34 && !g.ko);
        if (grawrOnTeam) {
          const aIsLou = a.id === 32 ? 1 : 0;
          const bIsLou = b.id === 32 ? 1 : 0;
          if (aIsLou !== bIsLou) return bIsLou - aIsLou; // Lou sorts to front (saved for last = kept on sideline)
        }
        const rd = (rarityRank[b.rarity] || 0) - (rarityRank[a.rarity] || 0);
        if (rd !== 0) return rd;
        return b.hp - a.hp;
      });
      // Pick the WORST (last in sorted = lowest rarity/HP), saving best for last
      const pick = alive[alive.length - 1];
      const pickIdx = t.ghosts.indexOf(pick);
      setTimeout(() => {
        if (B && B.phase === 'ko-swap' && B.koSwapQueue && B.koSwapQueue[0] === 'blue') {
          doKoSwap('blue', pickIdx);
        }
      }, 800 + Math.random() * 400);
      return;
    }
  }

  // --- Duel Phase: auto-click Done for blue ---
  if ((B.phase === 'duel-1' || B.phase === 'duel-2') && B.duelActiveTeam === 'blue') {
    aiCommitSpecials('blue');
    const doneBtn = document.getElementById('duelDoneBlueBtn');
    if (doneBtn && !doneBtn.disabled) {
      setTimeout(() => {
        if (doneBtn && !doneBtn.disabled) doneBtn.click();
      }, 500 + Math.random() * 500);
      return;
    }
  }

  // --- Hand Limit discard for blue: auto-discard least valuable resource ---
  if (B.handLimitPending && B.handLimitPending.team === 'blue') {
    const overlay = document.getElementById('handLimitOverlay');
    if (overlay && overlay.classList.contains('active')) {
      const blueRes = B.blue.resources;
      // Discard priority: least valuable first
      const discardOrder = ['ice', 'healingSeed', 'surge', 'fire', 'luckyStone', 'moonstone', 'firefly'];
      for (const key of discardOrder) {
        if ((blueRes[key] || 0) > 0) {
          setTimeout(() => doHandLimitDiscard('blue', key), 400);
          return;
        }
      }
    }
  }

  // --- Auto-handle blue ability modals ---
  // Timber choice: always choose to discard specials (less punishing)
  if (B.timberPending && B.timberPending.team !== 'blue') {
    // Timber is opponent's ability affecting blue — auto-pick "discard"
    const timberOverlay = document.getElementById('timberOverlay');
    if (timberOverlay && timberOverlay.classList.contains('active')) {
      setTimeout(() => doTimberChoice('discard'), 600);
      return;
    }
  }

  // Ryder Toll: AI takes 1 damage unless it would KO them (HP <= 1), then give Sacred Fire
  if (B.riderPending && B.riderPending.oppTeamName === 'blue') {
    const riderOverlay = document.getElementById('riderOverlay');
    if (riderOverlay && riderOverlay.classList.contains('active')) {
      const aiActive = active(B.blue);
      const choice = (aiActive && aiActive.hp <= 1) ? 'sacredfire' : 'damage';
      setTimeout(() => doRiderChoice(choice), 600);
      return;
    }
  }

  // Tyler: always opt in if HP > 4 (aggressive AI)
  if (B.tylerPending && B.tylerPending.team === 'blue') {
    const f = active(B.blue);
    setTimeout(() => doTylerChoice(f && f.hp > 4 ? 'yes' : 'no'), 600);
    return;
  }

  // Toby Pure Heart: declare when AI is losing (fewer remaining ghosts) or Toby is last ghost
  if (B.tobyPending && B.tobyPending.team === 'blue') {
    const blueAlive = S.blue.filter(g => g.hp > 0).length;
    const redAlive = S.red.filter(g => g.hp > 0).length;
    const shouldDeclare = blueAlive < redAlive || blueAlive === 1;
    setTimeout(() => doTobyPureHeart(shouldDeclare), 600);
    return;
  }

  // Romy prediction: pick 4 (most common high-value die)
  if (B.romyPending && B.romyPending.team === 'blue') {
    setTimeout(() => doRomyPrediction(4), 600);
    return;
  }

  // Selene (305): prefer Lucky Stones (3 LS is more impactful than 2 seeds)
  if (B.selenePending && B.selenePending.tName === 'blue') {
    const seleneOverlay = document.getElementById('seleneOverlay');
    if (seleneOverlay && seleneOverlay.classList.contains('active')) {
      setTimeout(() => doSeleneChoice('stone'), 600);
      return;
    }
  }

  // Pal Al: always pick damage (aggressive AI)
  if (B.wiseAlPending && B.wiseAlPending.winTeamName === 'blue') {
    setTimeout(() => { if (B.wiseAlPending) doWiseAlChoice('damage'); }, 600);
    return;
  }

  // Sophia: AI picks Mask of Night
  if (B.sophiaPending && B.sophiaPending.winTeamName === 'blue') {
    setTimeout(() => { if (B.sophiaPending) doSophiaChoice('night'); }, 600);
    return;
  }

  // Gordok: always pick damage (aggressive AI)
  if (B.gordokPending && B.gordokPending.winTeamName === 'blue') {
    setTimeout(() => { if (B.gordokPending) doGordokChoice('damage'); }, 600);
    return;
  }

  // Jackson (50): opt in if HP > 5 (aggressive but safe)
  if (B.jacksonPending && B.jacksonPending.team === 'blue') {
    const jacksonOverlay = document.getElementById('jacksonOverlay');
    if (jacksonOverlay && jacksonOverlay.classList.contains('active')) {
      const jf = active(B.blue);
      setTimeout(() => doJacksonChoice(jf && jf.hp > 5 ? 'yes' : 'no'), 600);
      return;
    }
  }

  // Sonya (69): always use Mesmerize (change die to 2 — weakens opponent)
  if (B.sonyaPending && B.sonyaPending.team === 'blue') {
    const sonyaOverlay = document.getElementById('sonyaOverlay');
    if (sonyaOverlay && sonyaOverlay.classList.contains('active')) {
      setTimeout(() => doSonyaChoice('yes'), 600);
      return;
    }
  }

  // Jeanie (90): always use Hidden Treasure (force opponent reroll)
  if (B.jeaniePending && B.jeaniePending.team === 'blue') {
    const jeanieOverlay = document.getElementById('jeanieOverlay');
    if (jeanieOverlay && jeanieOverlay.classList.contains('active')) {
      setTimeout(() => doJeanieChoice('yes'), 600);
      return;
    }
  }

  // Dark Wing: always opt in
  if (B.darkWingPending && B.darkWingPending.team === 'blue') {
    setTimeout(() => { if (typeof doDarkWingChoice === 'function') doDarkWingChoice('yes'); }, 600);
    return;
  }

  // Tommy chain: auto-roll the bonus die
  if (B.tommyChainPending && B.tommyChainPending.team === 'blue') {
    const tommyOverlay = document.getElementById('tommyOverlay');
    if (tommyOverlay && tommyOverlay.classList.contains('active')) {
      const tommyBtn = document.getElementById('tommyRollBtn');
      if (tommyBtn && !tommyBtn.disabled) {
        setTimeout(() => doTommyRoll(), 600);
      }
      return;
    }
  }

  // Balatron (113): auto-roll the counter die
  if (B.balatronPending && B.balatronPending.loseTeamName === 'blue') {
    const balatronOverlay = document.getElementById('balatronOverlay');
    if (balatronOverlay && balatronOverlay.classList.contains('active')) {
      const balatronBtn = document.getElementById('balatronRollBtn');
      if (balatronBtn && !balatronBtn.disabled) {
        setTimeout(() => doBalatronRoll(), 600);
      }
      return;
    }
  }

  // Sylvia (313): auto-roll ice shard die when modal appears
  if (B.sylviaResume && B.sylviaTeamName === 'blue') {
    const sylviaOverlay = document.getElementById('sylviaOverlay');
    if (sylviaOverlay && sylviaOverlay.classList.contains('active')) {
      const sylviaBtn = document.getElementById('sylviaRollBtn');
      if (sylviaBtn && !sylviaBtn.disabled) {
        setTimeout(() => { if (sylviaBtn.onclick) sylviaBtn.onclick(); else sylviaBtn.click(); }, 600);
      }
      return;
    }
  }

  // Pressure picker: blue is forced to swap — pick which of blue's own ghosts enters
  // pressurePickerTeam = 'blue' means red attacked, blue chooses which of their own sideline ghosts comes in
  if (B.pressurePickerTeam === 'blue') {
    const pressureOverlay = document.getElementById('pressureOverlay');
    if (pressureOverlay && pressureOverlay.classList.contains('active')) {
      const blueTeam = B.blue;
      const sidelineAlive = blueTeam.ghosts
        .map((g, i) => ({ ghost: g, index: i }))
        .filter(x => x.index !== blueTeam.activeIdx && !x.ghost.ko);
      if (sidelineAlive.length > 0) {
        // Save the best ghost: pick the weaker one now (same logic as KO swap)
        const rarityRank = { common: 0, uncommon: 1, rare: 2, 'ghost-rare': 3, legendary: 4 };
        // Bo (109) + Lucas (433) combo: keep Lucas on sideline for Kindling triggers
        const boOnTeamP = blueTeam.ghosts.some(g => g.id === 109 && !g.ko);
        sidelineAlive.sort((a, b) => {
          if (boOnTeamP) {
            const aIsLucas = a.ghost.id === 433 ? 1 : 0;
            const bIsLucas = b.ghost.id === 433 ? 1 : 0;
            if (aIsLucas !== bIsLucas) return aIsLucas - bIsLucas;
          }
          const rd = (rarityRank[b.ghost.rarity] || 0) - (rarityRank[a.ghost.rarity] || 0);
          if (rd !== 0) return rd;
          return b.ghost.hp - a.ghost.hp;
        });
        const pick = sidelineAlive[sidelineAlive.length - 1]; // weakest
        setTimeout(() => doPressureSwap('red', pick.index), 600);
      }
      return;
    }
  }

  // Burn picker overlay: auto-pick best target (lowest HP sideline ghost)
  if (B.burnPickerTeam === 'blue') {
    const burnOverlay = document.getElementById('burnOverlay');
    if (burnOverlay && burnOverlay.classList.contains('active')) {
      const enemyTeam = B.red;
      const sidelineTargets = enemyTeam.ghosts
        .map((g, i) => ({ ghost: g, index: i }))
        .filter(x => x.index !== enemyTeam.activeIdx && !x.ghost.ko);
      if (sidelineTargets.length > 0) {
        sidelineTargets.sort((a, b) => a.ghost.hp - b.ghost.hp);
        setTimeout(() => doBurnPlace('blue', sidelineTargets[0].index), 500);
      } else {
        setTimeout(() => closeBurnPicker(), 400);
      }
      return;
    }
  }

  // Firefly picker overlay: convert to moonstone (best default)
  if (B.fireflyPickerTeam === 'blue') {
    const fireflyOverlay = document.getElementById('fireflyOverlay');
    if (fireflyOverlay && fireflyOverlay.classList.contains('active')) {
      setTimeout(() => doFireflyConvert('blue', 'moonstone'), 500);
      return;
    }
  }

  // Nick Knack picker: steal most valuable resource from opponent
  if (B.nickKnackPending && B.nickKnackPending.team === 'blue') {
    const nickOverlay = document.getElementById('nickKnackOverlay');
    if (nickOverlay && nickOverlay.classList.contains('active')) {
      const oppRes = B.red.resources;
      // Priority: moonstone > luckyStone > surge > fire > ice > healingSeed
      const stealOrder = ['moonstone', 'luckyStone', 'surge', 'fire', 'ice', 'healingSeed'];
      const stealKey = stealOrder.find(k => (oppRes[k] || 0) > 0) || 'skip';
      setTimeout(() => doNickKnackSteal('blue', stealKey), 500);
      return;
    }
  }

  // --- Post-roll: auto-use moonstone / lucky stone for blue ---
  aiHandlePostRoll();
}

// AI commits available specials before rolling
function aiCommitSpecials(team) {
  if (!B || !B[team]) return;
  const t = B[team];
  const r = t.resources;
  if (!r) return;
  const f = active(t);
  if (!f || f.ko) return;

  // --- Magic Fireflies: convert to most useful resource FIRST (before other commits) ---
  while ((r.firefly || 0) > 0) {
    // Priority: moonstone > luckyStone > surge > ice > fire > healingSeed
    // Moonstone = guaranteed die change to 6, Lucky Stone = reroll safety net
    // Moonstone capped at 1 — skip if already holding one
    let bestRes = (r.moonstone || 0) >= 1 ? 'luckyStone' : 'moonstone';
    if ((r.luckyStone || 0) >= 2 && (r.moonstone || 0) >= 1) bestRes = 'surge';
    if ((r.surge || 0) >= 2) bestRes = 'ice';
    // If HP is low, prefer healing seed
    if (f.hp < f.maxHp * 0.5 && (r.healingSeed || 0) < 2) bestRes = 'healingSeed';
    doFireflyConvert(team, bestRes);
  }

  // --- Healing Seeds: use if HP below max (heal before fighting) ---
  while (r.healingSeed > 0 && f.hp < f.maxHp) {
    spendHealingSeed(team);
  }

  // --- Bonzai (Miyoshi 454): sacrifice 4 HP for +5 dice — use whenever survivable ---
  if (f.id === 454 && !f.ko && f.hp > 4 && B.bonzaiDecided && !B.bonzaiDecided[team]) {
    useBonzaiButton(team);
    // doPreRollSetup already ran (Red clicked first), so bonzaiBtnDice was 0 when
    // dice counts were computed. Inject the +5 directly into preRoll if it exists.
    if (B.preRoll && B.preRoll[team]) {
      B.preRoll[team].count = Math.min(10, B.preRoll[team].count + 5);
    }
  }

  // --- Ice Blade: swing it if forged ---
  if (B.iceBladeForgedPermanent && B.iceBladeForgedPermanent[team] &&
      B.iceBladeSwing && !B.iceBladeSwing[team]) {
    toggleIceBlade(team);
  }

  // --- Flame Blade: swing it if forged ---
  if (B.flameBlade && B.flameBlade[team] &&
      B.flameBladeSwing && !B.flameBladeSwing[team]) {
    if (typeof toggleFlameBlade === 'function') toggleFlameBlade(team);
  }

  // --- Zain Ice Blade forge: forge if we have Zain + materials ---
  if (!B.iceBladeForgedPermanent?.[team]) {
    const zain = t.ghosts.find(g => g.id === 206 && !g.ko && !g.iceBladeForged);
    if (zain && r.ice >= 1 && r.moonstone >= 1) {
      useZainForge(team);
    }
  }

  // --- Finn Flame Blade forge ---
  if (!B.flameBlade?.[team]) {
    const finn = t.ghosts.find(g => g.id === 204 && !g.ko);
    if (finn && r.healingSeed >= 1 && r.fire >= 1) {
      if (typeof useFinnFlameBlade === 'function') useFinnFlameBlade(team);
    }
  }

  // --- Harrison (315) Ascend: commit healing seeds for extra dice ---
  if (f.id === 315 && !f.ko && r.healingSeed > 0 && B.committed) {
    // Commit all available seeds (each = +1 die)
    while (r.healingSeed > 0) {
      toggleHarrison(team);
    }
  }

  // --- Commit resources using cycleCommit (properly moves from pool to committed) ---
  // Commit all ice shards
  while (r.ice > 0 && B.committed) {
    cycleCommit(team, 'ice');
  }

  // Commit all sacred fire
  while (r.fire > 0 && B.committed) {
    cycleCommit(team, 'fire');
  }

  // Commit all surge for extra dice
  while (r.surge > 0 && B.committed) {
    cycleCommit(team, 'surge');
  }

  // --- Aunt Susan (308): commit seeds for damage if HP is full ---
  if (r.healingSeed > 0 && f.hp >= f.maxHp && B.committed) {
    const auntSusan = t.ghosts.find(g => g.id === 308 && !g.ko);
    if (auntSusan) {
      while (r.healingSeed > 0) {
        if (typeof toggleAuntSusan === 'function') toggleAuntSusan(team);
        else break;
      }
    }
  }

  // --- Aunt Susan Heal (308): commit seeds for healing if HP is low and Aunt Susan active ---
  if (r.healingSeed > 0 && f.id === 308 && f.hp < f.maxHp && B.committed) {
    while (r.healingSeed > 0) {
      if (typeof toggleAuntSusanHeal === 'function') toggleAuntSusanHeal(team);
      else break;
    }
  }

  // --- Burn: place all burn on enemy sideline ghosts ---
  if ((r.burn || 0) > 0) {
    const enemyTeamName = team === 'red' ? 'blue' : 'red';
    const enemyTeam = B[enemyTeamName];
    // Find non-KO'd sideline ghosts on enemy team
    const sidelineTargets = enemyTeam.ghosts
      .map((g, i) => ({ ghost: g, index: i }))
      .filter(x => x.index !== enemyTeam.activeIdx && !x.ghost.ko);
    if (sidelineTargets.length > 0) {
      while ((r.burn || 0) > 0 && sidelineTargets.length > 0) {
        // Spread burn across targets, prioritizing ghosts with lower HP
        sidelineTargets.sort((a, b) => a.ghost.hp - b.ghost.hp);
        const target = sidelineTargets[0];
        // Call doBurnPlace directly (bypasses the overlay picker)
        r.burn--;
        if (!B.burn) B.burn = { red: {}, blue: {} };
        if (!B.burn[enemyTeamName]) B.burn[enemyTeamName] = {};
        B.burn[enemyTeamName][target.index] = (B.burn[enemyTeamName][target.index] || 0) + 1;
        // Track burn source for KO credit
        const burnPlacer = active(B[team]);
        const burnPlacerId = burnPlacer ? (burnPlacer.originalId || burnPlacer.id) : 0;
        if (!B.burnSource) B.burnSource = { red: {}, blue: {} };
        if (!B.burnSource[enemyTeamName]) B.burnSource[enemyTeamName] = {};
        if (!B.burnSource[enemyTeamName][target.index]) B.burnSource[enemyTeamName][target.index] = {};
        B.burnSource[enemyTeamName][target.index][burnPlacerId] = (B.burnSource[enemyTeamName][target.index][burnPlacerId] || 0) + 1;
        const totalBurn = B.burn[enemyTeamName][target.index];
        log(`<span class="log-ability">BURN!</span> AI placed on <span class="log-dmg">${target.ghost.name}</span>! (${totalBurn} total)`);
        // Mable (446) Hex: burn placement = enemy -1 die
        const mableActive = active(B[team]);
        if (mableActive && mableActive.id === 446 && !mableActive.ko) {
          if (!B.hexDieRemoval) B.hexDieRemoval = { red: 0, blue: 0 };
          B.hexDieRemoval[enemyTeamName] = (B.hexDieRemoval[enemyTeamName] || 0) + 1;
          log(`<span class="log-ability">${mableActive.name}</span> — Hex! Burn placed → enemy -1 die next roll!`);
        }
      }
    }
  }

  // --- Hex (Mable 446): spend burn for -1 enemy die + sacred fire ---
  if (f.id === 446 && !f.ko && (r.burn || 0) > 0) {
    while ((r.burn || 0) > 0) {
      useHex(team);
    }
  }

  renderBattle();
}

// --- POST-ROLL AI: auto-use moonstone and lucky stone for blue ---
function aiHandlePostRoll() {
  if (!AI_ACTIVE || !B) return;

  // Auto-use Moonstone when it pops up for blue
  if (B.pendingMoonstone && B.pendingMoonstone.team === 'blue') {
    const pm = B.pendingMoonstone;

    if (pm.phase === 'pick-resource') {
      // Click the moonstone tile to activate it
      const resEl = document.getElementById('blue-resources');
      const msEl = resEl && resEl.querySelector('.res-tile.moonstone.rerollable');
      if (msEl) {
        setTimeout(() => { if (msEl.onclick) msEl.onclick(); }, 600);
      } else {
        // If no clickable moonstone, skip
        setTimeout(() => skipMoonstone(), 600);
      }
      return;
    }

    if (pm.phase === 'pick-die') {
      // Pick the lowest die to change
      const dice = pm.dice || B.blueDice || [];
      let worstIdx = 0;
      let worstVal = 7;
      dice.forEach((d, i) => { if (d < worstVal) { worstVal = d; worstIdx = i; } });
      setTimeout(() => { if (typeof pickMsDie === 'function') pickMsDie(worstIdx); }, 500);
      return;
    }

    if (pm.phase === 'pick-value') {
      // Change to 6 (best value)
      setTimeout(() => { if (typeof pickMsValue === 'function') pickMsValue(6); }, 500);
      return;
    }
  }

  // Auto-use Lucky Stone when it appears for blue
  const blueDiceEl = document.getElementById('blue-dice');
  if (blueDiceEl) {
    const rerollable = blueDiceEl.querySelectorAll('.die.rerollable');
    if (rerollable.length > 0 && B.phase && B.phase.includes('luckystone') && B.blue?.resources?.luckyStone > 0) {
      // Find lowest die and click it
      let lowestEl = null, lowestVal = 7;
      rerollable.forEach(el => {
        const val = parseInt(el.textContent);
        if (!isNaN(val) && val < lowestVal) { lowestVal = val; lowestEl = el; }
      });
      if (lowestEl && lowestVal <= 3) {
        setTimeout(() => { if (lowestEl.onclick) lowestEl.onclick(); }, 600);
      }
    }
  }
}

// ============================================================
// LIVE PVP MODE — real-time 1v1 via Firebase
// ============================================================
// URL: ?livepvp=GAMEID&side=red|blue&red=IDS&blue=IDS
// Each player controls ONLY their roll button + their decisions.
// Dice sync: when you roll, your dice broadcast to opponent.
// Opponent's dice are injected DIRECTLY into engine state (bypassing rollReady
// to avoid pre-roll ability modals blocking on the wrong client).
(function checkLivePvPParams() {
  const params = new URLSearchParams(window.location.search);
  const gameId = params.get('livepvp');
  if (!gameId) return;

  const side = params.get('side');
  if (side !== 'red' && side !== 'blue') return;

  const redParam = params.get('red');
  const blueParam = params.get('blue');
  if (!redParam || !blueParam) return;

  const redIds = redParam.split(',').map(Number).filter(id => ghostData(id));
  const blueIds = blueParam.split(',').map(Number).filter(id => ghostData(id));
  if (redIds.length !== 3 || blueIds.length !== 3) return;

  LIVE_PVP = true;
  MP_MODE = true;
  PVP_SIDE = side;
  PVP_GAME_ID = gameId;
  PVP_GAME_REF = db.ref(`mp/livegames/${gameId}`);

  // Force standard settings
  const speedEl = document.getElementById('speedSlider');
  if (speedEl) speedEl.value = 0;
  const hlCheck = document.getElementById('handLimitCheckbox');
  if (hlCheck) hlCheck.checked = true;
  const hlSlider = document.getElementById('handLimitSlider');
  if (hlSlider) hlSlider.value = 4;
  const stSlider = document.getElementById('specialsTimerSlider');
  if (stSlider) stSlider.value = 8; // v731: 8 second timer (was 5)

  // Set teams
  S.redPicks = redIds;
  S.bluePicks = blueIds;

  // Show player labels
  const redName = params.get('redName') || 'Red';
  const blueName = params.get('blueName') || 'Blue';
  MP_PLAYER_NAMES.red = decodeURIComponent(redName);
  MP_PLAYER_NAMES.blue = decodeURIComponent(blueName);
  const redTitle = document.querySelector('.roster-title.red');
  const blueTitle = document.querySelector('.roster-title.blue');
  if (redTitle) redTitle.innerHTML = `<span class="roster-dot"></span> ${decodeURIComponent(redName)}${side === 'red' ? ' (You)' : ''}`;
  if (blueTitle) blueTitle.innerHTML = `<span class="roster-dot"></span> ${decodeURIComponent(blueName)}${side === 'blue' ? ' (You)' : ''}`;

  // Switch to arena tab and hide team selection UI
  switchTab('battle');
  const teamRosters = document.getElementById('teamRosters');
  if (teamRosters) teamRosters.style.display = 'none';
  const randRow = document.querySelector('.random-pick-row');
  if (randRow) randRow.style.display = 'none';
  const controls = document.querySelector('.controls');
  if (controls) controls.style.display = 'none';
  // Hide the tab bar itself — no switching in PvP
  const tabs = document.querySelector('.tabs');
  if (tabs) tabs.style.display = 'none';

  // Add wait banner
  const waitBanner = document.createElement('div');
  waitBanner.id = 'pvp-wait-banner';
  waitBanner.style.cssText = 'text-align:center;padding:12px;font-family:Creepster,cursive;font-size:1.2rem;color:var(--gold-bright);letter-spacing:2px;display:none;';
  waitBanner.textContent = "Waiting for opponent's roll...";
  const bv = document.getElementById('battle-view');
  if (bv) bv.prepend(waitBanner);

  // Add turn timer display — prominent, above the dice
  const timerBar = document.createElement('div');
  timerBar.id = 'pvp-turn-timer';
  timerBar.style.cssText = 'text-align:center;padding:8px 16px;font-family:Creepster,cursive;font-size:1.1rem;font-weight:700;color:var(--text2);letter-spacing:2px;background:rgba(0,0,0,0.4);border-radius:8px;margin:4px auto;max-width:400px;';
  timerBar.textContent = '';
  // Insert at top of battle view
  const battleView = document.getElementById('battle-view');
  if (battleView) battleView.prepend(timerBar);

  // Start battle immediately
  setTimeout(() => {
    renderPicks();
    startBattle();
    // Duel Phase disabled in live PvP — the Firebase ready-check already ensures
    // both players commit resources before resolution (Blue rolls when ready).
    if (B) B.duelPhaseMode = false;
    setupLivePvP();
  }, 400);
})();

// ---- LIVE PVP SETUP ----
let PVP_BLUE_READY_DATA = null;
// v726: generate BOTH dice sets only when both players are ready.
// Top-level so rollReady can call it from Red's roll handler.
function pvpTryGenerateDice() {
  if (!PVP_OPPONENT_READY || !pvpRedReady || !B) return;
  if (B.phase !== 'rolling') return;

  // Apply Blue's committed resources
  if (PVP_BLUE_READY_DATA) {
    if (PVP_BLUE_READY_DATA.committed) B.committed.blue = PVP_BLUE_READY_DATA.committed;
    if (PVP_BLUE_READY_DATA.resources) B.blue.resources = PVP_BLUE_READY_DATA.resources;
    if (PVP_BLUE_READY_DATA.activeHp != null) {
      const blueActive = active(B.blue);
      if (blueActive) blueActive.hp = PVP_BLUE_READY_DATA.activeHp;
    }
    PVP_BLUE_READY_DATA = null;
  }
  PVP_OPPONENT_READY = false;
  pvpRedReady = false;

  // Now generate Red's dice, then Blue's dice — standard engine flow
  doTeamRoll('red', document.getElementById('rollRedBtn'));
  // Small delay so Red's dice broadcast first, then Blue's
  setTimeout(() => { rollReady('blue'); }, 50);
}

function setupLivePvP() {
  if (!LIVE_PVP || !PVP_GAME_REF) return;

  const mySide = PVP_SIDE;
  const oppSide = mySide === 'red' ? 'blue' : 'red';
  const oppBtnId = oppSide === 'red' ? 'rollRedBtn' : 'rollBlueBtn';

  // Clean up stale data from previous games
  PVP_GAME_REF.child('blueReady').set(false);
  PVP_GAME_REF.child('redReady').set(false);
  PVP_GAME_REF.child('committedUpdate').set(null);
  PVP_GAME_REF.child('rolls').remove();
  PVP_GAME_REF.child('roundResult').remove();
  PVP_GAME_REF.child('koSwap').remove();
  PVP_GAME_REF.child('koSwapRequest').remove();
  PVP_GAME_REF.child('swap').remove();
  PVP_GAME_REF.child('gameOver').remove();
  PVP_GAME_REF.child('specialsChoice').remove(); // v731
  PVP_GAME_REF.child('specialsDone').set(null);   // v731

  // Hide opponent's roll button
  const oppBtn = document.getElementById(oppBtnId);
  if (oppBtn) oppBtn.style.display = 'none';

  // Connection tracking
  PVP_GAME_REF.child(`connected/${mySide}`).set(true);
  PVP_GAME_REF.child(`connected/${mySide}`).onDisconnect().set(false);

  // --- DICE SYNC (Red-authoritative) ---
  // Red generates ALL dice. Blue sends "ready" signal.
  // When both are ready, Red rolls both sides and broadcasts results.
  if (mySide === 'blue') {
    // v725: Blue listens for dice rolls, animates them, AND runs local combat resolution.
    // pvpInjectOpponentDice handles Red's dice; for Blue's own dice we inject + animate directly.
    // When both dice arrive, pvpInjectOpponentDice triggers doPostRollAndResolve locally.
    PVP_GAME_REF.child('rolls').on('child_added', snap => {
      const data = snap.val();
      if (!data || !B || B.phase === 'over') return;
      snap.ref.remove();
      if (typeof resetPvPAfk === 'function') resetPvPAfk();
      if (data.side === 'red') {
        // Red's dice — inject as opponent dice (triggers resolution if Blue's dice already present)
        pvpInjectOpponentDice('red', data.dice);
      } else {
        // Blue's own dice — inject into engine state + animate, then check for resolution
        pvpInjectOwnDice('blue', data.dice);
      }
    });

    // BLUE: listen for Red's authoritative round result
    // v725: when pvpBlueResolvedLocally is true, Blue already ran combat locally.
    // roundResult becomes a silent state correction — no effects, no callouts.
    let pvpBluePendingResults = []; // v729: queue results while Blue is in interactive state

    function pvpBlueProcessEvent(data) {
      // v730: queue roundResult while Blue is in any KO-related phase or mid-resolution.
      // Red's broadcasts (damageResolved, koSwap) arrive while Blue's local engine is
      // still processing — don't stomp the interactive KO picker or ability flow.
      if (B && (B.phase === 'ko-swap' || B.phase === 'ko-pause') && pvpBlueResolvedLocally) {
        pvpBluePendingResults.push(data);
        return;
      }

      // v722: reset AFK timer — Blue is actively watching, not idle
      if (typeof resetPvPAfk === 'function') resetPvPAfk();

      const banner = document.getElementById('pvp-wait-banner');
      if (banner) banner.style.display = 'none';

      // v726: dismiss stale PvP KO swap overlay if present
      const koOverlay = document.getElementById('pvp-ko-swap-overlay');
      if (koOverlay) koOverlay.style.display = 'none';

      if (pvpBlueResolvedLocally) {
        // v725: Blue already saw the full combat experience locally.
        // v728: Only re-render if Red's authoritative state actually differs from local state.
        const stateChanged = pvpApplyState(data.state);
        if (stateChanged) renderBattle();

        // Reset for next round on roundEnd
        if (data.event === 'roundEnd' || !data.event) {
          B.phase = 'ready';
          B.preRoll = null;
          B.committed.blue = { ice:0, fire:0, surge:0, auntSusan:0, auntSusanHeal:0, harrison:0, zainBlade:0 };
          pvpBlueResolvedLocally = false;
          const myBtn = document.getElementById('rollBlueBtn');
          if (myBtn && B.phase !== 'over') {
            myBtn.disabled = false;
            myBtn.textContent = 'ROLL';
          }
          renderBattle();
          if (typeof resetPvPAfk === 'function') resetPvPAfk();
          // v729: drain any results queued while Blue was in interactive phase
          while (pvpBluePendingResults.length > 0) {
            pvpBlueProcessEvent(pvpBluePendingResults.shift());
          }
        }

        // If game over from Red's authority
        if (data.gameOver) {
          setTimeout(() => {
            if (B && B.phase !== 'over') showGameOver(data.gameOver);
          }, 800);
        }
        return;
      }

      // Fallback: Blue hasn't resolved locally (shouldn't happen in v725, but safe)
      const abilities = data.abilityEvents || [];
      const hasAbilities = abilities.length > 0;

      // v724: Dice are animated live from the `rolls` listener.
      if (B.redDice && B.blueDice) {
        renderDice(B.redDice, B.blueDice);
        highlightRollPreview('red', B.redDice);
        highlightRollPreview('blue', B.blueDice);
      }

      if (hasAbilities) {
        const last = abilities[abilities.length - 1];
        showAbilityCallout(last.name, last.color, last.desc, last.team);
      }
      pvpApplyState(data.state);
      renderBattle();

      if (data.event === 'roundEnd' || !data.event) {
        B.phase = 'ready';
        B.preRoll = null;
        B.committed.blue = { ice:0, fire:0, surge:0, auntSusan:0, auntSusanHeal:0, harrison:0, zainBlade:0 };
        const myBtn = document.getElementById('rollBlueBtn');
        if (myBtn && B.phase !== 'over') {
          myBtn.disabled = false;
          myBtn.textContent = 'ROLL';
        }
        renderBattle();
        if (typeof resetPvPAfk === 'function') resetPvPAfk();
      }

      if (data.gameOver) {
        setTimeout(() => {
          if (B && B.phase !== 'over') showGameOver(data.gameOver);
        }, 800);
      }
    }

    PVP_GAME_REF.child('roundResult').on('child_added', snap => {
      const data = snap.val();
      if (!data || !B || B.phase === 'over') return;
      snap.ref.remove();
      pvpBlueProcessEvent(data);
    });
  } else {
    // v726: RED waits for BOTH ready signals before generating dice.
    // This gives Blue time to commit resources (Ice Shards, Fire, etc.)
    PVP_OPPONENT_READY = false;
    PVP_BLUE_READY_DATA = null;
    pvpRedReady = false;

    PVP_GAME_REF.child('blueReady').on('value', snap => {
      const data = snap.val();
      if (!data || !data.ready || !B || B.phase === 'over') return;
      PVP_OPPONENT_READY = true;
      PVP_BLUE_READY_DATA = data;
      PVP_GAME_REF.child('blueReady').set(false);

      const banner = document.getElementById('pvp-wait-banner');
      if (banner) banner.style.display = 'none';

      pvpTryGenerateDice();
    });

    // Poll: if both ready but phase wasn't right, retry
    setInterval(() => {
      if (PVP_OPPONENT_READY && pvpRedReady && B && B.phase !== 'over') pvpTryGenerateDice();
    }, 500);
  }

  // --- KO SWAP SYNC ---
  PVP_GAME_REF.child('koSwap').on('child_added', snap => {
    const data = snap.val();
    if (!data || data.side !== oppSide) return;
    snap.ref.remove();

    const banner = document.getElementById('pvp-wait-banner');
    if (banner) banner.style.display = 'none';

    if (B && B.phase === 'ko-swap' && B.koSwapQueue && B.koSwapQueue[0] === oppSide) {
      doKoSwap(oppSide, data.idx);
    }
  });

  // --- KO SWAP REQUEST (Blue receives from Red when Blue needs to pick) ---
  // v726: Blue now runs engine locally and auto-resolves KO swaps during resolution.
  // This Firebase listener is only needed as a FALLBACK when local resolution didn't handle it.
  if (mySide === 'blue') {
    PVP_GAME_REF.child('koSwapRequest').on('value', snap => {
      const data = snap.val();
      if (!data || data.side !== 'blue' || !B) return;
      PVP_GAME_REF.child('koSwapRequest').set(null);

      // v728: if Blue already resolved locally, the local engine showed the real picker.
      // Blue's doKoSwap already broadcast the choice — just skip the redundant picker.
      if (pvpBlueResolvedLocally) {
        // If Blue already picked (doKoSwap broadcast), skip. If not yet picked, the local
        // picker is still active and doKoSwap will broadcast when Blue chooses.
        if (B._blueKoSwapPick != null) {
          // Already broadcast — nothing to do
          B._blueKoSwapPick = null;
        }
        // Either way, don't show a second picker — local engine is handling it
        return;
      }

      const banner = document.getElementById('pvp-wait-banner');
      if (banner) banner.style.display = 'none';

      const aliveIdxes = data.aliveIdxes || [];
      const aliveNames = data.aliveNames || [];
      const fallenName = data.fallenName || 'Your ghost';

      if (aliveIdxes.length === 1) {
        narrate(`<b class="ko-text">${fallenName} is down!</b> <b class="blue-text">${aliveNames[0]}</b> steps up!`);
        PVP_GAME_REF.child('koSwap').push({ side: 'blue', idx: aliveIdxes[0], timestamp: firebase.database.ServerValue.TIMESTAMP });
        return;
      }

      narrate(`<b class="ko-text">${fallenName} is down!</b> <b class="blue-text">Blue</b> — who answers the call?`);

      let overlay = document.getElementById('pvp-ko-swap-overlay');
      if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'pvp-ko-swap-overlay';
        overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.85);z-index:9999;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px;';
        document.body.appendChild(overlay);
      }
      overlay.innerHTML = '<div style="font-family:Creepster,cursive;font-size:1.6rem;color:var(--gold-bright);letter-spacing:2px;margin-bottom:8px;">Choose your next ghost!</div>';
      aliveIdxes.forEach((idx, i) => {
        const btn = document.createElement('button');
        btn.textContent = aliveNames[i];
        btn.style.cssText = 'font-family:Creepster,cursive;font-size:1.3rem;padding:14px 32px;border-radius:10px;border:2px solid var(--gold-bright);background:rgba(30,30,50,0.95);color:var(--text);cursor:pointer;min-width:200px;transition:transform 0.15s;';
        btn.onmouseenter = () => { btn.style.transform = 'scale(1.08)'; };
        btn.onmouseleave = () => { btn.style.transform = 'scale(1)'; };
        btn.onclick = () => {
          overlay.style.display = 'none';
          PVP_GAME_REF.child('koSwap').push({ side: 'blue', idx: idx, timestamp: firebase.database.ServerValue.TIMESTAMP });
          narrate(`<b class="blue-text">${aliveNames[i]}</b> answers the call!`);
        };
        overlay.appendChild(btn);
      });
      overlay.style.display = 'flex';
    });
  }

  // --- v729: LIVE RESOURCE COMMIT SYNC ---
  // See opponent commit Ice Shards, Fire, Surge in real-time (the theater of the game)
  PVP_GAME_REF.child('committedUpdate').on('value', snap => {
    const data = snap.val();
    if (!data || data.side === mySide || !B) return;
    // Apply opponent's committed resources + updated resource pool + active HP
    if (data.committed) B.committed[data.side] = { ...data.committed };
    if (data.resources) Object.assign(B[data.side].resources, data.resources);
    if (data.activeHp != null) {
      const oppActive = active(B[data.side]);
      if (oppActive) oppActive.hp = data.activeHp;
    }
    // v735: sync burn state — critical for entry damage on KO swaps
    if (data.burn) {
      B.burn = data.burn;
      if (!B.burn.red) B.burn.red = {};
      if (!B.burn.blue) B.burn.blue = {};
    }
    if (data.burnSource) B.burnSource = data.burnSource;
    renderBattle();
    playSfx('sfxSpecial', 0.15); // subtle audio cue that opponent is doing something
  });

  // --- VOLUNTARY SWAP SYNC ---
  PVP_GAME_REF.child('swap').on('child_added', snap => {
    const data = snap.val();
    if (!data || data.side !== oppSide) return;
    snap.ref.remove();
    if (B && B.phase === 'ready') doSwap(oppSide, data.idx);
  });

  // --- DISCONNECT DETECTION ---
  // If opponent disconnects, they forfeit
  PVP_GAME_REF.child(`connected/${oppSide}`).on('value', snap => {
    const connected = snap.val();
    // Only trigger forfeit if game is in progress (not during initial load)
    if (connected === false && B && B.phase !== 'over' && B.round > 1) {
      const banner = document.getElementById('pvp-wait-banner');
      if (banner) {
        banner.textContent = 'Opponent disconnected — you win!';
        banner.style.display = 'block';
        banner.style.color = 'var(--uncommon)';
      }
      // Trigger game over — we win
      setTimeout(() => {
        if (B && B.phase !== 'over') showGameOver(mySide);
      }, 1500);
    }
  });

  // --- TURN TIMER + AFK TIMEOUT ---
  let pvpAfkTimer = null;
  let pvpAfkWarned = false;
  let pvpTurnStart = Date.now();
  let pvpTimerInterval = null;

  function updateTurnTimer() {
    const timerEl = document.getElementById('pvp-turn-timer');
    if (!timerEl || !B || B.phase === 'over') {
      if (timerEl) timerEl.textContent = '';
      return;
    }

    const elapsed = Math.floor((Date.now() - pvpTurnStart) / 1000);
    const remaining = Math.max(0, 45 - elapsed); // v722: 45s total (was 25s — too tight with ability replays)

    // Determine whose turn it is
    const myBtn = document.getElementById(mySide === 'red' ? 'rollRedBtn' : 'rollBlueBtn');
    const myTurnToRoll = myBtn && !myBtn.disabled && !myBtn.classList.contains('locked') &&
                         (B.phase === 'ready' || B.phase === 'rolling');

    if (B.phase === 'ko-swap') {
      const whoSwaps = B.koSwapQueue && B.koSwapQueue[0];
      if (whoSwaps === mySide) {
        timerEl.textContent = `Your pick — ${remaining}s`;
        timerEl.style.color = remaining <= 10 ? 'var(--accent)' : 'var(--gold-bright)';
      } else {
        timerEl.textContent = `Opponent picking...`;
        timerEl.style.color = 'var(--text2)';
      }
    } else if (myTurnToRoll) {
      if (remaining <= 10) {
        timerEl.textContent = `ROLL NOW! ${remaining}s`;
        timerEl.style.color = 'var(--accent)';
        timerEl.style.fontSize = '1.4rem';
        timerEl.style.background = 'rgba(233,69,96,0.2)';
        timerEl.style.animation = 'pvpTimerPulse 0.5s ease-in-out infinite';
      } else if (remaining <= 20) {
        timerEl.textContent = `Your roll — ${remaining}s`;
        timerEl.style.color = 'var(--accent)';
        timerEl.style.fontSize = '1.2rem';
        timerEl.style.background = 'rgba(233,69,96,0.1)';
        timerEl.style.animation = '';
      } else {
        timerEl.textContent = `Your roll — ${remaining}s`;
        timerEl.style.color = 'var(--gold-bright)';
        timerEl.style.fontSize = '1.1rem';
        timerEl.style.background = 'rgba(0,0,0,0.4)';
        timerEl.style.animation = '';
      }
    } else if (B.phase === 'ready' || B.phase === 'rolling') {
      timerEl.textContent = `Waiting for opponent...`;
      timerEl.style.color = 'var(--text2)';
      timerEl.style.fontSize = '1.1rem';
      timerEl.style.background = 'rgba(0,0,0,0.4)';
      timerEl.style.animation = '';
    } else {
      timerEl.textContent = '';
    }
  }

  // Start the visible timer
  pvpTimerInterval = setInterval(updateTurnTimer, 1000);

  function resetPvPAfk() {
    clearTimeout(pvpAfkTimer);
    pvpAfkWarned = false;
    pvpTurnStart = Date.now();
    const warn = document.getElementById('pvp-afk-warning');
    if (warn) warn.style.display = 'none';

    pvpAfkTimer = setTimeout(() => {
      if (!B || B.phase === 'over' || !LIVE_PVP) return;
      const myBtn = document.getElementById(mySide === 'red' ? 'rollRedBtn' : 'rollBlueBtn');
      if (!myBtn || myBtn.disabled || myBtn.classList.contains('locked')) return;
      if (B.phase !== 'ready' && B.phase !== 'rolling') return;

      pvpAfkWarned = true;
      let warn = document.getElementById('pvp-afk-warning');
      if (!warn) {
        warn = document.createElement('div');
        warn.id = 'pvp-afk-warning';
        warn.style.cssText = 'text-align:center;padding:10px;font-weight:800;font-size:1rem;color:var(--accent);display:none;';
        document.querySelector('.battle-arena')?.prepend(warn);
      }
      warn.textContent = 'Roll now or forfeit in 15 seconds!';
      warn.style.display = 'block';

      setTimeout(() => {
        if (!pvpAfkWarned || !B || B.phase === 'over') return;
        const myBtn2 = document.getElementById(mySide === 'red' ? 'rollRedBtn' : 'rollBlueBtn');
        if (myBtn2 && !myBtn2.disabled && !myBtn2.classList.contains('locked') &&
            (B.phase === 'ready' || B.phase === 'rolling')) {
          warn.textContent = 'Time expired — you forfeit!';
          PVP_GAME_REF.child(`connected/${mySide}`).set(false);
          setTimeout(() => {
            if (B && B.phase !== 'over') {
              const winSide = mySide === 'red' ? 'blue' : 'red';
              showGameOver(winSide);
            }
          }, 1000);
        }
      }, 15000); // v722: 15s forfeit window (was 10s)
    }, 30000); // v722: 30s before warning (was 15s)
  }

  // v736: only reset AFK timer on clicks during roll phases, not during ko-swap.
  // During ko-swap the timer was resetting on every click (including swap card clicks),
  // making the countdown jump back to 45s and preventing players from swapping.
  document.addEventListener('click', () => {
    if (B && (B.phase === 'ko-swap' || B.phase === 'ko-pause')) return; // don't reset during swaps
    resetPvPAfk();
  });
  // Start initial timer
  resetPvPAfk();

  // Cleanup
  window.addEventListener('beforeunload', () => {
    if (PVP_GAME_REF) PVP_GAME_REF.child(`connected/${mySide}`).set(false);
    clearTimeout(pvpAfkTimer);
    clearInterval(pvpTimerInterval);
  });

  // --- v722: CHOICE MODAL SPECTATING ---
  // When Red opens a choice modal (Pal Al, Gordok, Selene, etc.), broadcast it
  // so Blue sees what's happening instead of staring at a blank screen.
  if (mySide === 'red') {
    // Watch all selene-overlay elements for .active class
    const overlays = document.querySelectorAll('.selene-overlay');
    overlays.forEach(ol => {
      const obs = new MutationObserver(() => {
        if (ol.classList.contains('active')) {
          // Extract the ability name from the overlay's banner or h3
          const banner = ol.querySelector('.selene-banner');
          const h3 = ol.querySelector('h3');
          const abilityText = banner ? banner.textContent.trim() : (h3 ? h3.textContent.trim() : 'Making a choice...');
          PVP_GAME_REF.child('choiceModal').set({ text: abilityText, ts: Date.now() });
        } else {
          PVP_GAME_REF.child('choiceModal').set(null);
        }
      });
      obs.observe(ol, { attributes: true, attributeFilter: ['class'] });
    });
  } else {
    // Blue: show spectator banner when Red has a choice modal open
    PVP_GAME_REF.child('choiceModal').on('value', snap => {
      const data = snap.val();
      let spectBanner = document.getElementById('pvp-choice-spectate');
      if (!spectBanner) {
        spectBanner = document.createElement('div');
        spectBanner.id = 'pvp-choice-spectate';
        spectBanner.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);z-index:9999;' +
          'background:rgba(0,0,0,0.85);border:2px solid var(--gold-bright);border-radius:14px;padding:20px 32px;' +
          'font-family:Creepster,cursive;font-size:1.3rem;color:var(--gold-bright);text-align:center;letter-spacing:2px;' +
          'display:none;pointer-events:none;animation:pvpTimerPulse 1.5s ease-in-out infinite;';
        document.body.appendChild(spectBanner);
      }
      if (data && data.text) {
        spectBanner.textContent = '⚔️ ' + data.text;
        spectBanner.style.display = 'block';
        if (typeof resetPvPAfk === 'function') resetPvPAfk();
      } else {
        spectBanner.style.display = 'none';
      }
    });
  }
}

// v723: Animate dice on Blue's screen without running resolution.
// Blue sees the full dice show (shake → reveal → triples) but combat
// resolution still comes from Red's roundResult broadcast.
function pvpAnimateDice(side, dice) {
  if (!B) return;
  // Create minimal preRoll structure if needed (don't run doPreRollSetup — that triggers abilities)
  if (!B.preRoll) {
    B.preRoll = {
      red: { count: ghostData(active(B.red).id)?.dice ?? 3, dice: null },
      blue: { count: ghostData(active(B.blue).id)?.dice ?? 3, dice: null }
    };
    B.phase = 'rolling';
    renderBattle();
  }
  // Store dice in engine state
  B.preRoll[side].dice = dice;
  if (side === 'red') B.redDice = dice;
  else B.blueDice = dice;

  const f = active(B[side]);
  const cls = side === 'red' ? 'red-text' : 'blue-text';
  const diceCount = dice.length;

  // Full dice animation: shake → SFX → reveal → triples
  showRolling(side, diceCount);
  if (diceCount > 0) playSfx('sfxDiceRoll');
  narrate(`<b class="${cls}">${f.name}</b> rolls...`);

  setTimeout(() => {
    revealDice(side, dice);
    const roll = classify(dice);
    const tl = typeLabel(roll.type);
    narrate(`<b class="${cls}">${f.name}</b>&nbsp;rolled [${dice.join(', ')}]${tl ? '&nbsp;<b class="gold">'+tl+'</b>' : ''}`);
    if (isTripleOrBetter(roll.type)) showTriplesEffect(side, roll.type);
    // NO resolution here — Blue waits for roundResult from Red
  }, spd(700));
}

// Inject opponent's dice directly into the engine — bypasses rollReady entirely.
// This avoids all pre-roll ability modals (Timber, Romy, Tyler, etc.) firing
// on the wrong client. Those modals only fire when YOU click YOUR roll button.
function pvpInjectOpponentDice(oppSide, dice) {
  if (!B) return;

  // If pre-roll hasn't been set up yet (we haven't clicked our own roll),
  // we need to trigger it first so B.preRoll exists with correct dice counts.
  if (!B.preRoll) {
    doPreRollSetup();
    if (B.phase === 'ready') B.phase = 'rolling';
    renderBattle();
  }

  // Set opponent's dice in engine state
  B.preRoll[oppSide].dice = dice;
  if (oppSide === 'red') B.redDice = dice;
  else B.blueDice = dice;

  // Show rolling animation + reveal for opponent's side
  const f = active(B[oppSide]);
  const cls = oppSide === 'red' ? 'red-text' : 'blue-text';
  const diceCount = dice.length;

  showRolling(oppSide, diceCount);
  if (diceCount > 0) playSfx('sfxDiceRoll');
  narrate(`<b class="${cls}">${f.name}</b> rolls...`);

  setTimeout(() => {
    revealDice(oppSide, dice);
    const roll = classify(dice);
    const tl = typeLabel(roll.type);
    narrate(`<b class="${cls}">${f.name}</b>&nbsp;rolled [${dice.join(', ')}]${tl ? '&nbsp;<b class="gold">'+tl+'</b>' : ''}`);
    if (isTripleOrBetter(roll.type)) showTriplesEffect(oppSide, roll.type);

    // Check if both sides have rolled — resolve
    if (B.preRoll && B.preRoll.red.dice && B.preRoll.blue.dice && !B.preRoll.resolved) {
      B.preRoll.resolved = true;
      // v725: mark Blue as resolving locally so roundResult becomes a silent correction
      if (LIVE_PVP && PVP_SIDE === 'blue') pvpBlueResolvedLocally = true;
      const otherRoll = classify(B.preRoll[PVP_SIDE]?.dice || []);
      const eitherTripled = isTripleOrBetter(roll.type) || isTripleOrBetter(otherRoll.type);
      setTimeout(() => {
        doPostRollAndResolve(B.preRoll.red.dice, B.preRoll.blue.dice);
      }, spd(eitherTripled ? 1800 : 1400));
    }
  }, spd(700));
}

// v725: Inject Blue's own dice (received from Red's broadcast) into the engine.
// Similar to pvpInjectOpponentDice but for Blue's own side.
function pvpInjectOwnDice(side, dice) {
  if (!B) return;
  // Ensure preRoll exists (should already from doPreRollSetup in rollReady)
  if (!B.preRoll) {
    B.preRoll = {
      red: { count: ghostData(active(B.red).id)?.dice ?? 3, dice: null },
      blue: { count: ghostData(active(B.blue).id)?.dice ?? 3, dice: null }
    };
    if (B.phase === 'ready') B.phase = 'rolling';
    renderBattle();
  }

  // Store authoritative dice from Red (overrides any local placeholder)
  B.preRoll[side].dice = dice;
  if (side === 'red') B.redDice = dice;
  else B.blueDice = dice;

  // Reveal Blue's own dice (rolling animation already started in rollReady)
  const f = active(B[side]);
  const cls = side === 'red' ? 'red-text' : 'blue-text';

  setTimeout(() => {
    revealDice(side, dice);
    const roll = classify(dice);
    const tl = typeLabel(roll.type);
    narrate(`<b class="${cls}">${f.name}</b>&nbsp;rolled [${dice.join(', ')}]${tl ? '&nbsp;<b class="gold">'+tl+'</b>' : ''}`);
    if (isTripleOrBetter(roll.type)) showTriplesEffect(side, roll.type);

    // Check if both sides have rolled — resolve
    if (B.preRoll && B.preRoll.red.dice && B.preRoll.blue.dice && !B.preRoll.resolved) {
      B.preRoll.resolved = true;
      pvpBlueResolvedLocally = true;
      const otherRoll = classify(B.preRoll[side === 'red' ? 'blue' : 'red']?.dice || []);
      const eitherTripled = isTripleOrBetter(roll.type) || isTripleOrBetter(otherRoll.type);
      setTimeout(() => {
        doPostRollAndResolve(B.preRoll.red.dice, B.preRoll.blue.dice);
      }, spd(eitherTripled ? 1800 : 1400));
    }
  }, spd(400)); // shorter delay since rolling animation already started
}

// ---- HOOKS: broadcast our actions to Firebase ----

// Hook doTeamRoll — after our side rolls, broadcast dice
const _origDoTeamRollFn = doTeamRoll;
doTeamRoll = function(team, btn) {
  _origDoTeamRollFn(team, btn);

  // v723: Red broadcasts ALL dice (both sides) so Blue can animate them
  if (LIVE_PVP && PVP_SIDE === 'red' && B && B.preRoll && B.preRoll[team]?.dice) {
    PVP_GAME_REF.child('rolls').push({
      side: team,
      round: B.round,
      dice: B.preRoll[team].dice,
      timestamp: firebase.database.ServerValue.TIMESTAMP
    });

    // Show waiting banner if opponent hasn't rolled yet
    const oppSide = PVP_SIDE === 'red' ? 'blue' : 'red';
    if (!B.preRoll[oppSide]?.dice) {
      const banner = document.getElementById('pvp-wait-banner');
      if (banner) banner.style.display = 'block';
    }
  }
};

// Hook doKoSwap — broadcast our swap choice
const _origDoKoSwapFn = doKoSwap;
doKoSwap = function(team, idx) {
  if (LIVE_PVP && team === PVP_SIDE) {
    PVP_GAME_REF.child('koSwap').push({
      side: team, idx: idx,
      timestamp: firebase.database.ServerValue.TIMESTAMP
    });
  }
  _origDoKoSwapFn(team, idx);
  // Broadcast state after KO swap so Blue sees the new active ghost immediately
  pvpBroadcastState({ event: 'koSwap', swapTeam: team, swapIdx: idx });
};

// Hook doSwap — broadcast voluntary swaps
const _origDoSwapFn = doSwap;
doSwap = function(team, idx) {
  if (LIVE_PVP && team === PVP_SIDE) {
    PVP_GAME_REF.child('swap').push({
      side: team, idx: idx,
      timestamp: firebase.database.ServerValue.TIMESTAMP
    });
  }
  _origDoSwapFn(team, idx);
};

// ---- PVP STATE SYNC: Red is authoritative ----
function pvpBroadcastState(extras) {
  if (!LIVE_PVP || PVP_SIDE !== 'red' || !PVP_GAME_REF || !B) return;
  const state = pvpSerializeState();
  PVP_GAME_REF.child('stateSync').set(state);
  // v721: include ability events so Blue can replay callouts
  const abilityEvts = pvpAbilityEvents.length > 0 ? pvpAbilityEvents.slice() : null;
  pvpAbilityEvents = [];
  PVP_GAME_REF.child('roundResult').push({
    state: state,
    redDice: B.redDice || null,
    blueDice: B.blueDice || null,
    abilityEvents: abilityEvts,
    gameOver: null,
    ...extras,
    ts: Date.now()
  });
}

function pvpSerializeState() {
  if (!B) return null;
  return {
    round: B.round,
    phase: B.phase || null,
    koSwapQueue: B.koSwapQueue ? B.koSwapQueue.slice() : null,
    red: {
      activeIdx: B.red.activeIdx,
      ghosts: B.red.ghosts.map(g => ({ id: g.id, hp: g.hp, maxHp: g.maxHp, ko: g.ko, killedBy: g.killedBy || null })),
      resources: { ...B.red.resources },
      committed: B.committed.red ? { ...B.committed.red } : null
    },
    blue: {
      activeIdx: B.blue.activeIdx,
      ghosts: B.blue.ghosts.map(g => ({ id: g.id, hp: g.hp, maxHp: g.maxHp, ko: g.ko, killedBy: g.killedBy || null })),
      resources: { ...B.blue.resources },
      committed: B.committed.blue ? { ...B.committed.blue } : null
    },
    willowLostLast: B.willowLostLast ? { ...B.willowLostLast } : { red: false, blue: false },
    iceBladeForgedPermanent: B.iceBladeForgedPermanent ? { ...B.iceBladeForgedPermanent } : { red: false, blue: false },
    flameBlade: B.flameBlade ? { ...B.flameBlade } : { red: false, blue: false },
    sophiaMask: B.sophiaMask ? { ...B.sophiaMask } : { red: null, blue: null },
    sophiaMaskActive: B.sophiaMaskActive ? { ...B.sophiaMaskActive } : { red: false, blue: false },
    duelLastLoser: B.duelLastLoser || null,
    burn: B.burn ? { red: { ...B.burn.red }, blue: { ...B.burn.blue } } : { red: {}, blue: {} },
    log: B.log.slice(0, 20),
    ts: Date.now()
  };
}

function pvpApplyState(state) {
  if (!B || !state) return;
  B.round = state.round;

  // v728: track whether anything actually changed, to avoid unnecessary re-renders
  let changed = false;

  // Sync ghosts: HP, KO, activeIdx — only update if values actually differ
  ['red', 'blue'].forEach(side => {
    if (!state[side]) return;
    // v736: skip activeIdx update during Blue's local resolution — prevents
    // "old ghost" flash where Red's state correction briefly shows the wrong fighter
    if (B[side].activeIdx !== state[side].activeIdx) {
      if (!(pvpBlueResolvedLocally && (B.phase === 'ko-swap' || B.phase === 'ko-pause'))) {
        B[side].activeIdx = state[side].activeIdx;
        changed = true;
      }
    }
    state[side].ghosts.forEach((sg, i) => {
      const g = B[side].ghosts[i];
      if (!g) return;
      if (g.hp !== sg.hp) { g.hp = sg.hp; changed = true; }
      if (g.maxHp !== sg.maxHp) { g.maxHp = sg.maxHp; changed = true; }
      if (g.ko !== sg.ko) { g.ko = sg.ko; changed = true; }
      if (sg.killedBy) g.killedBy = sg.killedBy;
    });
    // Sync resources — only update keys that differ
    if (state[side].resources) {
      const sr = state[side].resources;
      const br = B[side].resources;
      for (const k in sr) {
        if (br[k] !== sr[k]) { br[k] = sr[k]; changed = true; }
      }
    }
    // v724: sync committed resources so Blue sees Red's specials (and vice versa)
    if (state[side].committed) {
      B.committed[side] = { ...state[side].committed };
    }
  });

  // Sync battle flags
  if (state.willowLostLast) B.willowLostLast = state.willowLostLast;
  if (state.iceBladeForgedPermanent) B.iceBladeForgedPermanent = state.iceBladeForgedPermanent;
  if (state.flameBlade) B.flameBlade = state.flameBlade;
  if (state.sophiaMask) B.sophiaMask = state.sophiaMask;
  if (state.sophiaMaskActive) B.sophiaMaskActive = state.sophiaMaskActive;
  if (state.duelLastLoser !== undefined) B.duelLastLoser = state.duelLastLoser;
  if (state.burn) B.burn = state.burn;
  if (state.log) B.log = state.log;

  return changed; // v728: caller can skip renderBattle() if nothing changed
}

// Also sync game over: if Red declares game over, Blue should see it
if (LIVE_PVP && PVP_GAME_REF) {
  PVP_GAME_REF.child('gameOver').on('value', snap => {
    const data = snap.val();
    if (data && data.winner && B && B.phase !== 'over') {
      // Red declared game over — show it on Blue's client too
      setTimeout(() => {
        if (B && B.phase !== 'over') showGameOver(data.winner);
      }, 500);
    }
  });
}

// ---- PVP: Auto-resolve ability modals ----
// v728: Both sides auto-resolve ONLY the opponent's modals.
// Blue's own interactive abilities (Lucky Stone, Moonstone, KO swap, etc.) now show real pickers.
// Red's roundResult silently corrects any divergence afterward.
if (LIVE_PVP) {
  const oppSide = PVP_SIDE === 'red' ? 'blue' : 'red';
  const mySide = PVP_SIDE;
  // v728: auto-resolve opponent's modals only — never auto-resolve your own team's choices
  const shouldAutoResolve = (modalTeam) => {
    return modalTeam === oppSide;
  };

  // Poll for modals and auto-resolve them
  setInterval(() => {
    if (!B || B.phase === 'over') return;

    // Pal Al — auto-pick damage (aggressive)
    if (B.wiseAlPending && shouldAutoResolve(B.wiseAlPending.winTeamName)) {
      setTimeout(() => { if (B.wiseAlPending) doWiseAlChoice('damage'); }, 300);
    }
    // Gordok — auto-pick damage
    if (B.gordokPending && shouldAutoResolve(B.gordokPending.winTeamName)) {
      setTimeout(() => { if (B.gordokPending) doGordokChoice('damage'); }, 300);
    }
    // Sophia — auto-pick Mask of Night (AI prefers dice mirroring)
    if (B.sophiaPending && shouldAutoResolve(B.sophiaPending.winTeamName)) {
      setTimeout(() => { if (B.sophiaPending) doSophiaChoice('night'); }, 300);
    }
    // Selene — auto-pick heal
    if (B.selenePending && shouldAutoResolve(B.selenePending.tName)) {
      const overlay = document.getElementById('seleneOverlay');
      if (overlay && overlay.classList.contains('active')) {
        setTimeout(() => { if (typeof doSeleneChoice === 'function') doSeleneChoice('heal'); }, 300);
      }
    }
    // Pressure / Raditz Hunt — auto-pick first available when overlay is active
    // v728: only auto-pick if the picker is for the OPPONENT's team
    const pressureOvl = document.getElementById('pressureOverlay');
    if (pressureOvl && pressureOvl.classList.contains('active') && B.pressurePickerTeam && shouldAutoResolve(B.pressurePickerTeam)) {
      const firstOpt = pressureOvl.querySelector('.pressure-opt');
      if (firstOpt) {
        setTimeout(() => { firstOpt.click(); }, 300);
      }
    }
    // Hand Limit — auto-discard first available resource
    // v728: only auto-discard for the opponent's team
    const handLimitOvl = document.getElementById('handLimitOverlay');
    if (handLimitOvl && handLimitOvl.classList.contains('active') && B.handLimitPending && shouldAutoResolve(B.handLimitPending.team)) {
      const hlTeam = B.handLimitPending.team;
      const hlRes = B[hlTeam]?.resources;
      if (hlRes) {
        const hlKey = Object.keys(hlRes).find(k => (hlRes[k] || 0) > 0);
        if (hlKey) setTimeout(() => { if (typeof doHandLimitDiscard === 'function') doHandLimitDiscard(hlTeam, hlKey); }, 300);
      }
    }
    // Sylvia — auto-roll (don't skip)
    const sylviaOverlay = document.getElementById('sylviaOverlay');
    if (sylviaOverlay && sylviaOverlay.classList.contains('active') && B.sylviaResume && B.sylviaTeamName && shouldAutoResolve(B.sylviaTeamName)) {
      setTimeout(() => { if (typeof doSylviaRoll === 'function') doSylviaRoll(); }, 300);
    }
    // Balatron — auto-roll
    const balatronOverlay = document.getElementById('balatronOverlay');
    if (balatronOverlay && balatronOverlay.classList.contains('active') && B.balatronPending && shouldAutoResolve(B.balatronPending.loseTeamName)) {
      setTimeout(() => { if (typeof doBalatronRoll === 'function') doBalatronRoll(); }, 300);
    }
    // DarkWing — auto-yes (reroll)
    if (B.darkWingPending && shouldAutoResolve(B.darkWingPending.team)) {
      const overlay = document.getElementById('darkWingOverlay');
      if (overlay && overlay.classList.contains('active')) {
        setTimeout(() => { if (typeof doDarkWingChoice === 'function') doDarkWingChoice('yes'); }, 300);
      }
    }
    // Jeanie — auto-yes (force reroll)
    if (B.jeaniePending && shouldAutoResolve(B.jeaniePending.team)) {
      const overlay = document.getElementById('jeanieOverlay');
      if (overlay && overlay.classList.contains('active')) {
        setTimeout(() => { if (typeof doJeanieChoice === 'function') doJeanieChoice('yes'); }, 300);
      }
    }
    // Nick Knack — auto-pick first option
    const nickOverlay = document.getElementById('nickKnackOverlay');
    if (nickOverlay && nickOverlay.classList.contains('active') && B.nickKnackPending && shouldAutoResolve(B.nickKnackPending.team)) {
      setTimeout(() => { if (typeof doNickKnackSteal === 'function') doNickKnackSteal(B.nickKnackPending.team, 'moonstone'); }, 300);
    }
    // Burn picker — auto-pick first enemy sideline
    const burnOverlay = document.getElementById('burnOverlay');
    if (burnOverlay && burnOverlay.classList.contains('active') && B.burnPickerPending && shouldAutoResolve(B.burnPickerPending.team)) {
      const autoPickTeam = B.burnPickerPending.team === 'red' ? B.blue : B.red;
      const target = autoPickTeam.ghosts.find((g, i) => i !== autoPickTeam.activeIdx && !g.ko);
      if (target) {
        const idx = autoPickTeam.ghosts.indexOf(target);
        setTimeout(() => { if (typeof doBurnPick === 'function') doBurnPick(idx); }, 300);
      }
    }
    // Firefly picker — auto-pick moonstone
    const fireflyOverlay = document.getElementById('fireflyOverlay');
    if (fireflyOverlay && fireflyOverlay.classList.contains('active') && B.fireflyPending && shouldAutoResolve(B.fireflyPending.team)) {
      setTimeout(() => { if (typeof doFireflyChoice === 'function') doFireflyChoice('moonstone'); }, 300);
    }
    // Tommy — auto-yes / auto-roll chain
    const tommyOverlay = document.getElementById('tommyOverlay');
    if (tommyOverlay && tommyOverlay.classList.contains('active')) {
      if (B.tommyPending && shouldAutoResolve(B.tommyPending.team)) {
        setTimeout(() => { if (typeof doTommyChoice === 'function') doTommyChoice('yes'); }, 300);
      } else if (B.tommyChainPending && shouldAutoResolve(B.tommyChainPending.team)) {
        setTimeout(() => { if (typeof doTommyRoll === 'function') doTommyRoll(); }, 300);
      }
    }
    // Jackson — auto-yes
    const jacksonOverlay = document.getElementById('jacksonOverlay');
    if (jacksonOverlay && jacksonOverlay.classList.contains('active') && B.jacksonPending && shouldAutoResolve(B.jacksonPending.team)) {
      setTimeout(() => { if (typeof doJacksonChoice === 'function') doJacksonChoice('yes'); }, 300);
    }
    // Sonya — auto-yes
    const sonyaOverlay = document.getElementById('sonyaOverlay');
    if (sonyaOverlay && sonyaOverlay.classList.contains('active') && B.sonyaPending && shouldAutoResolve(B.sonyaPending.team)) {
      setTimeout(() => { if (typeof doSonyaChoice === 'function') doSonyaChoice('yes'); }, 300);
    }
    // Toboggan — auto-pick first ghost
    const tobogganOverlay = document.getElementById('tobogganOverlay');
    if (tobogganOverlay && tobogganOverlay.classList.contains('active') && B.tobogganPending && shouldAutoResolve(B.tobogganPending.winTeamName)) {
      const tobTeam = B[B.tobogganPending.winTeamName];
      const tobAlive = tobTeam.ghosts.filter((g,i) => i !== tobTeam.activeIdx && !g.ko);
      const tobIdx = tobAlive.length > 0 ? tobTeam.ghosts.indexOf(tobAlive[0]) : -1;
      setTimeout(() => { if (typeof doTobogganChoice === 'function') doTobogganChoice(tobIdx); }, 300);
    }
    // Fang Outside — auto-skip (don't swap)
    const fangOutsideOverlay = document.getElementById('fangOutsideOverlay');
    if (fangOutsideOverlay && fangOutsideOverlay.classList.contains('active') && B.fangOutsidePending && shouldAutoResolve(B.fangOutsidePending.winTeamName)) {
      setTimeout(() => { if (typeof doFangOutsideChoice === 'function') doFangOutsideChoice(-1); }, 300);
    }
    // Winston Scheme — auto-pick first target
    const winstonOverlay = document.getElementById('winstonSchemeOverlay');
    if (winstonOverlay && winstonOverlay.classList.contains('active') && B.winstonSchemePending && shouldAutoResolve(B.winstonSchemePending.winTeamName)) {
      const wsTeam = B[B.winstonSchemePending.loseTeamName];
      const wsAlive = wsTeam.ghosts.filter((g,i) => i !== wsTeam.activeIdx && !g.ko);
      const wsIdx = wsAlive.length > 0 ? wsTeam.ghosts.indexOf(wsAlive[0]) : -1;
      setTimeout(() => { if (typeof doWinstonSchemeChoice === 'function') doWinstonSchemeChoice(wsIdx); }, 300);
    }
    // Gus Gale Force picker — auto-pick first available
    const gfPickerOverlay = document.getElementById('galeForcePickerOverlay');
    if (gfPickerOverlay && gfPickerOverlay.classList.contains('active') && B.galeForcePicker && shouldAutoResolve(B.galeForcePicker.winTeamName)) {
      const gfLoseTeam = B[B.galeForcePicker.loseTeamName];
      const gfAlive = gfLoseTeam?.ghosts?.filter((g,i) => i !== gfLoseTeam.activeIdx && !g.ko);
      if (gfAlive && gfAlive.length > 0) {
        const gfIdx = gfLoseTeam.ghosts.indexOf(gfAlive[0]);
        setTimeout(() => { if (typeof doGaleForcePickerChoice === 'function') doGaleForcePickerChoice(gfIdx); }, 300);
      }
    }
    // Gus Gale Force — auto-accept (always force swap for rival AI)
    const gusGaleBtnEl = document.getElementById('gusGaleBtn');
    if (gusGaleBtnEl && gusGaleBtnEl.style.display !== 'none' && B.gusGaleReactivePending && shouldAutoResolve(B.gusGaleReactivePending.winTeamName)) {
      setTimeout(() => { if (typeof doGusGaleReactive === 'function') doGusGaleReactive('yes'); }, 300);
    }
    // Guardian Fairy — auto-decline (let damage apply normally)
    const gfReactiveOverlay = document.getElementById('guardianFairyOverlay');
    if (gfReactiveOverlay && gfReactiveOverlay.classList.contains('active') && B.guardianFairyReactivePending && shouldAutoResolve(B.guardianFairyReactivePending.loseTeamName)) {
      setTimeout(() => { if (typeof doGuardianFairyReactive === 'function') doGuardianFairyReactive('no'); }, 300);
    }
    // Jenkins — auto-roll greeting dice
    const jenkinsOverlay = document.getElementById('jenkinsOverlay');
    if (jenkinsOverlay && jenkinsOverlay.classList.contains('active') && B.jenkinsPending && shouldAutoResolve(B.jenkinsPending.team)) {
      setTimeout(() => { if (typeof doJenkinsRoll === 'function') doJenkinsRoll(); }, 300);
    }
    // Jasper — auto-roll flame dive
    const jasperOverlay = document.getElementById('jasperOverlay');
    if (jasperOverlay && jasperOverlay.classList.contains('active') && B.jasperPending && shouldAutoResolve(B.jasperPending.winTeamName)) {
      setTimeout(() => { if (typeof doJasperRoll === 'function') doJasperRoll(); }, 300);
    }
    // Sky Elusive — auto-roll counter die
    const skyElOverlay = document.getElementById('skyElusiveOverlay');
    if (skyElOverlay && skyElOverlay.classList.contains('active') && B.skyElusivePending && shouldAutoResolve(B.skyElusivePending.winTeamName)) {
      setTimeout(() => { if (typeof doSkyElusiveRoll === 'function') doSkyElusiveRoll(); }, 300);
    }
    // Fang Undercover swap — auto-pick first available sideline ghost
    const fuSwapOverlay = document.getElementById('fangUndercoverSwapOverlay');
    if (fuSwapOverlay && fuSwapOverlay.classList.contains('active') && B.fangUndercoverSwapData) {
      const fuLoseTeam = B[B.fangUndercoverSwapData.loseTeamName];
      if (fuLoseTeam && shouldAutoResolve(B.fangUndercoverSwapData.loseTeamName)) {
        const fuAlive = fuLoseTeam.ghosts.filter((g,i) => i !== fuLoseTeam.activeIdx && !g.ko);
        if (fuAlive.length > 0) {
          const fuIdx = fuLoseTeam.ghosts.indexOf(fuAlive[0]);
          setTimeout(() => { if (typeof doFangUndercoverSwapChoice === 'function') doFangUndercoverSwapChoice(fuIdx); }, 300);
        }
      }
    }
  }, 500);
}

// Hook renderBattle — hide opponent's controls after each render
const _origRenderBattle = renderBattle;
renderBattle = function() {
  _origRenderBattle();
  if (!LIVE_PVP) return;
  const oppSide = PVP_SIDE === 'red' ? 'blue' : 'red';

  // Always hide opponent's roll button
  const oppBtnId = oppSide === 'red' ? 'rollRedBtn' : 'rollBlueBtn';
  const oppBtn = document.getElementById(oppBtnId);
  if (oppBtn) oppBtn.style.display = 'none';

  // Block clicking opponent's specials/resources
  const oppResources = document.getElementById(`${oppSide}-resources`);
  if (oppResources) {
    oppResources.style.pointerEvents = 'none';
    oppResources.style.opacity = '0.7';
  }

  // Block ALL opponent-side sideline interactions
  document.querySelectorAll(`#${oppSide}-sl-left, #${oppSide}-sl-right`).forEach(el => {
    el.style.pointerEvents = 'none';
  });

  // During KO swap: only allow clicking YOUR OWN sideline when it's YOUR swap turn
  if (B && B.phase === 'ko-swap' && B.koSwapQueue) {
    const whoSwaps = B.koSwapQueue[0];
    // Block YOUR sideline if it's NOT your turn to swap
    if (whoSwaps !== PVP_SIDE) {
      document.querySelectorAll(`#${PVP_SIDE}-sl-left, #${PVP_SIDE}-sl-right`).forEach(el => {
        el.style.pointerEvents = 'none';
      });
    }
    // Block opponent's sideline always (they pick on their own client)
    document.querySelectorAll(`#${oppSide}-sl-left, #${oppSide}-sl-right`).forEach(el => {
      el.style.pointerEvents = 'none';
    });
  }

  // v730: manage wait banner during KO swaps
  if (B && B.phase === 'ko-swap' && B.koSwapQueue && B.koSwapQueue[0] === oppSide) {
    const banner = document.getElementById('pvp-wait-banner');
    if (banner) {
      banner.textContent = "Waiting for opponent to choose replacement...";
      banner.style.display = 'block';
    }
  } else if (B && LIVE_PVP) {
    // Dismiss banner when it's our turn or not in ko-swap
    const banner = document.getElementById('pvp-wait-banner');
    if (banner && B.phase !== 'rolling') banner.style.display = 'none';
  }
};

// =================================================================
// BATTLE ENGINE EXPORT — Clean interface for raid adapter & other modules
// =================================================================
window.BattleEngine = {
  // Core battle lifecycle
  startBattle,
  renderBattle,
  showGameOver,
  resetRollButtons,
  startNextRound,

  // Dice & classification
  classify,
  rollDice,
  weightedRoll,

  // Team management
  active,

  // AI control
  startBlueAI,
  stopBlueAI,

  // Hook registration
  onGameOver,
  onResetRollButtons,
  onPostResolve,

  // State access
  getState: () => B,
  setState: (state) => { B = state; S.battle = B; },
  getS: () => S
};
