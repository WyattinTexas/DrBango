# 🦘 JUMPR v3 — the manual

Queue the NEXT Claude task; it fires by itself when the current one finishes — on whichever of your Claude accounts can take it.

You're running a long Claude Code task. You already know what's next. Instead of waiting around for the hand-off moment, you queue it: when the watched session finishes and sits quiet, jumpr opens a fresh Terminal window running Claude with the next task injected — then watches *that* session. A queue of N tasks chains N sessions back to back, overnight if you like. Empty queue = jumpr announces completion and disarms itself.

**Why this beats the alternatives:** every task gets a brand-new session — full context window, cold-read of the code as it is now. Hand-off happens through files (plans, notes, git), which don't degrade the way a single ever-growing session or subagent summaries do. And the queue serializes tasks within a project, so two sessions never edit the same code at once.

## Quickstart

```bash
jumpr attach                 # watch the most recently active session (prefix picks: jumpr attach 3f2a)
jumpr add "Fix the main menu — bigger tap targets"
jumpr add ~/redesign-plan.md # a .md path queues "execute this plan file"
jumpr accounts               # the a-j roster: installed / signed in / today's ring
jumpr status                 # see the board
```

Walk away. Each task fires as `/goal <task>` at effort max in a new 🦘-titled window, coloured by the account it runs on. Or drive it from the web dashboard: **http://localhost:8790** — composer, per-task account chips, 📋 plan-first, drag-in images, ⚡ jump-now, big ON/OFF switch. Or from your phone: the pad (see below).

## Accounts: the ring

This Mac can hold up to ten Claude logins, `~/.claude-a` … `~/.claude-j` (any subset installed). Every task fires on ONE letter, picked at fire time:

1. A task stamped `--account c` (or via a dashboard chip) runs on **c** — as long as c is installed, signed in, and not sitting out a wall. A stamped letter that can't run falls through to the ring instead of stalling the chain.
2. An unstamped task runs on the **default account** (`jumpr config default_account e`), or — if that letter can't run — the first usable letter of **failover_order** in `~/jumpr/state/config.json`.
3. "Can't run" means: config dir absent, keychain says signed out (a **read-only** check — jumpr never refreshes or touches a token), transcript-proven login failure (benched ~4h, cleared the moment you `/login`), or a usage wall in the last hour.

Mid-chain, a session that hits its **usage limit** would otherwise sit "working" forever. Jumpr reads the transcript, recognizes the wall, kills the dead window, puts the task back at the head of its lane (noting the letter in `tried_accounts`) and **fires it again on the next usable letter** — announced, no human needed. A login failure ("Login expired · run /login") hops the same way. Only when EVERY letter is absent, signed out, benched or already tried does jumpr pause and say so; `jumpr resume` (or the dashboard switch) clears the wall benches and re-fires. `jumpr config failover false` disables the transcript check.

**This build is Fable-only.** Every spawn pins `--model fable`; there is no model toggle in the CLI, the API, the dashboard or the pad.

## Lanes: projects run in parallel

Every task belongs to a **lane** — its working folder's name. Within a lane, tasks run strictly one at a time in queue order; different lanes run side by side, and a finished link advances only its own lane. Queue three webapp tasks and two blog tasks: the webapp chain and the blog chain run concurrently, each internally serial. (Two lanes = two simultaneous sessions = plan usage burns roughly twice as fast.)

## Plan-first pairs

`jumpr add "redesign the settings screen" --plan-first` (or the 📋 button) queues TWO links: a read-only session that studies the code and writes a plan document, then a build session that executes that document — with a re-verify clause in case the code moved underneath it. For big or risky tasks this beats one long session: the builder starts with a fresh context and a written plan.

## CLI reference

| command | what it does |
|---|---|
| `jumpr add "text" [--cwd DIR] [--plan FILE] [--img IMG] [--account a-j] [--effort E] [--mode goal\|plain] [--first] [--plan-first]` | queue a task (`--first` = front of the line; no `--account` = default + ring) |
| `jumpr accounts` | the a-j roster: installed / signed in / benched, and today's ring |
| `jumpr attach [prefix\|--self]` | arm: pick the session to wait on (adds a lane; repeat for more projects) |
| `jumpr status` / `jumpr sessions [--all]` | the board / visible sessions |
| `jumpr fire` | fire every idle lane's next task NOW (⚠ not from inside a sandboxed Claude shell — the window spawn silently no-ops; let the daemon fire, or `curl -X POST localhost:8790/api/fire`) |
| `jumpr off` / `jumpr resume` | kill switch (detaches, keeps queue) / re-arm after a pause (also clears wall benches) |
| `jumpr grace [SECONDS]` | fallback quiet-time before firing (default 600 — see "doneness" below) |
| `jumpr config KEY VALUE` | any config: `default_account c`, `skip_trust false`, `max_jumps_per_day 15`, `speak false` |
| `jumpr rm <n\|last>` / `jumpr clear` | edit the queue (hand-editing queue files is supported — insert between 0003 and 0004 by naming a file 0003z-…) |
| `jumpr-remote status` / `test` | phone-pad bridge health / end-to-end self-test |

## How doneness is detected

Sessions report themselves via a tiny hook (`~/.claude/command-center-hook.sh`, wired into every lettered profile's settings) into `~/.claude/command-center/sessions/`. A session counts as finished when it is status `ready` AND either (a) its transcript **proves** the turn ended (final assistant text, no tool call in flight) and it has been quiet ~2 minutes, or (b) it has been quiet past the full `grace_sec` fallback (600s) when the transcript can't be read. A session that ENDS mid-task pauses jumpr instead of firing into the unknown.

## The phone pad

**https://drbango.com/jumpr/#k=YOUR-KEY** — a tiny installable web app (Add to Home Screen). Dictate or type notes, pick a project button, hit SEND: the task lands in this Mac's queue within ~60s, and the pad shows the ack (queued as #NNNN), the Mac's armed/queue/jumps status, and "Mac asleep" when it isn't reachable. Offline notes wait and send themselves later.

- The pad can add tasks and — new in v3 — **a task added while jumpr is idle starts itself**: the bridge presses the dashboard's ⚡ starter (`auto_fire`, default on; `false` reverts to queue-and-wait). It still can never pause, re-order or delete anything.
- Pad tasks are unstamped: they fire on the default account + ring.
- The project buttons come from YOUR `~/jumpr/state/remote_config.json` map (unmapped → `default_cwd`); the folder path the phone sends is never trusted.
- Everything crossing the relay is end-to-end encrypted with your key. The link contains the key — share it with nobody.

## Safety rails (all on by default)

- **Claim-before-spawn:** a task moves queue→done *before* its window opens; a failed launch rolls it back and pauses loudly. A crash can drop one task, never double-launch one.
- **`max_jumps_per_day` 10** — runaway backstop. **`jumpr off`** — kill switch. Empty queue — self-disarm.
- **caffeinate held while armed** so the Mac resists sleeping through a chain (a closed laptop lid still sleeps — keep it open and on power overnight).
- ⚠ **Spawned sessions pass `--dangerously-skip-permissions`** (config `skip_trust`) — required for unattended runs; understand it before queueing anything sensitive.
- The keychain pre-flight is **read-only** and fails open: a locked keychain can't stop the chain (the transcript net still catches a truly dead account).

## Gotchas from the field

- **Folder-trust dialog:** a spawned session can park at Claude's trust prompt (especially in `$HOME`, and CLI updates re-ask). Jumpr reads the dialog and answers it — including the newer variant whose default is "❯ No, exit", where it presses Down first so Enter lands on "Yes, I trust this folder". First-ever spawn also triggers macOS Automation/Accessibility permission prompts: click Allow.
- **Windows get retitled:** Claude Code rewrites Terminal titles at boot; jumpr tracks windows by the `--session-id` UUID in the window name, not the title.
- **The Mac must be awake** for the 30s ticks; an unarmed Mac follows your normal sleep settings.
- Tasks longer than ~3,600 chars auto-spill to a plan file at fire time (`/goal` rejects >4,000-char conditions) — nothing is lost.
- A letter you sign out of is simply skipped — jumpr never nags about it. Sign back in (`claude-⟨x⟩` then `/login`) and it rejoins the ring on the next pick.

## Files

`~/jumpr/queue/` pending · `~/jumpr/done/` fired (audit trail with timestamps + session ids) · `~/jumpr/plans/` plan docs · `~/jumpr/state/` config/attach/remote key + `limit_bench.json`/`auth_dead.json` (the wall benches) · `~/jumpr/logs/` jumpr.log + remote.log · UI at `~/jumpr/ui/index.html`, served fresh per request.
