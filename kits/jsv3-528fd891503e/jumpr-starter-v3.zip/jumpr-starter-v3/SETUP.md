# JUMPR v3 — SETUP (multi-account "Skylar edition")

**To the human:** open Claude Code on your Mac, drag this whole `jumpr-starter-v3` folder into the chat, and say: **"Read SETUP.md and set jumpr up."** Claude does the rest. Read the SAFETY section at the bottom first — it's short and it matters.

**To Claude Code:** you are installing JUMPR on this machine. Follow these steps in order, verify each one, and report what you did. Do not skip the verify drill. Step 6 (phone pad) is part of the standard install unless the human says to skip it. **Step 7 is NOT part of the standard install — skip it entirely unless the human explicitly asks for remote dashboard access.** It requires installing a third-party VPN app; never install that (or suggest installing it) on your own initiative.

## What JUMPR is (30 seconds)

A task-queue daemon for Claude Code on macOS. You attach it to a working Claude session and queue the NEXT tasks; when the watched session finishes and goes quiet, jumpr opens a new Terminal window running Claude with the next task injected — then watches THAT session, so a queue of N tasks runs as N back-to-back sessions with zero human hand-offs. Tasks are grouped into **lanes** by project folder: serial within a project, parallel across projects. One-shot by design: empty queue = jumpr disarms.

**v3 is multi-account.** This Mac has lettered Claude profiles (`~/.claude-a` … `~/.claude-j`, any subset — each its own Claude login). Jumpr picks the letter at fire time: the default account, or the failover ring — skipping letters that aren't installed or aren't signed in (a read-only keychain check; it never refreshes a token). If a session hits its usage limit mid-chain, jumpr kills the dead window, re-queues the task and **hops to the next signed-in letter**; only when every letter is walled does it pause and wait for a human resume. **This build is Fable-only: every spawn pins `--model fable` and there is no Opus control anywhere.** Do not add one.

## Coexists with what's already on this Mac

This kit assumes the account kit ("SkylarKit") is already installed:

- The global briefing at `~/.claude/CLAUDE.md` belongs to that kit — **never overwrite it.**
- The lettered config dirs `~/.claude-⟨x⟩` and the `claude-⟨x⟩` launchers belong to it too. Jumpr only reads which dirs exist; it spawns sessions by exporting `CLAUDE_CONFIG_DIR` itself.
- Each letter's `settings.json` pins `{"model": "fable", "switchModelsOnFlag": false}` — **preserve those keys** when you merge hooks in (step 2).
- The board viewer already holds **port 8791**. Jumpr's dashboard takes **port 8790**, localhost-only. Don't touch 8791.

## 0. Preflight (check, don't assume)

1. macOS with **Terminal.app** (jumpr spawns and styles Terminal windows via AppleScript).
2. `python3` available (`command -v python3`).
3. Claude Code CLI installed (`command -v claude`, or `~/.claude/local/claude`).
4. List the lettered profiles: `ls -d ~/.claude-? 2>/dev/null` — note which letters exist. At least one must be signed in.
5. This folder's files present: `bin/jumpr`, `bin/jumpr-remote`, `bin/enter-nudge`, `ui/index.html`, `hooks/command-center-hook.sh`.

## 1. Install the files

```bash
mkdir -p ~/jumpr/queue ~/jumpr/done ~/jumpr/state ~/jumpr/logs ~/jumpr/attachments ~/jumpr/plans
cp -R <this-folder>/bin <this-folder>/ui ~/jumpr/
chmod +x ~/jumpr/bin/jumpr ~/jumpr/bin/jumpr-remote ~/jumpr/bin/enter-nudge
mkdir -p ~/.local/bin
ln -sf ~/jumpr/bin/jumpr ~/.local/bin/jumpr
ln -sf ~/jumpr/bin/jumpr-remote ~/.local/bin/jumpr-remote
ln -sf ~/jumpr/bin/enter-nudge ~/.local/bin/enter-nudge
```

If `~/.local/bin` isn't on the user's PATH, add it to their shell profile (ask first) or use the full path throughout.

## 2. Install the session-feed hook (jumpr's eyes) — into EVERY letter

Jumpr knows when a session is finished by reading `~/.claude/command-center/sessions/*.json`, written by a small hook on every prompt/tool/stop event. **Without this hook jumpr is blind.** The hook script installs ONCE (it writes to a shared absolute path), but the hook *entries* must be merged into **each lettered profile's settings**, or sessions on those letters are invisible.

1. `cp <this-folder>/hooks/command-center-hook.sh ~/.claude/command-center-hook.sh && chmod +x ~/.claude/command-center-hook.sh`
2. For **every** existing config dir — `~/.claude/settings.json` AND each `~/.claude-⟨x⟩/settings.json` found in preflight — **merge** (never overwrite) this entry into EACH of the five events `SessionStart`, `UserPromptSubmit`, `Stop`, `PostToolUse`, `SessionEnd`:

```json
{ "type": "command", "command": "bash ~/.claude/command-center-hook.sh", "timeout": 10, "async": true }
```

Use a Python/jq merge on the parsed JSON — no hand-edited string splices. Back up each settings.json first. **Preserve every existing key** (especially the `"model": "fable"` and `"switchModelsOnFlag": false` pins). If an entry for command-center-hook.sh already exists for an event, skip that event. If a new letter is added to this Mac later, repeat this step for it.

3. ⚠ Hooks load at session START — the session you're in right now won't feed the tracker. After install, the human starts ONE fresh Claude session (any letter, any folder) and you confirm a file appears in `~/.claude/command-center/sessions/`.

## 3. Install the daemon

```bash
~/jumpr/bin/jumpr install
```

That loads two launchd agents: `com.jumpr.daemon` (tick every 30s) and `com.jumpr.ui` (web dashboard at http://localhost:8790, localhost-only). Verify: `launchctl list | grep com.jumpr` shows both, and `curl -s localhost:8790 | head -1` returns HTML.

⚠ If you ever edit `~/jumpr/bin/jumpr` later: the UI server imports it once at boot — run `launchctl kickstart -k gui/$(id -u)/com.jumpr.ui` after any edit.

## 4. Accounts: default + ring

1. `jumpr accounts` — the roster. Every letter from preflight should show **signed in** (letters that aren't installed show "not installed"; that's fine). A letter showing SIGNED OUT can't take tasks until the human runs `/login` under it.
2. Ask the human which letter is the **main** one, then: `jumpr config default_account <letter>`.
3. The ring defaults to `a → j` (skipping anything absent or signed out at fire time), so it works untouched. To pin a custom hop order, edit `failover_order` in `~/jumpr/state/config.json`, e.g. `"failover_order": ["c", "e", "a"]`.
4. Re-run `jumpr accounts` and confirm the "ring today" line lists the letters you expect.

## 5. The verify drill (required)

1. `JUMPR_DRYRUN=1 jumpr add "dry run test" && JUMPR_DRYRUN=1 jumpr tick` — expect no errors; then remove the dry task file from `~/jumpr/queue/` (⚠ a DRYRUN tick can still claim a queued task — that's why this drill uses a throwaway).
2. Real mini-jump, with the human watching: in the FRESH session from step 2.3, do nothing (leave it idle). Then:
   ```bash
   jumpr attach            # attaches to that idle session
   jumpr grace 60          # short grace for the test only
   jumpr add "Say hello, state your working directory and which Claude account you are, then stop."
   ```
   Within ~2 minutes a new 🦘-titled Terminal window opens on the **default letter** and runs the task. **First spawn triggers macOS permission prompts** ("Terminal wants to control Terminal" / System Events accessibility for the Enter-nudge) — the human must click Allow. A spawned session parked at Claude's folder-trust dialog is auto-answered (jumpr reads the dialog and picks "Yes, I trust this folder").
3. Multi-account proof: `jumpr add "Say hello and which account you are, then stop." --account <a different signed-in letter>` → the window that opens is that letter's colour and reports that account.
4. Afterwards: `jumpr grace 600` (restore the default). Grace 600 is NOT slow: when a finished session's transcript proves the turn ended, jumpr fires after ~2 minutes of quiet (`ready_fast_sec`); the full 600s only applies when the transcript can't be read. Then `jumpr off` if they're done playing.

## 6. Remote: the phone pad (queue tasks from anywhere)

The pad is a small web app at **https://drbango.com/jumpr/** — notes pad, project buttons, a big SEND TO JUMPR button, live Mac status. Notes typed (or dictated) on the phone land in this Mac's queue within ~60 seconds — and **if jumpr is idle, the task starts itself** (the bridge presses the dashboard's ⚡ starter; `jumpr-remote` config `auto_fire false` reverts to queue-and-wait). Remote tasks fire on the default account + ring like any unstamped task.

How it travels: phone → an encrypted relay channel → `jumpr-remote` poller on this Mac. The relay is a Firebase database operated by the kit's author. **Everything on the relay is end-to-end encrypted** (HMAC-SHA256 stream cipher + MAC) with a key that exists only on this Mac and the linked phone; the channel id itself is derived from the key. The relay operator sees only ciphertext.

1. Generate a key and write the config:
   ```bash
   python3 -c "import secrets; print(secrets.token_hex(16))"
   ```
   Write `~/jumpr/state/remote_config.json` (then `chmod 600` it):
   ```json
   {
     "key": "<the 32-char hex key>",
     "projects": { "home": "~" },
     "default_cwd": "~"
   }
   ```
   **Ask the human which project folders they work in** and map them — the pad's buttons are generated from this map's KEY NAMES (up to 6), so pick short names the human will recognize on a phone button (e.g. `"game": "~/game-proto"`, `"home": "~"`). The pad learns the names from this Mac's first encrypted status heartbeat (within ~a minute of `jumpr-remote install`); until then it shows placeholder labels. Tasks from unmapped buttons land in `default_cwd`. The folder path the phone sends is never trusted.
2. `jumpr-remote install` — loads `com.jumpr.remote` (polls every 60s).
3. `jumpr-remote test` — a phone-free end-to-end proof: it encrypts a task onto the relay exactly like the phone does, runs a tick, checks the ack, and cleans up. Expect `PASS ✅`. If the network blocks it, check `~/jumpr/logs/remote.log`.
4. Hand the human their pad link: `https://drbango.com/jumpr/#k=<the key>` — **this link IS the key; it must only be opened on the owner's own phone** (AirDrop / iMessage to self). On the phone: open it once, then Share → **Add to Home Screen** for the 🦘 app icon. (The page is shared by multiple jumpr owners — if a phone is already linked to a different jumpr, opening the link asks before switching; each key sees only its own Mac.) To revoke a phone later: new key in remote_config.json, new link.

## 7. Remote: the full dashboard (SKIP BY DEFAULT — only on explicit request)

**Do not do this step unless the human specifically asks to open the dashboard from their phone.** Most people never need it: the phone pad (step 6) already queues tasks remotely, and on the Mac itself the dashboard is just http://localhost:8790 — no extra software. This step exists only for viewing the full dashboard from another device, and it means installing a VPN app (Tailscale).

The dashboard at :8790 has no login, and its buttons launch full-permission Claude sessions — **reaching that port is equivalent to running code on this Mac. NEVER expose it with ngrok, cloudflare quick tunnels, or router port-forwarding.**

The safe way is Tailscale (a private WireGuard network between the human's own devices; free plan is fine):

1. Human installs the Tailscale app on this Mac and on their phone, signs into BOTH with the same account (install needs an interactive admin password — have the human run it, e.g. `brew install --cask tailscale-app` or the App Store).
2. Then run: `tailscale serve --bg 8790` (if `tailscale` isn't on PATH, the CLI lives at `/Applications/Tailscale.app/Contents/MacOS/Tailscale`). It prints a private `https://<mac-name>.<tailnet>.ts.net` URL that only their devices can reach — and it persists across reboots.
3. Verify with `curl` on that URL, then send it to the human. On the phone (with Tailscale connected) it serves the full dashboard: queue, ⚡ jump now, ON/OFF, images, everything.

## 8. Teach the human (put this in your final report)

- `jumpr attach` (watch current/most-recent session) → `jumpr add "task"` → walk away. `jumpr add ~/plan.md` queues "execute this plan file." `jumpr add "big thing" --plan-first` queues a PAIR: a read-only planning session, then a build session that executes the plan doc.
- Accounts: plain `jumpr add` = the default letter (or the ring if it's walled/signed out); `--account c` (or the dashboard chip) pins a task to a letter. `jumpr accounts` shows the roster and today's ring.
- If a session hits a usage limit mid-chain, jumpr announces the hop and continues on the next letter by itself. Only "every signed-in account is at its limit" needs a human: `jumpr resume` (or the dashboard switch) once a limit resets.
- Different project folders run in PARALLEL lanes; tasks inside one folder run strictly in order.
- `jumpr status` · `jumpr off` (kill switch) · web dashboard at localhost:8790 · phone pad link.
- Mac must be awake for ticks; jumpr holds a caffeinate while armed (but a closed lid still sleeps most Macs — plug in + keep the lid open for overnight chains, or set the Mac to never sleep on power).
- Read `JUMPR.md` in this folder — it's the manual.

## SAFETY (human: read this)

- **Spawned sessions run with `--dangerously-skip-permissions`** — that's what makes unattended chains possible (no permission prompt can stall a 3am task), and it means queued tasks run with full tool access. Only queue tasks you'd be comfortable running yourself. Turn it off with `jumpr config skip_trust false` (spawns will then stall on prompts until you click).
- **The phone pad can ADD tasks — and an added task can START by itself when jumpr is idle** (the auto-fire starter; `jumpr-remote` config `auto_fire false` reverts to queue-and-wait). 10 remote adds/day cap, 32k chars max, only into folders you mapped yourself. Anyone with the pad link can queue AND start tasks on your Mac — treat the link like a password; rotate the key to revoke.
- **A usage-limit wall hops accounts automatically.** That's the feature — and it means a long queue can burn several accounts' Claude capacity, one after another. The ring only ever includes letters that are installed and signed in; trim `failover_order` to cap it.
- `max_jumps_per_day` defaults to **10** spawned sessions per day — a runaway backstop. `jumpr config max_jumps_per_day N` to change.
- `jumpr off` is the kill switch; an empty queue self-disarms; a watched session that dies mid-task pauses jumpr instead of firing blind.
- Each spawned session consumes Claude plan capacity like any session you'd open yourself. A queue of 6 big tasks is 6 real sessions.
- **Never** expose port 8790 to the internet (see step 7).

## Uninstall

```bash
launchctl unload ~/Library/LaunchAgents/com.jumpr.{daemon,ui,remote}.plist 2>/dev/null
rm -f ~/Library/LaunchAgents/com.jumpr.{daemon,ui,remote}.plist
rm -rf ~/jumpr ~/.local/bin/jumpr ~/.local/bin/jumpr-remote ~/.local/bin/enter-nudge
# optionally remove the hook entries from each config dir's settings.json and ~/.claude/command-center-hook.sh
```
