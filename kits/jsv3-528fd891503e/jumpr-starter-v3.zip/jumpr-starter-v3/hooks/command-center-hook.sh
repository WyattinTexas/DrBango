#!/bin/bash
# Command Center Hook v2 — enhanced session tracking
set -e

STATUS_DIR="$HOME/.claude/command-center/sessions"
mkdir -p "$STATUS_DIR"

export CC_TMPINPUT=$(mktemp)
cat > "$CC_TMPINPUT"

/usr/bin/python3 << 'PYEOF'
import json, os, sys, time
from datetime import datetime

status_dir = os.path.expanduser("~/.claude/command-center/sessions")

with open(os.environ["CC_TMPINPUT"], "r") as f:
    data = json.load(f)

session_id = data.get("session_id", "unknown")
event = data.get("hook_event_name", "")
cwd = data.get("cwd", "")
timestamp = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
local_time = datetime.now().strftime("%I:%M:%S %p")
project = os.path.basename(cwd) if cwd else "unknown"
epoch = int(time.time())

status_file = os.path.join(status_dir, f"{session_id}.json")

def load_status():
    try:
        with open(status_file, "r") as f:
            return json.load(f)
    except:
        return None

def save_status(s):
    with open(status_file, "w") as f:
        json.dump(s, f, indent=2)

if event == "SessionStart":
    model = data.get("model", "unknown")
    status = {
        "session_id": session_id,
        "status": "active",
        "project": project,
        "cwd": cwd,
        "model": model,
        "started_at": timestamp,
        "started_epoch": epoch,
        "updated_at": timestamp,
        "updated_epoch": epoch,
        "last_prompt": "",
        "turns": 0,
        "tool_calls": 0,
        "last_tools": [],
        "activity": [{"time": local_time, "epoch": epoch, "type": "start", "text": f"Session started in {project}"}]
    }
    save_status(status)

elif event == "UserPromptSubmit":
    prompt = data.get("prompt", "")
    display_prompt = (prompt[:300] + "...") if len(prompt) > 300 else prompt
    s = load_status()
    if s:
        s["last_prompt"] = display_prompt
        s["updated_at"] = timestamp
        s["updated_epoch"] = epoch
        s["status"] = "working"
        s["turns"] = s.get("turns", 0) + 1
        s["working_since"] = epoch
        activity = s.get("activity", [])
        short = (prompt[:80] + "...") if len(prompt) > 80 else prompt
        activity.append({"time": local_time, "epoch": epoch, "type": "prompt", "text": short})
        s["activity"] = activity[-30:]
        save_status(s)

elif event == "Stop":
    s = load_status()
    if s:
        s["updated_at"] = timestamp
        s["updated_epoch"] = epoch
        s["status"] = "ready"  # Claude finished — needs YOUR attention
        s["ready_since"] = epoch
        # Calculate how long this turn took
        working_since = s.get("working_since", epoch)
        turn_duration = epoch - working_since
        activity = s.get("activity", [])
        if turn_duration > 0:
            mins = turn_duration // 60
            secs = turn_duration % 60
            dur_str = f"{mins}m {secs}s" if mins > 0 else f"{secs}s"
            activity.append({"time": local_time, "epoch": epoch, "type": "done", "text": f"Turn complete ({dur_str})"})
        else:
            activity.append({"time": local_time, "epoch": epoch, "type": "done", "text": "Turn complete"})
        s["activity"] = activity[-30:]
        save_status(s)

elif event == "PostToolUse":
    tool_name = data.get("tool_name", "")
    s = load_status()
    if s:
        s["updated_at"] = timestamp
        s["updated_epoch"] = epoch
        s["tool_calls"] = s.get("tool_calls", 0) + 1
        last_tools = s.get("last_tools", [])
        last_tools.append(tool_name)
        s["last_tools"] = last_tools[-5:]  # Keep last 5 tools
        # Don't add to activity feed — too noisy. Just update the tool list.
        save_status(s)

elif event == "SessionEnd":
    s = load_status()
    if s:
        s["status"] = "offline"
        s["ended_at"] = timestamp
        s["ended_epoch"] = epoch
        s["updated_at"] = timestamp
        s["updated_epoch"] = epoch
        # Calculate total session duration
        started = s.get("started_epoch", epoch)
        duration = epoch - started
        activity = s.get("activity", [])
        mins = duration // 60
        activity.append({"time": local_time, "epoch": epoch, "type": "end", "text": f"Session ended ({mins}m total, {s.get('turns',0)} turns)"})
        s["activity"] = activity[-30:]
        save_status(s)
PYEOF

rm -f "$CC_TMPINPUT"
echo '{"continue": true, "suppressOutput": true}'
